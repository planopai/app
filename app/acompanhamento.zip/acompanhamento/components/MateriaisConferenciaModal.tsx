"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import Modal from "./Modal";

export type MatCheckItem = {
    key: string; // usado internamente (não exibimos)
    nome: string;
    qtd: number;
};

type PerItemState = {
    ok: boolean;
    naoConforme: boolean;
};

export type MateriaisConferenciaResult = {
    itens: Array<{
        key: string;
        nome: string;
        qtd: number;
        ok: boolean;
        naoConforme: boolean;
    }>;
    observacao: string;
};

type Props = {
    open: boolean;
    itens: MatCheckItem[];
    onClose: () => void;
    onConfirm: (result?: MateriaisConferenciaResult) => void | Promise<void>;
};

export default function MateriaisConferenciaModal({ open, itens, onClose, onConfirm }: Props) {
    const [states, setStates] = useState<Record<string, PerItemState>>({});
    const [observacao, setObservacao] = useState("");
    const [erro, setErro] = useState<string | null>(null);
    const [submitting, setSubmitting] = useState(false);

    const obsRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        if (!open) return;

        const initial: Record<string, PerItemState> = {};
        for (const it of itens || []) initial[String(it.key)] = { ok: false, naoConforme: false };

        setStates(initial);
        setObservacao("");
        setErro(null);
        setSubmitting(false);
    }, [open, itens]);

    const totals = useMemo(() => {
        const keys = (itens || []).map((i) => String(i.key));
        let ok = 0;
        let nc = 0;
        for (const k of keys) {
            const st = states[k];
            if (!st) continue;
            if (st.ok) ok++;
            if (st.naoConforme) nc++;
        }
        return { total: keys.length, ok, nc };
    }, [itens, states]);

    // ✅ NOVA REGRA:
    // - Se NÃO tiver itens, libera o confirmar (allResolved = true)
    // - Se tiver itens, exige marcar OK ou Não Conforme em todos
    const allResolved = useMemo(() => {
        if (!itens || itens.length === 0) return true;
        return itens.every((it) => {
            const st = states[String(it.key)];
            return !!st && (st.ok || st.naoConforme);
        });
    }, [itens, states]);

    const anyNaoConforme = useMemo(() => {
        if (!itens || itens.length === 0) return false;
        return itens.some((it) => states[String(it.key)]?.naoConforme);
    }, [itens, states]);

    const toggleOk = (key: string) => {
        setErro(null);
        setStates((prev) => {
            const cur = prev[key] ?? { ok: false, naoConforme: false };
            const nextOk = !cur.ok;
            return { ...prev, [key]: { ok: nextOk, naoConforme: nextOk ? false : cur.naoConforme } };
        });
    };

    const toggleNaoConforme = (key: string) => {
        setErro(null);
        setStates((prev) => {
            const cur = prev[key] ?? { ok: false, naoConforme: false };
            const nextNc = !cur.naoConforme;
            return { ...prev, [key]: { ok: nextNc ? false : cur.ok, naoConforme: nextNc } };
        });

        setTimeout(() => obsRef.current?.focus(), 50);
    };

    const handleConfirm = async () => {
        if (submitting) return;
        setErro(null);

        // ✅ NOVA REGRA: Se não há itens, permite confirmar e retorna lista vazia + observação
        if (!itens || itens.length === 0) {
            const result: MateriaisConferenciaResult = { itens: [], observacao: observacao.trim() };
            try {
                setSubmitting(true);
                await onConfirm(result);
            } finally {
                setSubmitting(false);
            }
            return;
        }

        // Se tiver itens, mantém validação normal
        if (!allResolved) {
            setErro("Marque OK ou Não Conforme para todos os itens.");
            return;
        }

        const result: MateriaisConferenciaResult = {
            itens: (itens || []).map((it) => {
                const k = String(it.key);
                const st = states[k] ?? { ok: false, naoConforme: false };
                return { key: k, nome: it.nome, qtd: Number(it.qtd ?? 0), ok: !!st.ok, naoConforme: !!st.naoConforme };
            }),
            observacao: observacao.trim(),
        };

        try {
            setSubmitting(true);
            await onConfirm(result);
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Modal open={open} onClose={onClose} ariaLabel="Conferência de Materiais" maxWidth={680}>
            <div className="flex items-start justify-between gap-3">
                <div>
                    <h3 className="text-lg font-semibold">Conferência de Materiais</h3>
                    <p className="mt-1 text-sm text-[#5B6478] dark:text-[#AEB9CF]">
                        Para confirmar <span className="font-medium">Material Recolhido</span>, marque{" "}
                        <span className="font-medium">OK</span> ou <span className="font-medium">Não Conforme</span> em cada item.
                        {(!itens || itens.length === 0) ? (
                            <span className="block mt-1 text-xs">
                                Nenhum material foi selecionado — você pode confirmar mesmo assim.
                            </span>
                        ) : null}
                    </p>
                </div>

                <div className="shrink-0 text-right">
                    <div className="rounded-md bg-[#EEF2F7] dark:bg-white/10 px-2 py-1 text-xs text-[#5B6478] dark:text-[#AEB9CF] whitespace-nowrap">
                        {totals.ok}/{totals.total} OK
                    </div>
                    {totals.nc > 0 && (
                        <div className="mt-1 rounded-md bg-[#FCF3CC] dark:bg-[#F2CB3F]/15 px-2 py-1 text-xs text-[#313C55] dark:text-white border border-[#F2CB3F] whitespace-nowrap">
                            {totals.nc} Não Conforme
                        </div>
                    )}
                </div>
            </div>

            <div className="mt-4 max-h-[45vh] overflow-auto rounded-lg border border-[#E3E8F0] dark:border-white/[0.12]">
                {(!itens || itens.length === 0) && (
                    <div className="p-4 text-sm text-[#5B6478] dark:text-[#AEB9CF]">
                        Nenhum material selecionado para conferência.
                    </div>
                )}

                {(itens || []).map((it) => {
                    const k = String(it.key);
                    const st = states[k] ?? { ok: false, naoConforme: false };

                    const pill = st.ok ? (
                        <span className="inline-flex rounded-full bg-[#EEF5D6] dark:bg-[#B3CE52]/20 px-2 py-0.5 text-xs font-medium text-[#313C55] dark:text-white">
                            OK
                        </span>
                    ) : st.naoConforme ? (
                        <span className="inline-flex rounded-full bg-[#FCF3CC] dark:bg-[#F2CB3F]/15 px-2 py-0.5 text-xs font-medium text-[#313C55] dark:text-white">
                            Não Conforme
                        </span>
                    ) : (
                        <span className="inline-flex rounded-full bg-[#EEF2F7] dark:bg-white/10 px-2 py-0.5 text-xs font-medium text-[#5B6478] dark:text-[#AEB9CF]">
                            Pendente
                        </span>
                    );

                    return (
                        <div key={k} className="border-b p-3 last:border-b-0">
                            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
                                <div className="min-w-0">
                                    <div className="flex flex-wrap items-center gap-2">
                                        <div className="text-base font-semibold leading-snug whitespace-normal break-words">
                                            {it.nome}
                                        </div>
                                        {pill}
                                    </div>

                                    <div className="mt-0.5 text-sm text-[#5B6478] dark:text-[#AEB9CF]">
                                        Qtd: <span className="font-medium text-[#313C55] dark:text-white">{Number(it.qtd ?? 0)}</span>
                                    </div>
                                </div>

                                <div className="flex items-center gap-2 justify-end whitespace-nowrap">
                                    <button
                                        type="button"
                                        onClick={() => toggleOk(k)}
                                        className={[
                                            "rounded-md border px-3 py-2 text-sm font-medium transition border-[#E3E8F0] dark:border-white/[0.12]",
                                            st.ok ? "bg-[#7BA11A] text-white border-[#5C7A12]" : "hover:bg-[#EEF2F7] dark:hover:bg-white/10",
                                        ].join(" ")}
                                        aria-pressed={st.ok}
                                    >
                                        OK
                                    </button>

                                    <button
                                        type="button"
                                        onClick={() => toggleNaoConforme(k)}
                                        className={[
                                            "rounded-md border px-3 py-2 text-sm font-medium transition border-[#E3E8F0] dark:border-white/[0.12]",
                                            st.naoConforme ? "bg-[#F2CB3F] text-[#313C55] border-[#E4BC30]" : "hover:bg-[#EEF2F7] dark:hover:bg-white/10",
                                        ].join(" ")}
                                        aria-pressed={st.naoConforme}
                                    >
                                        Não Conforme
                                    </button>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>

            <div className="mt-4 rounded-lg border p-3 border-[#E3E8F0] dark:border-white/[0.12]">
                <label className="block text-sm font-medium" htmlFor="mat-conf-obs">
                    Observação{" "}
                    {anyNaoConforme ? <span className="text-xs text-[#5B6478] dark:text-[#AEB9CF]">(há itens não conformes)</span> : null}
                </label>

                <textarea
                    id="mat-conf-obs"
                    ref={obsRef}
                    className="mt-2 w-full min-h-[92px] resize-y rounded-md border bg-[#F1F4F8] dark:bg-[#1C2334] px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary border-[#E3E8F0] dark:border-white/[0.12]"
                    placeholder="Descreva observações gerais (ex.: item faltando, quantidade divergente, avaria...)"
                    value={observacao}
                    onChange={(e) => setObservacao(e.target.value)}
                    maxLength={700}
                />

                <div className="mt-1 flex items-center justify-between text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                    <span className={erro ? "text-[#B42318] dark:text-[#FF9C92]" : ""}>{erro ? erro : " "}</span>
                    <span>{observacao.trim().length}/700</span>
                </div>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2">
                <button
                    type="button"
                    className="rounded-md border px-3 py-2 text-sm hover:bg-[#EEF2F7] dark:hover:bg-white/10 disabled:opacity-60 border-[#E3E8F0] dark:border-white/[0.12]"
                    onClick={onClose}
                    disabled={submitting}
                >
                    Cancelar
                </button>

                <button
                    type="button"
                    className="rounded-md bg-[#313C55] dark:bg-[#F2CB3F] px-3 py-2 text-sm font-medium text-white dark:text-[#313C55] hover:bg-[#232B40] dark:hover:bg-[#E4BC30] disabled:opacity-60"
                    onClick={handleConfirm}
                    disabled={!allResolved || submitting}
                    aria-busy={submitting}
                    title={!allResolved ? "Marque OK ou Não Conforme para todos os itens" : "Confirmar conferência"}
                >
                    {submitting ? "Salvando..." : "Confirmar"}
                </button>
            </div>
        </Modal>
    );
}
