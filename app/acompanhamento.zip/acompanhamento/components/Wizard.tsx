// UI ITENS V9 - KIT LANCHE SIM/NAO COM BAIXA FIXA NO BACKEND
"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import Modal from "./Modal";
import CoroasAtendimentoEditor from "./CoroasAtendimentoEditor";
import { Registro, CoroaAtendimentoItem } from "./types";
import { proximaEtapaDoRegistro } from "./proximaEtapa";
import { RascunhoOSContext, montarRascunhoOS, OS_CAMPOS_VAZIO, type OsCampos } from "./OsAtendimento";
import { NOME_TERMO, situacaoTermo, termosDoAtendimento } from "./termos";
import { LOCAL_MEMORIAL, locaisCerimonia, localCerimoniaEfetivo } from "./constants";
import { getLatestOfflineSignature } from "@/lib/offline/signatures";

const ENDPOINT = "https://api.planoassistencialintegrado.com.br";

type Step = {
    label: string;
    id: string;
    type:
    | "input"
    | "select"
    | "textarea"
    | "date"
    | "time"
    | "datalist"
    | "custom"
    | "file"
    | "async_urna"
    | "async_roupa"
    | "async_invol"
    | "async_veu"
    | "async_cordao"
    | "async_coroa";
    options?: string[];
    placeholder?: string;
    datalist?: string[];
    accept?: string;
};

type EstoqueRow = {
    id?: number;
    produto_id?: number;
    est_produto_id?: number;
    nome: string;
    codigo_barras?: string;
    saldo_total?: number;
};

const ESTOQUE_API = `${ENDPOINT}/materiais_gerais.php`;

const SALAS_VELORIO = ["Sala 01", "Sala 02", "Sala 03"] as const;

/* -------------------- helpers -------------------- */
function normUpper(v: any) {
    return String(v ?? "")
        .trim()
        .replace(/\s+/g, " ")
        .toUpperCase();
}

function normNoAccLower(v: any) {
    return String(v ?? "")
        .trim()
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");
}

function isRoupaPropria(v: any) {
    const s = normNoAccLower(v);
    return s === "roupa propria" || s === "roupa própria";
}

function isSimNao(v: string) {
    return v === "Sim" || v === "Não";
}

function getPidFromRow(it: EstoqueRow): number {
    return (
        Number((it as any).id ?? (it as any).produto_id ?? (it as any).est_produto_id ?? 0) || 0
    );
}

// key estável p/ lista do estoque (evita “clicar e não selecionar” / DOM reusado)
function getStableRowKey(it: EstoqueRow) {
    const pid = getPidFromRow(it);
    const cb = String((it as any).codigo_barras ?? "");
    const nome = String(it.nome ?? "");
    const saldo = String((it as any).saldo_total ?? "");
    return `${pid || "0"}|${cb}|${nome}|${saldo}`;
}

function isMobileCoarsePointer() {
    if (typeof window === "undefined") return false;
    try {
        return window.matchMedia?.("(pointer: coarse)")?.matches ?? false;
    } catch {
        return false;
    }
}

function fileToDataURL(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onload = () => resolve(String(reader.result || ""));
        reader.onerror = () => reject(new Error("Não foi possível ler a imagem selecionada."));
        reader.readAsDataURL(file);
    });
}

function normalizarFotoSrc(src: any): string {
    const s = String(src ?? "").trim();
    if (!s) return "";
    if (s.startsWith("data:")) return s;
    if (/^https?:\/\//i.test(s)) return s;
    if (s.startsWith("/")) return `${ENDPOINT}${s}`;
    return `${ENDPOINT}/${s.replace(/^\/+/, "")}`;
}

/** Marcação do botão escolhido: ✓ no Sim (e nas demais opções), ✕ no Não. */
function IconeMarcado({ valor }: { valor: string }) {
    const nao = valor === "Não";
    return (
        <svg viewBox="0 0 24 24" className="size-4 shrink-0" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            {nao ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M5 12.5l4.5 4.5L19 7.5" />}
        </svg>
    );
}

type CheckboxChoiceOption = {
    value: string;
    label: string;
};

function CheckboxChoiceGroup({
    inputId,
    label,
    value,
    options,
    onChange,
    disabled,
    hasError,
    ariaLabel,
}: {
    inputId: string;
    label: React.ReactNode;
    value: string;
    options: readonly CheckboxChoiceOption[];
    onChange: (value: string) => void;
    disabled?: boolean;
    hasError?: boolean;
    ariaLabel: string;
}) {
    // Padrão do mockup (Registro.dc.html): linha em cartão + seletor segmentado Sim | Não.
    return (
        <div
            data-wizard-error={hasError ? "1" : "0"}
            className={[
                "flex min-h-[68px] items-center gap-3 rounded-[14px] border px-4 py-2.5",
                hasError
                    ? "border-red-500 bg-[#FDECEA]/60 dark:bg-[#FF9C92]/10"
                    : "border-[#E3E8F0] bg-white dark:border-white/[0.12] dark:bg-[#232B3F]",
                disabled ? "opacity-60" : "",
            ].join(" ")}
            role="group"
            aria-label={ariaLabel}
        >
            {/* O page.tsx continua lendo o mesmo valor pelo mesmo ID. */}
            <input id={inputId} type="hidden" value={value} readOnly />

            <div className="min-w-0 flex-1 text-[15px] font-bold leading-tight text-[#313C55] dark:text-white">{label}</div>

            <div className="inline-flex shrink-0 overflow-hidden rounded-xl border-[1.5px] border-[#C9D1DE] dark:border-white/25">
                {options.map((option, i) => {
                    const marcado = value === option.value;
                    return (
                        <button
                            key={option.value}
                            type="button"
                            aria-pressed={marcado}
                            aria-label={`${ariaLabel}: ${option.label}`}
                            disabled={disabled}
                            onClick={() => onChange(option.value)}
                            className={[
                                "inline-flex h-11 min-w-[84px] items-center justify-center gap-1.5 px-3 text-sm font-extrabold transition-colors disabled:cursor-not-allowed",
                                i > 0 ? "border-l-[1.5px] border-[#C9D1DE] dark:border-white/25" : "",
                                marcado
                                    ? "bg-[#313C55] text-white dark:bg-[#3D6A99] dark:text-white"
                                    : "bg-white text-[#313C55] hover:bg-[#EEF2F7] dark:bg-[#232B3F] dark:text-white dark:hover:bg-white/10",
                            ].join(" ")}
                        >
                            {marcado ? <IconeMarcado valor={option.value} /> : null}
                            {option.label}
                        </button>
                    );
                })}
            </div>
        </div>
    );
}

const SIM_NAO_OPTIONS: readonly CheckboxChoiceOption[] = [
    { value: "Sim", label: "Sim" },
    { value: "Não", label: "Não" },
];

const ORNAMENTACAO_TIPO_OPTIONS: readonly CheckboxChoiceOption[] = [
    { value: "Natural", label: "Natural" },
    { value: "Artificial", label: "Artificial" },
];


/* =========================================================================
   Combobox genérico (estoque)
   - action: "urnas_buscar" | "roupas_buscar" | "invols_buscar" | "veus_buscar" | "cordoes_buscar"
   - Usa deposito_nome e somente_com_saldo=1
   - ✅ abre o modal já carregando a lista do depósito, sem precisar digitar
   - ✅ cache por depósito/action (evita modal “branco”)
   - ✅ iOS scroll smoothing e eventos pointer
   ========================================================================= */

type CacheKey = string;
type CacheEntry = {
    rows: EstoqueRow[];
    ts: number;
};
const CACHE_TTL_MS = 60_000; // 1 min (ajuda evitar “piscar branco” sem ficar desatualizado)

function EstoqueCombobox({
    inputId,
    label,
    required,
    placeholder,
    initialValue,
    disabled,

    depositoLabel,
    depositoOptions,
    depositoValue,
    onChangeDeposito,

    action,
    errorText,
    onBlurValidate,

    onSelectRow,
    onTypingInvalidate,

    footerHint,
    extraButtons,
}: {
    inputId: string;
    label: string;
    required: boolean;
    placeholder?: string;
    initialValue: string;
    disabled?: boolean;

    depositoLabel: string;
    depositoOptions: Array<{ value: string; label: string }>;
    depositoValue: string;
    onChangeDeposito: (v: string) => void;

    action: string;
    errorText?: string;
    onBlurValidate?: () => void;

    onSelectRow: (row: EstoqueRow) => void;
    onTypingInvalidate?: (typed: string) => void;

    footerHint?: React.ReactNode;
    extraButtons?: React.ReactNode;
}) {
    const inputRef = useRef<HTMLInputElement>(null);
    const searchRef = useRef<HTMLInputElement>(null);

    const [pickerOpen, setPickerOpen] = useState(false);

    // valor exibido no campo principal (e que o salvarGrupoWizard lê pelo DOM)
    const [value, setValue] = useState(initialValue || "");

    // busca dentro do modal (opcional)
    const [q, setQ] = useState("");
    const [loading, setLoading] = useState(false);
    const [err, setErr] = useState("");
    const [rows, setRows] = useState<EstoqueRow[]>([]);
    const lastInitSigRef = useRef<string>("");

    // cache local (por componente) p/ evitar “tela branca” quando já carregou antes
    const cacheRef = useRef<Record<CacheKey, CacheEntry>>({});

    const cacheKey: CacheKey = `${action}||${String(depositoValue || "").trim()}`;

    // sincroniza quando abrir/editar registro
    useEffect(() => {
        const sig = `${String(initialValue || "")}||${String(depositoValue || "")}`;
        if (lastInitSigRef.current === sig) return;
        lastInitSigRef.current = sig;
        setValue(initialValue || "");
    }, [initialValue, depositoValue]);

    // ✅ ao abrir modal: limpa erro, e tenta popular rows via cache instantâneo
    useEffect(() => {
        if (!pickerOpen) return;

        setErr("");

        // sempre limpa o filtro ao abrir para vir “lista do depósito”
        setQ("");

        // usa cache se existir e estiver recente
        const cached = cacheRef.current[cacheKey];
        if (cached && Date.now() - cached.ts < CACHE_TTL_MS) {
            setRows(cached.rows || []);
            setLoading(false);
        } else {
            // não zera rows agressivamente se já tinha algo (evita “branco” em re-open),
            // mas se não tiver cache, mantém o que estiver e mostra loading ao buscar
            // (o fetch vai atualizar)
        }

        // 🔥 não focar teclado automaticamente (evita bugs/reflow no celular)
        // requestAnimationFrame(() => searchRef.current?.focus());
    }, [pickerOpen, cacheKey]);

    // ✅ busca async (dentro do modal) — busca mesmo com q vazio
    useEffect(() => {
        if (!pickerOpen) return;

        const qq = q.trim();

        // debounce pequeno
        const ac = new AbortController();
        const t = setTimeout(async () => {
            setLoading(true);
            setErr("");

            try {
                const url = new URL(ESTOQUE_API);
                url.searchParams.set("action", action);
                url.searchParams.set("q", qq); // pode ser vazio
                url.searchParams.set("somente_com_saldo", "1");
                url.searchParams.set("limit", "60");
                url.searchParams.set("deposito_nome", String(depositoValue || ""));

                const r = await fetch(url.toString(), {
                    method: "GET",
                    cache: "no-store",
                    credentials: "include",
                    signal: ac.signal,
                });

                // se sessão cair, isso aqui ajuda a diagnosticar
                const j = await r.json().catch(() => null);
                if (!j?.ok) {
                    const httpInfo = r?.status ? ` (HTTP ${r.status})` : "";
                    throw new Error((j?.msg || "Falha ao buscar itens no estoque") + httpInfo);
                }

                const nextRows = (j.rows || []) as EstoqueRow[];

                setRows(nextRows);
                // cacheia somente quando q está vazio (lista “base” do depósito)
                if (!qq) {
                    cacheRef.current[cacheKey] = { rows: nextRows, ts: Date.now() };
                }
            } catch (e: any) {
                if (e?.name === "AbortError") return;
                setErr(e?.message || "Erro na busca");
                setRows([]);
            } finally {
                setLoading(false);
            }
        }, 150);

        return () => {
            clearTimeout(t);
            ac.abort();
        };
    }, [q, pickerOpen, action, depositoValue, cacheKey]);

    const applySelection = (it: EstoqueRow) => {
        const pid = getPidFromRow(it);
        if (!pid || pid <= 0) {
            setErr("Este item veio sem produto_id. Contate o suporte.");
            onBlurValidate?.();
            return;
        }

        const nome = String(it.nome || "").trim();

        // atualiza valor do campo principal (DOM lê isso)
        setValue(nome);
        setErr("");
        setPickerOpen(false);

        // informa o wizardData (meta: produto_id, cb, depósito etc)
        onSelectRow(it);

        // blur leve para evitar teclado/scroll bugs em mobile
        requestAnimationFrame(() => {
            try {
                searchRef.current?.blur();
                inputRef.current?.blur();
            } catch {
                // noop
            }
        });
    };

    const limparSelecao = () => {
        setValue("");
        setQ("");
        setRows([]);
        setErr("");
        onTypingInvalidate?.("");
        onBlurValidate?.();
    };

    return (
        <div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-[200px_1fr] sm:gap-2">
                <div>
                    <label className="mb-1 block text-xs font-medium text-[#313C55] dark:text-[#D6DCE8]">{depositoLabel}</label>

                    <select
                        className={CAMPO_CLS}
                        value={depositoValue}
                        onChange={(e) => {
                            onChangeDeposito(e.target.value);

                            // não zera rows agressivamente aqui (evita “modal branco”)
                            setErr("");

                            // ✅ ao trocar depósito, já abre o modal
                            setPickerOpen(true);

                            onBlurValidate?.();
                        }}
                        disabled={disabled}
                        title={depositoLabel}
                    >
                        {depositoOptions.map((op) => (
                            <option key={op.value} value={op.value}>
                                {op.label}
                            </option>
                        ))}
                    </select>

                    {extraButtons ? <div className="mt-2 flex flex-wrap gap-2">{extraButtons}</div> : null}
                </div>

                <div>
                    <label className="mb-1 block text-xs font-medium text-[#313C55] dark:text-[#D6DCE8]">
                        {label} {required && <span className="text-[#B42318] dark:text-[#FF9C92]">*</span>}
                    </label>

                    <div className="flex gap-2">
                        {/* mantém id pro salvarGrupoWizard */}
                        <input
                            id={inputId}
                            ref={inputRef}
                            type="text"
                            placeholder={placeholder || "Clique em Selecionar..."}
                            value={value}
                            readOnly
                            onClick={() => {
                                if (!disabled) setPickerOpen(true);
                            }}
                            className={`${CAMPO_CLS} ${errorText ? "border-red-500!" : ""
                                }`}
                            disabled={disabled}
                            autoComplete="off"
                            title={label}
                        />

                        <button
                            type="button"
                            className={`${BTN_SEC_CLS} shrink-0`}
                            disabled={disabled}
                            onClick={() => setPickerOpen(true)}
                        >
                            Selecionar
                        </button>
                    </div>

                    {errorText ? <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{errorText}</div> : null}

                    <div className="mt-2 flex flex-wrap gap-2">
                        <button
                            type="button"
                            className={`${BTN_SEC_CLS}`}
                            disabled={disabled}
                            onClick={limparSelecao}
                        >
                            Limpar
                        </button>
                    </div>
                </div>
            </div>



            {footerHint ? <div className="mt-1 text-[11px] text-[#7A8396] dark:text-[#8893AA]">{footerHint}</div> : null}

            {/* MODAL / POPUP */}
            <Modal open={pickerOpen} onClose={() => setPickerOpen(false)} ariaLabel={`Selecionar ${label}`} maxWidth={720}>
                <div className="flex items-center justify-between gap-2">
                    <div>
                        <h3 className="text-lg font-semibold">Selecionar {label}</h3>
                        <div className="mt-1 text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                            Depósito: <b>{depositoValue}</b>
                        </div>
                    </div>

                    <button
                        type="button"
                        className={`${BTN_SEC_CLS}`}
                        onClick={() => setPickerOpen(false)}
                    >
                        Fechar
                    </button>
                </div>

                {/* ✅ busca opcional */}
                <div className="mt-4 flex gap-2">
                    <input
                        ref={searchRef}
                        type="text"
                        value={q}
                        onChange={(e) => {
                            const v = e.target.value;
                            setQ(v);
                            setErr("");
                            // NÃO mexe na seleção
                        }}
                        placeholder="(Opcional) filtrar por nome ou código…"
                        className={CAMPO_CLS}
                        autoComplete="off"
                    />

                    <button
                        type="button"
                        className={`${BTN_SEC_CLS}`}
                        onClick={() => setQ("")}
                        title="Limpar filtro"
                    >
                        Limpar filtro
                    </button>
                </div>

                <div className="mt-3 rounded-xl border bg-white dark:bg-[#232B3F] border-[#E3E8F0] dark:border-white/[0.12]">
                    {loading ? (
                        <div className="p-3 text-base text-[#5B6478] dark:text-[#AEB9CF]">Carregando itens do depósito…</div>
                    ) : err ? (
                        <div className="p-3 text-sm text-[#B42318] dark:text-[#FF9C92]">{err}</div>
                    ) : rows.length === 0 ? (
                        <div className="p-3 text-base text-[#5B6478] dark:text-[#AEB9CF]">Nenhum item encontrado no estoque ({depositoValue}).</div>
                    ) : (
                        <ul
                            className="max-h-[65vh] overflow-auto py-1"
                            style={{ WebkitOverflowScrolling: "touch" }} // ✅ iOS smoother scroll
                        >
                            {rows.map((it) => {
                                const k = getStableRowKey(it);
                                return (
                                    <li key={k}>
                                        <button
                                            type="button"
                                            className="w-full px-3 py-3 text-left text-base hover:bg-[#EEF2F7] dark:hover:bg-white/10"
                                            onClick={() => applySelection(it)}
                                            onPointerUp={() => applySelection(it)} // ✅ melhora toque no iOS dentro de overflow
                                        >
                                            <div className="flex items-center justify-between gap-2">
                                                <span className="truncate font-medium text-[#313C55] dark:text-white">{it.nome}</span>
                                                <span className="shrink-0 text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                                                    estoque: <b>{Number(it.saldo_total) || 0}</b>
                                                </span>
                                            </div>
                                            <div className="mt-0.5 truncate text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                                                CB: <b>{(it as any).codigo_barras || ""}</b>
                                            </div>
                                        </button>
                                    </li>
                                );
                            })}
                        </ul>
                    )}
                </div>

                <div className="mt-3 text-[11px] text-[#5B6478] dark:text-[#AEB9CF]">Toque no item para selecionar. (Sem digitar, a lista já vem do depósito.)</div>
            </Modal>
        </div>
    );
}

/* =========================================================================
   Seletor de Coroa de Flores
   - Natural: lista catálogo e apenas registra no atendimento.
   - Artificial: lista somente produto/depósito com saldo > 0 e guarda o
     depósito escolhido para a baixa automática na fase Corpo Pronto.
   ========================================================================= */
type CoroaRow = EstoqueRow & {
    deposito_nome?: string;
    categoria_nome?: string;
    foto_url?: string;
};

function CoroaCombobox({
    inputId,
    tipo,
    required,
    initialValue,
    disabled,
    errorText,
    onSelectRow,
    onClear,
}: {
    inputId: string;
    tipo: "Natural" | "Artificial";
    required: boolean;
    initialValue: string;
    disabled?: boolean;
    errorText?: string;
    onSelectRow: (row: CoroaRow) => void;
    onClear: () => void;
}) {
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState(initialValue || "");
    const [q, setQ] = useState("");
    const [rows, setRows] = useState<CoroaRow[]>([]);
    const [loading, setLoading] = useState(false);
    const [err, setErr] = useState("");

    useEffect(() => {
        setValue(initialValue || "");
    }, [initialValue, tipo]);

    useEffect(() => {
        if (!open) return;

        const ac = new AbortController();
        const t = window.setTimeout(async () => {
            setLoading(true);
            setErr("");

            try {
                const url = new URL(ESTOQUE_API);
                url.searchParams.set("action", "coroas_buscar");
                url.searchParams.set("tipo", tipo.toLowerCase());
                url.searchParams.set("q", q.trim());
                url.searchParams.set("limit", "80");

                const r = await fetch(url.toString(), {
                    method: "GET",
                    cache: "no-store",
                    credentials: "include",
                    signal: ac.signal,
                });

                const j = await r.json().catch(() => null);
                if (!r.ok || !j?.ok) {
                    throw new Error(j?.msg || `Falha ao buscar coroas (${r.status}).`);
                }

                setRows(Array.isArray(j.rows) ? j.rows : []);
            } catch (e: any) {
                if (e?.name === "AbortError") return;
                setRows([]);
                setErr(e?.message || "Erro ao buscar modelos de coroa.");
            } finally {
                setLoading(false);
            }
        }, 150);

        return () => {
            window.clearTimeout(t);
            ac.abort();
        };
    }, [open, q, tipo]);

    const aplicar = (row: CoroaRow) => {
        const pid = getPidFromRow(row);
        if (pid <= 0) {
            setErr("Modelo de coroa inválido: produto sem ID.");
            return;
        }

        if (tipo === "Artificial" && !String(row.deposito_nome || "").trim()) {
            setErr("A coroa artificial selecionada veio sem depósito de estoque.");
            return;
        }

        setValue(String(row.nome || "").trim());
        setErr("");
        setOpen(false);
        onSelectRow(row);
    };

    return (
        <div>
            <label className="mb-1 block text-xs font-medium text-[#313C55] dark:text-[#D6DCE8]">
                Modelo da Coroa {required && <span className="text-[#B42318] dark:text-[#FF9C92]">*</span>}
            </label>

            <div className="flex gap-2">
                <input
                    id={inputId}
                    type="text"
                    value={value}
                    readOnly
                    placeholder={`Selecione uma Coroa ${tipo}...`}
                    className={`${CAMPO_CLS} ${errorText ? "border-red-500!" : ""}`}
                    disabled={disabled}
                    onClick={() => !disabled && setOpen(true)}
                />
                <button
                    type="button"
                    className={`${BTN_SEC_CLS} shrink-0`}
                    disabled={disabled}
                    onClick={() => setOpen(true)}
                >
                    Selecionar
                </button>
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-2">
                <button
                    type="button"
                    className={`${BTN_SEC_CLS}`}
                    disabled={disabled}
                    onClick={() => {
                        setValue("");
                        onClear();
                    }}
                >
                    Limpar
                </button>
                {tipo === "Natural" ? (
                    <span className="text-[11px] text-[#5B6478] dark:text-[#AEB9CF]">Natural: registrada sem baixa de estoque.</span>
                ) : (
                    <span className="text-[11px] text-[#5B6478] dark:text-[#AEB9CF]">Artificial: baixa de 1 unidade no Corpo Pronto.</span>
                )}
            </div>

            {errorText && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{errorText}</div>}

            <Modal open={open} onClose={() => setOpen(false)} ariaLabel="Selecionar Coroa de Flores" maxWidth={760}>
                <div className="flex items-center justify-between gap-3">
                    <div>
                        <h3 className="text-lg font-semibold">Selecionar Coroa {tipo}</h3>
                        <p className="mt-1 text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                            {tipo === "Natural"
                                ? "A seleção será registrada no atendimento e não movimentará estoque."
                                : "São exibidos somente modelos com saldo disponível, identificados pelo depósito."}
                        </p>
                    </div>
                    <button type="button" className={`${BTN_SEC_CLS}`} onClick={() => setOpen(false)}>
                        Fechar
                    </button>
                </div>

                <input
                    type="text"
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder="Filtrar por nome ou código..."
                    className={`${CAMPO_CLS} mt-4`}
                    autoComplete="off"
                />

                <div className="mt-3 rounded-xl border bg-white dark:bg-[#232B3F] border-[#E3E8F0] dark:border-white/[0.12]">
                    {loading ? (
                        <div className="p-3 text-base text-[#5B6478] dark:text-[#AEB9CF]">Carregando modelos...</div>
                    ) : err ? (
                        <div className="p-3 text-sm text-[#B42318] dark:text-[#FF9C92]">{err}</div>
                    ) : rows.length === 0 ? (
                        <div className="p-3 text-base text-[#5B6478] dark:text-[#AEB9CF]">Nenhum modelo disponível.</div>
                    ) : (
                        <ul className="max-h-[65vh] overflow-auto py-1" style={{ WebkitOverflowScrolling: "touch" }}>
                            {rows.map((row) => {
                                const pid = getPidFromRow(row);
                                const dep = String(row.deposito_nome || "").trim();
                                const key = `${pid}|${dep}|${row.codigo_barras || ""}|${row.nome}`;
                                return (
                                    <li key={key}>
                                        <button
                                            type="button"
                                            className="w-full px-3 py-3 text-left text-base hover:bg-[#EEF2F7] dark:hover:bg-white/10"
                                            onClick={() => aplicar(row)}
                                        >
                                            <div className="flex items-center justify-between gap-3">
                                                <span className="font-medium text-[#313C55] dark:text-white">{row.nome}</span>
                                                {tipo === "Artificial" && (
                                                    <span className="shrink-0 text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                                                        estoque: <b>{Number(row.saldo_total) || 0}</b>
                                                    </span>
                                                )}
                                            </div>
                                            <div className="mt-1 text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                                                CB: <b>{row.codigo_barras || ""}</b>
                                                {tipo === "Artificial" && dep ? <> · Depósito: <b>{dep}</b></> : null}
                                            </div>
                                        </button>
                                    </li>
                                );
                            })}
                        </ul>
                    )}
                </div>
            </Modal>
        </div>
    );
}

/* -------------------- depósitos -------------------- */
type DepUrna = "MEMORIAL" | "FUNERARIA";
type DepRoupa = "ARMARIO SANDRO" | "ARMARIO ILDO" | "FUNERARIA";
type DepInvol = "ARMARIO SANDRO" | "ARMARIO ILDO";

// ✅ VÉU e CORDÃO saem só destes 3
type DepVeu = "ARMARIO SANDRO" | "ARMARIO ILDO" | "FUNERARIA";
type DepCordao = "ARMARIO SANDRO" | "ARMARIO ILDO" | "FUNERARIA";

function normalizeDepUrna(v: any): DepUrna {
    const s = normUpper(v);
    return s === "FUNERARIA" ? "FUNERARIA" : "MEMORIAL";
}

function normalizeDepRoupa(v: any): DepRoupa {
    const s = normUpper(v);
    if (s === "ARMARIO ILDO") return "ARMARIO ILDO";
    if (s === "FUNERARIA") return "FUNERARIA";
    return "ARMARIO SANDRO";
}

function normalizeDepInvol(v: any): DepInvol {
    const s = normUpper(v);
    return s === "ARMARIO ILDO" ? "ARMARIO ILDO" : "ARMARIO SANDRO";
}

function normalizeDepVeu(v: any): DepVeu {
    const s = normUpper(v);
    if (s === "ARMARIO ILDO") return "ARMARIO ILDO";
    if (s === "FUNERARIA") return "FUNERARIA";
    return "ARMARIO SANDRO";
}

function normalizeDepCordao(v: any): DepCordao {
    const s = normUpper(v);
    if (s === "ARMARIO ILDO") return "ARMARIO ILDO";
    if (s === "FUNERARIA") return "FUNERARIA";
    return "ARMARIO SANDRO";
}

/* =========================================================================
   Wizard
   ========================================================================= */
/* Estilos de formulário do mockup (Registro.dc.html): campo de 48 px, raio 12, borda 1,5 px, rótulo 13 px em negrito. */
const CAMPO_CLS =
    "h-12 w-full rounded-xl border-[1.5px] border-[#C9D1DE] bg-white px-3.5 text-[15px] text-[#313C55] outline-none transition placeholder:text-[#7A8396] focus:border-[#3D6A99] focus:ring-2 focus:ring-[#3D6A99]/20 disabled:opacity-60 dark:border-white/25 dark:bg-[#232B3F] dark:text-white";
const AREA_CLS =
    "min-h-24 w-full rounded-xl border-[1.5px] border-[#C9D1DE] bg-white px-3.5 py-3 text-[15px] text-[#313C55] outline-none transition placeholder:text-[#7A8396] focus:border-[#3D6A99] focus:ring-2 focus:ring-[#3D6A99]/20 disabled:opacity-60 dark:border-white/25 dark:bg-[#232B3F] dark:text-white";
const BTN_SEC_CLS =
    "inline-flex h-11 items-center justify-center gap-2 rounded-xl border-[1.5px] border-[#C9D1DE] bg-white px-4 text-sm font-bold text-[#313C55] transition hover:bg-[#EEF2F7] disabled:opacity-60 dark:border-white/25 dark:bg-[#232B3F] dark:text-white dark:hover:bg-white/10";

/** Campo obrigatório que impediu o salvamento: nome, aba (índice e título) para levar o operador até ele. */
/** Itens travados depois do Corpo Pronto (ver page.tsx → CAMPOS_TRAVADOS_APOS_CORPO_PRONTO). */
export type TravaItens = { campos: string[]; podeAlterar: boolean; baixaFeita: boolean };

export type CampoFaltando = { id: string; rotulo: string; aba: number | null; abaTitulo: string };

/** Aviso fixo no rodapé do Wizard (sempre visível, sem precisar rolar a tela). */
function AvisoRodape({
    aviso,
    onFechar,
    onIr,
}: {
    aviso: { text: string; ok: boolean; faltando?: CampoFaltando[] };
    onFechar?: () => void;
    onIr: (c: CampoFaltando) => void;
}) {
    const lista = aviso.faltando ?? [];
    return (
        <div
            role={aviso.ok ? "status" : "alert"}
            className={[
                "mb-3 flex items-start gap-3 rounded-xl border px-3 py-2.5 text-sm",
                aviso.ok
                    ? "border-[#7BA11A]/50 bg-[#EEF5D6] text-[#313C55] dark:border-[#B3CE52]/40 dark:bg-[#B3CE52]/20 dark:text-white"
                    : "border-[#B42318]/40 bg-[#FDECEA] text-[#B42318] dark:border-[#FF9C92]/40 dark:bg-[#FF9C92]/15 dark:text-[#FF9C92]",
            ].join(" ")}
        >
            <div className="min-w-0 flex-1">
                {lista.length ? (
                    <>
                        <div className="font-extrabold">Não foi possível salvar. Falta preencher:</div>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                            {lista.map((c) => (
                                <button
                                    key={c.id}
                                    type="button"
                                    onClick={() => onIr(c)}
                                    className="rounded-full border border-[#B42318]/40 bg-white px-2.5 py-1 text-xs font-extrabold text-[#B42318] hover:bg-[#FFF5F4] dark:border-[#FF9C92]/40 dark:bg-transparent dark:text-[#FF9C92]"
                                >
                                    {c.rotulo}
                                    {c.abaTitulo ? <span className="font-semibold opacity-80"> · {c.abaTitulo}</span> : null}
                                </button>
                            ))}
                        </div>
                    </>
                ) : (
                    <div className="font-semibold">{aviso.text}</div>
                )}
            </div>
            {onFechar ? (
                <button type="button" onClick={onFechar} aria-label="Fechar aviso" className="-mr-1 grid size-8 shrink-0 place-items-center rounded-lg hover:bg-black/5 dark:hover:bg-white/10">
                    <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" aria-hidden="true">
                        <path d="M18 6 6 18M6 6l12 12" />
                    </svg>
                </button>
            ) : null}
        </div>
    );
}

/* =========================================================================
   Coluna da direita do "Editar registro" (mockup Registro.dc.html):
   DOCUMENTOS (termos) + PRÓXIMA ETAPA com o botão Registrar ação.
   ========================================================================= */
function IcDoc() {
    return (
        <svg viewBox="0 0 24 24" className="size-5 shrink-0" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" /><path d="M14 2v6h6" /><path d="M9 13h6" /><path d="M9 17h6" />
        </svg>
    );
}

/** Ícone de concluído (círculo com check) para o termo assinado. */
function IcOk() {
    return (
        <svg viewBox="0 0 24 24" className="size-5 shrink-0" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <circle cx="12" cy="12" r="9" /><path d="m8.5 12.5 2.5 2.5 4.5-5" />
        </svg>
    );
}

/**
 * Situação de cada termo: assinado no servidor, salvo só no aparelho (aguardando envio) ou pendente.
 * A assinatura do servidor vem do próprio registro (assinatura_responsavel / assinatura_requerente);
 * a do aparelho vem da fila offline (lib/offline/signatures), a mesma que o SignatureModal grava.
 */
function useSituacaoTermos(registro: Registro | null) {
    const servidor = {
        recebimento: situacaoTermo(registro, "recebimento"),
        requisicao: situacaoTermo(registro, "requisicao"),
    };
    const [noAparelho, setNoAparelho] = useState<{ recebimento: boolean; requisicao: boolean }>({ recebimento: false, requisicao: false });
    const id = registro?.id != null ? String(registro.id) : "";
    useEffect(() => {
        if (!id) return;
        let vivo = true;
        (async () => {
            const r: { recebimento: boolean; requisicao: boolean } = { recebimento: false, requisicao: false };
            for (const t of ["recebimento", "requisicao"] as const) {
                try {
                    const local: any = await getLatestOfflineSignature(id, t);
                    r[t] = !!local && local.status !== "synced";
                } catch {
                    /* sem armazenamento local: fica só o que veio do servidor */
                }
            }
            if (vivo) setNoAparelho(r);
        })();
        return () => {
            vivo = false;
        };
        // a lista é refeita quando o registro volta do servidor (depois de assinar)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [id, servidor.recebimento.url, servidor.requisicao.url]);
    return { servidor, noAparelho };
}

function PainelEdicao({
    registro,
    proxima,
    onDocumento,
    onRegistrarAcao,
    resumoOS,
}: {
    /** null = novo registro (ainda não existe atendimento: documentos e próxima etapa só depois de salvar). */
    registro: Registro | null;
    proxima: string;
    onDocumento?: (tipo: "recebimento" | "requisicao") => void;
    onRegistrarAcao?: () => void;
    /** Resumo da OS (Prefeitura e família) e "Ver OS", abaixo dos Documentos. */
    resumoOS?: React.ReactNode;
}) {
    const novo = !registro;
    const { servidor, noAparelho } = useSituacaoTermos(registro);
    /*
     * Termos (08/10/2026): só os que o atendimento tem (Assistência → recebimento de material; Sepultamento → requisição
     * de veículo) e uma assinatura só para todos, numa linha "Termos do atendimento". Sem nenhum, o quadro não aparece.
     */
    const termos = termosDoAtendimento(registro);
    const assinados = termos.filter((t) => servidor[t].assinado);
    const noAparelhoPend = termos.filter((t) => !servidor[t].assinado && noAparelho[t]);
    const pendentes = termos.filter((t) => !servidor[t].assinado && !noAparelho[t]);
    const feito = termos.length > 0 && pendentes.length === 0;
    const titulo = termos.length === 1 ? (termos[0] === "recebimento" ? "Termo de recebimento de material" : "Termo de requisição de veículo") : "Termos do atendimento";
    const nomes = termos.map((t) => NOME_TERMO[t]).join(" · ");
    const quem = assinados.length ? servidor[assinados[0]].nome : "";
    const sub = pendentes.length === 0 && noAparelhoPend.length === 0
        ? `Assinado${quem ? ` por ${quem}` : ""} · toque para ver`
        : pendentes.length === 0
            ? "Salvo no aparelho · aguardando envio"
            : assinados.length || noAparelhoPend.length
                ? `Falta assinar: ${pendentes.map((t) => NOME_TERMO[t]).join(" e ")}`
                : "Pendente de assinatura";
    const tipoAbrir = pendentes[0] ?? termos[0];
    return (
        <div className={`flex-col gap-2.5 ${novo ? "hidden lg:flex" : "flex"}`}>
            {/* Coluna compacta: Documentos, Resumo da OS e Próxima etapa cabem numa tela, sem rolagem. */}
            {novo || termos.length ? (
                <section className="rounded-[18px] border border-[#E3E8F0] bg-white px-4 py-3 dark:border-white/[0.12] dark:bg-[#232B3F]" aria-label="Documentos">
                    <div className="mb-2 text-[11px] font-extrabold uppercase tracking-[0.12em] text-[#5B6478] dark:text-[#AEB9CF]">Documentos</div>
                    {termos.length ? (
                        <button
                            type="button"
                            onClick={() => tipoAbrir && onDocumento?.(tipoAbrir)}
                            disabled={!onDocumento || novo}
                            aria-label={`${titulo}: ${sub}`}
                            className={[
                                "flex min-h-[44px] w-full items-center gap-2.5 rounded-xl border-[1.5px] px-3 py-1.5 text-left disabled:opacity-50",
                                feito
                                    ? "border-[#B3CE52] bg-[#EEF5D6] text-[#313C55] hover:bg-[#E2EDBB] dark:border-[#B3CE52]/60 dark:bg-[#B3CE52]/15 dark:text-white"
                                    : "border-[#C9D1DE] bg-white text-[#313C55] hover:bg-[#EEF2F7] dark:border-white/25 dark:bg-[#232B3F] dark:text-white dark:hover:bg-white/10",
                            ].join(" ")}
                        >
                            <span className={feito ? "text-[#5C7A12] dark:text-[#B3CE52]" : ""}>{feito ? <IcOk /> : <IcDoc />}</span>
                            <span className="min-w-0 flex-1">
                                <span className="block text-[13px] font-bold leading-tight">{titulo}</span>
                                {termos.length > 1 ? <span className="block text-[11px] font-semibold leading-tight text-[#5B6478] dark:text-[#AEB9CF]">{nomes} · uma assinatura</span> : null}
                                <span className={`block text-[11px] font-semibold leading-tight ${feito ? "text-[#5C7A12] dark:text-[#B3CE52]" : "text-[#5B6478] dark:text-[#AEB9CF]"}`}>{sub}</span>
                            </span>
                        </button>
                    ) : null}
                    {novo && <p className="mt-2 text-xs text-[#5B6478] dark:text-[#AEB9CF]">Os termos ficam disponíveis depois que o registro for salvo.</p>}
                </section>
            ) : null}

            {resumoOS}

            {!novo && proxima !== "—" && (
                <section className="rounded-[18px] bg-[#313C55] px-4 py-3 text-white dark:border dark:border-white/[0.12] dark:bg-[#1C2334]" aria-label="Próxima etapa">
                    <div className="mb-0.5 text-[11px] font-extrabold uppercase tracking-[0.12em] text-[#B3CE52]">Próxima etapa</div>
                    <div className="mb-2 text-base font-extrabold leading-tight">{proxima}</div>
                    <button
                        type="button"
                        onClick={onRegistrarAcao}
                        disabled={!onRegistrarAcao}
                        className="flex h-10 w-full items-center justify-center rounded-xl bg-[#F2CB3F] text-sm font-extrabold text-[#313C55] hover:bg-[#E4BC30] disabled:opacity-60"
                    >
                        Registrar ação
                    </button>
                </section>
            )}
        </div>
    );
}

export default function Wizard({
    open,
    onClose,
    wizardTitle,
    wizardStep,
    setWizardStep,
    wizardRestrictGroup,
    osSlot,
    osProcedimentoSlot,
    osTransladoSlot,
    osCoroaSlot,
    osLateralSlot,
    convenioSlot,
    falecidoSlot,
    osCampos,
    wizardData,
    setWizardData,
    obrigatorios,
    steps,
    wizardStepIndexes,
    wizardStepTitles,

    assistenciaVal,
    setAssistenciaVal,
    tanatoVal,
    setTanatoVal,

    materiaisSelecionadosResumo,
    arrumacaoSelecionadaResumo,
    setMateriaisOpen,
    setArrumacaoOpen,

    salvarGrupoWizard,
    concluirWizard,

    wizardSubmitting,
    registroEdicao,
    onAbrirDocumento,
    onRegistrarAcaoEdicao,
    aviso,
    onFecharAviso,
    travaItens,
}: {
    open: boolean;
    onClose: () => void;
    wizardTitle: string;
    wizardStep: number;
    setWizardStep: (n: number) => void;
    wizardRestrictGroup: number | null;
    /** Bloco "Dados da OS" (campos da OS, resumo e folha). Aparece no grupo em que está a Tanatopraxia (Itens). */
    osSlot?: React.ReactNode;
    /** Tipo de procedimento + Reconstituição facial: aparece logo depois de Tanatopraxia (quando Sim). */
    osProcedimentoSlot?: React.ReactNode;
    /** Item Translado: aparece logo depois de Invol, antes de Velório. */
    osTransladoSlot?: React.ReactNode;
    /** "A Prefeitura autorizou a coroa?" (Prefeitura com pacote de coroa), logo abaixo da Coroa de flores. */
    osCoroaSlot?: React.ReactNode;
    /** Resumo da OS e "Ver OS", na coluna fixa ao lado, abaixo dos Documentos. */
    osLateralSlot?: React.ReactNode;
    /** Campo Convênio ligado ao cadastro (convênio, pacote e autorização da Prefeitura). Substitui o seletor simples. */
    convenioSlot?: React.ReactNode;
    /** Seleção do titular, dependente ou agregado após localizar o contrato. */
    falecidoSlot?: React.ReactNode;
    /** Campos da OS em edição (convênio, pacote, procedimento, translado...): alimentam a prévia da OS em tempo real. */
    osCampos?: OsCampos;
    wizardData: Registro;
    setWizardData: React.Dispatch<React.SetStateAction<Registro>>;
    obrigatorios: string[];
    steps: readonly Step[];
    wizardStepIndexes: number[][];
    wizardStepTitles: string[];

    assistenciaVal: string;
    setAssistenciaVal: (v: string) => void;
    tanatoVal: string;
    setTanatoVal: (v: string) => void;

    materiaisSelecionadosResumo: string;
    arrumacaoSelecionadaResumo: string;
    setMateriaisOpen: (b: boolean) => void;
    setArrumacaoOpen: (b: boolean) => void;

    salvarGrupoWizard: () => Registro | null;
    concluirWizard: () => Promise<void>;

    wizardSubmitting: boolean;

    /** Registro que está sendo editado. Só com ele o "Editar registro" usa o layout do mockup (coluna de documentos). */
    registroEdicao?: Registro | null;
    onAbrirDocumento?: (tipo: "recebimento" | "requisicao") => void;
    onRegistrarAcaoEdicao?: () => void;
    /** Aviso do salvamento (campos obrigatórios que faltam, erro da OS ou sucesso): mostrado no rodapé, acima dos botões. */
    aviso?: { text: string; ok: boolean; faltando?: CampoFaltando[] } | null;
    onFecharAviso?: () => void;
    /**
     * Trava dos itens a partir do Corpo Pronto (fase12, junto com a baixa no estoque).
     * campos: ids dos passos travados; podeAlterar: Gestão/administrador; baixaFeita: o Corpo Pronto já deu baixa no estoque.
     * O servidor (informativo.php) confere a mesma regra ao salvar.
     */
    travaItens?: TravaItens | null;
}) {
    const [ornamentacaoVal, setOrnamentacaoVal] = useState<string>("");
    const [involVal, setInvolVal] = useState<string>("");
    const [veuVal, setVeuVal] = useState<string>("");
    const [cordaoVal, setCordaoVal] = useState<string>("");
    const [kitLancheVal, setKitLancheVal] = useState<string>("");
    const [coroaFloresVal, setCoroaFloresVal] = useState<string>("");
    const [coroaTipoVal, setCoroaTipoVal] = useState<string>("");
    const [realizaVelorioVal, setRealizaVelorioVal] = useState<string>("");
    const [realizaSepultamentoVal, setRealizaSepultamentoVal] = useState<string>("");

    // Controle exclusivamente visual para mostrar ou esconder os seletores.
    // Os dados continuam sendo gravados nos campos atuais de urna e roupa.
    const [urnaUsoVal, setUrnaUsoVal] = useState<string>("");
    const [roupaUsoVal, setRoupaUsoVal] = useState<string>("");

    // ✅ Velório: sala + velório online (condicional)
    const [salaVelorioVal, setSalaVelorioVal] = useState<string>("");
    const [velorioOnlineVal, setVelorioOnlineVal] = useState<string>("");

    const [assistenciaErro, setAssistenciaErro] = useState<string>("");
    const [urnaUsoErro, setUrnaUsoErro] = useState<string>("");
    const [roupaUsoErro, setRoupaUsoErro] = useState<string>("");
    const [urnaErro, setUrnaErro] = useState<string>("");
    const [roupaErro, setRoupaErro] = useState<string>("");
    const [involErro, setInvolErro] = useState<string>("");
    const [veuErro, setVeuErro] = useState<string>("");
    const [cordaoErro, setCordaoErro] = useState<string>("");

    // ✅ erros de "Sim/Não" (select obrigatório)
    const [tanatoSelectErro, setTanatoSelectErro] = useState<string>("");
    const [ornamentacaoSelectErro, setOrnamentacaoSelectErro] = useState<string>("");
    const [involSelectErro, setInvolSelectErro] = useState<string>("");
    const [veuSelectErro, setVeuSelectErro] = useState<string>("");
    const [cordaoSelectErro, setCordaoSelectErro] = useState<string>("");
    const [kitLancheSelectErro, setKitLancheSelectErro] = useState<string>("");
    const [coroaFloresSelectErro, setCoroaFloresSelectErro] = useState<string>("");
    const [coroaTipoErro, setCoroaTipoErro] = useState<string>("");
    const [coroaModeloErro, setCoroaModeloErro] = useState<string>("");
    const [realizaVelorioErro, setRealizaVelorioErro] = useState<string>("");
    const [realizaSepultamentoErro, setRealizaSepultamentoErro] = useState<string>("");
    const [velorioOnlineErro, setVelorioOnlineErro] = useState<string>("");

    // ✅ erro do tipo (Natural/Artificial) quando ornamentacao = Sim
    const [ornamentacaoTipoErro, setOrnamentacaoTipoErro] = useState<string>("");

    // depósitos locais (controlados)
    const [depUrna, setDepUrna] = useState<DepUrna>("MEMORIAL");
    const [depRoupa, setDepRoupa] = useState<DepRoupa>("ARMARIO SANDRO");
    const [depInvol, setDepInvol] = useState<DepInvol>("ARMARIO SANDRO");
    const [depVeu, setDepVeu] = useState<DepVeu>("ARMARIO SANDRO");
    const [depCordao, setDepCordao] = useState<DepCordao>("ARMARIO SANDRO");

    useEffect(() => {
        if (!open) return;

        const registroExistente = (wizardData as any).id != null;

        const temUrna =
            Number((wizardData as any).urna_produto_id ?? 0) > 0 ||
            String((wizardData as any).urna ?? "").trim() !== "";

        const temRoupa =
            Number((wizardData as any).roupa_produto_id ?? 0) > 0 ||
            String((wizardData as any).roupa ?? "").trim() !== "";

        setUrnaUsoVal(temUrna ? "Sim" : registroExistente ? "Não" : "");
        setRoupaUsoVal(temRoupa ? "Sim" : registroExistente ? "Não" : "");
    }, [open, (wizardData as any).id]);

    useEffect(() => {
        setOrnamentacaoVal(String((wizardData as any).ornamentacao ?? ""));
        setInvolVal(String((wizardData as any).invol ?? ""));
        setVeuVal(String((wizardData as any).veu ?? ""));
        setCordaoVal(String((wizardData as any).cordao ?? ""));
        setKitLancheVal(String((wizardData as any).kit_lanche ?? ""));
        setCoroaFloresVal(String((wizardData as any).coroa_flores ?? ""));
        setCoroaTipoVal(String((wizardData as any).coroa_tipo ?? ""));
        setRealizaVelorioVal(String((wizardData as any).realiza_velorio ?? ""));
        setRealizaSepultamentoVal(String((wizardData as any).realiza_sepultamento ?? ""));
        setSalaVelorioVal(String((wizardData as any).sala_velorio ?? ""));
        setVelorioOnlineVal(String((wizardData as any).velorio_online ?? ""));
    }, [
        open,
        (wizardData as any).ornamentacao,
        (wizardData as any).invol,
        (wizardData as any).veu,
        (wizardData as any).cordao,
        (wizardData as any).kit_lanche,
        (wizardData as any).coroa_flores,
        (wizardData as any).coroa_tipo,
        (wizardData as any).realiza_velorio,
        (wizardData as any).realiza_sepultamento,
        (wizardData as any).sala_velorio,
        (wizardData as any).velorio_online,
    ]);

    useEffect(() => {
        if (!open) return;

        setUrnaUsoErro("");
        setRoupaUsoErro("");
        setUrnaErro("");
        setRoupaErro("");
        setInvolErro("");
        setVeuErro("");
        setCordaoErro("");
        setAssistenciaErro("");

        // ✅ limpa erros dos selects Sim/Não
        setTanatoSelectErro("");
        setOrnamentacaoSelectErro("");
        setInvolSelectErro("");
        setVeuSelectErro("");
        setCordaoSelectErro("");
        setKitLancheSelectErro("");
        setCoroaFloresSelectErro("");
        setCoroaTipoErro("");
        setCoroaModeloErro("");
        setRealizaVelorioErro("");
        setRealizaSepultamentoErro("");
        setVelorioOnlineErro("");

        // ✅ limpa erro do Natural/Artificial
        setOrnamentacaoTipoErro("");

        setDepUrna(normalizeDepUrna((wizardData as any).urna_deposito_nome ?? "MEMORIAL"));
        setDepRoupa(normalizeDepRoupa((wizardData as any).roupa_deposito_nome ?? "ARMARIO SANDRO"));
        setDepInvol(normalizeDepInvol((wizardData as any).invol_deposito_nome ?? "ARMARIO SANDRO"));
        setDepVeu(normalizeDepVeu((wizardData as any).veu_deposito_nome ?? "ARMARIO SANDRO"));
        setDepCordao(normalizeDepCordao((wizardData as any).cordao_deposito_nome ?? "ARMARIO SANDRO"));
    }, [open]);

    // ✅ auto-limpa erro quando produto_id chega
    useEffect(() => {
        const urnaPid = Number((wizardData as any).urna_produto_id ?? 0) || 0;
        if (urnaPid > 0) setUrnaErro("");
    }, [(wizardData as any).urna_produto_id]);

    useEffect(() => {
        const involPid = Number((wizardData as any).invol_produto_id ?? 0) || 0;
        if (involPid > 0) setInvolErro("");
    }, [(wizardData as any).invol_produto_id]);

    useEffect(() => {
        const pid = Number((wizardData as any).veu_produto_id ?? 0) || 0;
        if (pid > 0) setVeuErro("");
    }, [(wizardData as any).veu_produto_id]);

    useEffect(() => {
        const pid = Number((wizardData as any).cordao_produto_id ?? 0) || 0;
        if (pid > 0) setCordaoErro("");
    }, [(wizardData as any).cordao_produto_id]);

    // ✅ limpa erro URNA quando seleção chega no wizardData
    useEffect(() => {
        if (!open) return;

        const urnaTxt = String((wizardData as any).urna ?? "").trim();
        const pid = Number((wizardData as any).urna_produto_id ?? 0) || 0;

        if (pid > 0 || urnaTxt === "") setUrnaErro("");
    }, [open, (wizardData as any).urna, (wizardData as any).urna_produto_id]);

    // ✅ limpa erro INVOL quando invol != Sim, ou quando produto/depósito chegam
    useEffect(() => {
        if (!open) return;

        const invol = String((wizardData as any).invol ?? involVal ?? "");
        if (invol !== "Sim") {
            setInvolErro("");
            return;
        }

        const pid = Number((wizardData as any).invol_produto_id ?? 0) || 0;
        const dep = String((wizardData as any).invol_deposito_nome ?? "").trim();

        if (pid > 0 && dep) setInvolErro("");
    }, [open, involVal, (wizardData as any).invol, (wizardData as any).invol_produto_id, (wizardData as any).invol_deposito_nome]);

    useEffect(() => {
        if (!open) return;

        const veu = String((wizardData as any).veu ?? veuVal ?? "");
        if (veu !== "Sim") {
            setVeuErro("");
            return;
        }

        const pid = Number((wizardData as any).veu_produto_id ?? 0) || 0;
        const dep = String((wizardData as any).veu_deposito_nome ?? "").trim();
        if (pid > 0 && dep) setVeuErro("");
    }, [open, veuVal, (wizardData as any).veu, (wizardData as any).veu_produto_id, (wizardData as any).veu_deposito_nome]);

    useEffect(() => {
        if (!open) return;

        const cordao = String((wizardData as any).cordao ?? cordaoVal ?? "");
        if (cordao !== "Sim") {
            setCordaoErro("");
            return;
        }

        const pid = Number((wizardData as any).cordao_produto_id ?? 0) || 0;
        const dep = String((wizardData as any).cordao_deposito_nome ?? "").trim();
        if (pid > 0 && dep) setCordaoErro("");
    }, [open, cordaoVal, (wizardData as any).cordao, (wizardData as any).cordao_produto_id, (wizardData as any).cordao_deposito_nome]);

    const isRequired = (id: string) => obrigatorios.includes(id);

    // Quando o page.tsx mandar obrigatorios = [], nenhuma regra especial deve bloquear.
    // Quando fase02 em diante ativar obrigatorios, as regras especiais voltam a valer.
    const obrigatoriedadeAtiva = obrigatorios.length > 0;

    const assistenciaGroupIndex = useMemo(() => {
        return wizardStepIndexes.findIndex((arr) => arr.some((idx) => steps[idx]?.id === "assistencia"));
    }, [wizardStepIndexes, steps]);

    const isRestrito = typeof wizardRestrictGroup === "number";

    const requireAssistencia = useMemo(() => {
        if (!obrigatorios.includes("assistencia")) return false;
        if (assistenciaGroupIndex < 0) return false;
        if (!isRestrito) return true;
        return wizardRestrictGroup === assistenciaGroupIndex;
    }, [assistenciaGroupIndex, isRestrito, wizardRestrictGroup, obrigatorios]);

    const grupoIndices = wizardStepIndexes[wizardStep] || [];
    const grupoSteps = useMemo(() => grupoIndices.map((i) => steps[i]), [grupoIndices, steps]);

    // Passo "Itens" no padrão do mockup: uma coluna, ITENS PRINCIPAIS (urna, roupa, coroa de flores)
    // e depois DEMAIS ITENS E SERVIÇOS. A ordem relativa dentro de cada bloco não muda
    // (ex.: "Véu" continua antes de "Véu (estoque)"), então a validação e os IDs seguem iguais.
    const ehPassoItens = useMemo(() => grupoSteps.some((s) => s.id === "urna"), [grupoSteps]);
    const secaoDoPasso = (id: string): "principais" | "demais" =>
        id === "urna" || id === "roupa" || id === "coroa_flores" || id.startsWith("coroa") ? "principais" : "demais";
    const passosOrdenados = useMemo(() => {
        if (!ehPassoItens) return grupoSteps;
        const rank = (id: string) => (secaoDoPasso(id) === "principais" ? 0 : 1);
        return grupoSteps
            .map((s, i) => ({ s, i }))
            .sort((a, b) => rank(a.s.id) - rank(b.s.id) || a.i - b.i)
            .map((x) => x.s);
    }, [grupoSteps, ehPassoItens]);

    const assistenciaNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "assistencia"), [grupoSteps]);
    const urnaNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "urna"), [grupoSteps]);
    const roupaNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "roupa"), [grupoSteps]);
    const involNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "invol"), [grupoSteps]);
    const involItemNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "invol_item"), [grupoSteps]);
    const veuNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "veu"), [grupoSteps]);
    const veuItemNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "veu_item"), [grupoSteps]);
    const cordaoNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "cordao"), [grupoSteps]);
    const cordaoItemNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "cordao_item"), [grupoSteps]);
    const tanatoNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "tanato"), [grupoSteps]);
    const ornamentacaoNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "ornamentacao"), [grupoSteps]);
    const involSelectNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "invol"), [grupoSteps]);
    const veuSelectNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "veu"), [grupoSteps]);
    const cordaoSelectNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "cordao"), [grupoSteps]);
    const kitLancheNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "kit_lanche"), [grupoSteps]);
    const coroaFloresNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "coroa_flores"), [grupoSteps]);
    const coroaModeloNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "coroa_modelo"), [grupoSteps]);
    const realizaVelorioNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "realiza_velorio"), [grupoSteps]);
    const realizaSepultamentoNoGrupoAtual = useMemo(() => grupoSteps.some((s) => s.id === "realiza_sepultamento"), [grupoSteps]);
    const velorioOnlineNoGrupoAtual = useMemo(
        () => grupoSteps.some((s) => s.id === "local_velorio" || s.id === "sala_velorio" || s.id === "velorio_online"),
        [grupoSteps]
    );

    const validarAssistencia = () => {
        if (!requireAssistencia) return true;
        if (isSimNao(assistenciaVal)) {
            setAssistenciaErro("");
            return true;
        }
        setAssistenciaErro('Selecione "Sim" ou "Não".');
        return false;
    };

    const bloqueiaPorAssistencia = requireAssistencia && assistenciaNoGrupoAtual && !isSimNao(assistenciaVal);

    // ✅ validações "Sim/Não" para selects obrigatórios
    const validarTanatoSelect = () => {
        if (!tanatoNoGrupoAtual) return true;
        if (!isRequired("tanato")) return true;

        if (isSimNao(tanatoVal)) {
            setTanatoSelectErro("");
            return true;
        }
        setTanatoSelectErro('Selecione "Sim" ou "Não".');
        return false;
    };

    const validarOrnamentacaoSelect = () => {
        if (!ornamentacaoNoGrupoAtual) return true;
        if (!isRequired("ornamentacao")) return true;

        if (isSimNao(ornamentacaoVal)) {
            setOrnamentacaoSelectErro("");
            return true;
        }
        setOrnamentacaoSelectErro('Selecione "Sim" ou "Não".');
        return false;
    };

    const validarInvolSelect = () => {
        if (!involSelectNoGrupoAtual) return true;
        if (!isRequired("invol")) return true;

        if (isSimNao(involVal)) {
            setInvolSelectErro("");
            return true;
        }
        setInvolSelectErro('Selecione "Sim" ou "Não".');
        return false;
    };

    const validarVeuSelect = () => {
        if (!veuSelectNoGrupoAtual) return true;
        if (!isRequired("veu")) return true;

        if (isSimNao(veuVal)) {
            setVeuSelectErro("");
            return true;
        }
        setVeuSelectErro('Selecione "Sim" ou "Não".');
        return false;
    };

    const validarCordaoSelect = () => {
        if (!cordaoSelectNoGrupoAtual) return true;
        if (!isRequired("cordao")) return true;

        if (isSimNao(cordaoVal)) {
            setCordaoSelectErro("");
            return true;
        }
        setCordaoSelectErro('Selecione "Sim" ou "Não".');
        return false;
    };

    const validarKitLancheSelect = () => {
        if (!kitLancheNoGrupoAtual) return true;
        if (!isRequired("kit_lanche")) return true;

        if (isSimNao(kitLancheVal)) {
            setKitLancheSelectErro("");
            return true;
        }

        setKitLancheSelectErro('Selecione "Sim" ou "Não".');
        return false;
    };

    const validarCoroaSeNecessario = () => {
        if (!coroaFloresNoGrupoAtual && !coroaModeloNoGrupoAtual) return true;
        // Registros legados podem ter o campo vazio e não devem ser bloqueados.
        // Porém, se o usuário marcou explicitamente "Sim", os itens da coroa
        // precisam ser validados mesmo quando a obrigatoriedade global está inativa.
        if (!isRequired("coroa_flores") && coroaFloresVal !== "Sim") {
            setCoroaFloresSelectErro("");
            setCoroaTipoErro("");
            setCoroaModeloErro("");
            return true;
        }

        if (!isSimNao(coroaFloresVal)) {
            setCoroaFloresSelectErro('Selecione "Sim" ou "Não".');
            return false;
        }
        setCoroaFloresSelectErro("");

        if (coroaFloresVal !== "Sim") {
            setCoroaTipoErro("");
            setCoroaModeloErro("");
            return true;
        }

        const itens = Array.isArray((wizardData as any).coroas_itens)
            ? ((wizardData as any).coroas_itens as CoroaAtendimentoItem[])
            : [];

        if (itens.length < 1 || itens.length > 20) {
            setCoroaModeloErro("Informe de 1 a 20 coroas para este atendimento.");
            return false;
        }

        for (let i = 0; i < itens.length; i += 1) {
            const item = itens[i];
            if (item.tipo_coroa !== "natural" && item.tipo_coroa !== "artificial") {
                setCoroaModeloErro(`Coroa ${i + 1}: selecione Natural ou Artificial.`);
                return false;
            }
            if (Number(item.produto_id || 0) <= 0 || !String(item.modelo_coroa || "").trim()) {
                setCoroaModeloErro(`Coroa ${i + 1}: selecione o modelo.`);
                return false;
            }
            if (item.tipo_coroa === "artificial") {
                const dep = String(item.deposito_nome || "").trim().toUpperCase();
                if (dep !== "MEMORIAL" && dep !== "FUNERARIA") {
                    setCoroaModeloErro(`Coroa ${i + 1}: selecione MEMORIAL ou FUNERÁRIA.`);
                    return false;
                }
            }
            if (!String(item.frase || "").trim()) {
                setCoroaModeloErro(`Coroa ${i + 1}: preencha a frase.`);
                return false;
            }
        }

        setCoroaTipoErro("");
        setCoroaModeloErro("");
        return true;
    };

    const validarRealizaVelorio = () => {
        if (!realizaVelorioNoGrupoAtual || !isRequired("realiza_velorio")) return true;
        if (isSimNao(realizaVelorioVal)) {
            setRealizaVelorioErro("");
            return true;
        }
        setRealizaVelorioErro('Selecione "Sim" ou "Não" em Velório.');
        return false;
    };

    const validarRealizaSepultamento = () => {
        if (!realizaSepultamentoNoGrupoAtual || !isRequired("realiza_sepultamento")) return true;
        if (isSimNao(realizaSepultamentoVal)) {
            setRealizaSepultamentoErro("");
            return true;
        }
        setRealizaSepultamentoErro('Selecione "Sim" ou "Não" em Sepultamento.');
        return false;
    };

    // ✅ Velório Online é obrigatório somente quando uma sala for marcada.
    const validarVelorioOnlineSeNecessario = () => {
        if (!velorioOnlineNoGrupoAtual) return true;

        // Antes de Corpo na Clínica, o page.tsx envia obrigatorios = [].
        // Nesse cenário, Velório Online não deve bloquear, mesmo se sala estiver marcada.
        if (!obrigatoriedadeAtiva) {
            setVelorioOnlineErro("");
            return true;
        }

        const sala = String(salaVelorioVal || (wizardData as any).sala_velorio || "").trim();
        if (!sala) {
            setVelorioOnlineErro("");
            return true;
        }

        const online = String(velorioOnlineVal || (wizardData as any).velorio_online || "").trim();
        if (online === "Sim" || online === "Não") {
            setVelorioOnlineErro("");
            return true;
        }

        setVelorioOnlineErro('Selecione "Sim" ou "Não" em Velório Online.');
        return false;
    };

    // ✅ se ornamentacao = Sim, exige Natural/Artificial
    const validarOrnamentacaoTipoSeNecessario = () => {
        const tipoNoGrupoAtual = grupoSteps.some((s) => s.id === "ornamentacao_tipo");
        if (!tipoNoGrupoAtual) return true;

        // Só exige Natural/Artificial quando a obrigatoriedade de Ornamentação estiver ativa.
        if (!isRequired("ornamentacao")) {
            setOrnamentacaoTipoErro("");
            return true;
        }

        if (ornamentacaoVal !== "Sim") {
            setOrnamentacaoTipoErro("");
            return true;
        }

        const tipo = String((wizardData as any).ornamentacao_tipo ?? "").trim();
        if (!tipo) {
            setOrnamentacaoTipoErro('Selecione "Natural" ou "Artificial".');
            return false;
        }

        setOrnamentacaoTipoErro("");
        return true;
    };


    // ✅ valida URNA: a escolha visual Sim/Não é obrigatória quando as validações do Wizard estão ativas.
    const validarUrnaSeNecessario = () => {
        if (!urnaNoGrupoAtual) return true;

        if (!obrigatoriedadeAtiva) {
            setUrnaUsoErro("");
            setUrnaErro("");
            return true;
        }

        if (!isSimNao(urnaUsoVal)) {
            setUrnaUsoErro('Marque "Sim" ou "Não" em Urna.');
            setUrnaErro("");
            return false;
        }

        setUrnaUsoErro("");

        if (urnaUsoVal === "Não") {
            setUrnaErro("");
            return true;
        }

        const urnaTxt = String((wizardData as any).urna ?? "").trim();
        const pid = Number((wizardData as any).urna_produto_id ?? 0) || 0;

        if (!urnaTxt || pid <= 0) {
            setUrnaErro("Selecione uma urna da lista (produto do estoque).");
            return false;
        }

        setUrnaErro("");
        return true;
    };

    // ✅ valida ROUPA: a escolha visual Sim/Não é obrigatória quando as validações do Wizard estão ativas.
    const validarRoupaSeNecessario = () => {
        if (!roupaNoGrupoAtual) return true;

        if (!obrigatoriedadeAtiva) {
            setRoupaUsoErro("");
            setRoupaErro("");
            return true;
        }

        if (!isSimNao(roupaUsoVal)) {
            setRoupaUsoErro('Marque "Sim" ou "Não" em Roupa.');
            setRoupaErro("");
            return false;
        }

        setRoupaUsoErro("");

        if (roupaUsoVal === "Não") {
            setRoupaErro("");
            return true;
        }

        const roupaTxt = String((wizardData as any).roupa ?? "").trim();

        if (!roupaTxt) {
            setRoupaErro('Selecione uma roupa da lista (estoque) ou use "ROUPA PRÓPRIA".');
            return false;
        }

        if (isRoupaPropria(roupaTxt)) {
            setRoupaErro("");
            return true;
        }

        const pid = Number((wizardData as any).roupa_produto_id ?? 0) || 0;
        const dep = String((wizardData as any).roupa_deposito_nome ?? "").trim();

        if (pid <= 0) {
            setRoupaErro('Selecione uma roupa da lista (estoque) ou use "ROUPA PRÓPRIA".');
            return false;
        }

        if (!dep) {
            setRoupaErro("Selecione o local de saída da roupa.");
            return false;
        }

        setRoupaErro("");
        return true;
    };

    // ✅ valida INVOL somente quando a obrigatoriedade de INVOL estiver ativa e invol = Sim
    const validarInvolSeNecessario = () => {
        if (!involNoGrupoAtual && !involItemNoGrupoAtual) return true;

        if (!isRequired("invol")) {
            setInvolErro("");
            return true;
        }

        const invol = String((wizardData as any).invol ?? involVal ?? "");
        if (invol !== "Sim") {
            setInvolErro("");
            return true;
        }

        const pid = Number((wizardData as any).invol_produto_id ?? 0) || 0;
        const dep = String((wizardData as any).invol_deposito_nome ?? "").trim();

        if (pid <= 0) {
            setInvolErro("Selecione um INVOL da lista (produto do estoque).");
            return false;
        }

        if (!dep) {
            setInvolErro("Selecione o local do INVOL (ARMARIO SANDRO ou ARMARIO ILDO).");
            return false;
        }

        setInvolErro("");
        return true;
    };

    // ✅ valida VÉU somente quando a obrigatoriedade de VÉU estiver ativa e veu = Sim
    const validarVeuSeNecessario = () => {
        if (!veuNoGrupoAtual && !veuItemNoGrupoAtual) return true;

        if (!isRequired("veu")) {
            setVeuErro("");
            return true;
        }

        const veu = String((wizardData as any).veu ?? veuVal ?? "");
        if (veu !== "Sim") {
            setVeuErro("");
            return true;
        }

        const pid = Number((wizardData as any).veu_produto_id ?? 0) || 0;
        const dep = String((wizardData as any).veu_deposito_nome ?? "").trim();

        if (pid <= 0) {
            setVeuErro("Selecione um VÉU da lista (produto do estoque).");
            return false;
        }

        if (!dep) {
            setVeuErro("Selecione o local do VÉU (ARMARIO SANDRO, ARMARIO ILDO ou FUNERARIA).");
            return false;
        }

        setVeuErro("");
        return true;
    };

    // ✅ valida CORDÃO somente quando a obrigatoriedade de CORDÃO estiver ativa e cordao = Sim
    const validarCordaoSeNecessario = () => {
        if (!cordaoNoGrupoAtual && !cordaoItemNoGrupoAtual) return true;

        if (!isRequired("cordao")) {
            setCordaoErro("");
            return true;
        }

        const cordao = String((wizardData as any).cordao ?? cordaoVal ?? "");
        if (cordao !== "Sim") {
            setCordaoErro("");
            return true;
        }

        const pid = Number((wizardData as any).cordao_produto_id ?? 0) || 0;
        const dep = String((wizardData as any).cordao_deposito_nome ?? "").trim();

        if (pid <= 0) {
            setCordaoErro("Selecione um CORDÃO da lista (produto do estoque).");
            return false;
        }

        if (!dep) {
            setCordaoErro("Selecione o local do CORDÃO (ARMARIO SANDRO, ARMARIO ILDO ou FUNERARIA).");
            return false;
        }

        setCordaoErro("");
        return true;
    };

    // GPS p/ Local do Velório
    const [gpsLoading, setGpsLoading] = useState(false);
    const [gpsMsg, setGpsMsg] = useState<string | null>(null);
    const localVelorioRef = useRef<HTMLInputElement>(null);

    async function preencherLocalVelorioComGPS() {
        setGpsMsg(null);

        if (typeof window === "undefined") return;
        if (!("geolocation" in navigator)) {
            setGpsMsg("Este dispositivo/navegador não suporta GPS (geolocalização).");
            return;
        }

        setGpsLoading(true);

        navigator.geolocation.getCurrentPosition(
            (pos) => {
                const lat = pos.coords.latitude;
                const lng = pos.coords.longitude;
                const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`;

                const el = localVelorioRef.current;
                if (el) el.value = url;

                setGpsMsg("Localização capturada e link gerado!");
                setGpsLoading(false);
            },
            (err) => {
                let msg = "Não foi possível obter a localização.";
                if ((err as any)?.code === 1) msg = "Permissão de localização negada.";
                if ((err as any)?.code === 2) msg = "Localização indisponível no momento (GPS sem sinal).";
                if ((err as any)?.code === 3) msg = "Tempo esgotado ao tentar obter localização.";
                setGpsMsg(msg);
                setGpsLoading(false);
            },
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
        );
    }

    const visibleWizardStepIndexes = useMemo(() => {
        const fluxoFunerarioPadrao = wizardStepTitles[1] === "Itens" && wizardStepIndexes.length >= 4;

        return wizardStepIndexes
            .map((_, index) => index)
            .filter((index) => {
                // Somente no fluxo funerário padrão: grupo 2 = Velório, grupo 3 = Sepultamento.
                // Campo vazio mantém as abas visíveis por compatibilidade com registros antigos.
                if (fluxoFunerarioPadrao && index === 2 && realizaVelorioVal === "Não") return false;
                if (fluxoFunerarioPadrao && index === 3 && realizaSepultamentoVal === "Não") return false;
                return true;
            });
    }, [wizardStepIndexes, wizardStepTitles, realizaVelorioVal, realizaSepultamentoVal]);

    const isLastStep = wizardStep === visibleWizardStepIndexes[visibleWizardStepIndexes.length - 1];

    const goPrev = () => {
        if (wizardSubmitting) return;
        const pos = visibleWizardStepIndexes.indexOf(wizardStep);
        const prev = pos > 0 ? visibleWizardStepIndexes[pos - 1] : visibleWizardStepIndexes[0] ?? 0;
        setWizardStep(prev);
    };

    // Edição: as abas são livres. Antes de trocar, guarda o que foi digitado na aba atual (os campos são lidos do formulário).
    const irParaAba = (i: number) => {
        if (wizardSubmitting || i === wizardStep) return;
        const ok = salvarGrupoWizard();
        if (!ok) return;
        setWizardStep(i);
    };

    const scrollToFirstError = () => {
        const el =
            (document.querySelector('[data-wizard-error="1"]') as HTMLElement | null) ||
            (document.querySelector(".border-red-500") as HTMLElement | null);

        if (!el) return;

        // ✅ no mobile: evita smooth (reduz bug “tela branca”/repaint)
        const mobile = isMobileCoarsePointer();
        el.scrollIntoView({ behavior: mobile ? "auto" : "smooth", block: "center" });

        // ✅ no mobile: não força focus (teclado/reflow)
        if (!mobile) {
            requestAnimationFrame(() => {
                (el as any)?.focus?.();
            });
        }
    };


    /** Validação da aba atual que falhou: aviso no rodapé com o nome do campo, além do destaque e da rolagem até ele. */
    const ROTULO_VALIDACAO: Record<string, [string, string]> = {
        validarAssistencia: ["Assistência", "assistencia"],
        validarTanatoSelect: ["Tanatopraxia", "tanato"],
        validarOrnamentacaoSelect: ["Ornamentação", "ornamentacao"],
        validarOrnamentacaoTipoSeNecessario: ["Tipo de ornamentação", "ornamentacao_tipo"],
        validarInvolSelect: ["Invol", "invol"],
        validarVeuSelect: ["Véu", "veu"],
        validarCordaoSelect: ["Cordão", "cordao"],
        validarKitLancheSelect: ["Kit lanche", "kit_lanche"],
        validarCoroaSeNecessario: ["Coroa de flores", "coroa_flores"],
        validarRealizaVelorio: ["Velório (Sim ou Não)", "realiza_velorio"],
        validarRealizaSepultamento: ["Sepultamento (Sim ou Não)", "realiza_sepultamento"],
        validarVelorioOnlineSeNecessario: ["Velório online", "velorio_online"],
        validarUrnaSeNecessario: ["Urna", "urna"],
        validarRoupaSeNecessario: ["Roupa", "roupa"],
        validarVeuSeNecessario: ["Véu (item do estoque)", "veu_item"],
        validarCordaoSeNecessario: ["Cordão (item do estoque)", "cordao_item"],
        validarInvolSeNecessario: ["Invol (item do estoque)", "invol_item"],
    };
    const [avisoLocal, setAvisoLocal] = useState<{ text: string; ok: boolean; faltando?: CampoFaltando[] } | null>(null);
    const avisarCampo = (validador: string) => {
        const [rotulo, id] = ROTULO_VALIDACAO[validador] ?? ["Campo obrigatório", ""];
        const abaTitulo = String(wizardStepTitles[wizardStep] ?? "");
        setAvisoLocal({ text: `Não foi possível salvar. Falta preencher: ${rotulo}.`, ok: false, faltando: [{ id, rotulo, aba: wizardStep, abaTitulo }] });
        scrollToFirstError();
    };

    const goNext = () => {
        if (wizardSubmitting) return;
        setAvisoLocal(null);

        if (assistenciaNoGrupoAtual && !validarAssistencia()) {
            avisarCampo("validarAssistencia");
            return;
        }

        if (!validarTanatoSelect()) {
            avisarCampo("validarTanatoSelect");
            return;
        }
        if (!validarOrnamentacaoSelect()) {
            avisarCampo("validarOrnamentacaoSelect");
            return;
        }
        if (!validarOrnamentacaoTipoSeNecessario()) {
            avisarCampo("validarOrnamentacaoTipoSeNecessario");
            return;
        }
        if (!validarInvolSelect()) {
            avisarCampo("validarInvolSelect");
            return;
        }
        if (!validarVeuSelect()) {
            avisarCampo("validarVeuSelect");
            return;
        }
        if (!validarCordaoSelect()) {
            avisarCampo("validarCordaoSelect");
            return;
        }
        if (!validarKitLancheSelect()) {
            avisarCampo("validarKitLancheSelect");
            return;
        }
        if (!validarCoroaSeNecessario()) {
            avisarCampo("validarCoroaSeNecessario");
            return;
        }
        if (!validarRealizaVelorio()) {
            avisarCampo("validarRealizaVelorio");
            return;
        }
        if (!validarRealizaSepultamento()) {
            avisarCampo("validarRealizaSepultamento");
            return;
        }
        if (!validarVelorioOnlineSeNecessario()) {
            avisarCampo("validarVelorioOnlineSeNecessario");
            return;
        }

        if (!validarUrnaSeNecessario()) {
            avisarCampo("validarUrnaSeNecessario");
            return;
        }
        if (!validarRoupaSeNecessario()) {
            avisarCampo("validarRoupaSeNecessario");
            return;
        }
        if (!validarVeuSeNecessario()) {
            avisarCampo("validarVeuSeNecessario");
            return;
        }
        if (!validarCordaoSeNecessario()) {
            avisarCampo("validarCordaoSeNecessario");
            return;
        }
        if (!validarInvolSeNecessario()) {
            avisarCampo("validarInvolSeNecessario");
            return;
        }

        const ok = salvarGrupoWizard();
        if (!ok) return;
        if (!isLastStep) {
            const pos = visibleWizardStepIndexes.indexOf(wizardStep);
            const next = pos >= 0 ? visibleWizardStepIndexes[pos + 1] : undefined;
            if (typeof next === "number") setWizardStep(next);
        }
    };

    const tentarConcluir = async () => {
        if (wizardSubmitting) return;
        setAvisoLocal(null);
        onFecharAviso?.();

        if (assistenciaNoGrupoAtual && !validarAssistencia()) {
            avisarCampo("validarAssistencia");
            return;
        }

        if (!validarTanatoSelect()) {
            avisarCampo("validarTanatoSelect");
            return;
        }
        if (!validarOrnamentacaoSelect()) {
            avisarCampo("validarOrnamentacaoSelect");
            return;
        }
        if (!validarOrnamentacaoTipoSeNecessario()) {
            avisarCampo("validarOrnamentacaoTipoSeNecessario");
            return;
        }

        if (!validarInvolSelect()) {
            avisarCampo("validarInvolSelect");
            return;
        }
        if (!validarVeuSelect()) {
            avisarCampo("validarVeuSelect");
            return;
        }
        if (!validarCordaoSelect()) {
            avisarCampo("validarCordaoSelect");
            return;
        }
        if (!validarKitLancheSelect()) {
            avisarCampo("validarKitLancheSelect");
            return;
        }
        if (!validarCoroaSeNecessario()) {
            avisarCampo("validarCoroaSeNecessario");
            return;
        }
        if (!validarRealizaVelorio()) {
            avisarCampo("validarRealizaVelorio");
            return;
        }
        if (!validarRealizaSepultamento()) {
            avisarCampo("validarRealizaSepultamento");
            return;
        }
        if (!validarVelorioOnlineSeNecessario()) {
            avisarCampo("validarVelorioOnlineSeNecessario");
            return;
        }

        if (!validarUrnaSeNecessario()) {
            avisarCampo("validarUrnaSeNecessario");
            return;
        }
        if (!validarRoupaSeNecessario()) {
            avisarCampo("validarRoupaSeNecessario");
            return;
        }
        if (!validarVeuSeNecessario()) {
            avisarCampo("validarVeuSeNecessario");
            return;
        }
        if (!validarCordaoSeNecessario()) {
            avisarCampo("validarCordaoSeNecessario");
            return;
        }
        if (!validarInvolSeNecessario()) {
            avisarCampo("validarInvolSeNecessario");
            return;
        }

        try {
            await concluirWizard();
        } catch (e: any) {
            console.error("Falha ao concluir wizard:", e);
            alert(e?.message || "Erro ao salvar. Veja o console/Network.");
        }
    };

    // Rascunho do registro para a prévia da OS em tempo real: tudo o que está na tela agora, sem consultar o banco.
    const rascunhoOS = useMemo(
        () =>
            montarRascunhoOS(wizardData as any, osCampos ?? OS_CAMPOS_VAZIO, {
                urnaUso: urnaUsoVal, roupaUso: roupaUsoVal, veu: veuVal, cordao: cordaoVal, invol: involVal, kitLanche: kitLancheVal,
                assistencia: assistenciaVal, tanato: tanatoVal, ornamentacao: ornamentacaoVal, coroaFlores: coroaFloresVal,
                realizaVelorio: realizaVelorioVal, realizaSepultamento: realizaSepultamentoVal,
            }),
        [wizardData, osCampos, urnaUsoVal, roupaUsoVal, veuVal, cordaoVal, involVal, kitLancheVal, assistenciaVal, tanatoVal, ornamentacaoVal, coroaFloresVal, realizaVelorioVal, realizaSepultamentoVal],
    );

    if (!open) return null;

    const editandoCompleto = !isRestrito; // layout do mockup: Novo registro e Editar registro
    // Registro em edição: o que a página informa; na falta disso, os próprios dados do formulário quando já têm id
    // (assim o layout de edição aparece mesmo que a página não repasse o registro).
    const registroAtual: Registro | null =
        registroEdicao ?? (String((wizardData as any)?.id ?? "").trim() !== "" ? (wizardData as Registro) : null);
    const emEdicao = !!registroAtual;
    const proximaTxt = registroAtual ? proximaEtapaDoRegistro(registroAtual) : "—";

    return (
        <RascunhoOSContext.Provider value={rascunhoOS}>
            <Modal
                open={open}
                onClose={onClose}
                ariaLabel="Wizard"
                maxWidth={editandoCompleto ? 1140 : 740}
                aside={
                    editandoCompleto ? (
                        <PainelEdicao registro={registroAtual} proxima={proximaTxt} onDocumento={onAbrirDocumento} onRegistrarAcao={onRegistrarAcaoEdicao} resumoOS={osLateralSlot} />
                    ) : undefined
                }
                footer={
                    <>
                        {avisoLocal || aviso ? (
                            <AvisoRodape
                                aviso={(avisoLocal || aviso)!}
                                onFechar={() => (avisoLocal ? setAvisoLocal(null) : onFecharAviso?.())}
                                onIr={(c) => {
                                    if (!isRestrito && c.aba != null) setWizardStep(c.aba);
                                    // espera a aba aparecer e leva o operador até o campo
                                    window.setTimeout(() => {
                                        const el = document.getElementById("wizard-" + c.id) || document.querySelector<HTMLElement>(`[data-campo="${c.id}"]`);
                                        el?.scrollIntoView({ behavior: "smooth", block: "center" });
                                        (el as HTMLElement | null)?.focus?.({ preventScroll: true });
                                    }, 80);
                                }}
                            />
                        ) : null}
                        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                            <div className="text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                                {isRestrito && (
                                    <>
                                        Editando apenas: <b>{wizardStepTitles[wizardRestrictGroup!]}</b>
                                    </>
                                )}
                            </div>

                            <div className="flex w-full justify-end gap-2 sm:w-auto">
                                <button className="rounded-xl border-[1.5px] px-4 py-2.5 text-sm font-bold disabled:opacity-60 border-[#313C55] text-[#313C55] hover:bg-[#EEF2F7] dark:border-white/40 dark:text-white dark:hover:bg-white/10" onClick={onClose} disabled={wizardSubmitting}>
                                    Cancelar
                                </button>

                                {isRestrito || editandoCompleto ? (
                                    <button
                                        className="rounded-xl bg-[#313C55] dark:bg-[#F2CB3F] px-5 py-2.5 text-sm font-extrabold text-white dark:text-[#313C55] hover:bg-[#232B40] dark:hover:bg-[#E4BC30] disabled:opacity-60"
                                        onClick={tentarConcluir}
                                        disabled={wizardSubmitting || bloqueiaPorAssistencia}
                                        aria-busy={wizardSubmitting}
                                        title={bloqueiaPorAssistencia ? 'Selecione "Sim" ou "Não" em Assistência' : undefined}
                                    >
                                        {wizardSubmitting ? "Salvando…" : emEdicao && !isRestrito ? "Salvar alterações" : "Salvar"}
                                    </button>
                                ) : (
                                    <>
                                        {wizardStep > 0 && (
                                            <button className="rounded-xl border-[1.5px] px-4 py-2.5 text-sm font-bold disabled:opacity-60 border-[#313C55] text-[#313C55] hover:bg-[#EEF2F7] dark:border-white/40 dark:text-white dark:hover:bg-white/10" onClick={goPrev} disabled={wizardSubmitting}>
                                                Anterior
                                            </button>
                                        )}
                                        {isLastStep ? (
                                            <button
                                                className="rounded-xl bg-[#313C55] dark:bg-[#F2CB3F] px-5 py-2.5 text-sm font-extrabold text-white dark:text-[#313C55] hover:bg-[#232B40] dark:hover:bg-[#E4BC30] disabled:opacity-60"
                                                onClick={tentarConcluir}
                                                disabled={wizardSubmitting || bloqueiaPorAssistencia}
                                                aria-busy={wizardSubmitting}
                                                title={bloqueiaPorAssistencia ? 'Selecione "Sim" ou "Não" em Assistência' : undefined}
                                            >
                                                {wizardSubmitting ? "Salvando…" : "Concluir"}
                                            </button>
                                        ) : (
                                            <button
                                                className="rounded-xl bg-[#313C55] dark:bg-[#F2CB3F] px-5 py-2.5 text-sm font-extrabold text-white dark:text-[#313C55] hover:bg-[#232B40] dark:hover:bg-[#E4BC30] disabled:opacity-60"
                                                onClick={goNext}
                                                disabled={wizardSubmitting || bloqueiaPorAssistencia}
                                                title={bloqueiaPorAssistencia ? 'Selecione "Sim" ou "Não" em Assistência' : undefined}
                                            >
                                                Próximo
                                            </button>
                                        )}
                                    </>
                                )}
                            </div>
                        </div>
                    </>
                }
            >
                <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
                    <div className="min-w-0 flex-1">
                        <h2 className={editandoCompleto ? "text-2xl font-extrabold leading-tight text-[#313C55] dark:text-white sm:text-[28px]" : "text-xl font-extrabold text-[#313C55] dark:text-white"}>
                            {wizardTitle}
                        </h2>
                        {editandoCompleto && (
                            <p className="mt-1 text-sm text-[#5B6478] dark:text-[#AEB9CF]">
                                {emEdicao ? `${String((registroAtual as any)?.falecido || "").trim() || "Atendimento"} · ` : ""}preencha as abas e conclua.
                            </p>
                        )}
                    </div>
                    {editandoCompleto && emEdicao && proximaTxt !== "—" && (
                        <span className="inline-flex h-8 items-center gap-2 rounded-2xl bg-[#E9EFF6] px-3.5 text-[13px] font-bold text-[#313C55] dark:bg-[#3D6A99]/20 dark:text-white">
                            <span className="size-2 rounded-full bg-[#3D6A99]" />
                            Aguardando {proximaTxt}
                        </span>
                    )}
                    {wizardSubmitting && (
                        <span
                            className="ml-1 inline-flex items-center gap-1 rounded-full bg-[#E9EFF6] dark:bg-[#3D6A99]/20 px-2 py-0.5 text-xs text-[#313C55] dark:text-white"
                            aria-live="polite"
                        >
                            <svg className="h-3 w-3 animate-spin text-[#313C55] dark:text-white" viewBox="0 0 24 24" fill="none">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                            </svg>
                            Salvando…
                        </span>
                    )}
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                    {visibleWizardStepIndexes.map((i) => {
                        const t = wizardStepTitles[i];
                        if (!t) return null;
                        const ativa = i === wizardStep;
                        const classe = `inline-flex items-center rounded-full border-[1.5px] font-bold ${editandoCompleto ? "h-11 px-5 text-sm" : "px-3 py-1 text-xs"} ${ativa ? "border-[#313C55] bg-[#313C55] text-white dark:border-[#3D6A99] dark:bg-[#3D6A99] dark:text-white" : "border-[#C9D1DE] bg-white text-[#313C55] dark:border-white/25 dark:bg-transparent dark:text-[#D6DCE8]"}`;
                        // Novo registro e Editar registro: a aba é um botão (troca livre). A validação completa fica no Salvar.
                        return editandoCompleto ? (
                            <button
                                key={`${t}-${i}`}
                                type="button"
                                onClick={() => irParaAba(i)}
                                disabled={wizardSubmitting}
                                aria-current={ativa ? "step" : undefined}
                                className={`${classe} ${ativa ? "" : "hover:bg-[#EEF2F7] dark:hover:bg-white/10"} disabled:opacity-60`}
                            >
                                {t}
                            </button>
                        ) : (
                            <span key={`${t}-${i}`} className={classe}>
                                {t}
                            </span>
                        );
                    })}
                </div>

                {ehPassoItens && travaItens && (
                    <AvisoTravaItens podeAlterar={travaItens.podeAlterar} baixaFeita={travaItens.baixaFeita} />
                )}

                <div
                    className={
                        ehPassoItens
                            ? "mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 sm:[&>*]:col-span-2"
                            : "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2"
                    }
                >
                    {(() => {
                        let secaoAtual = "";
                        return passosOrdenados.map((step) => {
                            const conteudo = ((): React.ReactNode => {
                                if (step.id === "ornamentacao_tipo" && ornamentacaoVal !== "Sim") return null;
                                if (step.id === "arrumacao" && tanatoVal !== "Sim") return null;
                                // Os campos legados coroa_tipo/coroa_modelo não são mais renderizados: a configuração
                                // completa de 1..20 coroas fica no editor abaixo de Coroa de Flores.
                                if (step.id === "coroa_tipo" || step.id === "coroa_modelo" || step.id === "coroas_itens") return null;

                                // Convênio ligado ao cadastro de Convênios (pacote + autorização da Prefeitura).
                                if (step.id === "convenio" && convenioSlot) {
                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            {convenioSlot}
                                        </div>
                                    );
                                }

                                if (step.id === "falecido" && falecidoSlot) {
                                    return <div key={step.id} className="sm:col-span-2">{falecidoSlot}</div>;
                                }

                                /* ===========================
                                   URNA (checkbox Sim/Não + seletor async)
                                   =========================== */
                                if (step.type === "async_urna" && step.id === "urna") {
                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        Urna
                                                        {obrigatoriedadeAtiva && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId="wizard-urna-uso"
                                                ariaLabel="Urna"
                                                value={urnaUsoVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!urnaUsoErro}
                                                onChange={(v) => {
                                                    setUrnaUsoVal(v);
                                                    setUrnaUsoErro("");

                                                    if (v === "Não") {
                                                        setWizardData((prev: any) => ({
                                                            ...prev,
                                                            urna: "",
                                                            urna_deposito_nome: "",
                                                            urna_produto_id: 0,
                                                            urna_codigo_barras: "",
                                                        }));
                                                        setUrnaErro("");
                                                        return;
                                                    }

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        urna_deposito_nome:
                                                            String(prev?.urna_deposito_nome ?? "").trim() || depUrna,
                                                    }));
                                                }}
                                            />

                                            {urnaUsoErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{urnaUsoErro}</div>}

                                            {urnaUsoVal === "Sim" && (
                                                <div className="mt-3">
                                                    <EstoqueCombobox
                                                        inputId="wizard-urna"
                                                        label="Urna para selecionar"
                                                        required={obrigatoriedadeAtiva}
                                                        placeholder={step.placeholder || "Selecione no estoque…"}
                                                        initialValue={String((wizardData as any).urna ?? "")}
                                                        disabled={wizardSubmitting}
                                                        depositoLabel="Local da Urna"
                                                        depositoOptions={[
                                                            { value: "MEMORIAL", label: "MEMORIAL" },
                                                            { value: "FUNERARIA", label: "FUNERARIA" },
                                                        ]}
                                                        depositoValue={depUrna}
                                                        onChangeDeposito={(v) => {
                                                            const next = normalizeDepUrna(v);
                                                            setDepUrna(next);

                                                            setWizardData((prev: any) => ({
                                                                ...prev,
                                                                urna: "",
                                                                urna_deposito_nome: next,
                                                                urna_produto_id: 0,
                                                                urna_codigo_barras: "",
                                                            }));

                                                            validarUrnaSeNecessario();
                                                        }}
                                                        action="urnas_buscar"
                                                        errorText={urnaErro}
                                                        onBlurValidate={validarUrnaSeNecessario}
                                                        onTypingInvalidate={(typed) => {
                                                            setWizardData((prev: any) => ({
                                                                ...prev,
                                                                urna: typed,
                                                                urna_deposito_nome: depUrna,
                                                                urna_produto_id: 0,
                                                                urna_codigo_barras: "",
                                                            }));
                                                        }}
                                                        onSelectRow={(it) => {
                                                            const pid = getPidFromRow(it);
                                                            const cb = String((it as any).codigo_barras || "").trim();

                                                            setWizardData((prev: any) => ({
                                                                ...prev,
                                                                urna: String(it.nome || "").trim(),
                                                                urna_deposito_nome: depUrna,
                                                                urna_produto_id: pid,
                                                                urna_codigo_barras: cb,
                                                            }));

                                                            setUrnaErro("");
                                                        }}
                                                    />
                                                </div>
                                            )}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   ROUPA (checkbox Sim/Não + seletor async)
                                   =========================== */
                                if (step.type === "async_roupa" && step.id === "roupa") {
                                    const roupaAtual = String((wizardData as any).roupa ?? "");
                                    const isPropria = isRoupaPropria(roupaAtual);

                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        Roupa
                                                        {obrigatoriedadeAtiva && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId="wizard-roupa-uso"
                                                ariaLabel="Roupa"
                                                value={roupaUsoVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!roupaUsoErro}
                                                onChange={(v) => {
                                                    setRoupaUsoVal(v);
                                                    setRoupaUsoErro("");

                                                    if (v === "Não") {
                                                        setWizardData((prev: any) => ({
                                                            ...prev,
                                                            roupa: "",
                                                            roupa_deposito_nome: "",
                                                            roupa_produto_id: 0,
                                                            roupa_codigo_barras: "",
                                                            roupa_propria: 0,
                                                        }));
                                                        setRoupaErro("");
                                                        return;
                                                    }

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        roupa_deposito_nome:
                                                            isRoupaPropria(prev?.roupa)
                                                                ? ""
                                                                : String(prev?.roupa_deposito_nome ?? "").trim() || depRoupa,
                                                    }));
                                                }}
                                            />

                                            {roupaUsoErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{roupaUsoErro}</div>}

                                            {roupaUsoVal === "Sim" && (
                                                <div className="mt-3">
                                                    <EstoqueCombobox
                                                        inputId="wizard-roupa"
                                                        label="Roupa para selecionar"
                                                        required={obrigatoriedadeAtiva}
                                                        placeholder={step.placeholder || 'Selecione no estoque ou use "ROUPA PRÓPRIA"'}
                                                        initialValue={String((wizardData as any).roupa ?? "")}
                                                        disabled={wizardSubmitting}
                                                        depositoLabel="Local da Roupa"
                                                        depositoOptions={[
                                                            { value: "ARMARIO SANDRO", label: "ARMARIO SANDRO" },
                                                            { value: "ARMARIO ILDO", label: "ARMARIO ILDO" },
                                                            { value: "FUNERARIA", label: "FUNERARIA" },
                                                        ]}
                                                        depositoValue={depRoupa}
                                                        onChangeDeposito={(v) => {
                                                            const next = normalizeDepRoupa(v);
                                                            setDepRoupa(next);

                                                            if (isRoupaPropria((wizardData as any).roupa)) return;

                                                            setWizardData((prev: any) => ({
                                                                ...prev,
                                                                roupa: "",
                                                                roupa_deposito_nome: next,
                                                                roupa_produto_id: 0,
                                                                roupa_codigo_barras: "",
                                                            }));

                                                            validarRoupaSeNecessario();
                                                        }}
                                                        action="roupas_buscar"
                                                        errorText={roupaErro}
                                                        onBlurValidate={validarRoupaSeNecessario}
                                                        onTypingInvalidate={(typed) => {
                                                            if (typed && isRoupaPropria(typed)) {
                                                                setWizardData((prev: any) => ({
                                                                    ...prev,
                                                                    roupa: "ROUPA PRÓPRIA",
                                                                    roupa_deposito_nome: "",
                                                                    roupa_produto_id: 0,
                                                                    roupa_codigo_barras: "",
                                                                }));
                                                                setRoupaErro("");
                                                                return;
                                                            }

                                                            setWizardData((prev: any) => ({
                                                                ...prev,
                                                                roupa: typed,
                                                                roupa_deposito_nome: depRoupa,
                                                                roupa_produto_id: 0,
                                                                roupa_codigo_barras: "",
                                                            }));
                                                        }}
                                                        onSelectRow={(it) => {
                                                            const pid = getPidFromRow(it);
                                                            const cb = String((it as any).codigo_barras || "").trim();

                                                            setWizardData((prev: any) => ({
                                                                ...prev,
                                                                roupa: String(it.nome || "").trim(),
                                                                roupa_deposito_nome: depRoupa,
                                                                roupa_produto_id: pid,
                                                                roupa_codigo_barras: cb,
                                                                roupa_propria: 0,
                                                            }));

                                                            setRoupaErro("");
                                                        }}
                                                        extraButtons={
                                                            <>
                                                                <button
                                                                    type="button"
                                                                    className={`${BTN_SEC_CLS}`}
                                                                    disabled={wizardSubmitting}
                                                                    onClick={() => {
                                                                        setWizardData((prev: any) => ({
                                                                            ...prev,
                                                                            roupa: "ROUPA PRÓPRIA",
                                                                            roupa_deposito_nome: "",
                                                                            roupa_produto_id: 0,
                                                                            roupa_codigo_barras: "",
                                                                            roupa_propria: 1,
                                                                        }));

                                                                        const el = document.getElementById("wizard-roupa") as HTMLInputElement | null;
                                                                        if (el) {
                                                                            el.value = "ROUPA PRÓPRIA";
                                                                            el.dispatchEvent(new Event("input", { bubbles: true }));
                                                                            el.dispatchEvent(new Event("change", { bubbles: true }));
                                                                            el.blur();
                                                                        }

                                                                        setRoupaErro("");
                                                                        requestAnimationFrame(() => validarRoupaSeNecessario());
                                                                    }}
                                                                >
                                                                    Usar ROUPA PRÓPRIA
                                                                </button>

                                                                {isPropria ? (
                                                                    <span className="self-center text-[11px] text-[#5B6478] dark:text-[#AEB9CF]">
                                                                        Roupa própria não usa estoque.
                                                                    </span>
                                                                ) : null}
                                                            </>
                                                        }
                                                    />
                                                </div>
                                            )}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   VÉU (checkbox Sim/Não)
                                   =========================== */
                                if (step.id === "veu" && step.type === "select") {
                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        {step.label}
                                                        {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId={`wizard-${step.id}`}
                                                ariaLabel={step.label}
                                                value={veuVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!(veuSelectErro || veuErro)}
                                                onChange={(v) => {
                                                    setVeuVal(v);

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        veu: v,
                                                        ...(v !== "Sim"
                                                            ? {
                                                                veu_deposito_nome: "",
                                                                veu_produto_id: 0,
                                                                veu_codigo_barras: "",
                                                                veu_item: "",
                                                            }
                                                            : {}),
                                                    }));

                                                    setVeuSelectErro("");
                                                    if (v !== "Sim") setVeuErro("");
                                                }}
                                            />

                                            {veuSelectErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{veuSelectErro}</div>}
                                            {veuErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{veuErro}</div>}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   VÉU ITEM (async) - só se veu=Sim
                                   =========================== */
                                if (step.type === "async_veu" && step.id === "veu_item") {
                                    if (veuVal !== "Sim") return null;

                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <EstoqueCombobox
                                                inputId="wizard-veu_item"
                                                label="VÉU (estoque)"
                                                required={isRequired("veu")}
                                                placeholder={step.placeholder || "Selecione no estoque…"}
                                                initialValue={String((wizardData as any).veu_item ?? "")}
                                                disabled={wizardSubmitting}
                                                depositoLabel="Local do VÉU"
                                                depositoOptions={[
                                                    { value: "ARMARIO SANDRO", label: "ARMARIO SANDRO" },
                                                    { value: "ARMARIO ILDO", label: "ARMARIO ILDO" },
                                                    { value: "FUNERARIA", label: "FUNERARIA" },
                                                ]}
                                                depositoValue={depVeu}
                                                onChangeDeposito={(v) => {
                                                    const next = normalizeDepVeu(v);
                                                    setDepVeu(next);
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        veu_item: "",
                                                        veu_deposito_nome: next,
                                                        veu_produto_id: 0,
                                                        veu_codigo_barras: "",
                                                    }));
                                                    validarVeuSeNecessario();
                                                }}
                                                action="veus_buscar"
                                                errorText={veuErro}
                                                onBlurValidate={validarVeuSeNecessario}
                                                onTypingInvalidate={(typed) => {
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        veu_item: typed,
                                                        veu_deposito_nome: depVeu,
                                                        veu_produto_id: 0,
                                                        veu_codigo_barras: "",
                                                    }));
                                                }}
                                                onSelectRow={(it) => {
                                                    const pid = getPidFromRow(it);
                                                    const cb = String((it as any).codigo_barras || "").trim();

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        veu: "Sim",
                                                        veu_item: String(it.nome || "").trim(),
                                                        veu_deposito_nome: depVeu,
                                                        veu_produto_id: pid,
                                                        veu_codigo_barras: cb,
                                                    }));

                                                    setVeuErro("");
                                                }}
                                            />
                                        </div>
                                    );
                                }

                                /* ===========================
                                   CORDÃO (checkbox Sim/Não)
                                   =========================== */
                                if (step.id === "cordao" && step.type === "select") {
                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        {step.label}
                                                        {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId={`wizard-${step.id}`}
                                                ariaLabel={step.label}
                                                value={cordaoVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!(cordaoSelectErro || cordaoErro)}
                                                onChange={(v) => {
                                                    setCordaoVal(v);

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        cordao: v,
                                                        ...(v !== "Sim"
                                                            ? {
                                                                cordao_deposito_nome: "",
                                                                cordao_produto_id: 0,
                                                                cordao_codigo_barras: "",
                                                                cordao_item: "",
                                                            }
                                                            : {}),
                                                    }));

                                                    setCordaoSelectErro("");
                                                    if (v !== "Sim") setCordaoErro("");
                                                }}
                                            />

                                            {cordaoSelectErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{cordaoSelectErro}</div>}
                                            {cordaoErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{cordaoErro}</div>}
                                        </div>
                                    );
                                }


                                /* ===========================
                                   KIT LANCHE (checkbox Sim/Não)
                                   Produto fixo no backend:
                                   código de barras 678560, depósito MEMORIAL.
                                   =========================== */
                                if (step.id === "kit_lanche" && step.type === "select") {
                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        {step.label}
                                                        {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId="wizard-kit_lanche"
                                                ariaLabel="KIT LANCHE"
                                                value={kitLancheVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!kitLancheSelectErro}
                                                onChange={(v) => {
                                                    setKitLancheVal(v);
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        kit_lanche: v,
                                                    }));
                                                    setKitLancheSelectErro("");
                                                }}
                                            />

                                            {kitLancheSelectErro && (
                                                <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{kitLancheSelectErro}</div>
                                            )}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   COROA DE FLORES - múltiplas coroas
                                   =========================== */
                                if (step.id === "coroa_flores" && step.type === "select") {
                                    const itensCoroa = Array.isArray((wizardData as any).coroas_itens)
                                        ? ((wizardData as any).coroas_itens as CoroaAtendimentoItem[])
                                        : [];

                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        {step.label}
                                                        {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId="wizard-coroa_flores"
                                                ariaLabel="Coroa de Flores"
                                                value={coroaFloresVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!coroaFloresSelectErro}
                                                onChange={(v) => {
                                                    setCoroaFloresVal(v);
                                                    setCoroaFloresSelectErro("");
                                                    setCoroaModeloErro("");

                                                    if (v === "Não") {
                                                        setCoroaTipoVal("");
                                                        setWizardData((prev: any) => ({
                                                            ...prev,
                                                            coroa_flores: "Não",
                                                            coroa_tipo: "",
                                                            coroa_produto_id: 0,
                                                            coroa_modelo: "",
                                                            coroa_codigo_barras: "",
                                                            coroa_deposito_nome: "",
                                                            coroas_itens: [],
                                                        }));
                                                        return;
                                                    }

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        coroa_flores: v,
                                                        coroas_itens: Array.isArray(prev?.coroas_itens) && prev.coroas_itens.length
                                                            ? prev.coroas_itens
                                                            : [{
                                                                ordem: 1,
                                                                tipo_coroa: "",
                                                                produto_id: 0,
                                                                modelo_coroa: "",
                                                                codigo_barras: "",
                                                                deposito_nome: "",
                                                                frase: "",
                                                                valor: null,
                                                                foto_produto_url: "",
                                                            }],
                                                    }));
                                                }}
                                            />
                                            {coroaFloresSelectErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{coroaFloresSelectErro}</div>}

                                            {coroaFloresVal === "Sim" && (
                                                <>
                                                    <CoroasAtendimentoEditor
                                                        value={itensCoroa}
                                                        disabled={wizardSubmitting}
                                                        hasError={!!coroaModeloErro}
                                                        onChange={(itens) => {
                                                            const primeiro = itens[0];
                                                            const tipoLegado = primeiro?.tipo_coroa === "natural"
                                                                ? "Natural"
                                                                : primeiro?.tipo_coroa === "artificial"
                                                                    ? "Artificial"
                                                                    : "";
                                                            const modeloResumo = primeiro?.modelo_coroa
                                                                ? `${primeiro.modelo_coroa}${itens.length > 1 ? ` +${itens.length - 1}` : ""}`
                                                                : "";
                                                            setWizardData((prev: any) => ({
                                                                ...prev,
                                                                coroas_itens: itens,
                                                                coroa_tipo: tipoLegado,
                                                                coroa_produto_id: Number(primeiro?.produto_id || 0),
                                                                coroa_modelo: modeloResumo,
                                                                coroa_codigo_barras: String(primeiro?.codigo_barras || ""),
                                                                coroa_deposito_nome: primeiro?.tipo_coroa === "artificial"
                                                                    ? String(primeiro?.deposito_nome || "")
                                                                    : "",
                                                            }));
                                                            setCoroaModeloErro("");
                                                        }}
                                                    />
                                                    {coroaModeloErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{coroaModeloErro}</div>}
                                                    {osCoroaSlot}
                                                </>
                                            )}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   VELÓRIO / SEPULTAMENTO (roteamento)
                                   =========================== */
                                if (step.id === "realiza_velorio" && step.type === "select") {
                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        Velório
                                                        {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId="wizard-realiza_velorio"
                                                ariaLabel="Velório"
                                                value={realizaVelorioVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!realizaVelorioErro}
                                                onChange={(v) => {
                                                    setRealizaVelorioVal(v);
                                                    setRealizaVelorioErro("");

                                                    if (v === "Não") {
                                                        setSalaVelorioVal("");
                                                        setVelorioOnlineVal("");
                                                        setVelorioOnlineErro("");
                                                    }

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        realiza_velorio: v,
                                                        ...(v === "Não"
                                                            ? {
                                                                local_cerimonia: "",
                                                                local_velorio: "",
                                                                sala_velorio: "",
                                                                velorio_online: "",
                                                                data_inicio_velorio: "",
                                                                data_fim_velorio: "",
                                                                hora_inicio_velorio: "",
                                                                hora_fim_velorio: "",
                                                                observacao_velorio01: "",
                                                            }
                                                            : {}),
                                                    }));
                                                }}
                                            />
                                            {realizaVelorioErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{realizaVelorioErro}</div>}
                                        </div>
                                    );
                                }

                                if (step.id === "realiza_sepultamento" && step.type === "select") {
                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        Sepultamento
                                                        {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId="wizard-realiza_sepultamento"
                                                ariaLabel="Sepultamento"
                                                value={realizaSepultamentoVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!realizaSepultamentoErro}
                                                onChange={(v) => {
                                                    setRealizaSepultamentoVal(v);
                                                    setRealizaSepultamentoErro("");
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        realiza_sepultamento: v,
                                                        ...(v === "Não" ? { local: "", observacao_velorio02: "" } : {}),
                                                    }));
                                                }}
                                            />
                                            {realizaSepultamentoErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{realizaSepultamentoErro}</div>}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   CORDÃO ITEM (async) - só se cordao=Sim
                                   =========================== */
                                if (step.type === "async_cordao" && step.id === "cordao_item") {
                                    if (cordaoVal !== "Sim") return null;

                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <EstoqueCombobox
                                                inputId="wizard-cordao_item"
                                                label="CORDÃO (estoque)"
                                                required={isRequired("cordao")}
                                                placeholder={step.placeholder || "Selecione no estoque…"}
                                                initialValue={String((wizardData as any).cordao_item ?? "")}
                                                disabled={wizardSubmitting}
                                                depositoLabel="Local do CORDÃO"
                                                depositoOptions={[
                                                    { value: "ARMARIO SANDRO", label: "ARMARIO SANDRO" },
                                                    { value: "ARMARIO ILDO", label: "ARMARIO ILDO" },
                                                    { value: "FUNERARIA", label: "FUNERARIA" },
                                                ]}
                                                depositoValue={depCordao}
                                                onChangeDeposito={(v) => {
                                                    const next = normalizeDepCordao(v);
                                                    setDepCordao(next);
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        cordao_item: "",
                                                        cordao_deposito_nome: next,
                                                        cordao_produto_id: 0,
                                                        cordao_codigo_barras: "",
                                                    }));
                                                    validarCordaoSeNecessario();
                                                }}
                                                action="cordoes_buscar"
                                                errorText={cordaoErro}
                                                onBlurValidate={validarCordaoSeNecessario}
                                                onTypingInvalidate={(typed) => {
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        cordao_item: typed,
                                                        cordao_deposito_nome: depCordao,
                                                        cordao_produto_id: 0,
                                                        cordao_codigo_barras: "",
                                                    }));
                                                }}
                                                onSelectRow={(it) => {
                                                    const pid = getPidFromRow(it);
                                                    const cb = String((it as any).codigo_barras || "").trim();

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        cordao: "Sim",
                                                        cordao_item: String(it.nome || "").trim(),
                                                        cordao_deposito_nome: depCordao,
                                                        cordao_produto_id: pid,
                                                        cordao_codigo_barras: cb,
                                                    }));

                                                    setCordaoErro("");
                                                }}
                                            />
                                        </div>
                                    );
                                }

                                /* ===========================
                                   local_velorio com GPS (datalist)
                                   + Sala 01 / Sala 02 / Sala 03
                                   + Velório Online obrigatório quando escolher sala
                                   =========================== */
                                if (step.id === "local_velorio" && step.type === "datalist") {
                                    const listId = `dl-${step.id}`;
                                    const currentText = String((wizardData as any)[step.id] ?? "");
                                    const salaAtual = String(salaVelorioVal || (wizardData as any).sala_velorio || "").trim();
                                    const onlineAtual = String(velorioOnlineVal || (wizardData as any).velorio_online || "").trim();
                                    const mostraVelorioOnline = !!salaAtual;
                                    // Local do velório (lista fixa). A sala do Memorial só aparece com o Memorial escolhido.
                                    const localCerimonia = localCerimoniaEfetivo(wizardData as any);
                                    const ehMemorial = localCerimonia === LOCAL_MEMORIAL;
                                    const localForaDaLista = !!localCerimonia && !(locaisCerimonia as readonly string[]).includes(localCerimonia);

                                    const selecionarLocalCerimonia = (local: string) => {
                                        const saiDoMemorial = local !== LOCAL_MEMORIAL;
                                        if (saiDoMemorial) {
                                            setSalaVelorioVal("");
                                            setVelorioOnlineVal("");
                                            setVelorioOnlineErro("");
                                        }
                                        setWizardData((prev: any) => {
                                            const enderecoAtual = String(prev?.local_velorio ?? "").trim();
                                            const enderecoEraMemorial = enderecoAtual.toLowerCase().startsWith("memorial");
                                            return {
                                                ...prev,
                                                local_cerimonia: local,
                                                // Memorial: o endereço não é digitado (é a própria empresa); grava o nome do Memorial.
                                                ...(local === LOCAL_MEMORIAL ? { local_velorio: LOCAL_MEMORIAL } : {}),
                                                ...(saiDoMemorial ? { sala_velorio: "", velorio_online: "", ...(enderecoEraMemorial ? { local_velorio: "" } : {}) } : {}),
                                            };
                                        });
                                    };

                                    const selecionarSala = (sala: string) => {
                                        const nextSala = salaAtual === sala ? "" : sala;
                                        const nextOnline = nextSala ? onlineAtual : "";

                                        setSalaVelorioVal(nextSala);
                                        setVelorioOnlineVal(nextOnline);
                                        setVelorioOnlineErro("");

                                        setWizardData((prev: any) => ({
                                            ...prev,
                                            sala_velorio: nextSala,
                                            velorio_online: nextOnline,
                                        }));
                                    };

                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <label htmlFor="wizard-local_cerimonia" className="mb-1.5 block text-[13px] font-bold">
                                                Local do Velório {obrigatoriedadeAtiva && <span className="text-[#B42318] dark:text-[#FF9C92]">*</span>}
                                            </label>
                                            <select
                                                id="wizard-local_cerimonia"
                                                className={`${CAMPO_CLS} mb-4`}
                                                value={localCerimonia}
                                                onChange={(e) => selecionarLocalCerimonia(e.target.value)}
                                                disabled={wizardSubmitting}
                                            >
                                                <option value="" disabled>
                                                    Selecione…
                                                </option>
                                                {localForaDaLista && <option value={localCerimonia}>{localCerimonia}</option>}
                                                {locaisCerimonia.map((op) => (
                                                    <option key={op} value={op}>
                                                        {op}
                                                    </option>
                                                ))}
                                            </select>

                                            {ehMemorial ? (
                                                /* Memorial Senhor do Bonfim: é a própria empresa, o endereço não aparece. Grava o nome do Memorial. */
                                                <input id={`wizard-${step.id}`} type="hidden" value={LOCAL_MEMORIAL} readOnly />
                                            ) : (
                                                <>
                                                    <label className="mb-1.5 block text-[13px] font-bold">
                                                        {step.label} {obrigatoriedadeAtiva && <span className="text-[#B42318] dark:text-[#FF9C92]">*</span>}
                                                    </label>

                                                    <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                                                        <input
                                                            key={`${wizardStep}-${step.id}-${localCerimonia}`} // ✅ força remount do defaultValue por step e por local (evita “travadas”)
                                                            ref={localVelorioRef}
                                                            id={`wizard-${step.id}`}
                                                            list={listId}
                                                            placeholder={step.placeholder || "Digite o endereço ou use o GPS"}
                                                            defaultValue={currentText}
                                                            className={`${CAMPO_CLS} flex-1`}
                                                            disabled={wizardSubmitting}
                                                        />

                                                        <div className="flex flex-wrap gap-2">
                                                            <button
                                                                type="button"
                                                                className={`${BTN_SEC_CLS}`}
                                                                onClick={preencherLocalVelorioComGPS}
                                                                disabled={wizardSubmitting || gpsLoading}
                                                                title="Capturar localização e gerar link de rota"
                                                            >
                                                                {gpsLoading ? "Capturando…" : "Usar GPS"}
                                                            </button>

                                                            <button
                                                                type="button"
                                                                className={`${BTN_SEC_CLS}`}
                                                                onClick={() => {
                                                                    if (localVelorioRef.current) localVelorioRef.current.value = "";
                                                                    setGpsMsg(null);
                                                                }}
                                                                disabled={wizardSubmitting}
                                                                title="Limpar para digitar manualmente"
                                                            >
                                                                Limpar
                                                            </button>
                                                        </div>
                                                    </div>

                                                    <datalist id={listId}>
                                                        {(step.datalist || []).map((op) => (
                                                            <option key={op} value={op} />
                                                        ))}
                                                    </datalist>

                                                    {gpsMsg && (
                                                        <div className={`mt-2 text-xs ${gpsMsg.includes("capturada") ? "text-[#313C55] dark:text-white" : "text-[#B42318] dark:text-[#FF9C92]"}`}>
                                                            {gpsMsg}
                                                        </div>
                                                    )}
                                                </>
                                            )}

                                            {/* ✅ Campos reais/ocultos para o salvarGrupoWizard ler pelo DOM.
                                    Com sala marcada, o hidden de Velório Online vem do grupo de botões Sim | Não abaixo. */}
                                            <input id="wizard-sala_velorio" type="hidden" value={salaAtual} readOnly />
                                            {!mostraVelorioOnline && <input id="wizard-velorio_online" type="hidden" value={onlineAtual} readOnly />}

                                            {ehMemorial && (
                                                <div className="rounded-xl border bg-[#F6F8FB] dark:bg-[#1C2334] p-3 border-[#E3E8F0] dark:border-white/[0.12]">
                                                    <label className="block text-sm font-medium">
                                                        Sala do Velório <span className="text-xs font-normal text-[#5B6478] dark:text-[#AEB9CF]">(opcional)</span>
                                                    </label>

                                                    {/* As 3 salas sempre na mesma linha, em cartões altos (quase quadrados). */}
                                                    <div className="mt-2 grid grid-cols-3 gap-2 sm:gap-3">
                                                        {SALAS_VELORIO.map((sala) => {
                                                            const checked = salaAtual === sala;
                                                            return (
                                                                <button
                                                                    key={sala}
                                                                    type="button"
                                                                    data-wizard-error={velorioOnlineErro ? "1" : "0"}
                                                                    className={`flex min-h-[84px] items-center justify-center rounded-[14px] border-[1.5px] px-2 text-[15px] font-extrabold transition disabled:opacity-60 sm:min-h-[104px] sm:text-base border-[#E3E8F0] dark:border-white/[0.12] ${checked
                                                                        ? "border-[#313C55] dark:border-[#F2CB3F] bg-[#313C55] dark:bg-[#F2CB3F] text-white dark:text-[#313C55] shadow-sm"
                                                                        : "bg-white dark:bg-[#232B3F] text-[#313C55] dark:text-[#D6DCE8] hover:bg-[#EEF2F7] dark:hover:bg-white/10"
                                                                        }`}
                                                                    disabled={wizardSubmitting}
                                                                    aria-pressed={checked}
                                                                    onClick={() => selecionarSala(sala)}
                                                                >
                                                                    {sala}
                                                                </button>
                                                            );
                                                        })}
                                                    </div>

                                                    {mostraVelorioOnline && (
                                                        <div className="mt-4">
                                                            {/* Mesmo seletor Sim | Não das outras perguntas; o hidden wizard-velorio_online vem dele. */}
                                                            <CheckboxChoiceGroup
                                                                label={
                                                                    <>
                                                                        Velório Online <span className="text-[#B42318] dark:text-[#FF9C92]">*</span>
                                                                    </>
                                                                }
                                                                inputId="wizard-velorio_online"
                                                                ariaLabel="Velório Online"
                                                                value={onlineAtual}
                                                                options={SIM_NAO_OPTIONS}
                                                                disabled={wizardSubmitting}
                                                                hasError={!!velorioOnlineErro}
                                                                onChange={(v) => {
                                                                    setVelorioOnlineVal(v);
                                                                    setWizardData((prev: any) => ({
                                                                        ...prev,
                                                                        sala_velorio: salaAtual,
                                                                        velorio_online: v,
                                                                    }));
                                                                    if (v === "Sim" || v === "Não") setVelorioOnlineErro("");
                                                                }}
                                                            />

                                                            {velorioOnlineErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{velorioOnlineErro}</div>}
                                                        </div>
                                                    )}

                                                    {!mostraVelorioOnline && (
                                                        <p className="mt-2 text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                                                            {obrigatoriedadeAtiva
                                                                ? "Ao marcar uma sala, será obrigatório informar se terá Velório Online."
                                                                : "Velório Online ficará obrigatório somente após Corpo na Clínica."}
                                                        </p>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    );
                                }

                                // ✅ Estes campos são renderizados dentro do bloco Local do Velório acima.
                                // Mantemos os IDs ocultos para o salvarGrupoWizard ler e salvar corretamente.
                                if (step.id === "sala_velorio" || step.id === "velorio_online") {
                                    return null;
                                }

                                /* ===========================
                                   custom arrumacao
                                   =========================== */
                                if (step.type === "custom" && step.id === "arrumacao") {
                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <label className="mb-1.5 block text-[13px] font-bold">{step.label}</label>
                                            <div className="flex flex-col items-start gap-2 sm:flex-row sm:items-center">
                                                <button
                                                    type="button"
                                                    className={`${BTN_SEC_CLS}`}
                                                    onClick={() => setArrumacaoOpen(true)}
                                                    disabled={wizardSubmitting}
                                                >
                                                    Selecionar Itens…
                                                </button>
                                                <span className="text-sm text-[#5B6478] dark:text-[#AEB9CF]">{arrumacaoSelecionadaResumo || "Nenhum item selecionado"}</span>
                                            </div>
                                            <input id="wizard-arrumacao" type="hidden" defaultValue="__custom__" />
                                        </div>
                                    );
                                }

                                /* ===========================
                                   assistência (checkbox Sim/Não)
                                   =========================== */
                                if (step.id === "assistencia" && step.type === "select") {
                                    const showRequiredStar = isRequired(step.id) || requireAssistencia;

                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        {step.label}
                                                        {showRequiredStar && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId={`wizard-${step.id}`}
                                                ariaLabel={step.label}
                                                value={assistenciaVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!assistenciaErro}
                                                onChange={(v) => {
                                                    setAssistenciaVal(v);
                                                    setAssistenciaErro("");

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        assistencia: v,
                                                    }));

                                                    if (v === "Não") setMateriaisOpen(false);
                                                }}
                                            />

                                            {assistenciaErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{assistenciaErro}</div>}

                                            {assistenciaVal === "Sim" && (
                                                <div className="mt-2 flex items-center gap-2">
                                                    <button
                                                        type="button"
                                                        className={`${BTN_SEC_CLS}`}
                                                        onClick={() => setMateriaisOpen(true)}
                                                        disabled={wizardSubmitting}
                                                    >
                                                        Selecionar Materiais…
                                                    </button>
                                                    <span className="text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                                                        {materiaisSelecionadosResumo || "Nenhum material selecionado"}
                                                    </span>
                                                </div>
                                            )}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   tanatopraxia (checkbox Sim/Não)
                                   =========================== */
                                if (step.id === "tanato" && step.type === "select") {
                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        {step.label}
                                                        {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId={`wizard-${step.id}`}
                                                ariaLabel={step.label}
                                                value={tanatoVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!tanatoSelectErro}
                                                onChange={(v) => {
                                                    setTanatoVal(v);
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        tanato: v,
                                                    }));
                                                    setTanatoSelectErro("");

                                                    if (v !== "Sim") setArrumacaoOpen(false);
                                                }}
                                            />

                                            {tanatoSelectErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{tanatoSelectErro}</div>}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   ornamentação (checkbox Sim/Não)
                                   =========================== */
                                if (step.id === "ornamentacao" && step.type === "select") {
                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        {step.label}
                                                        {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId={`wizard-${step.id}`}
                                                ariaLabel={step.label}
                                                value={ornamentacaoVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!ornamentacaoSelectErro}
                                                onChange={(v) => {
                                                    setOrnamentacaoVal(v);

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        ornamentacao: v,
                                                        ...(v !== "Sim" ? { ornamentacao_tipo: "" } : {}),
                                                    }));

                                                    setOrnamentacaoSelectErro("");
                                                    if (v !== "Sim") setOrnamentacaoTipoErro("");
                                                }}
                                            />

                                            {ornamentacaoSelectErro && (
                                                <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{ornamentacaoSelectErro}</div>
                                            )}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   INVOL (checkbox Sim/Não)
                                   =========================== */
                                if (step.id === "invol" && step.type === "select") {
                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        {step.label}
                                                        {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId={`wizard-${step.id}`}
                                                ariaLabel={step.label}
                                                value={involVal}
                                                options={SIM_NAO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!(involSelectErro || involErro)}
                                                onChange={(v) => {
                                                    setInvolVal(v);

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        invol: v,
                                                        ...(v !== "Sim"
                                                            ? {
                                                                invol_deposito_nome: "",
                                                                invol_produto_id: 0,
                                                                invol_codigo_barras: "",
                                                                invol_item: "",
                                                            }
                                                            : {}),
                                                    }));

                                                    setInvolSelectErro("");
                                                    if (v !== "Sim") setInvolErro("");
                                                }}
                                            />

                                            {involSelectErro && <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{involSelectErro}</div>}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   INVOL ITEM (async) - só se invol=Sim
                                   =========================== */
                                if (step.type === "async_invol" && step.id === "invol_item") {
                                    if (involVal !== "Sim") return null;

                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <EstoqueCombobox
                                                inputId="wizard-invol_item"
                                                label="INVOL (estoque)"
                                                required={isRequired("invol")}
                                                placeholder={step.placeholder || "Selecione no estoque…"}
                                                initialValue={String((wizardData as any).invol_item ?? "")}
                                                disabled={wizardSubmitting}
                                                depositoLabel="Local do INVOL"
                                                depositoOptions={[
                                                    { value: "ARMARIO SANDRO", label: "ARMARIO SANDRO" },
                                                    { value: "ARMARIO ILDO", label: "ARMARIO ILDO" },
                                                ]}
                                                depositoValue={depInvol}
                                                onChangeDeposito={(v) => {
                                                    const next = normalizeDepInvol(v);
                                                    setDepInvol(next);
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        invol_item: "",
                                                        invol_deposito_nome: next,
                                                        invol_produto_id: 0,
                                                        invol_codigo_barras: "",
                                                    }));
                                                    validarInvolSeNecessario();
                                                }}
                                                action="invols_buscar"
                                                errorText={involErro}
                                                onBlurValidate={validarInvolSeNecessario}
                                                onTypingInvalidate={(typed) => {
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        invol_item: typed,
                                                        invol_deposito_nome: depInvol,
                                                        invol_produto_id: 0,
                                                        invol_codigo_barras: "",
                                                    }));
                                                }}
                                                onSelectRow={(it) => {
                                                    const pid = getPidFromRow(it);
                                                    const cb = String((it as any).codigo_barras || "").trim();

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        invol_item: String(it.nome || "").trim(),
                                                        invol_deposito_nome: depInvol,
                                                        invol_produto_id: pid,
                                                        invol_codigo_barras: cb,
                                                    }));

                                                    setInvolErro("");
                                                }}
                                            />
                                        </div>
                                    );
                                }

                                /* ===========================
                                   tipo de ornamentação (checkbox Natural/Artificial)
                                   =========================== */
                                if (step.id === "ornamentacao_tipo" && step.type === "select") {
                                    const ornamentacaoTipoVal = String((wizardData as any).ornamentacao_tipo ?? "");

                                    return (
                                        <div key={step.id}>
                                            <CheckboxChoiceGroup
                                                label={
                                                    <>
                                                        {step.label}
                                                        {isRequired("ornamentacao") && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                                    </>
                                                }
                                                inputId={`wizard-${step.id}`}
                                                ariaLabel={step.label}
                                                value={ornamentacaoTipoVal}
                                                options={ORNAMENTACAO_TIPO_OPTIONS}
                                                disabled={wizardSubmitting}
                                                hasError={!!ornamentacaoTipoErro}
                                                onChange={(v) => {
                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        ornamentacao_tipo: v,
                                                    }));
                                                    setOrnamentacaoTipoErro("");
                                                }}
                                            />

                                            {ornamentacaoTipoErro && (
                                                <div className="mt-1 text-xs text-[#B42318] dark:text-[#FF9C92]">{ornamentacaoTipoErro}</div>
                                            )}
                                        </div>
                                    );
                                }

                                /* ===========================
                                   FOTO DO FALECIDO (upload real)
                                   - mantém foto_falecido como caminho/URL salvo
                                   - envia a nova imagem em foto_falecido_base64 para o backend salvar fisicamente
                                   =========================== */
                                if (step.id === "foto_falecido" || step.type === "file") {
                                    const fotoAtual = String((wizardData as any).foto_falecido ?? "");
                                    const fotoBase64 = String((wizardData as any).foto_falecido_base64 ?? "");
                                    const fotoNome = String((wizardData as any).foto_falecido_nome ?? "");
                                    const previewSrc = normalizarFotoSrc(fotoBase64 || fotoAtual);

                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <label className="mb-1.5 block text-[13px] font-bold">
                                                {step.label}
                                                {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                            </label>

                                            <div className="grid grid-cols-1 items-start gap-4 sm:grid-cols-[112px_1fr]">
                                                <div className="flex size-28 items-center justify-center overflow-hidden rounded-2xl bg-[#EEF2F7] text-[#5B6478] dark:bg-white/10 dark:text-[#AEB9CF]">
                                                    {previewSrc ? (
                                                        <img
                                                            src={previewSrc}
                                                            alt="Prévia da foto do falecido"
                                                            className="h-full w-full object-cover"
                                                        />
                                                    ) : (
                                                        <span className="px-2 text-center text-xs text-[#5B6478] dark:text-[#AEB9CF]">Sem foto</span>
                                                    )}
                                                </div>

                                                <div>
                                                    {/* valor persistido no banco; o FileReader envia a nova imagem em foto_falecido_base64 */}
                                                    <input
                                                        id={`wizard-${step.id}`}
                                                        type="hidden"
                                                        value={fotoAtual}
                                                        readOnly
                                                    />

                                                    <input
                                                        id={`wizard-${step.id}_file`}
                                                        type="file"
                                                        accept={step.accept || "image/*"}
                                                        className="block w-full text-sm text-[#5B6478] file:mr-3 file:h-11 file:cursor-pointer file:rounded-xl file:border-[1.5px] file:border-[#C9D1DE] file:bg-white file:px-4 file:text-sm file:font-bold file:text-[#313C55] hover:file:bg-[#EEF2F7] disabled:opacity-60 dark:text-[#AEB9CF] dark:file:border-white/25 dark:file:bg-[#232B3F] dark:file:text-white dark:hover:file:bg-white/10"
                                                        disabled={wizardSubmitting}
                                                        onChange={async (e) => {
                                                            const file = e.target.files?.[0];

                                                            if (!file) return;

                                                            if (!file.type.startsWith("image/")) {
                                                                alert("Selecione um arquivo de imagem válido.");
                                                                e.currentTarget.value = "";
                                                                return;
                                                            }

                                                            const maxBytes = 5 * 1024 * 1024;
                                                            if (file.size > maxBytes) {
                                                                alert("A imagem deve ter no máximo 5MB.");
                                                                e.currentTarget.value = "";
                                                                return;
                                                            }

                                                            try {
                                                                const dataUrl = await fileToDataURL(file);

                                                                setWizardData((prev: any) => ({
                                                                    ...prev,
                                                                    foto_falecido_base64: dataUrl,
                                                                    foto_falecido_nome: file.name,
                                                                    foto_falecido_tipo: file.type,
                                                                    foto_falecido_tamanho: file.size,
                                                                }));
                                                            } catch (err: any) {
                                                                alert(err?.message || "Erro ao carregar a imagem.");
                                                                e.currentTarget.value = "";
                                                            }
                                                        }}
                                                    />

                                                    <div className="mt-2 text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                                                        {fotoNome ? (
                                                            <>
                                                                Nova foto selecionada: <b>{fotoNome}</b>
                                                            </>
                                                        ) : fotoAtual ? (
                                                            <>
                                                                Foto atual: <b>{fotoAtual}</b>
                                                            </>
                                                        ) : (
                                                            <>Selecione uma imagem JPG, PNG ou WEBP.</>
                                                        )}
                                                    </div>

                                                    {(fotoAtual || fotoBase64) && (
                                                        <button
                                                            type="button"
                                                            className={`${BTN_SEC_CLS} mt-2`}
                                                            disabled={wizardSubmitting}
                                                            onClick={() => {
                                                                setWizardData((prev: any) => ({
                                                                    ...prev,
                                                                    foto_falecido: "",
                                                                    foto_falecido_base64: "",
                                                                    foto_falecido_nome: "",
                                                                    foto_falecido_tipo: "",
                                                                    foto_falecido_tamanho: 0,
                                                                }));

                                                                const fileEl = document.getElementById(`wizard-${step.id}_file`) as HTMLInputElement | null;
                                                                if (fileEl) fileEl.value = "";
                                                            }}
                                                        >
                                                            Remover foto
                                                        </button>
                                                    )}

                                                    <p className="mt-2 text-[13px] text-[#5B6478] dark:text-[#AEB9CF]">
                                                        ATENÇÃO: Essa foto será usada no obituário, painel e página de homenagens.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                }

                                /* ===========================
                                   defaults
                                   =========================== */
                                if (step.type === "input") {
                                    const isCpfResponsavel = step.id === "cpf_responsavel";

                                    return (
                                        <div key={step.id}>
                                            <label className="mb-1.5 block text-[13px] font-bold">
                                                {step.label}
                                                {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                            </label>
                                            <input
                                                key={`${wizardStep}-${step.id}-${["falecido", "data_nascimento"].includes(step.id) ? String((wizardData as any)[step.id] ?? "") : ""}`} // Atualiza nome/nascimento após seleção do beneficiário
                                                id={`wizard-${step.id}`}
                                                type="text"
                                                inputMode={isCpfResponsavel ? "numeric" : undefined}
                                                maxLength={isCpfResponsavel ? 11 : undefined}
                                                pattern={isCpfResponsavel ? "\\d{11}" : undefined}
                                                placeholder={step.placeholder || ""}
                                                defaultValue={String((wizardData as any)[step.id] ?? "")}
                                                onInput={(e) => {
                                                    if (!isCpfResponsavel) return;

                                                    const el = e.currentTarget;
                                                    const somenteNumeros = el.value.replace(/\D/g, "").slice(0, 11);

                                                    if (el.value !== somenteNumeros) {
                                                        el.value = somenteNumeros;
                                                    }

                                                    setWizardData((prev: any) => ({
                                                        ...prev,
                                                        cpf_responsavel: somenteNumeros,
                                                    }));
                                                }}
                                                className={CAMPO_CLS}
                                                disabled={wizardSubmitting}
                                            />
                                        </div>
                                    );
                                }

                                if (step.type === "textarea") {
                                    return (
                                        <div key={step.id} className="sm:col-span-2">
                                            <label className="mb-1.5 block text-[13px] font-bold">{step.label}</label>
                                            <textarea
                                                key={`${wizardStep}-${step.id}`} // ✅ remount por step
                                                id={`wizard-${step.id}`}
                                                placeholder={step.placeholder || ""}
                                                defaultValue={String((wizardData as any)[step.id] ?? "")}
                                                className={AREA_CLS}
                                                rows={3}
                                                disabled={wizardSubmitting}
                                            />
                                        </div>
                                    );
                                }

                                if (step.type === "select") {
                                    const options = step.options && step.options.length > 0 ? step.options : ["Sim", "Não"];

                                    return (
                                        <div key={step.id}>
                                            <label className="mb-1.5 block text-[13px] font-bold">
                                                {step.label}
                                                {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                            </label>

                                            <select
                                                key={`${wizardStep}-${step.id}`} // ✅ remount por step
                                                id={`wizard-${step.id}`}
                                                className={CAMPO_CLS}
                                                defaultValue={String((wizardData as any)[step.id] ?? "")}
                                                disabled={wizardSubmitting}
                                            >
                                                <option value="" disabled>
                                                    Selecione…
                                                </option>

                                                {options.filter(Boolean).map((op) => (
                                                    <option key={op} value={op}>
                                                        {op}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                    );
                                }

                                if (step.type === "date") {
                                    return (
                                        <div key={step.id}>
                                            <label className="mb-1.5 block text-[13px] font-bold">
                                                {step.label}
                                                {isRequired(step.id) && <span className="text-[#B42318] dark:text-[#FF9C92]"> *</span>}
                                            </label>

                                            <input
                                                key={`${wizardStep}-${step.id}`} // ✅ remount por step
                                                id={`wizard-${step.id}`}
                                                type="date"
                                                defaultValue={String((wizardData as any)[step.id] ?? "")}
                                                className={CAMPO_CLS}
                                                disabled={wizardSubmitting}
                                            />
                                        </div>
                                    );
                                }

                                if (step.type === "time") {
                                    return (
                                        <div key={step.id}>
                                            <label className="mb-1.5 block text-[13px] font-bold">{step.label}</label>
                                            <input
                                                key={`${wizardStep}-${step.id}`} // ✅ remount por step
                                                id={`wizard-${step.id}`}
                                                type="time"
                                                defaultValue={String((wizardData as any)[step.id] ?? "")}
                                                className={CAMPO_CLS}
                                                disabled={wizardSubmitting}
                                            />
                                        </div>
                                    );
                                }

                                if (step.type === "datalist") {
                                    const listId = `dl-${step.id}`;
                                    return (
                                        <div key={step.id}>
                                            <label className="mb-1.5 block text-[13px] font-bold">{step.label}</label>
                                            <input
                                                key={`${wizardStep}-${step.id}`} // ✅ remount por step
                                                id={`wizard-${step.id}`}
                                                list={listId}
                                                placeholder={step.placeholder || ""}
                                                defaultValue={String((wizardData as any)[step.id] ?? "")}
                                                className={CAMPO_CLS}
                                                disabled={wizardSubmitting}
                                            />
                                            <datalist id={listId}>
                                                {(step.datalist || []).map((op) => (
                                                    <option key={op} value={op} />
                                                ))}
                                            </datalist>
                                        </div>
                                    );
                                }

                                return null;
                            })();
                            if (conteudo == null || conteudo === false) return null;
                            const secao = ehPassoItens ? secaoDoPasso(step.id) : "";
                            const abreSecao = ehPassoItens && secao !== secaoAtual;
                            if (abreSecao) secaoAtual = secao;
                            // Blocos da OS encaixados nos itens: procedimento depois de Tanatopraxia (Sim); translado depois de Invol.
                            const depoisDoItem: React.ReactNode[] = [];
                            if (ehPassoItens) {
                                if (step.id === "tanato" && tanatoVal === "Sim" && osProcedimentoSlot) {
                                    // Tipo de procedimento e reconstituição facial seguem a trava da Tanatopraxia.
                                    const procedimentoTravado = !!travaItens && !travaItens.podeAlterar && travaItens.campos.includes("tanato");
                                    depoisDoItem.push(
                                        procedimentoTravado ? (
                                            <fieldset key="os-procedimento" disabled aria-disabled="true" className="m-0 min-w-0 border-0 p-0 sm:col-span-2" title="Item travado após o Corpo Pronto">
                                                <div className="pointer-events-none select-none opacity-60">{osProcedimentoSlot}</div>
                                            </fieldset>
                                        ) : (
                                            <React.Fragment key="os-procedimento">{osProcedimentoSlot}</React.Fragment>
                                        ),
                                    );
                                }
                                if (osTransladoSlot && ((step.id === "invol" && involVal !== "Sim") || step.id === "invol_item")) {
                                    depoisDoItem.push(<React.Fragment key="os-translado">{osTransladoSlot}</React.Fragment>);
                                }
                            }
                            return (
                                <React.Fragment key={step.id}>
                                    {abreSecao ? (
                                        <div className={`text-xs font-extrabold uppercase tracking-[0.12em] text-[#5B6478] dark:text-[#AEB9CF] ${secao === "demais" ? "mt-3" : ""}`}>
                                            {secao === "principais" ? "Itens principais" : "Demais itens e serviços"}
                                        </div>
                                    ) : null}
                                    {travaItens && !travaItens.podeAlterar && travaItens.campos.includes(step.id) ? (
                                        /* Item travado: fieldset desabilita os campos nativos; pointer-events-none barra os botões próprios (Sim/Não, listas). */
                                        <fieldset disabled aria-disabled="true" className="m-0 min-w-0 border-0 p-0 sm:col-span-2" title="Item travado após o Corpo Pronto">
                                            <div className="pointer-events-none select-none opacity-60">{conteudo}</div>
                                        </fieldset>
                                    ) : (
                                        conteudo
                                    )}
                                    {depoisDoItem}
                                </React.Fragment>
                            );
                        });
                    })()}
                </div>

                {tanatoNoGrupoAtual ? osSlot : null}

            </Modal>
        </RascunhoOSContext.Provider>
    );
}

/** Faixa no topo da aba Itens quando o atendimento já passou do Corpo Pronto. */
function AvisoTravaItens({ podeAlterar, baixaFeita }: { podeAlterar: boolean; baixaFeita: boolean }) {
    return (
        <div
            role="note"
            className="mt-4 flex items-start gap-3 rounded-[14px] border-[1.5px] border-[#F2CB3F] bg-[#FCF3CC] px-3.5 py-3 text-[13px] leading-snug text-[#313C55] dark:bg-[#F2CB3F]/16 dark:text-white"
        >
            <svg viewBox="0 0 24 24" className="mt-0.5 size-5 shrink-0" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <rect x="5" y="11" width="14" height="10" rx="2" />
                <path d="M8 11V7a4 4 0 0 1 8 0v4" />
            </svg>
            <div>
                <b>Itens travados após o Corpo Pronto.</b>{" "}
                {podeAlterar ? (
                    <>
                        Você pode alterar porque tem acesso à Gestão.
                        {baixaFeita
                            ? " A baixa no estoque já foi feita no Corpo Pronto: trocar um item aqui não mexe no estoque. Corrija a saída pela movimentação."
                            : " A baixa no estoque acontece no Corpo Pronto, com os itens que estiverem aqui."}
                    </>
                ) : (
                    <>A baixa no estoque já foi feita. Urna, roupa, véu, cordão, invol, tanatopraxia (com o procedimento e os insumos), ornamentação, kit lanche e coroa não podem mais ser alterados. Se precisar, fale com a Gestão.</>
                )}
            </div>
        </div>
    );
}
