"use client";

import React, {
    forwardRef,
    useEffect,
    useImperativeHandle,
    useMemo,
    useRef,
    useState,
} from "react";
import Modal from "./Modal";
import { Registro } from "./types";

const TELEMETRIA_URL = "https://api.planoassistencialintegrado.com.br/telemetria.php";
/* ======================= Tipos ======================= */

export type TipoTele = "remocao" | "para_velorio" | "para_sepultamento";

type VeiculoOpcao = {
    nome: string;
    placa: string | null;
};

type OffPayload = {
    when: number;
    url: string;
    body: any;
};

export type TelemetriaHandle = {
    /** Chamado externamente quando chegar a fase que encerra a telemetria */
    stopAndSave: () => Promise<void>;
};

/* ======================= Veículos fixos ======================= */

const VEICULOS_FIXOS: VeiculoOpcao[] = [
    { nome: "STRADA", placa: "RDR8G25" },
    { nome: "S10", placa: "PRY7H63" },
    { nome: "SPRINTER", placa: "RDG9170" },
    { nome: "DOBLO", placa: "OZP9875" },
    { nome: "SAVEIRO", placa: "RCQ5B26" },
    { nome: "HILUX", placa: "SKT5G28" },
    { nome: "HILUX", placa: "QTV4I21" },
    { nome: "SAVEIRO", placa: "ONQ6794" },
    { nome: "DUCATO", placa: "PLV6H34" },
    { nome: "DUCATO", placa: "PLL6E98" },
    { nome: "OUTRA EMPRESA", placa: null },
];

/* ======================= Utils ======================= */

function normalizePlaca(v?: string | null) {
    return String(v || "")
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, "")
        .slice(0, 7);
}

function placaComTraco(v?: string | null) {
    const p = normalizePlaca(v || "");
    if (p.length !== 7) return p || "";
    return `${p.slice(0, 3)}-${p.slice(3)}`;
}

function veiculoLabel(v: VeiculoOpcao) {
    const placa = placaComTraco(v.placa);
    return placa ? `${v.nome} ${placa}` : v.nome;
}

function getRegistroId(registro?: Registro) {
    const r = registro as any;
    return r?.sepultamento_id ?? r?.id_sepultamento ?? r?.id ?? null;
}

function getFalecido(registro?: Registro) {
    const r = registro as any;
    return r?.falecido || r?.falecido_nome || r?.nome_falecido || r?.nome || null;
}

function pad2(v: number) {
    return String(v).padStart(2, "0");
}

function toMysqlDateTime(date: Date) {
    return [
        date.getFullYear(),
        "-",
        pad2(date.getMonth() + 1),
        "-",
        pad2(date.getDate()),
        " ",
        pad2(date.getHours()),
        ":",
        pad2(date.getMinutes()),
        ":",
        pad2(date.getSeconds()),
    ].join("");
}

function getPayloadError(j: any, fallback = "Falha ao enviar telemetria.") {
    return String(j?.msg || j?.erro || j?.message || fallback);
}

/* ======================= Fila offline ======================= */

function readQueue(): OffPayload[] {
    if (typeof window === "undefined") return [];
    try {
        const raw = localStorage.getItem("telemetria_offline_queue");
        return raw ? (JSON.parse(raw) as OffPayload[]) : [];
    } catch {
        return [];
    }
}

function writeQueue(q: OffPayload[]) {
    if (typeof window === "undefined") return;
    try {
        localStorage.setItem("telemetria_offline_queue", JSON.stringify(q));
    } catch { }
}

function isLocalAttendanceId(value: unknown) {
    return String(value ?? "").startsWith("local-atendimento-");
}

/**
 * Chamado pelo page.tsx assim que o atendimento criado offline recebe
 * o ID definitivo do servidor.
 *
 * Atualiza tanto a fila de telemetria encerrada quanto a sessão ativa.
 */
export function remapOfflineTelemetryRecordId(
    localId: string,
    serverId: string | number
): void {
    if (typeof window === "undefined") return;

    const local = String(localId);
    const server = String(serverId);

    try {
        const queue = readQueue().map((item) => {
            const current = String(
                item?.body?.sepultamento_id ??
                item?.body?.id ??
                ""
            );

            if (current !== local) return item;

            return {
                ...item,
                body: {
                    ...(item.body || {}),
                    sepultamento_id: server,
                },
            };
        });

        writeQueue(queue);
    } catch { }

    try {
        const raw = localStorage.getItem("tele_active_snapshot");

        if (raw) {
            const snapshot = JSON.parse(raw);

            if (
                snapshot &&
                typeof snapshot === "object" &&
                String(
                    snapshot.id ??
                    snapshot.sepultamento_id ??
                    ""
                ) === local
            ) {
                localStorage.setItem(
                    "tele_active_snapshot",
                    JSON.stringify({
                        ...snapshot,
                        id: server,
                        sepultamento_id: server,
                    })
                );
            }
        }
    } catch { }
}

async function postTelemetria(payload: any) {
    const r = await fetch(TELEMETRIA_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        cache: "no-store",
        body: JSON.stringify(payload),
    });

    const text = await r.text();
    let j: any = null;

    try {
        j = text ? JSON.parse(text) : null;
    } catch {
        j = null;
    }

    if (!r.ok || !j?.sucesso) {
        throw new Error(getPayloadError(j, `Erro HTTP ${r.status} ao salvar telemetria.`));
    }

    return j;
}

async function flushQueue() {
    if (typeof navigator === "undefined") return;
    const q = readQueue();
    if (!q.length || navigator.onLine === false) return;

    const rest: OffPayload[] = [];

    for (const item of q) {
        const recordId = String(
            item?.body?.sepultamento_id ??
            item?.body?.id ??
            ""
        );

        /*
         * Atendimento ainda não existe no servidor.
         * Mantém a telemetria no aparelho até o page.tsx trocar o ID local
         * pelo ID definitivo.
         */
        if (isLocalAttendanceId(recordId)) {
            rest.push(item);
            continue;
        }

        try {
            await postTelemetria(item.body);
        } catch {
            rest.push(item);
        }
    }

    writeQueue(rest);
}

function enqueueTelemetria(payload: any) {
    const q = readQueue();
    q.push({ when: Date.now(), url: TELEMETRIA_URL, body: payload });
    writeQueue(q);
}

/* ======================= Snapshot da sessão ativa ======================= */

function saveActiveSnapshot(snap: any) {
    if (typeof window === "undefined") return;
    try {
        localStorage.setItem("tele_active_snapshot", JSON.stringify(snap));
    } catch { }
}

function clearActiveSnapshot() {
    if (typeof window === "undefined") return;
    try {
        localStorage.removeItem("tele_active_snapshot");
    } catch { }
}

function readActiveSnapshot(): any | null {
    if (typeof window === "undefined") return null;
    try {
        const raw = localStorage.getItem("tele_active_snapshot");
        if (!raw) return null;

        const snap = JSON.parse(raw);
        return snap && typeof snap === "object" ? snap : null;
    } catch {
        return null;
    }
}

/* ======================= Wake Lock ======================= */

async function requestWakeLock(): Promise<any | null> {
    try {
        // @ts-ignore
        if (navigator.wakeLock && typeof navigator.wakeLock.request === "function") {
            // @ts-ignore
            return await navigator.wakeLock.request("screen");
        }
    } catch { }

    return null;
}

/* ======================= Componente ======================= */

export default forwardRef<
    TelemetriaHandle,
    {
        open: boolean;
        onClose: () => void;
        registro?: Registro;
        fase: string;
        tipo: TipoTele;
        /** Atualiza status sem perguntar, por exemplo fase01/fase07/fase09 */
        onConfirmAcao?: (fase: string) => Promise<void> | void;
        onStarted?: (info: { fase: string }) => void;
        onSaved?: () => void;
    }
>(function TelemetriaModal(
    { open, onClose, registro, fase, tipo, onConfirmAcao, onStarted, onSaved },
    ref
) {
    const [veiculo, setVeiculo] = useState<string>("");
    const [saving, setSaving] = useState(false);
    const [starting, setStarting] = useState(false);
    const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);

    const startTsRef = useRef<number | null>(null);
    const endTsRef = useRef<number | null>(null);
    const snapshotTimerRef = useRef<number | null>(null);
    const wakeLockRef = useRef<any | null>(null);
    const relockHandlerRef = useRef<() => void>(() => { });
    const veiculoRef = useRef<VeiculoOpcao | null>(null);
    const activeRef = useRef(false);

    const veiculosOpcoes = useMemo(() => VEICULOS_FIXOS, []);

    const veiculoSelecionado = useMemo(() => {
        return veiculosOpcoes.find((v) => veiculoLabel(v) === veiculo) || null;
    }, [veiculosOpcoes, veiculo]);

    useImperativeHandle(ref, () => ({
        stopAndSave: async () => {
            await stopAndSave();
        },
    }));

    const titulo = useMemo(() => {
        if (tipo === "remocao") return "Remoção";
        if (tipo === "para_velorio") return "Transporte para Velório";
        return "Transporte para Sepultamento";
    }, [tipo]);

    function snapshotBase() {
        const veic = veiculoRef.current || veiculoSelecionado;

        return {
            id: getRegistroId(registro),
            fase,
            tipo,
            veiculo: veic ? veiculoLabel(veic) : veiculo,
            veiculo_nome: veic?.nome || veiculo || null,
            falecido: getFalecido(registro),
            placa: veic?.placa || null,
            startTs: startTsRef.current,
            origem_dados: veic?.placa ? "itrack" : "manual_sem_rota",
            source_device: veic?.placa ? "rastreador" : "sem_rastreador",
        };
    }

    async function startAfterSelect(veiculoEscolhido: VeiculoOpcao) {
        if (starting || activeRef.current) return;

        setStarting(true);
        setMsg(null);

        const placa = normalizePlaca(veiculoEscolhido.placa);
        const veicNormalizado: VeiculoOpcao = {
            ...veiculoEscolhido,
            placa: placa || null,
        };

        try {
            // Primeiro registra a fase inicial no atendimento.
            // Se isso falhar, não marca a telemetria como ativa.
            await onConfirmAcao?.(fase);

            veiculoRef.current = veicNormalizado;
            activeRef.current = true;
            startTsRef.current = Date.now();
            endTsRef.current = null;

            wakeLockRef.current = await requestWakeLock();
            const relock = async () => {
                if (!wakeLockRef.current) {
                    wakeLockRef.current = await requestWakeLock();
                }
            };
            relockHandlerRef.current = relock;
            window.addEventListener("visibilitychange", relock);
            window.addEventListener("online", flushQueue);

            saveActiveSnapshot(snapshotBase());

            if (snapshotTimerRef.current == null) {
                snapshotTimerRef.current = window.setInterval(() => {
                    saveActiveSnapshot(snapshotBase());
                }, 5000) as unknown as number;
            }

            onStarted?.({ fase });
            onClose();
        } catch (e: any) {
            activeRef.current = false;
            veiculoRef.current = null;
            startTsRef.current = null;
            setMsg({
                text: e?.message || "Não foi possível iniciar a telemetria.",
                ok: false,
            });
        } finally {
            setStarting(false);
        }
    }

    async function cleanupActiveSession() {
        if (snapshotTimerRef.current != null) {
            window.clearInterval(snapshotTimerRef.current);
            snapshotTimerRef.current = null;
        }

        window.removeEventListener("visibilitychange", relockHandlerRef.current);
        window.removeEventListener("online", flushQueue);

        if (wakeLockRef.current) {
            try {
                await wakeLockRef.current.release?.();
            } catch { }
            wakeLockRef.current = null;
        }

        clearActiveSnapshot();
    }

    function buildPayload(snapshotFallback?: any) {
        const veic = veiculoRef.current || veiculoSelecionado;

        const placa = normalizePlaca(
            veic?.placa ||
            snapshotFallback?.placa ||
            ""
        );

        const inicioMs =
            startTsRef.current ||
            Number(snapshotFallback?.startTs || 0) ||
            Date.now();

        const fimMs = endTsRef.current || Date.now();
        const durS = Math.max(1, Math.round((fimMs - inicioMs) / 1000));

        const veiculoNome =
            veic?.nome ||
            snapshotFallback?.veiculo_nome ||
            snapshotFallback?.veiculo ||
            veiculo ||
            null;

        const sepultamentoId =
            getRegistroId(registro) ??
            snapshotFallback?.id ??
            snapshotFallback?.sepultamento_id ??
            null;

        const falecido =
            getFalecido(registro) ??
            snapshotFallback?.falecido ??
            null;

        const tipoPayload = snapshotFallback?.tipo || tipo;

        const base = {
            sepultamento_id: sepultamentoId,
            tipo: tipoPayload,
            falecido,
            veiculo_nome: veiculoNome,
            placa: placa || null,
            veiculo_obs: placa ? null : "OUTRA EMPRESA / sem rastreador",
            inicio_ts: toMysqlDateTime(new Date(inicioMs)),
            fim_ts: toMysqlDateTime(new Date(fimMs)),
            duracao_seg: durS,
            encerrado: 1,
        };

        if (placa) {
            return {
                acao: "inserir_itrack",
                ...base,
                source_device: "rastreador",
                origem_dados: "itrack",
            };
        }

        // OUTRA EMPRESA: não existe placa/rastreador para consultar na iTrack.
        return {
            acao: "inserir",
            ...base,
            distancia_km: 0,
            vel_media_kmh: 0,
            vel_max_kmh: 0,
            velocidade_media: 0,
            velocidade_max: 0,
            amostras: 0,
            pontos_json: [],
            source_device: "sem_rastreador",
            origem_dados: "manual_sem_rota",
            observacao: "Veículo de outra empresa ou sem placa/rastreador. Registro salvo sem rota.",
        };
    }

    async function stopAndSave() {
        if (saving) return;

        const snap = readActiveSnapshot();

        // Se a sessão ativa foi perdida por remount/reload, recupera pelo snapshot local.
        if (!activeRef.current && !startTsRef.current && !veiculoRef.current && !snap) {
            console.warn("[TELEMETRIA] Nenhuma sessão ativa encontrada para salvar.");
            return;
        }

        setSaving(true);

        try {
            endTsRef.current = Date.now();

            const payload = buildPayload(snap);

            console.log("[TELEMETRIA] payload stopAndSave", payload);

            try {
                const payloadRecordId = String(
                    payload.sepultamento_id ??
                    ""
                );

                if (isLocalAttendanceId(payloadRecordId)) {
                    throw new Error("atendimento-local");
                }

                if (typeof navigator === "undefined" || navigator.onLine !== false) {
                    const retorno = await postTelemetria(payload);
                    console.log("[TELEMETRIA] retorno PHP", retorno);
                    setMsg({ text: "Telemetria salva!", ok: true });
                } else {
                    throw new Error("offline");
                }
            } catch (e: any) {
                console.error("[TELEMETRIA] falha ao salvar, enfileirando", e);
                enqueueTelemetria(payload);
                setMsg({
                    text: "Telemetria salva no aparelho e será reenviada quando houver conexão.",
                    ok: true,
                });
            }

            await cleanupActiveSession();

            startTsRef.current = null;
            endTsRef.current = null;
            activeRef.current = false;
            veiculoRef.current = null;
            setVeiculo("");

            onSaved?.();
        } finally {
            setSaving(false);
        }
    }

    useEffect(() => {
        if (!open) {
            setVeiculo(veiculoRef.current ? veiculoLabel(veiculoRef.current) : "");
            setMsg(null);
            setStarting(false);
            return;
        }
    }, [open]);

    useEffect(() => {
        flushQueue();
        const on = () => flushQueue();
        window.addEventListener("online", on);
        return () => window.removeEventListener("online", on);
    }, []);

    return (
        <Modal open={open} onClose={onClose} ariaLabel="Selecionar veículo" maxWidth={440}>
            <div className="space-y-4">
                <div className="flex items-start justify-between gap-3">
                    <div>
                        <h2 className="text-lg font-semibold">Selecionar veículo</h2>
                        <div className="mt-1 text-xs text-[#5B6478] dark:text-[#AEB9CF]">{titulo}</div>
                    </div>
                </div>

                <div>
                    <select
                        className="w-full rounded-md border px-3 py-2 text-sm border-[#E3E8F0] dark:border-white/[0.12]"
                        value={veiculo}
                        disabled={saving || starting}
                        onChange={async (e) => {
                            const label = e.target.value;
                            setVeiculo(label);
                            if (!label) return;

                            const escolhido = veiculosOpcoes.find((v) => veiculoLabel(v) === label);
                            if (!escolhido) return;

                            await startAfterSelect(escolhido);
                        }}
                    >
                        <option value="">Selecione…</option>
                        {veiculosOpcoes.map((v) => {
                            const label = veiculoLabel(v);
                            return (
                                <option key={`${v.nome}-${v.placa || label}`} value={label}>
                                    {label}
                                </option>
                            );
                        })}
                    </select>
                </div>

                {msg && (
                    <div
                        className={`rounded-md border px-3 py-2 text-sm border-[#E3E8F0] dark:border-white/[0.12] ${msg.ok ? "border-[#7BA11A]/50 dark:border-[#B3CE52]/40 bg-[#EEF5D6] dark:bg-[#B3CE52]/20 text-[#313C55] dark:text-white" : "border-[#B42318]/40 dark:border-[#FF9C92]/40 bg-[#FDECEA] dark:bg-[#FF9C92]/15 text-[#B42318] dark:text-[#FF9C92]"
                            }`}
                    >
                        {msg.text}
                    </div>
                )}

                <div className="flex justify-end">
                    <button
                        type="button"
                        onClick={onClose}
                        disabled={saving || starting}
                        className="rounded-md border px-3 py-2 text-sm disabled:opacity-60 border-[#E3E8F0] dark:border-white/[0.12]"
                    >
                        Fechar
                    </button>
                </div>
            </div>
        </Modal>
    );
});