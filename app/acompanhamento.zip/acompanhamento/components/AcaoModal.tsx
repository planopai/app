"use client";

import React, { useEffect, useMemo, useState } from "react";
import Modal from "./Modal";
import TextFeedback from "./TextFeedback";
import { Registro } from "./types";
import { fases } from "./constants";
import { dadosFaltandoParaOrnamentacao, itensBaixaCorpoPronto } from "./avisosAcao";
import { BotaoCorrecoesAtendimento } from "@/components/correcoes/CorrecoesAtendimento";
import {
    acaoToStatus,
    isTanatoNo,
    proximaFaseDoRegistro,
    normalizarStatus,
    consultarStatusAtual,
    isVelorioMemorial,
} from "./helpers";
import {
    browserSaysOnline,
    getCurrentOfflineSession,
    type OfflineSession,
} from "@/lib/offline/session";
import {
    isOperationalOfflineCommand,
    validateOfflineResponsibility,
} from "@/lib/offline/actions";

type Fase = (typeof fases)[number];
type FotoAcaoTipo = "fim_ornamentacao" | "entrega_corpo";

export type EstoqueInsuficienteItem = {
    produto_id: number;
    produto_nome: string;
    deposito_nome: string;
    disponivel: number;
    necessario: number;
    faltante: number;
};

export type EstoqueInsuficienteAlerta = {
    titulo: string;
    mensagem: string;
    itens: EstoqueInsuficienteItem[];
};

function isTerceiroBySession(id?: string | number | null | undefined) {
    try {
        if (id == null) return false;
        const raw = sessionStorage.getItem("terceiro_ids");
        if (!raw) return false;
        const arr = JSON.parse(raw) as Array<string | number>;
        return arr.some((v) => String(v) === String(id));
    } catch {
        return false;
    }
}

function isNao(v?: string) {
    const s = (v || "").toString().trim().toLowerCase();
    return s === "não" || s === "nao" || s === "n";
}

const FASES_COM_VEICULO: Fase[] = ["fase01", "fase07", "fase09"];
const FASES_CONSERVACAO: Fase[] = ["fase03", "fase04"];
const FASES_COM_FOTO: Fase[] = ["fase06", "fase08"];

function getFotoAcaoTipo(fase: Fase): FotoAcaoTipo | null {
    if (fase === "fase06") return "fim_ornamentacao";
    if (fase === "fase08") return "entrega_corpo";
    return null;
}

export default function AcaoModal({
    open,
    setOpen,
    registros,
    acaoId,
    registrarAcao,
    acaoMsg,
    acaoSubmitting,
    estoqueInsuficiente,
    onCloseEstoqueInsuficiente,
    onVeiculoRequired,
    onFotoAcaoRequired,
    onAbrirCadastro,
    onCorrecaoFeita,
}: {
    open: boolean;
    setOpen: (b: boolean) => void;
    registros: Registro[];
    acaoId: Registro["id"] | null | undefined;
    registrarAcao: (
        acao: string,
        opts?: {
            skipMaterialCheck?: boolean;
            skipConfirm?: boolean;
            extra?: Record<string, any>;
        },
    ) => Promise<any>;
    acaoMsg: { text: string; ok: boolean } | null;
    acaoSubmitting: boolean;
    estoqueInsuficiente?: EstoqueInsuficienteAlerta | null;
    onCloseEstoqueInsuficiente?: () => void;
    onVeiculoRequired?: (id: string | number | null | undefined, fase: string) => void;
    onFotoAcaoRequired?: (
        id: string | number | null | undefined,
        fase: Fase,
        tipo: FotoAcaoTipo,
    ) => void;
    /** Abre o cadastro completo do atendimento para edição. Sem esta função, vai para /acompanhamento?editar=<id> (o mesmo endereço do Quadro). */
    onAbrirCadastro?: (id: string) => void;
    /** Depois de uma correção da Gestão (voltar etapa / cancelar). Sem esta função, a página recarrega. */
    onCorrecaoFeita?: (msg: string) => void;
}) {
    const [frontMsg, setFrontMsg] = useState<{ text: string; ok: boolean } | null>(null);
    const [me, setMe] = useState<OfflineSession | null>(null);
    const [meLoading, setMeLoading] = useState(false);
    const [meError, setMeError] = useState<string | null>(null);
    const [networkOnline, setNetworkOnline] = useState(true);

    useEffect(() => {
        const update = () => setNetworkOnline(browserSaysOnline());
        update();
        window.addEventListener("online", update);
        window.addEventListener("offline", update);
        return () => {
            window.removeEventListener("online", update);
            window.removeEventListener("offline", update);
        };
    }, []);

    useEffect(() => {
        let cancel = false;

        async function run() {
            setMeError(null);
            if (!open) return;
            setMeLoading(true);
            try {
                const current = await getCurrentOfflineSession({
                    refreshIfOnline: browserSaysOnline(),
                    allowCachedOnNetworkFailure: true,
                });
                if (!cancel) {
                    setMe(current);
                    if (!current) {
                        setMeError("Usuário não está disponível no armazenamento offline. Abra o PAI online antes de sair da empresa.");
                    }
                }
            } catch (e: any) {
                if (!cancel) setMeError(e?.message || "Falha ao identificar o usuário.");
            } finally {
                if (!cancel) setMeLoading(false);
            }
        }

        void run();
        return () => {
            cancel = true;
        };
    }, [open, acaoId, networkOnline]);

    useEffect(() => {
        setFrontMsg(null);
    }, [open, acaoId]);

    const registroLocal = useMemo(() => {
        const r = acaoId != null
            ? registros.find((x) => String(x.id) === String(acaoId))
            : undefined;
        if (!r) return undefined;
        const statusFix = (normalizarStatus(r.status) ?? "fase00") as Fase;
        return { ...r, status: statusFix } as Registro & { status: Fase };
    }, [acaoId, registros]);

    const [loadingOnline, setLoadingOnline] = useState(false);
    const [onlineError, setOnlineError] = useState<string | null>(null);
    const [online, setOnline] = useState<any>(null);

    useEffect(() => {
        let cancel = false;

        async function run() {
            setOnline(null);
            setOnlineError(null);
            if (!open || !acaoId || !browserSaysOnline()) return;

            setLoadingOnline(true);
            try {
                const s: any = await consultarStatusAtual(acaoId);
                if (cancel) return;
                setOnline({
                    ...s,
                    id: String(s.id ?? acaoId),
                    status: (normalizarStatus(s.status) ?? "fase00") as Fase,
                });
            } catch (e: any) {
                if (!cancel) setOnlineError(e?.message || "Falha ao consultar status.");
            } finally {
                if (!cancel) setLoadingOnline(false);
            }
        }

        void run();
        return () => {
            cancel = true;
        };
    }, [open, acaoId, networkOnline]);

    const efetivo = useMemo(() => {
        if (online) {
            return {
                ...registroLocal,
                ...online,
                status: online.status as Fase,
                local_velorio: online.local_velorio || registroLocal?.local_velorio || "",
                sala_velorio: online.sala_velorio || registroLocal?.sala_velorio || "",
                tanato: online.tanato || registroLocal?.tanato || "",
                ornamentacao: online.ornamentacao || registroLocal?.ornamentacao || "",
                assistencia: online.assistencia || registroLocal?.assistencia || "",
                realiza_velorio: online.realiza_velorio || registroLocal?.realiza_velorio || "",
                realiza_sepultamento: online.realiza_sepultamento || registroLocal?.realiza_sepultamento || "",
                tipo_atendimento: online.tipo_atendimento || registroLocal?.tipo_atendimento || "",
                responsavel_velorio_id: online.responsavel_velorio_id ?? registroLocal?.responsavel_velorio_id,
                responsavel_velorio_nome: online.responsavel_velorio_nome ?? registroLocal?.responsavel_velorio_nome,
                responsavel_sepultamento_id:
                    online.responsavel_sepultamento_id ?? registroLocal?.responsavel_sepultamento_id,
                responsavel_sepultamento_nome:
                    online.responsavel_sepultamento_nome ?? registroLocal?.responsavel_sepultamento_nome,
            } as Registro & { status: Fase };
        }
        return registroLocal ?? null;
    }, [online, registroLocal]);

    const tipoEfetivo = String((efetivo as any)?.tipo_atendimento ?? "").trim().toLowerCase();
    const isTerceiro =
        tipoEfetivo === "terceiro" ||
        (tipoEfetivo !== "funerario" && isTerceiroBySession(acaoId));

    const skipConservacao = !!efetivo && isTanatoNo(efetivo.tanato);
    const skipOrnamentacao = !!efetivo && isNao(efetivo.ornamentacao);
    const skipTransportando = !!efetivo && isVelorioMemorial(efetivo);
    const skipMaterialRecolhido = !!efetivo && isNao(efetivo.assistencia);
    const skipVelorio = !!efetivo && isNao(efetivo.realiza_velorio);
    const skipSepultamento = !!efetivo && isNao(efetivo.realiza_sepultamento);

    const fasesVisiveis = useMemo<Fase[]>(() => {
        if (isTerceiro) return ["fase08", "fase09", "fase10"];
        return (fases as readonly Fase[]).filter((f) => {
            if (efetivo && f === efetivo.status) return true;
            if (skipTransportando && f === "fase07") return false;
            if (skipConservacao && (f === "fase03" || f === "fase04")) return false;
            if (skipOrnamentacao && (f === "fase05" || f === "fase06")) return false;
            if (skipVelorio && (f === "fase07" || f === "fase08")) return false;
            if (skipSepultamento && (f === "fase09" || f === "fase10")) return false;
            if (skipMaterialRecolhido && f === "fase11") return false;
            return true;
        }) as Fase[];
    }, [
        isTerceiro,
        efetivo,
        skipTransportando,
        skipConservacao,
        skipOrnamentacao,
        skipVelorio,
        skipSepultamento,
        skipMaterialRecolhido,
    ]);

    const prox = useMemo<Fase | null>(() => {
        if (!efetivo) return null;

        const fluxoCompleto = fases as readonly Fase[];
        const visiveis = fasesVisiveis as readonly Fase[];
        const faseFinal = isTerceiro ? ("fase10" as Fase) : (visiveis[visiveis.length - 1] ?? null);
        if (faseFinal && efetivo.status === faseFinal) return null;

        const p = proximaFaseDoRegistro(
            {
                status: efetivo.status ?? "fase00",
                local_velorio: efetivo.local_velorio,
                sala_velorio: efetivo.sala_velorio,
                tanato: efetivo.tanato,
                ornamentacao: efetivo.ornamentacao,
                assistencia: efetivo.assistencia,
                realiza_velorio: efetivo.realiza_velorio,
                realiza_sepultamento: efetivo.realiza_sepultamento,
            },
            visiveis as readonly string[],
        ) as Fase | null;

        if (p) return p;

        const idxAtual = fluxoCompleto.indexOf(efetivo.status as Fase);
        if (idxAtual === -1) return visiveis[0] ?? null;
        for (let i = idxAtual + 1; i < fluxoCompleto.length; i++) {
            const candidato = fluxoCompleto[i];
            if (visiveis.includes(candidato)) return candidato;
        }
        return null;
    }, [efetivo, fasesVisiveis, isTerceiro]);

    const faseFinalEfetiva = isTerceiro
        ? ("fase10" as Fase)
        : (fasesVisiveis[fasesVisiveis.length - 1] ?? null);
    const concluido = !!efetivo && !!faseFinalEfetiva && efetivo.status === faseFinalEfetiva;

    /* ---- Avisos do mockup ---- */
    // 1) Faltam dados para iniciar a ornamentação: bloqueia o botão até o cadastro ficar completo.
    const faltandoOrn = useMemo(
        () => (efetivo && prox === "fase05" ? dadosFaltandoParaOrnamentacao(efetivo) : []),
        [efetivo, prox],
    );
    // 2) Corpo Pronto: mostra a baixa automática de estoque e só registra depois da confirmação.
    const [confirmandoBaixa, setConfirmandoBaixa] = useState(false);
    const itensBaixa = useMemo(() => (efetivo && prox === "fase12" ? itensBaixaCorpoPronto(efetivo) : []), [efetivo, prox]);
    useEffect(() => {
        setConfirmandoBaixa(false);
    }, [open, acaoId, prox]);

    function abrirCadastroCompleto() {
        const id = acaoId != null ? String(acaoId) : "";
        if (!id) return;
        if (onAbrirCadastro) {
            setOpen(false);
            onAbrirCadastro(id);
        } else if (typeof window !== "undefined") {
            window.location.assign(`/acompanhamento?editar=${encodeURIComponent(id)}`);
        }
    }

    function podeConservacao(): boolean {
        return !!me?.podeConservacao && (me.userId === "7" || me.userId === "16") && me.cargo === "tanatopraxista";
    }

    function offlineBlockReason(f: Fase): string | null {
        if (networkOnline) return null;
        if (!me) return "Usuário offline não identificado.";
        if (!efetivo) return "Atendimento indisponível no cache local.";

        if (f === "fase07") return "Transportando Óbito P/Velório precisa ser iniciado com internet para registrar o responsável.";
        if (f === "fase09") return "Transportando P/ Sepultamento precisa ser iniciado com internet para registrar o responsável.";
        if (f === "fase12") return "Corpo Pronto exige internet por envolver baixa de estoque.";
        if (f === "fase06") return "Fim da Ornamentação permanece online nesta versão.";

        if (isOperationalOfflineCommand(f)) {
            const validation = validateOfflineResponsibility(efetivo, f, me);
            return validation.ok ? null : validation.message;
        }

        return "Esta etapa exige conexão com a internet nesta versão offline.";
    }

    async function handleClickFase(f: Fase, baixaConfirmada = false) {
        setFrontMsg(null);

        const habilitar = prox === f && !acaoSubmitting && !loadingOnline && !concluido;
        if (!habilitar) return;

        if (f === "fase05" && faltandoOrn.length > 0) {
            setFrontMsg({ ok: false, text: `Faltam ${faltandoOrn.length} dado${faltandoOrn.length === 1 ? "" : "s"} para iniciar a ornamentação. Complete o cadastro.` });
            return;
        }
        if (f === "fase12" && !baixaConfirmada && !offlineBlockReason(f)) {
            setConfirmandoBaixa(true);
            return;
        }

        const blockReason = offlineBlockReason(f);
        if (blockReason) {
            setFrontMsg({ ok: false, text: blockReason });
            return;
        }

        const requiresVehicle = FASES_COM_VEICULO.includes(f);
        const isConservacao = FASES_CONSERVACAO.includes(f);

        if (isConservacao) {
            if (meLoading) {
                setFrontMsg({ ok: false, text: "Carregando permissões do usuário. Tente novamente." });
                return;
            }
            if (meError) {
                setFrontMsg({ ok: false, text: meError });
                return;
            }
            if (!podeConservacao()) {
                setFrontMsg({ ok: false, text: "Somente os tanatopraxistas autorizados podem iniciar ou finalizar a conservação." });
                return;
            }

            const ok = window.confirm(`Confirmar "${acaoToStatus(f)}"?`);
            if (!ok) return;
            await registrarAcao(f, { skipConfirm: true, extra: { confirmar: true } });
            return;
        }

        const fotoTipo = FASES_COM_FOTO.includes(f) ? getFotoAcaoTipo(f) : null;
        if (fotoTipo && onFotoAcaoRequired) {
            onFotoAcaoRequired(acaoId ?? null, f, fotoTipo);
            return;
        }

        if (requiresVehicle && onVeiculoRequired) {
            onVeiculoRequired(acaoId ?? null, f);
            return;
        }

        try {
            await registrarAcao(f);
        } catch (e: any) {
            setFrontMsg({ ok: false, text: e?.message || "Falha ao registrar ação." });
        }
    }

    const conteudo = (
        <>
                <div className="mt-2 text-xs text-[#5B6478] dark:text-[#AEB9CF]">
                    {!networkOnline && (
                        <span className="font-semibold text-[#313C55] dark:text-white">
                            Modo offline. Somente as etapas operacionais autorizadas ficam disponíveis.
                        </span>
                    )}
                    {networkOnline && loadingOnline && "Sincronizando status com o servidor..."}
                    {networkOnline && !loadingOnline && online && !onlineError && "Status sincronizado com o servidor."}
                    {networkOnline && !loadingOnline && onlineError && (
                        <span className="text-[#B42318] dark:text-[#FF9C92]">{onlineError}. Exibindo dados locais como fallback.</span>
                    )}
                </div>

                {efetivo && !networkOnline && (
                    <div className="mt-3 rounded-lg border border-[#F2CB3F] bg-[#FCF3CC] dark:bg-[#F2CB3F]/15 p-3 text-xs text-[#313C55] dark:text-white">
                        <div>Usuário: <b>{me?.userName || "não identificado"}</b></div>
                        {efetivo.responsavel_velorio_nome && (
                            <div>Responsável pelo velório: <b>{efetivo.responsavel_velorio_nome}</b></div>
                        )}
                        {efetivo.responsavel_sepultamento_nome && (
                            <div>Responsável pelo sepultamento: <b>{efetivo.responsavel_sepultamento_nome}</b></div>
                        )}
                    </div>
                )}

                {!efetivo && (
                    <p className="mt-4 text-sm text-[#5B6478] dark:text-[#AEB9CF]">
                        Nenhum registro selecionado. Selecione um registro para continuar.
                    </p>
                )}

                {faltandoOrn.length > 0 && (
                    <div role="alert" className="mt-4 rounded-[14px] border-[1.5px] border-[#F2CB3F] bg-[#FCF3CC] p-3.5 text-[#313C55] dark:bg-[#F2CB3F]/16 dark:text-white">
                        <div className="flex items-start gap-2.5">
                            <svg viewBox="0 0 24 24" className="mt-0.5 size-5 shrink-0" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                                <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" />
                                <path d="M12 9v4" />
                                <path d="M12 17h.01" />
                            </svg>
                            <div>
                                <div className="text-sm font-extrabold">
                                    Faltam {faltandoOrn.length} dado{faltandoOrn.length === 1 ? "" : "s"} para iniciar a ornamentação
                                </div>
                                <div className="mt-0.5 text-[13px] leading-snug">Complete o cadastro para liberar o Início da Ornamentação.</div>
                            </div>
                        </div>
                        <div className="mt-2.5 flex flex-col gap-1.5">
                            {faltandoOrn.map((d) => (
                                <button
                                    key={d.chave}
                                    type="button"
                                    onClick={abrirCadastroCompleto}
                                    className="flex min-h-11 w-full items-center gap-2.5 rounded-[10px] border border-[#E3E8F0] bg-white px-3 py-1.5 text-left text-[#313C55] dark:border-white/[0.12] dark:bg-[#232B3F] dark:text-white"
                                >
                                    <span className="size-[22px] shrink-0 rounded-full border-2 border-[#F2CB3F] bg-white dark:bg-[#232B3F]" aria-hidden="true" />
                                    <span className="min-w-0 flex-1">
                                        <span className="block text-[13px] font-bold">{d.rotulo}</span>
                                        <span className="block text-xs text-[#5B6478] dark:text-[#AEB9CF]">Toque para preencher no cadastro</span>
                                    </span>
                                </button>
                            ))}
                        </div>
                        <button
                            type="button"
                            onClick={abrirCadastroCompleto}
                            className="mt-3 flex h-11 w-full items-center justify-center rounded-xl border-[1.5px] border-[#313C55] bg-white text-sm font-extrabold text-[#313C55] hover:bg-[#EEF2F7] dark:border-white/40 dark:bg-[#232B3F] dark:text-white dark:hover:bg-white/10"
                        >
                            Abrir o cadastro completo
                        </button>
                    </div>
                )}

                {efetivo && fasesVisiveis.length > 0 && (
                    <>
                        <p className="mb-2 mt-4 text-xs font-extrabold uppercase tracking-[0.12em] text-[#5B6478] dark:text-[#AEB9CF]">
                            Etapas
                        </p>
                        <div className="grid grid-cols-1 gap-2">
                            {fasesVisiveis.map((f, idx) => {
                                const habilitar = prox === f && !acaoSubmitting && !loadingOnline && !concluido;
                                const isConservacao = FASES_CONSERVACAO.includes(f);
                                const bloqueadoPorCargo = isConservacao && !meLoading && !!me && !podeConservacao();
                                const reason = habilitar ? offlineBlockReason(f) : null;
                                const faltaDados = f === "fase05" && faltandoOrn.length > 0;
                                const disabled = !habilitar || bloqueadoPorCargo || !!reason || faltaDados;
                                const exigeFoto = FASES_COM_FOTO.includes(f);

                                const posProx = prox ? (fasesVisiveis as readonly Fase[]).indexOf(prox) : -1;
                                const feita = concluido || (posProx >= 0 && idx < posProx);
                                const atual = !concluido && prox === f;

                                return (
                                    <button
                                        key={f}
                                        type="button"
                                        disabled={disabled}
                                        onClick={() => handleClickFase(f)}
                                        className={[
                                            "flex min-h-[52px] items-center gap-3 rounded-xl border px-3 py-2 text-left text-sm font-bold outline-none transition focus:ring-2 focus:ring-[#00AEEC]/30 border-[#E3E8F0] dark:border-white/[0.12]",
                                            atual
                                                ? "border-[#F2CB3F] bg-[#F2CB3F] text-[#313C55] hover:bg-[#E4BC30]"
                                                : feita
                                                    ? "border-[#7BA11A] bg-[#EEF5D6] text-[#313C55] dark:border-[#B3CE52]/60 dark:bg-[#B3CE52]/20 dark:text-white"
                                                    : "border-[#E3E8F0] bg-white dark:bg-[#232B3F] text-[#5B6478] opacity-70 dark:border-white/[0.12] dark:bg-[#1C2334] dark:text-[#AEB9CF]",
                                            atual && disabled ? "opacity-70" : "",
                                        ].join(" ")}
                                        title={
                                            reason ||
                                            (faltaDados
                                                ? "Complete o cadastro para liberar o Início da Ornamentação"
                                                : bloqueadoPorCargo
                                                ? "Usuário sem permissão para conservação"
                                                : habilitar && exigeFoto
                                                    ? "Anexar foto para confirmar esta etapa"
                                                    : habilitar
                                                        ? "Confirmar próxima etapa"
                                                        : feita
                                                            ? "Etapa já registrada"
                                                            : "Aguardando etapas anteriores")
                                        }
                                    >
                                        <span
                                            aria-hidden
                                            className={[
                                                "grid size-7 shrink-0 place-items-center rounded-full text-xs font-extrabold",
                                                atual
                                                    ? "bg-[#313C55] text-white"
                                                    : feita
                                                        ? "bg-[#7BA11A] text-white"
                                                        : "bg-[#EEF2F7] text-[#5B6478] dark:bg-white/10 dark:text-[#AEB9CF]",
                                            ].join(" ")}
                                        >
                                            {feita ? "✓" : idx + 1}
                                        </span>
                                        <span className="min-w-0 flex-1">
                                            {acaoToStatus(f)}
                                            {atual && exigeFoto ? (
                                                <span className="mt-0.5 block text-[11px] font-semibold opacity-80">exige foto</span>
                                            ) : null}
                                        </span>
                                    </button>
                                );
                            })}
                        </div>
                    </>
                )}

                {confirmandoBaixa && prox === "fase12" && (
                    <div role="alertdialog" aria-label="Confirmar Corpo Pronto" className="mt-3 rounded-[14px] border-[1.5px] border-[#F2CB3F] bg-[#FCF3CC] p-4 text-[#313C55] dark:bg-[#F2CB3F]/16 dark:text-white">
                        <div className="text-sm font-extrabold">Registrar “{acaoToStatus("fase12")}” agora?</div>
                        <div className="mt-0.5 text-[13px] text-[#5B6478] dark:text-[#AEB9CF]">A etapa fica registrada no atendimento, com seu nome e a hora.</div>
                        <div className="mt-3 rounded-xl border border-[#E3E8F0] bg-white p-3 dark:border-white/[0.12] dark:bg-[#232B3F]">
                            <div className="text-[13px] font-extrabold">Baixa automática no estoque</div>
                            <div className="mt-0.5 text-xs leading-snug text-[#5B6478] dark:text-[#AEB9CF]">
                                O app dá baixa nos itens abaixo, saindo de cada local indicado. Confira antes de confirmar: depois disso os itens do atendimento ficam travados e só a Gestão altera. O saldo é conferido antes de dar baixa.
                            </div>
                            <ul className="mt-2 flex flex-col gap-2">
                                {itensBaixa.length === 0 ? (
                                    <li className="text-[13px] text-[#5B6478] dark:text-[#AEB9CF]">Nenhum item com baixa neste cadastro.</li>
                                ) : (
                                    itensBaixa.map((b, i) => (
                                        <li key={`${b.nome}-${b.local ?? ""}-${i}`} className={`flex items-baseline gap-3 text-[13px] ${b.semBaixa ? "text-[#5B6478] dark:text-[#AEB9CF]" : ""}`}>
                                            <span className="min-w-0 flex-1 break-words">
                                                <span className="font-bold">{b.nome}</span>
                                                {!b.semBaixa && (
                                                    <span className="mt-0.5 block text-xs font-semibold text-[#5B6478] dark:text-[#AEB9CF]">
                                                        Sai de: {b.local ? <b className="font-extrabold text-[#313C55] dark:text-white">{b.local}</b> : "local definido pelo sistema"}
                                                    </span>
                                                )}
                                            </span>
                                            <span className="shrink-0 text-xs font-extrabold text-[#5B6478] dark:text-[#AEB9CF]">{b.qtd}</span>
                                        </li>
                                    ))
                                )}
                            </ul>
                        </div>
                        <div className="mt-3 flex gap-2">
                            <button
                                type="button"
                                onClick={() => setConfirmandoBaixa(false)}
                                disabled={acaoSubmitting}
                                className="h-12 flex-1 rounded-xl border-[1.5px] border-[#313C55] bg-white text-sm font-extrabold text-[#313C55] hover:bg-[#EEF2F7] disabled:opacity-60 dark:border-white/40 dark:bg-[#232B3F] dark:text-white dark:hover:bg-white/10"
                            >
                                Cancelar
                            </button>
                            <button
                                type="button"
                                onClick={async () => {
                                    setConfirmandoBaixa(false);
                                    await handleClickFase("fase12" as Fase, true);
                                }}
                                disabled={acaoSubmitting}
                                className="h-12 flex-[1.4] rounded-xl bg-[#313C55] text-sm font-extrabold text-white hover:bg-[#232B40] disabled:opacity-60 dark:bg-[#3D6A99] dark:text-white dark:hover:bg-[#355D86]"
                            >
                                Confirmar Corpo Pronto
                            </button>
                        </div>
                    </div>
                )}

                {/* Correções da Gestão (09/10/2026): voltar uma etapa ou cancelar o atendimento. Só aparece com a página Gestão. */}
                {efetivo && networkOnline && (
                    <BotaoCorrecoesAtendimento
                        className="mt-4"
                        id={acaoId}
                        falecido={(efetivo as any)?.falecido}
                        onFeito={(msg) => {
                            setOpen(false);
                            if (onCorrecaoFeita) onCorrecaoFeita(msg);
                            else if (typeof window !== "undefined") window.location.reload();
                        }}
                    />
                )}

                {concluido && (
                    <p className="mt-3 rounded-xl border border-[#7BA11A] bg-[#EEF5D6] px-3 py-2 text-sm font-bold text-[#313C55] dark:border-[#B3CE52]/60 dark:bg-[#B3CE52]/20 dark:text-white">Todas as etapas registradas.</p>
                )}

                {meError && !networkOnline && (
                    <TextFeedback kind="error">{meError}</TextFeedback>
                )}
                {frontMsg && <TextFeedback kind={frontMsg.ok ? "success" : "error"}>{frontMsg.text}</TextFeedback>}
                {acaoMsg && <TextFeedback kind={acaoMsg.ok ? "success" : "error"}>{acaoMsg.text}</TextFeedback>}
        </>
    );

    return (
        <>
            {/* Janela dinâmica: só existe quando o usuário toca em "Registrar ação". No computador abre pela direita; no celular sobe de baixo. */}
            <Modal
                open={open}
                onClose={() => setOpen(false)}
                ariaLabel="Registrar ação"
                variant="drawer"
                maxWidth={480}
                eyebrow="Registrar uma ação"
                title={(efetivo as any)?.falecido || "Atendimento"}
            >
                {conteudo}
            </Modal>

            <Modal
                open={!!estoqueInsuficiente}
                onClose={() => onCloseEstoqueInsuficiente?.()}
                ariaLabel="Estoque insuficiente"
                role="alertdialog"
                maxWidth={560}
                zIndex={80}
                closeOnBackdrop={false}
            >
                <div className="text-center" aria-live="assertive">
                    <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#FDECEA] dark:bg-[#FF9C92]/15 text-3xl font-bold text-[#B42318] dark:text-[#FF9C92]">
                        !
                    </div>

                    <h2 className="mt-4 text-2xl font-bold text-[#B42318] dark:text-[#FF9C92]">
                        {estoqueInsuficiente?.titulo || "Estoque insuficiente"}
                    </h2>

                    <p className="mt-3 text-base font-semibold text-[#B42318] dark:text-[#FF9C92]">
                        {estoqueInsuficiente?.mensagem ||
                            "Não é possível avançar para Corpo Pronto."}
                    </p>
                </div>

                {!!estoqueInsuficiente?.itens?.length && (
                    <div className="mt-5 space-y-3">
                        {estoqueInsuficiente.itens.map((item, index) => (
                            <div
                                key={`${item.produto_id}-${item.deposito_nome}-${index}`}
                                className="rounded-xl border-2 border-[#B42318]/40 dark:border-[#FF9C92]/40 bg-[#FDECEA] dark:bg-[#FF9C92]/15 p-4"
                            >
                                <div className="text-base font-bold text-[#B42318] dark:text-[#FF9C92]">
                                    {item.produto_nome || `Produto ${item.produto_id}`}
                                </div>

                                <div className="mt-1 text-sm text-[#B42318] dark:text-[#FF9C92]">
                                    Depósito:{" "}
                                    <b>{item.deposito_nome || "não informado"}</b>
                                </div>

                                <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                                    <div className="rounded-lg bg-white dark:bg-[#232B3F] p-2 text-[#B42318] dark:text-[#FF9C92]">
                                        Disponível:{" "}
                                        <b>{item.disponivel}</b>
                                    </div>
                                    <div className="rounded-lg bg-white dark:bg-[#232B3F] p-2 text-[#B42318] dark:text-[#FF9C92]">
                                        Necessário:{" "}
                                        <b>{item.necessario}</b>
                                    </div>
                                </div>

                                <p className="mt-3 text-sm font-semibold text-[#B42318] dark:text-[#FF9C92]">
                                    É necessário repor este item
                                    {item.faltante > 0
                                        ? ` em pelo menos ${item.faltante} unidade${item.faltante === 1 ? "" : "s"}`
                                        : ""}
                                    {" "}para avançar.
                                </p>
                            </div>
                        ))}
                    </div>
                )}

                <div className="mt-5 rounded-xl border border-[#B42318]/40 dark:border-[#FF9C92]/40 bg-[#FDECEA] dark:bg-[#FF9C92]/15 p-4 text-center">
                    <p className="text-sm font-bold text-[#B42318] dark:text-[#FF9C92]">
                        Faça a reposição do estoque e tente novamente o comando
                        Corpo Pronto.
                    </p>
                </div>

                <div className="mt-6 flex justify-center">
                    <button
                        type="button"
                        autoFocus
                        onClick={() => onCloseEstoqueInsuficiente?.()}
                        className="min-w-40 rounded-lg bg-[#B42318] px-5 py-3 text-sm font-bold text-white shadow-sm hover:bg-[#8F1B12] focus:outline-none focus:ring-2 focus:ring-[#B42318] focus:ring-offset-2"
                    >
                        Entendi
                    </button>
                </div>
            </Modal>
        </>
    );
}
