"use client";

import React, { useMemo, useState } from "react";
import type { Aviso, Registro } from "./types";
import TextFeedback from "./TextFeedback";

const TAG_SERVICO = "Atendimento:";
const TAG_GERAL = "Geral:";

function startsWithFalecidoPrefix(s: string) {
    const t = (s || "").trim().toLowerCase();
    // aceita: "Falecido(a):", "Falecido:", "Falecida:", etc
    return (
        t.startsWith("falecido(a):") ||
        t.startsWith("falecido:") ||
        t.startsWith("falecida:") ||
        t.startsWith("falecidos(a):") ||
        t.startsWith("falecidos:")
    );
}

function parseAvisoMensagem(raw: any): { tag: "Serviço" | "Geral"; text: string } {
    const s = String(raw ?? "").trim();

    // ✅ Serviço: tag explícita do sistema
    if (s.startsWith(TAG_SERVICO)) {
        return { tag: "Serviço", text: s.slice(TAG_SERVICO.length).trim() };
    }

    // ✅ Serviço: mensagens antigas vindas da aba INFO (começam com "Falecido(a): ...")
    if (startsWithFalecidoPrefix(s)) {
        return { tag: "Serviço", text: s };
    }

    // ✅ Geral
    if (s.startsWith(TAG_GERAL)) {
        return { tag: "Geral", text: s.slice(TAG_GERAL.length).trim() };
    }

    // fallback (caso exista aviso antigo sem tag)
    return { tag: "Geral", text: s };
}

function TagChip({ kind }: { kind: "Serviço" | "Geral" }) {
    // ✅ Geral = vermelho | Serviço = amarelo
    const cls =
        kind === "Serviço"
            ? "bg-[#FCF3CC] dark:bg-[#F2CB3F]/15 text-[#313C55] dark:text-white border-[#F2CB3F]"
            : "bg-[#FDECEA] dark:bg-[#FF9C92]/15 text-[#B42318] dark:text-[#FF9C92] border-[#B42318]/40 dark:border-[#FF9C92]/40";

    return (
        <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[12px] border-[#E3E8F0] dark:border-white/[0.12] ${cls}`}>
            {kind}
        </span>
    );
}

function Modal({
    open,
    title,
    subtitle,
    children,
    onClose,
    disableClose,
}: {
    open: boolean;
    title: string;
    subtitle?: string;
    children: React.ReactNode;
    onClose: () => void;
    disableClose?: boolean;
}) {
    if (!open) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6">
            <div
                className="absolute inset-0 bg-black/40"
                onClick={disableClose ? undefined : onClose}
                aria-hidden
            />
            <div className="relative z-10 w-full max-w-lg rounded-2xl border bg-[#F1F4F8] dark:bg-[#1C2334] shadow-2xl overflow-hidden border-[#E3E8F0] dark:border-white/[0.12]">
                <div className="border-b px-4 py-3 sm:px-5 sm:py-4 bg-[#F6F8FB] dark:bg-[#1C2334]">
                    <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                            <h3 className="text-base sm:text-lg font-semibold leading-tight break-words [overflow-wrap:anywhere]">
                                {title}
                            </h3>
                            {subtitle ? (
                                <p className="mt-1 text-[14px] text-[#5B6478] dark:text-[#AEB9CF] break-words [overflow-wrap:anywhere]">
                                    {subtitle}
                                </p>
                            ) : null}
                        </div>

                        <button
                            type="button"
                            className="shrink-0 rounded-full border px-3 py-1.5 text-[14px] hover:bg-[#EEF2F7] dark:hover:bg-white/10 disabled:opacity-60 border-[#E3E8F0] dark:border-white/[0.12]"
                            onClick={onClose}
                            disabled={!!disableClose}
                            aria-label="Fechar"
                            title="Fechar"
                        >
                            Fechar
                        </button>
                    </div>
                </div>

                <div className="px-4 py-4 sm:px-5 sm:py-5">{children}</div>
            </div>
        </div>
    );
}

export default function AvisosBox({
    avisos,
    registros,
    onAddObservacao,

    avisoMsg,
    setAvisoMsg,
    enviarAviso,
    editarAviso,
    excluirAviso,
    avisoInputRef,
}: {
    avisos: Aviso[];
    registros: Registro[];
    onAddObservacao: (registroId: string) => void;

    avisoMsg: { text: string; ok: boolean } | null;
    setAvisoMsg: (m: { text: string; ok: boolean } | null) => void;

    enviarAviso: () => Promise<void>;
    editarAviso: (id: number | string, mensagem: string) => Promise<void>;
    excluirAviso: (id: number | string) => Promise<void>;

    avisoInputRef: React.RefObject<HTMLInputElement | null>;
}) {
    // -------- Modal edição de aviso ----------
    const [editOpen, setEditOpen] = useState(false);
    const [editLoading, setEditLoading] = useState(false);
    const [editId, setEditId] = useState<number | string | null>(null);
    const [editTag, setEditTag] = useState<"Serviço" | "Geral">("Geral");
    const [editText, setEditText] = useState("");

    const avisosAtivos = useMemo(() => {
        return (avisos ?? []).filter((a: any) => Number(a?.finalizado ?? 0) !== 1);
    }, [avisos]);

    const openEdit = (a: any) => {
        const { tag, text } = parseAvisoMensagem(a?.mensagem);
        setEditId(a?.id);
        setEditTag(tag);
        setEditText(text);
        setEditOpen(true);
    };

    const closeEdit = () => {
        if (editLoading) return;
        setEditOpen(false);
        setEditId(null);
        setEditText("");
    };

    const submitEdit = async () => {
        if (editId == null) return;

        const t = editText.trim();
        if (!t) {
            setAvisoMsg({ ok: false, text: "Digite um texto para salvar." });
            return;
        }

        setEditLoading(true);
        try {
            // ✅ Se o texto já começa com "Falecido(a):", manter assim (continua sendo Serviço pelo parser)
            // Caso contrário, mantém tags [Serviço]/[Geral] quando editar.
            const mensagem =
                startsWithFalecidoPrefix(t)
                    ? t
                    : `${editTag === "Serviço" ? TAG_SERVICO : TAG_GERAL} ${t}`;

            await editarAviso(editId, mensagem);
            setAvisoMsg({ ok: true, text: "Aviso atualizado!" });
            closeEdit();
        } catch (e: any) {
            setAvisoMsg({ ok: false, text: e?.message || "Erro ao editar!" });
        } finally {
            setEditLoading(false);
        }
    };

    return (
        <section className="space-y-4">
            {/* Atendimentos */}
            <div className="rounded-2xl border bg-white dark:bg-[#232B3F] p-4 sm:p-5 border-[#E3E8F0] dark:border-white/[0.12]">
                <div className="flex items-center justify-between gap-3">
                    <h2 className="text-lg font-semibold">Atendimentos</h2>
                    <span className="text-sm text-[#5B6478] dark:text-[#AEB9CF]">{registros?.length ?? 0} ativo(s)</span>
                </div>

                <div className="mt-3 space-y-2">
                    {(registros ?? []).map((r: any) => (
                        <div
                            key={String(r?.id)}
                            className="rounded-xl border bg-[#F1F4F8]/60 dark:bg-[#1C2334]/60 p-3 sm:p-4 border-[#E3E8F0] dark:border-white/[0.12]"
                        >
                            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                <div className="min-w-0">
                                    <div className="font-semibold break-words [overflow-wrap:anywhere]">
                                        {String(r?.falecido ?? "")}
                                    </div>
                                    <div className="mt-1 text-[14px] text-[#5B6478] dark:text-[#AEB9CF]">
                                        Status: {String(r?.status ?? "")}
                                    </div>
                                </div>

                                <button
                                    type="button"
                                    className="w-full sm:w-auto rounded-xl bg-[#313C55] dark:bg-[#F2CB3F] px-4 py-2 text-[14px] font-semibold text-white dark:text-[#313C55] hover:bg-[#232B40] dark:hover:bg-[#E4BC30]"
                                    onClick={() => onAddObservacao(String(r?.id))}
                                >
                                    Adicionar Observação
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Enviar Aviso Geral */}
            <div className="rounded-2xl border bg-white dark:bg-[#232B3F] p-4 sm:p-5 border-[#E3E8F0] dark:border-white/[0.12]">
                <h2 className="text-lg font-semibold">Aviso Geral</h2>

                <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
                    <input
                        ref={avisoInputRef as React.RefObject<HTMLInputElement>}
                        type="text"
                        maxLength={255}
                        placeholder="Digite um aviso..."
                        className="w-full flex-1 rounded-xl border px-3 py-2 text-[16px] border-[#E3E8F0] dark:border-white/[0.12]"
                        onKeyDown={(e) => {
                            if (e.key === "Enter") enviarAviso();
                        }}
                    />

                    <button
                        type="button"
                        className="w-full sm:w-auto rounded-xl bg-[#313C55] dark:bg-[#F2CB3F] px-4 py-2 text-[14px] font-semibold text-white dark:text-[#313C55] hover:bg-[#232B40] dark:hover:bg-[#E4BC30]"
                        onClick={enviarAviso}
                    >
                        Enviar
                    </button>
                </div>

                {avisoMsg ? (
                    <div className="mt-2">
                        <TextFeedback kind={avisoMsg.ok ? "success" : "error"}>
                            {avisoMsg.text}
                        </TextFeedback>
                    </div>
                ) : null}
            </div>

            {/* Avisos */}
            <div className="rounded-2xl border bg-white dark:bg-[#232B3F] p-4 sm:p-5 border-[#E3E8F0] dark:border-white/[0.12]">
                <h2 className="text-lg font-semibold">Avisos Ativos</h2>

                <div className="mt-3 space-y-2">
                    {avisosAtivos.length === 0 ? (
                        <div className="rounded-xl border bg-[#F1F4F8]/60 dark:bg-[#1C2334]/60 p-4 text-sm text-[#5B6478] dark:text-[#AEB9CF] border-[#E3E8F0] dark:border-white/[0.12]">
                            Nenhum aviso no momento.
                        </div>
                    ) : (
                        avisosAtivos.map((a: any) => {
                            const { tag, text } = parseAvisoMensagem(a?.mensagem);
                            const usuario = String(a?.usuario ?? "").trim();
                            const criadoEm = a?.criado_em ? new Date(a.criado_em).toLocaleString() : "";

                            return (
                                <div key={String(a?.id)} className="rounded-xl border bg-[#F1F4F8]/60 dark:bg-[#1C2334]/60 p-3 sm:p-4 border-[#E3E8F0] dark:border-white/[0.12]">
                                    <div className="flex flex-wrap items-center gap-2">
                                        <TagChip kind={tag} />
                                        {usuario ? (
                                            <span className="rounded-full border bg-[#F6F8FB] dark:bg-[#1C2334] px-2 py-0.5 text-[12px] border-[#E3E8F0] dark:border-white/[0.12]">
                                                {usuario}
                                            </span>
                                        ) : null}

                                        {criadoEm ? (
                                            <span className="text-[12px] text-[#5B6478] dark:text-[#AEB9CF]">{criadoEm}</span>
                                        ) : null}
                                    </div>

                                    <div className="mt-2 text-[16px] leading-relaxed break-words [overflow-wrap:anywhere]">
                                        {text}
                                    </div>

                                    <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:justify-end">
                                        <button
                                            type="button"
                                            className="w-full sm:w-auto rounded-xl bg-[#313C55] dark:bg-[#F2CB3F] px-4 py-2 text-[14px] font-semibold text-white dark:text-[#313C55] hover:bg-[#232B40] dark:hover:bg-[#E4BC30]"
                                            onClick={() => openEdit(a)}
                                        >
                                            Editar
                                        </button>

                                        <button
                                            type="button"
                                            className="w-full sm:w-auto rounded-xl bg-[#313C55] dark:bg-[#F2CB3F] px-4 py-2 text-[14px] font-semibold text-white dark:text-[#313C55] hover:bg-[#232B40] dark:hover:bg-[#E4BC30]"
                                            onClick={() => excluirAviso(a?.id)}
                                        >
                                            Excluir
                                        </button>
                                    </div>
                                </div>
                            );
                        })
                    )}
                </div>
            </div>

            {/* Modal editar aviso */}
            <Modal
                open={editOpen}
                title="Editar aviso"
                subtitle={editTag ? `Tipo: ${editTag}` : undefined}
                onClose={closeEdit}
                disableClose={editLoading}
            >
                <label className="block text-[14px] font-medium text-[#5B6478] dark:text-[#AEB9CF]">Texto</label>
                <textarea
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    rows={5}
                    maxLength={255}
                    className="mt-2 w-full rounded-xl border px-3 py-2 text-[16px] outline-none focus:ring-2 focus:ring-[#00AEEC]/30 border-[#E3E8F0] dark:border-white/[0.12]"
                    placeholder="Digite o aviso..."
                />

                <div className="mt-4 flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2">
                    <button
                        type="button"
                        className="w-full sm:w-auto rounded-xl border px-4 py-2 text-[14px] hover:bg-[#EEF2F7] dark:hover:bg-white/10 disabled:opacity-60 border-[#E3E8F0] dark:border-white/[0.12]"
                        onClick={closeEdit}
                        disabled={editLoading}
                    >
                        Cancelar
                    </button>

                    <button
                        type="button"
                        className="w-full sm:w-auto rounded-xl bg-[#313C55] dark:bg-[#F2CB3F] px-4 py-2 text-[14px] font-semibold text-white dark:text-[#313C55] hover:bg-[#232B40] dark:hover:bg-[#E4BC30] disabled:opacity-60"
                        onClick={submitEdit}
                        disabled={editLoading}
                    >
                        {editLoading ? "Salvando..." : "Salvar"}
                    </button>
                </div>
            </Modal>
        </section>
    );
}