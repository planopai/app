"use client";

/**
 * Messenger — conversas da equipe, grupos e atendimento de clientes pelo WhatsApp.
 * Rota /messenger · página "messenger" do pai_api.php · API: messenger.php
 * Visual do mockup "PAI Messenger estilo WhatsApp" (07/10/2026).
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { enviarArquivo, msgGet, msgPost, novoUuid } from "@/components/messenger/api";
import { audioParaMp3, comprimirFoto } from "@/components/messenger/compressao";
import { ativarNotificacoes, ouvir, ouvirNotificacoes, ouvirSeguranca, type EstadoNotificacoes } from "@/components/messenger/tempoReal";
import { ocultarBarraCelular } from "@/components/barra/BarraCelular";
import { useSemZoom } from "@/components/messenger/semZoom";
import type { Aba, Conversa, EtiquetaCurta, Mensagem, Perfil, Setor } from "@/components/messenger/tipos";
import { Abas, Icone, LinhaConversa, SeloCor, TIPO_CONTATO_SELO } from "./components/Lista";
import NovaConversaWhats from "./components/NovaConversaWhats";
import JanelaConversa from "./components/Conversa";
import { DetalhesGrupo, Encaminhar, EnviarContato, EtiquetasConversa, NovaConversa, Transferir } from "./components/Modais";
import HistoricoClientes from "./components/Historico";
import PainelCliente from "./components/PainelCliente";
import { salvarAutomatico } from "@/components/messenger/salvarArquivos";

/**
 * Celular com a conversa aberta: a conversa ocupa só a parte visível da tela (acima do teclado),
 * como no WhatsApp. No iPhone o teclado não diminui a página; por isso a altura vem do visualViewport.
 */
function useAreaVisivel(ativo: boolean) {
    const [area, setArea] = useState<{ altura: number; topo: number } | null>(null);
    useEffect(() => {
        if (!ativo || typeof window === "undefined" || !window.visualViewport) {
            setArea(null);
            return;
        }
        const vv = window.visualViewport;
        const celular = window.matchMedia("(max-width: 767px)");
        const medir = () => setArea(celular.matches ? { altura: Math.round(vv.height), topo: Math.round(vv.offsetTop) } : null);
        medir();
        // o iPhone nem sempre avisa quando o teclado fecha: mede de novo logo depois de sair/entrar no campo
        const remedir = () => [60, 300, 700].forEach((ms) => setTimeout(medir, ms));
        const aoSairDoCampo = () => {
            remedir();
            setTimeout(() => window.scrollTo(0, 0), 120); // a página não fica rolada depois que o teclado some
        };
        vv.addEventListener("resize", medir);
        vv.addEventListener("scroll", medir);
        window.addEventListener("resize", remedir);
        window.addEventListener("orientationchange", remedir);
        document.addEventListener("focusin", remedir);
        document.addEventListener("focusout", aoSairDoCampo);
        celular.addEventListener?.("change", medir);
        const antes = document.documentElement.style.overflow;
        document.documentElement.style.overflow = "hidden";
        return () => {
            vv.removeEventListener("resize", medir);
            vv.removeEventListener("scroll", medir);
            window.removeEventListener("resize", remedir);
            window.removeEventListener("orientationchange", remedir);
            document.removeEventListener("focusin", remedir);
            document.removeEventListener("focusout", aoSairDoCampo);
            celular.removeEventListener?.("change", medir);
            document.documentElement.style.overflow = antes;
        };
    }, [ativo]);
    return area;
}

/**
 * Presença dos colegas ("online" / "visto por último"): consulta o servidor a cada 30 s com a tela aberta.
 * O app avisa a presença de qualquer tela (tempoReal.ts); "online" = visto há até 2 minutos.
 */
function usePresencas() {
    const [dados, setDados] = useState<{ vistos: Record<string, string>; limite: number; ajuste: number }>({ vistos: {}, limite: 120, ajuste: 0 });
    const [, setTique] = useState(0);
    useEffect(() => {
        let vivo = true;
        const buscar = async () => {
            if (document.visibilityState !== "visible") return;
            try {
                const d = await msgGet<{ agora: string; online_segundos: number; vistos: Record<string, string> }>("presencas", {}, false);
                if (vivo) setDados({ vistos: d.vistos || {}, limite: d.online_segundos || 120, ajuste: Date.now() - Date.parse(d.agora) });
            } catch {
                /* sem presença: ninguém aparece online */
            }
        };
        buscar();
        const t = setInterval(() => { buscar(); setTique((n) => n + 1); }, 30000);
        const aoVoltar = () => document.visibilityState === "visible" && buscar();
        document.addEventListener("visibilitychange", aoVoltar);
        return () => {
            vivo = false;
            clearInterval(t);
            document.removeEventListener("visibilitychange", aoVoltar);
        };
    }, []);
    const vistoEm = (id?: number | null) => (id && dados.vistos[String(id)] ? Date.parse(dados.vistos[String(id)]) : 0);
    const online = (id?: number | null) => {
        const v = vistoEm(id);
        return v > 0 && Date.now() - dados.ajuste - v <= dados.limite * 1000;
    };
    const texto = (id?: number | null) => {
        if (!id) return "";
        if (online(id)) return "online";
        const v = vistoEm(id);
        if (!v) return "";
        const d = new Date(v);
        const h = d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
        const hoje = new Date();
        const ontem = new Date(hoje.getTime() - 86400000);
        if (d.toDateString() === hoje.toDateString()) return `visto por último hoje às ${h}`;
        if (d.toDateString() === ontem.toDateString()) return `visto por último ontem às ${h}`;
        return `visto por último em ${d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })} às ${h}`;
    };
    return { online, texto };
}

const TIPOS_DOC: Record<string, string> = {
    pdf: "application/pdf", doc: "application/msword", docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    xls: "application/vnd.ms-excel", xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ppt: "application/vnd.ms-powerpoint", pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation", txt: "text/plain", mp4: "video/mp4",
};

export default function MessengerPage() {
    const [perfil, setPerfil] = useState<Perfil | null>(null);
    const [aba, setAba] = useState<Aba>("tudo");
    const [conversas, setConversas] = useState<Conversa[]>([]);
    const [fila, setFila] = useState<Conversa[]>([]);
    const [selId, setSelId] = useState<number | null>(null);
    const [conversaSel, setConversaSel] = useState<Conversa | null>(null);
    const [mensagens, setMensagens] = useState<Mensagem[]>([]);
    const [temMais, setTemMais] = useState(false);
    const [fixadas, setFixadas] = useState<Mensagem[]>([]);
    const [busca, setBusca] = useState("");
    const [erro, setErro] = useState("");
    const [aviso, setAviso] = useState("");
    // avisos de sucesso somem sozinhos; erros ficam até fechar
    useEffect(() => {
        if (!aviso) return;
        const t = setTimeout(() => setAviso(""), 4000);
        return () => clearTimeout(t);
    }, [aviso]);
    const [carregando, setCarregando] = useState(true);
    const [seguranca, setSeguranca] = useState(false);
    const [digitando, setDigitando] = useState<Record<number, { nome: string; ate: number }>>({});
    const [modal, setModal] = useState<null | "nova" | "grupo" | "whats" | "transferir" | "detalhes" | "contato" | "encaminhar" | "etiquetas">(null);
    // pacote 4A: filtros da aba Clientes por setor (0 = todos, -1 = sem setor) e por etiqueta
    const [setores, setSetores] = useState<Setor[]>([]);
    const [filtroSetor, setFiltroSetor] = useState(0);
    const [filtroEtiqueta, setFiltroEtiqueta] = useState(0);
    const [filtroTipo, setFiltroTipo] = useState(""); // 27/10/2026: tipo de contato (fornecedor, prestador, parceiro, público)
    const [paraEncaminhar, setParaEncaminhar] = useState<Mensagem | null>(null);
    const [verHistorico, setVerHistorico] = useState(false);
    const [pastaEquipeAberta, setPastaEquipeAberta] = useState(false);
    // computador: tela cheia (o Messenger cobre o menu lateral e o topo do app); a escolha fica guardada no aparelho
    const [telaCheia, setTelaCheia] = useState(false);
    useEffect(() => {
        try {
            setTelaCheia(localStorage.getItem("pai.msg.telacheia") === "1");
        } catch {
            /* sem armazenamento */
        }
    }, []);
    // tela cheia: a página de trás não rola e o menu do app fica escondido debaixo do Messenger
    useEffect(() => {
        if (!telaCheia || !window.matchMedia("(min-width: 768px)").matches) return;
        const antes = document.body.style.overflow;
        document.body.style.overflow = "hidden";
        const esc = (e: KeyboardEvent) => e.key === "Escape" && !document.querySelector('[role="dialog"]') && alternarTelaCheia();
        window.addEventListener("keydown", esc);
        return () => {
            document.body.style.overflow = antes;
            window.removeEventListener("keydown", esc);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [telaCheia]);
    const alternarTelaCheia = () => {
        setTelaCheia((v) => {
            try {
                localStorage.setItem("pai.msg.telacheia", v ? "0" : "1");
            } catch {
                /* sem armazenamento */
            }
            return !v;
        });
    };
    // mensagem que está sendo respondida (responder direcionado, como no WhatsApp)
    const [respondendo, setRespondendo] = useState<Mensagem | null>(null);
    useEffect(() => setRespondendo(null), [selId]);
    // pacote 5B: painel do cliente (Unymos) — terceira coluna em tela larga, por cima nas demais
    const [painelCli, setPainelCli] = useState(false);
    const [textoPainel, setTextoPainel] = useState<{ texto: string; n: number }>({ texto: "", n: 0 });
    useEffect(() => setPainelCli(false), [selId]);
    const [largo, setLargo] = useState(false);
    useEffect(() => {
        const mq = window.matchMedia("(min-width: 1280px)");
        const medir = () => setLargo(mq.matches);
        medir();
        mq.addEventListener?.("change", medir);
        return () => mq.removeEventListener?.("change", medir);
    }, []);
    const presenca = usePresencas();
    useSemZoom();
    const [notif, setNotif] = useState<{ estado: EstadoNotificacoes; detalhe?: string }>({ estado: "desligadas" });
    const selRef = useRef<number | null>(null);
    const perfilRef = useRef<Perfil | null>(null);
    selRef.current = selId;
    perfilRef.current = perfil;

    /* ---------- carregamento ---------- */
    const carregarListas = useCallback(async () => {
        try {
            const [lista, pf] = await Promise.all([msgGet<Conversa[]>("conversas"), perfil ? Promise.resolve(perfil) : msgGet<Perfil>("perfil")]);
            setConversas(lista);
            if (!perfil) setPerfil(pf);
            if (pf.atendente) setFila(await msgGet<Conversa[]>("fila").catch(() => []));
            msgGet<{ setores: Setor[] }>("setores", {}, false).then((d) => setSetores(d.setores.filter((x) => x.ativo))).catch(() => setSetores([]));
            setErro("");
        } catch (e: any) {
            setErro(e.message);
        } finally {
            setCarregando(false);
        }
    }, [perfil]);

    const abrirConversa = useCallback(async (id: number, manterMensagens = false) => {
        setSelId(id);
        if (!manterMensagens) {
            setMensagens([]);
            setTemMais(false);
            setFixadas([]);
        }
        const u = new URL(window.location.href);
        u.searchParams.set("conversa", String(id));
        window.history.replaceState(null, "", u.toString());
        try {
            const d = await msgGet<{ conversa: Conversa; mensagens: Mensagem[]; tem_mais: boolean; fixadas?: Mensagem[] }>("mensagens", { conversa_id: id });
            if (selRef.current !== id) return;
            setConversaSel(d.conversa);
            setFixadas(d.fixadas || []);
            setMensagens(d.mensagens);
            setTemMais(d.tem_mais);
            const ultimo = d.mensagens[d.mensagens.length - 1];
            if (ultimo && d.conversa.participo) {
                await msgPost("marcar_lida", { conversa_id: id, ate_id: ultimo.id }).catch(() => {});
                window.dispatchEvent(new Event("messenger:lida"));
                setConversas((cs) => cs.map((c) => (c.id === id ? { ...c, nao_lidas: 0, marcada_nao_lida: false } : c)));
            }
        } catch (e: any) {
            if (e.status === 403 || e.status === 404) {
                setSelId(null);
                setConversaSel(null);
                setAviso(e.message);
            } else setErro(e.message);
        }
    }, []);

    const fecharConversa = () => {
        setSelId(null);
        setConversaSel(null);
        const u = new URL(window.location.href);
        u.searchParams.delete("conversa");
        window.history.replaceState(null, "", u.toString());
    };

    useEffect(() => {
        carregarListas();
        const id = Number(new URLSearchParams(window.location.search).get("conversa") || 0);
        if (id) abrirConversa(id);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    /* ---------- barra de baixo do celular: some com a conversa aberta ---------- */
    useEffect(() => {
        ocultarBarraCelular(selId !== null);
    }, [selId]);
    useEffect(() => () => {
        ocultarBarraCelular(false);
    }, []);

    /* ---------- notificações (OneSignal, o mesmo do app) ----------
       Com o app aberto na própria conversa, não mostra a notificação dela. */
    useEffect(() => {
        const w = window as any;
        let oneSignal: any = null;
        const aoExibir = (ev: any) => {
            const dados = ev?.notification?.additionalData || {};
            if (dados.origem === "messenger" && Number(dados.conversa_id) === selRef.current && document.visibilityState === "visible") {
                ev.preventDefault();
            }
        };
        w.OneSignalDeferred = w.OneSignalDeferred || [];
        w.OneSignalDeferred.push((OS: any) => {
            oneSignal = OS;
            OS?.Notifications?.addEventListener?.("foregroundWillDisplay", aoExibir);
        });
        return () => oneSignal?.Notifications?.removeEventListener?.("foregroundWillDisplay", aoExibir);
    }, []);

    /* ---------- notificações pela Ably (quando o servidor usa esse canal) ---------- */
    useEffect(() => ouvirNotificacoes((estado, detalhe) => setNotif({ estado, detalhe })), []);

    /* ---------- tempo real ---------- */
    const recarregarDepois = useRef<ReturnType<typeof setTimeout> | null>(null);
    const agendarRecarga = useCallback(() => {
        if (recarregarDepois.current) clearTimeout(recarregarDepois.current);
        recarregarDepois.current = setTimeout(() => carregarListas(), 500);
    }, [carregarListas]);

    useEffect(() => {
        const pararSeg = ouvirSeguranca(setSeguranca);
        const parar = ouvir(({ nome, dados }) => {
            const aberta = selRef.current;
            if (nome === "mensagem") {
                const m = dados as Mensagem;
                // salvar automático (Configurações › Geral, Chrome/Edge no computador): fotos e documentos recebidos
                if (m.anexos?.length && m.autor_usuario_id !== perfilRef.current?.id && !m.apagada) salvarAutomatico(m.anexos).catch(() => {});
                if (m.conversa_id === aberta) {
                    setMensagens((ms) => {
                        const i = ms.findIndex((x) => x.id === m.id || (m.cliente_uuid && x.cliente_uuid === m.cliente_uuid));
                        if (i >= 0) return ms.map((x, j) => (j === i ? m : x));
                        return [...ms, m].sort((a, b) => a.id - b.id);
                    });
                    setDigitando((d) => ({ ...d, [m.conversa_id]: { nome: "", ate: 0 } }));
                    if (document.visibilityState === "visible") {
                        msgPost("marcar_lida", { conversa_id: m.conversa_id, ate_id: m.id }).then(() => window.dispatchEvent(new Event("messenger:lida"))).catch(() => {});
                    }
                }
                agendarRecarga();
            } else if (nome === "fixadas") {
                if (dados.conversa_id === aberta) setFixadas(dados.fixadas || []);
            } else if (nome === "reacao") {
                // reação com emoji feita por alguém (ou por mim em outro aparelho)
                if (dados.conversa_id === aberta) setMensagens((ms) => ms.map((x) => (x.id === dados.mensagem_id ? { ...x, reacoes: dados.reacoes || [] } : x)));
            } else if (nome === "mensagem_apagada") {
                if (dados.conversa_id === aberta) setMensagens((ms) => ms.map((x) => (x.id === dados.mensagem_id ? { ...x, apagada: true, texto: null, anexos: [] } : x)));
                agendarRecarga();
            } else if (nome === "status_envio") {
                if (dados.conversa_id === aberta) setMensagens((ms) => ms.map((x) => (x.id === dados.mensagem_id ? { ...x, status_envio: dados.status_envio, erro_envio: dados.erro_envio } : x)));
                // lista: tiques da última mensagem
                setConversas((cs) => cs.map((c) => (c.id === dados.conversa_id && c.ultima_mensagem?.id === dados.mensagem_id ? { ...c, ultima_mensagem: { ...c.ultima_mensagem!, status_envio: dados.status_envio } } : c)));
            } else if (nome === "leitura") {
                // lista: tiques azuis quando o colega lê
                setConversas((cs) => cs.map((c) => (c.id === dados.conversa_id ? { ...c, membros: c.membros.map((p) => (p.usuario_id === dados.usuario_id ? { ...p, ultima_lida_id: Math.max(p.ultima_lida_id, dados.ultima_lida_id) } : p)) } : c)));
                if (dados.conversa_id === aberta) {
                    setConversaSel((c) => (c ? { ...c, membros: c.membros.map((p) => (p.usuario_id === dados.usuario_id ? { ...p, ultima_lida_id: Math.max(p.ultima_lida_id, dados.ultima_lida_id) } : p)) } : c));
                }
            } else if (nome === "digitando") {
                setDigitando((d) => ({ ...d, [dados.conversa_id]: { nome: dados.nome, ate: Date.now() + 4000 } }));
                setTimeout(() => setDigitando((d) => ({ ...d })), 4200);
            } else if (nome === "conversa") {
                agendarRecarga();
                if (dados.conversa_id === aberta) abrirConversa(dados.conversa_id, true);
            }
        });
        return () => {
            parar();
            pararSeg();
        };
    }, [agendarRecarga, abrirConversa]);

    /* ---------- listas por aba ---------- */
    const porSetor = (c: Conversa) => filtroSetor === 0 || (filtroSetor === -1 ? !c.setor_id : c.setor_id === filtroSetor);
    const porEtiqueta = (c: Conversa) => (filtroEtiqueta === 0 || (c.etiquetas || []).some((e) => e.id === filtroEtiqueta)) && (!filtroTipo || (c.contato?.tipo || "cliente") === filtroTipo);
    const porAba = useMemo(() => {
        const q = busca.trim().toLowerCase();
        const f = (c: Conversa) => !q || c.titulo.toLowerCase().includes(q) || (c.contato?.telefone || "").replace(/\D/g, "").includes(q.replace(/\D/g, "") || "#");
        return {
            // atendimentos que a Gestão só acompanha ficam numa pasta à parte (não misturam com as conversas dela)
            tudo: conversas.filter((c) => !c.gestao_acompanha && f(c)),
            equipe: conversas.filter((c) => c.canal === "interno" && f(c)),
            grupos: conversas.filter((c) => c.tipo === "grupo" && f(c)),
            clientes: conversas.filter((c) => c.canal === "whatsapp" && !c.gestao_acompanha && f(c) && porEtiqueta(c)),
            daEquipe: conversas.filter((c) => !!c.gestao_acompanha && f(c) && porEtiqueta(c)),
            fila: fila.filter((c) => f(c) && porSetor(c) && porEtiqueta(c)),
        };
    }, [conversas, fila, busca, filtroSetor, filtroEtiqueta, filtroTipo]);
    // tipos de contato em uso nas conversas de clientes (para os botões de filtro)
    const tiposEmUso = useMemo(() => [...new Set([...conversas, ...fila].map((c) => c.contato?.tipo || "").filter((t) => !!TIPO_CONTATO_SELO[t]))], [conversas, fila]);
    // etiquetas em uso nas conversas de clientes (para os botões de filtro)
    const etiquetasEmUso = useMemo(() => {
        const mapa = new Map<number, EtiquetaCurta>();
        [...conversas, ...fila].forEach((c) => (c.etiquetas || []).forEach((e) => mapa.set(e.id, e)));
        return [...mapa.values()].sort((a, b) => a.nome.localeCompare(b.nome));
    }, [conversas, fila]);
    const contagem: Record<Aba, number> = {
        tudo: conversas.filter((c) => c.nao_lidas > 0).length + fila.length,
        equipe: conversas.filter((c) => c.canal === "interno" && c.nao_lidas > 0).length,
        grupos: conversas.filter((c) => c.tipo === "grupo" && c.nao_lidas > 0).length,
        clientes: fila.length + conversas.filter((c) => c.canal === "whatsapp" && c.nao_lidas > 0).length,
    };

    /* ---------- envio ---------- */
    const acrescentarLocal = (m: Mensagem) => setMensagens((ms) => [...ms, m]);
    const trocarLocal = (uuid: string, nova: Partial<Mensagem>) => setMensagens((ms) => ms.map((x) => (x.cliente_uuid === uuid ? { ...x, ...nova } : x)));
    const mensagemLocal = (uuid: string, tipo: Mensagem["tipo"], texto: string | null): Mensagem => ({
        id: Number.MAX_SAFE_INTEGER, conversa_id: selId!, autor_tipo: "usuario", autor_usuario_id: perfil!.id, autor_contato_id: null, autor_nome: perfil!.nome,
        tipo, texto, responde_a_id: null, cliente_uuid: uuid, status_envio: null, erro_envio: null, apagada: false, criado_em: new Date().toISOString(), anexos: [], _enviando: true,
    });
    const enviarCorpo = async (uuid: string, corpo: Record<string, any>) => {
        try {
            const r = await msgPost("enviar", { conversa_id: selId, cliente_uuid: uuid, ...corpo });
            setMensagens((ms) => ms.map((x) => (x.cliente_uuid === uuid ? r.dados : x)).sort((a, b) => a.id - b.id));
            agendarRecarga();
        } catch (e: any) {
            trocarLocal(uuid, { _enviando: false, _falhaLocal: e.message });
            if (e.detalhe?.janela_fechada) abrirConversa(selId!, true);
        }
    };
    const enviarTexto = (t: string) => {
        const uuid = novoUuid();
        const resposta = respondendo?.id ?? null;
        setRespondendo(null);
        acrescentarLocal({ ...mensagemLocal(uuid, "texto", t), responde_a_id: resposta });
        enviarCorpo(uuid, { tipo: "texto", texto: t, responde_a_id: resposta });
    };
    const enviarModelo = (m: { nome: string; idioma: string; parametros: string[]; texto: string }) => {
        const uuid = novoUuid();
        acrescentarLocal(mensagemLocal(uuid, "modelo", m.texto));
        enviarCorpo(uuid, { tipo: "modelo", texto: m.texto, modelo: { nome: m.nome, idioma: m.idioma, parametros: m.parametros } });
    };
    const enviarMidia = async (f: File | Blob, opcoes: { mime?: string; duracao_s?: number } = {}) => {
        const uuid = novoUuid();
        const nome = (f as File).name || "";
        let mime = (opcoes.mime || f.type || "").split(";")[0];
        if (!mime && nome) mime = TIPOS_DOC[nome.split(".").pop()!.toLowerCase()] || "";
        const tipo: Mensagem["tipo"] = mime.startsWith("image/") ? "imagem" : mime.startsWith("audio/") ? "audio" : "documento";
        const resposta = respondendo?.id ?? null;
        setRespondendo(null);
        acrescentarLocal({ ...mensagemLocal(uuid, tipo, tipo === "documento" ? nome : null), responde_a_id: resposta, texto: tipo === "imagem" ? "Enviando foto…" : tipo === "audio" ? "Enviando áudio…" : `Enviando ${nome}…` });
        try {
            const anexo: Record<string, any> = { nome_original: nome || null, duracao_s: opcoes.duracao_s };
            if (tipo === "imagem" && mime !== "image/gif") {
                const foto = await comprimirFoto(f);
                anexo.chave = await enviarArquivo(foto.arquivo, "image/jpeg");
                anexo.miniatura_chave = await enviarArquivo(foto.miniatura, "image/jpeg", "miniatura").catch(() => null);
                anexo.largura = foto.largura;
                anexo.altura = foto.altura;
            } else if (tipo === "audio" && conversaSel?.tipo === "externo" && !["audio/mpeg", "audio/ogg", "audio/aac", "audio/amr"].includes(mime)) {
                // WhatsApp: o áudio do Safari (MP4) e do Chrome (WebM) é recusado pela Meta; vai em MP3
                // áudio anexado pelo clipe (a gravação do Messenger já sai em MP3)
                let arquivo: Blob;
                try {
                    arquivo = await audioParaMp3(f);
                } catch {
                    throw new Error("Este áudio não pôde ser convertido para o WhatsApp. Grave pelo microfone do Messenger.");
                }
                anexo.nome_original = "audio.mp3";
                anexo.chave = await enviarArquivo(arquivo, "audio/mpeg");
            } else {
                anexo.chave = await enviarArquivo(f, mime);
            }
            await enviarCorpo(uuid, { tipo, anexo, responde_a_id: resposta });
        } catch (e: any) {
            trocarLocal(uuid, { _enviando: false, _falhaLocal: e.message });
        }
    };

    /* ---------- ações ---------- */
    /* ---------- pacote 3: nota interna, localização, contato, reação, encaminhar, salvar contato ---------- */
    const enviarNota = (t: string) => {
        const uuid = novoUuid();
        const resposta = respondendo?.id ?? null;
        setRespondendo(null);
        acrescentarLocal({ ...mensagemLocal(uuid, "texto", t), responde_a_id: resposta, interna: true });
        enviarCorpo(uuid, { tipo: "texto", texto: t, interna: true, responde_a_id: resposta });
    };
    const enviarLocalizacao = () => {
        if (!navigator.geolocation) {
            setErro("Este aparelho não informa a localização.");
            return;
        }
        navigator.geolocation.getCurrentPosition(
            (pos) => {
                if (!window.confirm("Enviar a sua localização atual nesta conversa?")) return;
                const uuid = novoUuid();
                acrescentarLocal(mensagemLocal(uuid, "texto", "📍 Enviando localização…"));
                enviarCorpo(uuid, { tipo: "localizacao", latitude: pos.coords.latitude, longitude: pos.coords.longitude, nome: "Localização atual" });
            },
            (e) => setErro(e.code === 1 ? "Permita o acesso à localização nas configurações do aparelho/navegador para enviar." : "Não foi possível obter a localização agora."),
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
        );
    };
    const enviarContato = (nome: string, telefone: string) => {
        setModal(null);
        const uuid = novoUuid();
        acrescentarLocal(mensagemLocal(uuid, "texto", `👤 ${nome}`));
        enviarCorpo(uuid, { tipo: "contato", contato: { nome, telefone } });
    };
    const reagir = async (m: Mensagem, emoji: string) => {
        const eu = perfil!.id;
        const antes = m.reacoes || [];
        const depois = [...antes.filter((r) => r.usuario_id !== eu), ...(emoji ? [{ emoji, usuario_id: eu, nome: perfil!.nome }] : [])];
        setMensagens((ms) => ms.map((x) => (x.id === m.id ? { ...x, reacoes: depois } : x)));
        try {
            const r = await msgPost("reagir", { mensagem_id: m.id, emoji });
            setMensagens((ms) => ms.map((x) => (x.id === m.id ? { ...x, reacoes: r.dados.reacoes || [] } : x)));
        } catch (e: any) {
            setMensagens((ms) => ms.map((x) => (x.id === m.id ? { ...x, reacoes: antes } : x)));
            setErro(e.message);
        }
    };
    const encaminhar = async (ids: number[]) => {
        const m = paraEncaminhar;
        setModal(null);
        setParaEncaminhar(null);
        if (!m) return;
        try {
            const r = await msgPost("encaminhar", { mensagem_id: m.id, conversa_ids: ids });
            setAviso(r.dados.recusadas?.length ? `${r.msg} (${r.dados.recusadas.length} conversa(s) não aceitaram.)` : r.msg);
            carregarListas();
            // como no WhatsApp: encaminhou para uma conversa só, ela abre com a mensagem encaminhada
            const aceitas = ids.filter((i) => !(r.dados.recusadas || []).includes(i));
            if (aceitas.length === 1) abrirConversa(aceitas[0], aceitas[0] === selId);
            else if (selId && ids.includes(selId)) abrirConversa(selId, true);
        } catch (e: any) {
            setErro(e.message);
        }
    };
    const fixarMensagem = async (m: Mensagem, fixar: boolean) => {
        try {
            const r = await msgPost("fixar_mensagem", { mensagem_id: m.id, fixar });
            setFixadas(r.dados.fixadas || []);
            setAviso(r.msg);
        } catch (e: any) {
            setErro(e.message);
        }
    };
    const salvarContato = async () => {
        if (!conversaSel?.contato) return;
        const atual = conversaSel.contato.salvo ? conversaSel.contato.nome || "" : conversaSel.contato.nome_whatsapp || conversaSel.contato.nome || "";
        const nome = window.prompt(`Nome para ${conversaSel.contato.telefone}${conversaSel.contato.nome_whatsapp ? ` (no WhatsApp: ${conversaSel.contato.nome_whatsapp})` : ""}:`, atual);
        if (nome === null) return;
        try {
            const r = await msgPost("contato_salvar", { conversa_id: conversaSel.id, nome: nome.trim() });
            setConversaSel(r.dados);
            setAviso(r.msg);
            carregarListas();
        } catch (e: any) {
            setErro(e.message);
        }
    };

    /* ---------- fixar e marcar como não lida (deslizar no celular, menu no computador) ---------- */
    const fixarConversa = async (c: Conversa) => {
        try {
            await msgPost("fixar", { conversa_id: c.id, fixar: !c.fixada });
            setAviso(c.fixada ? "Conversa desafixada." : "Conversa fixada no topo.");
            await carregarListas();
        } catch (e: any) {
            setErro(e.message);
        }
    };
    const marcarConversa = async (c: Conversa) => {
        try {
            if (c.nao_lidas > 0 && c.ultima_mensagem) {
                await msgPost("marcar_lida", { conversa_id: c.id, ate_id: c.ultima_mensagem.id });
                setConversas((cs) => cs.map((x) => (x.id === c.id ? { ...x, nao_lidas: 0, marcada_nao_lida: false } : x)));
            } else {
                const marcar = !c.marcada_nao_lida;
                await msgPost("marcar_nao_lida", { conversa_id: c.id, nao_lida: marcar });
                setConversas((cs) => cs.map((x) => (x.id === c.id ? { ...x, marcada_nao_lida: marcar } : x)));
            }
            window.dispatchEvent(new Event("messenger:lida")); // atualiza o contador do menu
        } catch (e: any) {
            setErro(e.message);
        }
    };

    const executar = async (fn: () => Promise<any>, ok?: string) => {
        try {
            const r = await fn();
            setAviso(ok || r?.msg || "");
            setErro("");
            return r;
        } catch (e: any) {
            setErro(e.message);
        }
    };
    const assumir = (id: number) => executar(async () => {
        const r = await msgPost("assumir", { conversa_id: id });
        await carregarListas();
        await abrirConversa(id);
        return r;
    }, "Atendimento assumido.");
    const encerrar = () => {
        if (!conversaSel || !window.confirm("Encerrar o atendimento? A conversa vai para o histórico e sai da sua lista.")) return;
        executar(async () => {
            const r = await msgPost("encerrar", { conversa_id: conversaSel.id });
            fecharConversa();
            await carregarListas();
            return r;
        });
    };
    const apagar = (m: Mensagem) => {
        if (!window.confirm("Apagar esta mensagem para todos?")) return;
        executar(async () => {
            const r = await msgPost("apagar_mensagem", { mensagem_id: m.id });
            setMensagens((ms) => ms.map((x) => (x.id === m.id ? { ...x, apagada: true, texto: null, anexos: [] } : x)));
            return r;
        });
    };
    const silenciar = () => conversaSel && executar(async () => {
        const r = await msgPost("silenciar", { conversa_id: conversaSel.id, silenciada: !conversaSel.silenciada });
        setConversaSel({ ...conversaSel, silenciada: r.dados.silenciada });
        window.dispatchEvent(new CustomEvent("messenger:silenciada", { detail: { conversa_id: conversaSel.id, silenciada: r.dados.silenciada } }));
        return r;
    }, conversaSel.silenciada ? "Notificações desta conversa ligadas." : "Conversa silenciada.");
    const carregarMais = async () => {
        if (!selId || !mensagens.length) return;
        try {
            const d = await msgGet<{ mensagens: Mensagem[]; tem_mais: boolean }>("mensagens", { conversa_id: selId, antes_id: mensagens[0].id });
            setMensagens((ms) => [...d.mensagens, ...ms]);
            setTemMais(d.tem_mais);
        } catch (e: any) {
            setErro(e.message);
        }
    };

    const digitandoAgora = selId && digitando[selId] && digitando[selId].ate > Date.now() ? digitando[selId].nome : "";
    const listaAtual = aba === "clientes" ? porAba.clientes : aba === "grupos" ? porAba.grupos : aba === "equipe" ? porAba.equipe : porAba.tudo;
    const area = useAreaVisivel(selId !== null);

    if (carregando && !perfil) return <div className="p-8 text-[#313C55] dark:text-white">Carregando o Messenger…</div>;
    if (verHistorico) return <HistoricoClientes embutido onVoltar={() => setVerHistorico(false)} />;

    return (
        <div className={`flex ${selId ? "h-[calc(100dvh-var(--header-height))]" : "h-[calc(100dvh-var(--header-height)-4.25rem-env(safe-area-inset-bottom))]"} flex-col overflow-x-hidden bg-white text-[#1F2638] md:min-h-[560px] md:bg-[#F4F6F9] dark:bg-[#1C2334] dark:text-white md:dark:bg-[#1C2334] ${telaCheia ? "md:fixed md:inset-0 md:z-[1000] md:h-[100dvh] md:p-2" : "md:h-[calc(100dvh-var(--header-height))] md:p-4"}`}>
            {(erro || aviso) && (
                <div className={`mx-2 mb-2 mt-2 flex items-center gap-3 rounded-xl border px-4 py-2 text-sm font-bold md:mx-0 md:mt-0 ${erro ? "border-[#B42318] bg-[#FDECEA] text-[#B42318] dark:border-[#FF9C92]/60 dark:bg-[#FF9C92]/15 dark:text-[#FF9C92]" : "border-[#B3CE52] bg-[#EEF5D6] dark:bg-[#B3CE52]/15"}`}>
                    <span className="flex-1">{erro || aviso}</span>
                    <button type="button" onClick={() => { setErro(""); setAviso(""); }} aria-label="Fechar aviso"><Icone nome="x" className="h-4 w-4" /></button>
                </div>
            )}
            <div className={`relative grid min-h-0 flex-1 overflow-hidden border-[#E1E5EC] bg-white ${painelCli && largo && conversaSel?.tipo === "externo" ? "md:grid-cols-[330px_minmax(0,1fr)_470px]" : "md:grid-cols-[400px_minmax(0,1fr)]"} md:rounded-2xl md:border dark:border-white/12 dark:bg-[#232B3F]`}>
                {/* lista */}
                <div className={`${selId ? "hidden md:flex" : "flex"} min-h-0 flex-col border-r border-[#E6E9EE] dark:border-white/12`}>
                    <div className="flex items-center gap-1 pb-1 pl-4 pr-2 pt-3">
                        <h1 className="m-0 min-w-0 flex-1 truncate text-[26px] font-extrabold text-[#313C55] md:text-[22px] dark:text-white">Conversas</h1>
                        <button type="button" onClick={() => setModal("nova")} className="hidden h-11 flex-none items-center gap-1.5 rounded-full bg-[#313C55] px-3.5 text-[14.5px] font-extrabold text-white shadow-sm hover:bg-[#262F45] md:flex dark:bg-[#3D6A99] dark:hover:bg-[#4A7AAB]" aria-label="Nova conversa" title="Nova conversa"><Icone nome="novaconversa" className="h-5 w-5" /><span className={painelCli && largo ? "hidden" : ""}>Nova conversa</span></button>
                        <button type="button" onClick={() => setVerHistorico(true)} className="flex h-11 w-11 items-center justify-center rounded-full text-[#313C55] hover:bg-[#F0F2F5] dark:text-white dark:hover:bg-white/10" aria-label="Histórico de clientes" title="Histórico de clientes"><Icone nome="clock" className="h-[22px] w-[22px]" /></button>
                        <button type="button" onClick={alternarTelaCheia} aria-pressed={telaCheia} className="hidden h-11 w-11 items-center justify-center rounded-full text-[#313C55] hover:bg-[#F0F2F5] md:flex dark:text-white dark:hover:bg-white/10" aria-label={telaCheia ? "Sair da tela cheia" : "Tela cheia"} title={telaCheia ? "Sair da tela cheia" : "Tela cheia"}><Icone nome={telaCheia ? "recolher" : "expandir"} className="h-[20px] w-[20px]" /></button>
                    </div>
                    <div className="flex flex-col gap-2.5 px-4 pb-2.5 pt-1">
                        <label className="flex h-[52px] items-center gap-3 rounded-full bg-[#F0F2F5] px-4 text-[#5B6478] dark:bg-[#1C2334] dark:text-[#AEB9CF]">
                            <Icone nome="search" />
                            <input type="search" value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Pesquisar" aria-label="Pesquisar conversa" className="min-w-0 flex-1 bg-transparent text-[18px] text-[#1F2638] outline-none dark:text-white" />
                        </label>
                        <Abas aba={aba} setAba={setAba} contagem={contagem} />
                        {aba === "clientes" && (setores.length > 0 || etiquetasEmUso.length > 0 || tiposEmUso.length > 0) && (
                            <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden" aria-label="Filtrar clientes">
                                {setores.length > 0 && (
                                    <>
                                        <button type="button" onClick={() => setFiltroSetor(0)} aria-pressed={filtroSetor === 0} className={`h-8 flex-none rounded-full border px-3 text-[13.5px] font-extrabold ${filtroSetor === 0 ? "border-[#313C55] bg-[#313C55] text-white dark:border-[#3D6A99] dark:bg-[#3D6A99]" : "border-[#E1E5EC] text-[#313C55] dark:border-white/15 dark:text-white"}`}>Todos os setores {fila.length || ""}</button>
                                        {setores.map((x) => {
                                            const qtd = fila.filter((c) => c.setor_id === x.id).length;
                                            return (
                                                <button key={x.id} type="button" onClick={() => setFiltroSetor(filtroSetor === x.id ? 0 : x.id)} aria-pressed={filtroSetor === x.id} title={x.situacao} className={`flex h-8 flex-none items-center gap-1.5 rounded-full border px-3 text-[13.5px] font-extrabold ${filtroSetor === x.id ? "border-[#313C55] bg-[#E9EFF6] dark:border-[#A9BED6] dark:bg-[#3D6A99]/30" : "border-[#E1E5EC] dark:border-white/15"} ${x.aberto ? "" : "opacity-70"}`}>
                                                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: x.cor }} aria-hidden="true" />{x.nome}{qtd ? ` ${qtd}` : ""}
                                                </button>
                                            );
                                        })}
                                        {fila.some((c) => !c.setor_id) && <button type="button" onClick={() => setFiltroSetor(filtroSetor === -1 ? 0 : -1)} aria-pressed={filtroSetor === -1} className={`h-8 flex-none rounded-full border px-3 text-[13.5px] font-extrabold ${filtroSetor === -1 ? "border-[#313C55] bg-[#E9EFF6] dark:bg-[#3D6A99]/30" : "border-[#E1E5EC] dark:border-white/15"}`}>Sem setor {fila.filter((c) => !c.setor_id).length}</button>}
                                    </>
                                )}
                                {tiposEmUso.map((t) => (
                                    <button key={`t${t}`} type="button" onClick={() => setFiltroTipo(filtroTipo === t ? "" : t)} aria-pressed={filtroTipo === t} className={`flex-none rounded-full ${filtroTipo === t ? "ring-2 ring-[#313C55] dark:ring-white" : ""}`} aria-label={`Filtrar: ${TIPO_CONTATO_SELO[t][0]}`}>
                                        <SeloCor nome={TIPO_CONTATO_SELO[t][0]} cor={TIPO_CONTATO_SELO[t][1]} />
                                    </button>
                                ))}
                                {etiquetasEmUso.map((e) => (
                                    <button key={`e${e.id}`} type="button" onClick={() => setFiltroEtiqueta(filtroEtiqueta === e.id ? 0 : e.id)} aria-pressed={filtroEtiqueta === e.id} className={`flex-none rounded-full ${filtroEtiqueta === e.id ? "ring-2 ring-[#313C55] dark:ring-white" : ""}`} aria-label={`Filtrar pela etiqueta ${e.nome}`}>
                                        <SeloCor nome={e.nome} cor={e.cor} ponto />
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto pb-24 md:pb-3">
                        {seguranca && <div className="mx-2 mb-1 rounded-lg bg-[#FCF3CC] px-3 py-1.5 text-xs font-bold dark:bg-[#F2CB3F]/15">Modo de segurança: atualizando a cada 5 s.</div>}
                        {perfil?.notificacoes_canal === "ably" && notif.estado === "pendente" && (
                            <div className="mx-2 mb-1 flex items-center gap-2 rounded-lg bg-[#E9EFF6] px-3 py-1.5 text-xs font-bold dark:bg-[#3D6A99]/20">
                                <span className="flex-1">Receba aviso de mensagem nova neste aparelho.</span>
                                <button type="button" onClick={() => ativarNotificacoes()} className="h-8 rounded-[10px] bg-[#313C55] px-3 text-[12.5px] font-extrabold text-white dark:bg-[#3D6A99]">Ativar notificações</button>
                            </div>
                        )}
                        {perfil?.notificacoes_canal === "ably" && (notif.estado === "negadas" || notif.estado === "erro") && (
                            <div className="mx-2 mb-1 rounded-lg bg-[#FCF3CC] px-3 py-1.5 text-xs font-bold dark:bg-[#F2CB3F]/15">
                                {notif.estado === "negadas" ? "As notificações estão bloqueadas neste aparelho. Libere nas configurações do navegador para receber avisos." : `Não foi possível ativar as notificações: ${notif.detalhe || "erro desconhecido"}`}
                            </div>
                        )}
                        {aba === "grupos" && (
                            <div className="flex items-center gap-2 px-3 pb-1.5 pt-2 text-[11.5px] font-extrabold uppercase tracking-wider text-[#5B6478] dark:text-[#AEB9CF]">
                                <span className="flex-1">Grupos{contagem.grupos ? ` · ${contagem.grupos} com mensagens novas` : ""}</span>
                                <button type="button" onClick={() => setModal("grupo")} className="h-8 rounded-[10px] bg-[#313C55] px-3 text-[13px] normal-case tracking-normal text-white dark:bg-[#3D6A99]">+ Criar grupo</button>
                            </div>
                        )}
                        {(aba === "clientes" || (aba === "tudo" && porAba.fila.length > 0)) && perfil?.atendente && (
                            <>
                                <div className="px-3 pb-1.5 pt-2 text-[11.5px] font-extrabold uppercase tracking-wider text-[#5B6478] dark:text-[#AEB9CF]">Aguardando atendimento · {porAba.fila.length}</div>
                                {porAba.fila.map((c) => (
                                    <LinhaConversa key={`f${c.id}`} c={c} eu={perfil.id} selecionada={selId === c.id} onAbrir={() => abrirConversa(c.id)}
                                        acao={<button type="button" onClick={() => assumir(c.id)} className="h-9 flex-none rounded-[10px] bg-[#313C55] px-3 text-[13px] font-extrabold text-white dark:bg-[#3D6A99]">Assumir</button>} />
                                ))}
                                {!porAba.fila.length && <p className="px-4 text-sm text-[#6B7488] dark:text-[#AEB9CF]">Nenhum cliente na fila.</p>}
                                <div className="px-3 pb-1.5 pt-3 text-[11.5px] font-extrabold uppercase tracking-wider text-[#5B6478] dark:text-[#AEB9CF]">{aba === "tudo" ? "Conversas" : "Em atendimento"}</div>
                            </>
                        )}
                        {perfil && listaAtual.map((c) => (
                            <LinhaConversa key={c.id} c={c} eu={perfil.id} selecionada={selId === c.id} onAbrir={() => abrirConversa(c.id)} online={c.tipo === "individual" && presenca.online(c.outro_usuario_id)} acoes={c.participo ? { onFixar: () => fixarConversa(c), onMarcar: () => marcarConversa(c) } : undefined} />
                        ))}
                        {aba === "clientes" && perfil?.gestao && porAba.daEquipe.length > 0 && (
                            <>
                                <button type="button" onClick={() => setPastaEquipeAberta((v) => !v)} aria-expanded={pastaEquipeAberta} className="mx-2 mt-3 flex items-center gap-2 rounded-xl bg-[#F0F2F5] px-3 py-2.5 text-left text-[14px] font-extrabold text-[#313C55] hover:bg-[#E6E9EE] dark:bg-[#1C2334] dark:text-white dark:hover:bg-white/10">
                                    <Icone nome="users" className="h-5 w-5 flex-none" />
                                    <span className="flex-1">Em atendimento pela equipe</span>
                                    <span className="rounded-full bg-[#313C55] px-2 py-0.5 text-[12.5px] text-white dark:bg-[#3D6A99]">{porAba.daEquipe.length}</span>
                                    <span className={`transition-transform ${pastaEquipeAberta ? "rotate-180" : ""}`}><Icone nome="chevron" className="h-4 w-4" /></span>
                                </button>
                                {pastaEquipeAberta && porAba.daEquipe.map((c) => (
                                    <LinhaConversa key={`g${c.id}`} c={c} eu={perfil.id} selecionada={selId === c.id} onAbrir={() => abrirConversa(c.id)} />
                                ))}
                            </>
                        )}
                        {!listaAtual.length && !carregando && (
                            <p className="px-4 py-4 text-sm text-[#6B7488] dark:text-[#AEB9CF]">
                                {aba === "clientes" ? (perfil?.atendente ? "Nenhum atendimento com você." : "Você não atende clientes do WhatsApp.") : aba === "grupos" ? "Você ainda não participa de grupos." : "Nenhuma conversa ainda. Toque no botão de nova conversa para começar."}
                            </p>
                        )}
                    </div>
                </div>
                {!selId && (
                    <button type="button" onClick={() => setModal("nova")} className="absolute bottom-4 right-4 flex h-[58px] w-[58px] items-center justify-center rounded-[18px] bg-[#313C55] text-white shadow-[0_4px_12px_rgba(31,38,56,0.25)] md:hidden dark:bg-[#3D6A99]" aria-label="Nova conversa">
                        <Icone nome="novaconversa" className="h-[26px] w-[26px]" />
                    </button>
                )}
                {/* conversa (no celular, ocupa a área visível acima do teclado) */}
                <div className={`${selId ? "flex" : "hidden md:flex"} min-h-0 flex-col bg-[#EFEAE2] dark:bg-[#1C2334]`} style={area ? { position: "fixed", left: 0, right: 0, top: area.topo, height: area.altura, zIndex: 60 } : undefined}>
                    {conversaSel && perfil && selId === conversaSel.id ? (
                        <JanelaConversa
                            presenca={conversaSel.tipo === "individual" ? presenca.texto(conversaSel.outro_usuario_id) : ""}
                            online={conversaSel.tipo === "individual" && presenca.online(conversaSel.outro_usuario_id)}
                            conversa={conversaSel} mensagens={mensagens} perfil={perfil} temMais={temMais} digitando={digitandoAgora} seguranca={seguranca}
                            respondendo={respondendo} onResponder={setRespondendo}
                            onVoltar={fecharConversa} onCarregarMais={carregarMais}
                            onEnviarTexto={enviarTexto} onEnviarModelo={enviarModelo} onEnviarArquivo={enviarMidia} onApagar={apagar}
                            onReagir={reagir} onEncaminhar={(m) => { setParaEncaminhar(m); setModal("encaminhar"); }} onEnviarNota={enviarNota}
                            onEnviarLocalizacao={enviarLocalizacao} onPedirContato={() => setModal("contato")} onSalvarContato={salvarContato}
                            fixadas={fixadas} onFixarMensagem={fixarMensagem} onEtiquetas={() => setModal("etiquetas")}
                            tecladoAberto={!!area && typeof window !== "undefined" && area.altura < window.innerHeight * 0.8}
                            onDigitando={() => msgPost("digitando", { conversa_id: conversaSel.id }).catch(() => {})}
                            onAssumir={() => assumir(conversaSel.id)} onTransferir={() => setModal("transferir")} onEncerrar={encerrar}
                            onSilenciar={silenciar} onDetalhes={() => setModal("detalhes")}
                            onAbrirCliente={() => setPainelCli((v) => !v)} painelClienteAberto={painelCli} textoParaInserir={textoPainel}
                        />
                    ) : (
                        <div className="flex flex-1 flex-col items-center justify-center gap-2 bg-[#F0F2F5] p-8 text-center text-[#5B6478] dark:bg-[#1C2334] dark:text-[#AEB9CF]">
                            <Icone nome="msg" className="h-10 w-10" />
                            <p className="text-[15px] font-bold">{selId ? "Abrindo a conversa…" : "Escolha uma conversa"}</p>
                        </div>
                    )}
                </div>
                {/* pacote 5B: painel do cliente como terceira coluna (tela larga) ou por cima (demais) */}
                {painelCli && conversaSel && conversaSel.tipo === "externo" && selId === conversaSel.id && (
                    <div className={largo ? "hidden min-h-0 md:flex" : "contents"}>
                        <PainelCliente
                            key={conversaSel.id}
                            conversa={conversaSel}
                            coluna={largo}
                            onFechar={() => setPainelCli(false)}
                            onInserirTexto={(t) => { setTextoPainel((x) => ({ texto: t, n: x.n + 1 })); if (!largo) setPainelCli(false); }}
                            onEnviarArquivo={(f) => enviarMidia(f)}
                        />
                    </div>
                )}
            </div>

            {(modal === "nova" || modal === "grupo") && (
                <NovaConversa online={presenca.online} grupoInicial={modal === "grupo"} onFechar={() => setModal(null)} onAberta={(c) => { setModal(null); carregarListas(); setAba(c.tipo === "grupo" ? "grupos" : "equipe"); abrirConversa(c.id); }} onWhatsApp={perfil?.atendente ? () => setModal("whats") : undefined} />
            )}
            {modal === "whats" && (
                <NovaConversaWhats onFechar={() => setModal(null)} onAberta={(id) => { setModal(null); carregarListas(); setAba("clientes"); abrirConversa(id); }} />
            )}
            {modal === "transferir" && conversaSel && (
                <Transferir conversa={conversaSel} onFechar={() => setModal(null)} onFeito={() => { setModal(null); setAviso("Conversa transferida."); if (perfil?.gestao) abrirConversa(conversaSel.id, true); else fecharConversa(); carregarListas(); }} />
            )}
            {modal === "etiquetas" && conversaSel && <EtiquetasConversa conversa={conversaSel} onFechar={() => setModal(null)} onSalvo={(c) => { setModal(null); setConversaSel(c); setAviso("Etiquetas atualizadas."); carregarListas(); }} />}
            {modal === "contato" && <EnviarContato onFechar={() => setModal(null)} onEnviar={enviarContato} />}
            {modal === "encaminhar" && paraEncaminhar && <Encaminhar conversas={conversas} onFechar={() => { setModal(null); setParaEncaminhar(null); }} onEnviar={encaminhar} />}
            {modal === "detalhes" && conversaSel && perfil && (
                <DetalhesGrupo conversa={conversaSel} perfil={perfil} onFechar={() => setModal(null)} onMudou={(c) => { setConversaSel(c); carregarListas(); }} onSaiu={() => { setModal(null); fecharConversa(); carregarListas(); }} />
            )}
        </div>
    );
}
