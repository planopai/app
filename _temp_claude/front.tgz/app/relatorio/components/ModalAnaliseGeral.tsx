"use client";

import React from "react";

import {

    ARR_KEYS,

    ARR_LABELS,

    normSimNao,

    extrairEstadoArrumacao,

} from "./MateriaisArrumacao";

import { listarAnalitico, listarLogPorId } from "./Api";

import type { RegistroAnalise } from "./TiposHistorico";

const BALANCO_URL = "https://api.planoassistencialintegrado.com.br/balanco.php";

type BalancoAtendimento = {
    atendimento_id?: number | string;
    id?: number | string;
    falecido?: string;
    convenio?: string;
    data_referencia?: string;
    assistencia_ativa?: boolean;
    tanatopraxia_ativa?: boolean;
    [key: string]: any;
};

type BalancoResponse = {
    ok?: boolean;
    need_login?: number;
    msg?: string;
    atendimentos?: BalancoAtendimento[];
};

function hojeIso(): string {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
}

function periodoParaBalanco(aDe?: string, aAte?: string): { inicio: string; fim: string } {
    if (aDe && aAte) {
        return aDe <= aAte
            ? { inicio: aDe, fim: aAte }
            : { inicio: aAte, fim: aDe };
    }

    if (aDe) return { inicio: aDe, fim: aDe };
    if (aAte) return { inicio: aAte, fim: aAte };

    // Sem filtro explícito, mantém a ideia de "todo o histórico" do analítico.
    return { inicio: "1970-01-01", fim: hojeIso() };
}

async function listarAtendimentosBalanco(aDe?: string, aAte?: string): Promise<BalancoAtendimento[]> {
    const { inicio, fim } = periodoParaBalanco(aDe, aAte);
    const url = `${BALANCO_URL}?inicio=${encodeURIComponent(inicio)}&fim=${encodeURIComponent(fim)}`;

    const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        cache: "no-store",
    });

    const json = (await response.json().catch(() => null)) as BalancoResponse | null;

    if (!response.ok || !json || json.ok === false) {
        throw new Error(json?.msg || `Falha HTTP ${response.status} ao consultar o balanço.`);
    }

    return Array.isArray(json.atendimentos) ? json.atendimentos : [];
}

function getBalancoId(r: BalancoAtendimento): string {
    return String(r.atendimento_id ?? r.id ?? "").trim();
}



/* =========================

   Helpers visuais

   ========================= */

const fmt0 = (n: number) =>

    new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 }).format(n);



const ICONES_TIPO: Record<string, string> = {

    Assistência: "🕯️",

    "Conservação do Corpo": "🧪",

    Arrumação: "🧴",

    Material: "📦",

    Tanatopraxia: "⚗️",

    Convênio: "🤝",

    Principal: "⭐",

};



function ItemCard({

    titulo,

    valor,

    tipo,

    subtexto,

    destaque = "blue",

}: {

    titulo: string;

    valor: number;

    tipo?: string;

    subtexto?: React.ReactNode;

    destaque?: "blue" | "yellow" | "sky" | "teal" | "indigo" | "rose";

}) {

    const leftBar = {

        blue: "border-l-blue-500",

        yellow: "border-l-yellow-400",

        sky: "border-l-[#3D6A99]",

        teal: "border-l-[#3D6A99]",

        indigo: "border-l-indigo-500",

        rose: "border-l-rose-500 dark:border-l-[#FF9C92]/60",

    }[destaque];



    const chipColor = {

        blue: "bg-blue-50 text-blue-700 dark:bg-[#3D6A99]/20 dark:text-[#A9BED6]",

        yellow: "bg-yellow-50 text-yellow-700 dark:bg-[#F2CB3F]/15 dark:text-[#F2CB3F]",

        sky: "bg-[#E9EFF6] text-[#3D6A99] dark:bg-[#3D6A99]/20 dark:text-[#A9BED6]",

        teal: "bg-[#E9EFF6] text-[#3D6A99] dark:bg-[#3D6A99]/20 dark:text-[#A9BED6]",

        indigo: "bg-indigo-50 text-indigo-700 dark:bg-[#3D6A99]/20 dark:text-[#A9BED6]",

        rose: "bg-rose-50 text-rose-700 dark:bg-[#FF9C92]/15 dark:text-[#FF9C92]",

    }[destaque];



    return (

        <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden dark:border-white/12 dark:bg-[#232B3F]">

            <div className={`border-l-4 ${leftBar} p-4`}>

                <div className="flex items-start justify-between">

                    <div className="text-3xl font-extrabold leading-none">{fmt0(valor)}</div>

                    {tipo && (

                        <span className={`ml-2 rounded-md px-2 py-1 text-[11px] font-semibold ${chipColor}`}>

                            {ICONES_TIPO[tipo] ? `${ICONES_TIPO[tipo]} ` : ""}

                            {tipo}

                        </span>

                    )}

                </div>

                <div className="mt-1 text-sm text-gray-600 dark:text-[#AEB9CF]">{titulo}</div>

                {subtexto && <div className="mt-1 text-xs text-gray-500 dark:text-[#AEB9CF]">{subtexto}</div>}

            </div>

        </div>

    );

}



const DESTAQUES: Array<"blue" | "yellow" | "sky" | "teal" | "indigo" | "rose"> = [

    "blue",

    "yellow",

    "sky",

    "teal",

    "indigo",

    "rose",

];



/* =========================

   Parser de datas (BR/ISO)

   ========================= */

function parseBrDate(s: string): Date | null {

    const m = s

        .trim()

        .match(/^(\d{2})\/(\d{2})\/(\d{4})(?:[,\s]+(\d{2}):(\d{2})(?::(\d{2}))?)?$/);

    if (!m) return null;

    const [, dd, mm, yyyy, hh = "00", mi = "00", ss = "00"] = m;

    const d = new Date(+yyyy, +mm - 1, +dd, +hh, +mi, +ss);

    return isNaN(d.getTime()) ? null : d;

}



function parseIsoDate(s: string): Date | null {

    const t = s.trim().replace(" ", "T");



    let m = t.match(/^(\d{4})-(\d{2})-(\d{2})$/);

    if (m) {

        const [, yyyy, mm, dd] = m;

        const d = new Date(+yyyy, +mm - 1, +dd, 0, 0, 0);

        return isNaN(d.getTime()) ? null : d;

    }



    m = t.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/);

    if (m) {

        const [, yyyy, mm, dd, hh, mi, ss = "00"] = m;

        const d = new Date(+yyyy, +mm - 1, +dd, +hh, +mi, +ss);

        return isNaN(d.getTime()) ? null : d;

    }



    const d = new Date(t);

    return isNaN(d.getTime()) ? null : d;

}



function parseDateFlex(s?: string | null): Date | null {

    if (!s) return null;

    return parseBrDate(s) || parseIsoDate(s) || null;

}



function getRegistroDate(r: RegistroAnalise): Date | null {

    const candidatos = [

        (r as any).data,

        (r as any).data_inicio_velorio,

        (r as any).data_fim_velorio,

        (r as any).datahora,

        (r as any).ultima_datahora,

        (r as any).created_at,

    ];

    for (const c of candidatos) {

        const d = parseDateFlex(String(c || ""));

        if (d) return d;

    }

    return null;

}



function makeRange(aDe?: string, aAte?: string) {

    const hasDe = !!aDe,

        hasAte = !!aAte;

    const deStr = hasDe ? aDe! : hasAte ? aAte! : "";

    const ateStr = hasAte ? aAte! : hasDe ? aDe! : "";

    const start = deStr ? new Date(`${deStr}T00:00:00`) : null;

    const end = ateStr ? new Date(`${ateStr}T23:59:59`) : null;



    if (start && end && end < start) {

        return {

            start: end,

            end: new Date(start.getTime() + 23 * 3600 * 1000 + 59 * 60000 + 59 * 1000),

        };

    }

    return { start, end };

}



/* =========================

   Helpers TANATO (somente início puro)

   ========================= */

const norm = (s: string) =>

    s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();



/**

 * Aceita os formatos mais comuns que podem vir do PHP/MySQL.

 * Mantém compatibilidade com "Sim"/"Não", mas também trata 1/0 e boolean.

 */

function valorEhSim(v: any): boolean {

    if (v === true || v === 1) return true;

    if (v === false || v === 0 || v == null) return false;



    const normalizado = normSimNao(String(v));

    if (normalizado === "sim") return true;

    if (normalizado === "nao") return false;



    const s = norm(String(v));

    return s === "1" || s === "true" || s === "yes" || s === "s";

}



const titleCase = (s: string) =>

    s

        .split(/\s+/)

        .map((p) => (p ? p[0].toUpperCase() + p.slice(1).toLowerCase() : ""))

        .join(" ");



function logTs(log: any): number {

    const s = String(log?.datahora || log?.data || log?.created_at || "");

    const d = parseDateFlex(s);

    return d ? d.getTime() : Number.NaN;

}



function fmtDateHora(ts: number) {

    if (!Number.isFinite(ts)) return "";

    return new Intl.DateTimeFormat("pt-BR", {

        day: "2-digit",

        month: "2-digit",

        year: "numeric",

        hour: "2-digit",

        minute: "2-digit",

    }).format(new Date(ts));

}



function agenteDoLog(log: any): string {

    const pick = (o: any) =>

        o?.usuario ||

        o?.usuario_nome ||

        o?.usuarioNome ||

        o?.nome_usuario ||

        o?.user ||

        o?.user_name ||

        o?.username ||

        o?.operador ||

        o?.agente ||

        o?.nome ||

        o?.name ||

        "";



    const direct = pick(log);

    if (direct) return String(direct).trim();



    try {

        const det =

            typeof log?.detalhes === "string" ? JSON.parse(log.detalhes) : log?.detalhes;

        const poss = pick(det) || det?.usuario_nome || det?.user_name || det?.nome_usuario;

        if (poss) return String(poss).trim();

    } catch { }

    return "";

}



function isDetalhesVazio(log: any): boolean {

    const d = log?.detalhes;



    if (d === null || d === undefined) return true;



    if (typeof d === "string") {

        const s = d.trim();

        if (!s) return true;

        if (s === "null") return true;

        if (s === "{}") return true;



        try {

            const obj = JSON.parse(s);

            if (obj === null) return true;

            if (typeof obj === "object" && obj && Object.keys(obj).length === 0) return true;

            return false;

        } catch {

            return false;

        }

    }



    if (typeof d === "object") {

        return Object.keys(d || {}).length === 0;

    }



    return false;

}



function isInicioConservacaoPuro(log: any): boolean {

    const acao = norm(String(log?.acao || ""));

    const statusAnterior = norm(String(log?.status_anterior || ""));

    const statusNovo = norm(String(log?.status_novo || log?.status || ""));

    const titulo = norm(String(log?.titulo || ""));

    const texto = `${acao} ${statusNovo} ${titulo}`;



    // 1) excluir "editou"

    if (acao.includes("edit")) return false;



    // 2) tem que ser mudança de status

    const matchMudancaStatus =

        acao.includes("atualizou status") ||

        acao.includes("atualizou situacao") ||

        acao.includes("alterou status") ||

        acao.includes("mudou status") ||

        acao.includes("status");



    if (!matchMudancaStatus) return false;



    // 3) exigir fase02 -> fase03 quando houver campos

    const temFases = !!(log?.status_anterior || log?.status_novo);

    if (temFases) {

        if (!(statusAnterior === "fase02" && statusNovo === "fase03")) return false;

    } else {

        const matchConservacao =

            /inicio\s*(de\s*)?conservacao/.test(texto) ||

            /iniciou\s*conservacao/.test(texto) ||

            /conservacao\s*iniciada/.test(texto) ||

            /fase\s*0*3\b/.test(texto);

        if (!matchConservacao) return false;

    }



    // 4) detalhes vazio

    if (!isDetalhesVazio(log)) return false;



    return true;

}



type AgenteFix = "Sandro" | "Joseildo";

function agentePermitido(log: any): AgenteFix | "" {

    const a = norm(agenteDoLog(log));

    if (a === "sandro") return "Sandro";

    if (a === "joseildo") return "Joseildo";

    return "";

}



function findPrimeiroInicioPuroNoPeriodo(

    logs: any[],

    start: Date | null,

    end: Date | null

): any | null {

    let best: any | null = null;



    for (const log of logs || []) {

        if (!isInicioConservacaoPuro(log)) continue;



        const ag = agentePermitido(log);

        if (!ag) continue;



        const t = logTs(log);

        if (Number.isNaN(t)) continue;

        if (start && t < start.getTime()) continue;

        if (end && t > end.getTime()) continue;



        if (!best) best = log;

        else if (t < logTs(best)) best = log;

    }



    return best;

}



/* =========================

   IDs / entidade (dedupe por sepultamento)

   ========================= */

function getIdsParaTentar(r: RegistroAnalise): string[] {

    const anyR = r as any;

    const candidates = [

        anyR.sepultamento_id,

        anyR.sepultamentoId,

        anyR.id_sepultamento,

        anyR.atendimento_id,

        anyR.atendimentoId,

        anyR.id,

    ]

        .map((x: any) => String(x || "").trim())

        .filter(Boolean);



    return Array.from(new Set(candidates));

}



function getEntityKey(r: RegistroAnalise): string {

    const anyR = r as any;

    const primary = String(anyR.sepultamento_id || anyR.sepultamentoId || anyR.id_sepultamento || "").trim();

    if (primary) return primary;



    const ids = getIdsParaTentar(r);

    return ids[0] || "";

}



/* =========================

   Falecido (para o modal)

   ========================= */

function getFalecidoNome(r: RegistroAnalise): string {

    const anyR = r as any;

    const nome =

        anyR.falecido ||

        anyR.falecido_nome ||

        anyR.nome_falecido ||

        anyR.falecidoNome ||

        anyR.nomeFalecido ||

        anyR.nome ||

        anyR.falecido_nome_completo ||

        "";

    return String(nome || "").trim();

}



/* =========================

   Modal de lista (Tanato)

   ========================= */

type TanatoItem = {

    entityKey: string;

    falecido: string;

    ts: number;

};



function ModalListaTanato({

    aberto,

    onFechar,

    agente,

    itens,

}: {

    aberto: boolean;

    onFechar: () => void;

    agente: string;

    itens: TanatoItem[];

}) {

    if (!aberto) return null;



    const itensOrdenados = [...(itens || [])].sort((a, b) => a.ts - b.ts);



    return (

        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[60]">

            <div className="bg-white w-[96%] md:w-[80%] lg:w-[60%] rounded-2xl shadow-2xl max-h-[90%] overflow-hidden dark:bg-[#232B3F]">

                <div className="flex items-center justify-between gap-3 border-b p-4 bg-white/90 backdrop-blur dark:bg-[#232B3F]/90">

                    <div>

                        <div className="text-base font-bold">Tanatopraxia: {agente}</div>

                        <div className="text-xs text-gray-500 dark:text-[#AEB9CF]">{fmt0(itensOrdenados.length)} falecido(s)</div>

                    </div>

                    <button

                        onClick={onFechar}

                        className="rounded-lg border px-3 py-1.5 text-sm text-red-600 hover:bg-red-50 dark:text-[#FF9C92] dark:hover:bg-[#FF9C92]/15"

                    >

                        Fechar

                    </button>

                </div>



                <div className="p-4 overflow-y-auto max-h-[78vh]">

                    {itensOrdenados.length === 0 ? (

                        <div className="rounded-lg border p-6 text-center text-sm text-gray-500 dark:text-[#AEB9CF]">

                            Nenhum registro para este agente no período.

                        </div>

                    ) : (

                        <div className="space-y-2">

                            {itensOrdenados.map((it) => (

                                <div

                                    key={it.entityKey}

                                    className="rounded-xl border border-gray-200 bg-white p-3 dark:border-white/12 dark:bg-[#232B3F]"

                                >

                                    <div className="text-sm font-semibold text-gray-900 dark:text-white">

                                        {it.falecido || "(Sem nome do falecido)"}

                                    </div>

                                    <div className="mt-1 text-xs text-gray-500 flex flex-wrap gap-3 dark:text-[#AEB9CF]">

                                        <span>Data/hora: {fmtDateHora(it.ts) || "-"}</span>

                                        <span>Entidade: {it.entityKey}</span>

                                    </div>

                                </div>

                            ))}

                        </div>

                    )}

                </div>

            </div>

        </div>

    );

}



/* =========================

   Componente

   ========================= */

export default function ModalAnaliseGeral({

    aberto,

    onFechar,

    aDe,

    aAte,

    setADe,

    setAAte,

    somenteTanato,

    setSomenteTanato,

    onRecarregar,

}: {

    aberto: boolean;

    onFechar: () => void;

    aDe: string;

    aAte: string;

    setADe: (v: string) => void;

    setAAte: (v: string) => void;

    somenteTanato: boolean;

    setSomenteTanato: (v: boolean) => void;

    onRecarregar?: () => void;

}) {

    type CacheEntry = { logs: any[]; fetched: boolean };



    const [busy, setBusy] = React.useState(false);

    const [dados, setDados] = React.useState<RegistroAnalise[]>([]);
    const [atendimentosBalanco, setAtendimentosBalanco] = React.useState<BalancoAtendimento[]>([]);

    const [erro, setErro] = React.useState<string | null>(null);

    const [analiseInicialCarregada, setAnaliseInicialCarregada] = React.useState(false);



    /*

     * Cache dos logs usados no cálculo da Tanatopraxia.

     *

     * O ponto principal da correção é não liberar os cards enquanto existir

     * alguma entidade de tanato cujo log ainda não terminou de carregar.

     */

    const cacheRef = React.useRef<Record<string, CacheEntry>>({});

    const inFlightRef = React.useRef<Set<string>>(new Set());

    const cicloLogsRef = React.useRef(0);

    const requisicaoAnaliticoRef = React.useRef(0);

    const [cacheVersion, setCacheVersion] = React.useState(0);



    const [tanatoModal, setTanatoModal] = React.useState<{

        aberto: boolean;

        agente: string;

        itens: TanatoItem[];

    }>({ aberto: false, agente: "", itens: [] });



    const resetarCacheTanato = React.useCallback(() => {

        cicloLogsRef.current += 1;

        cacheRef.current = {};

        inFlightRef.current.clear();

        setCacheVersion((v) => v + 1);

    }, []);



    const carregar = React.useCallback(async () => {
        const requisicao = ++requisicaoAnaliticoRef.current;

        try {
            setErro(null);
            setBusy(true);

            /*
             * O balanço é a fonte autoritativa da quantidade de atendimentos do período.
             * Ele usa a mesma regra do backend:
             * COALESCE(MIN(historico.datahora), MIN(est_movimento.criado_em)).
             *
             * O analítico continua sendo carregado para ornamentação, arrumação e
             * demais campos operacionais que não fazem parte do resumo do balanço.
             */
            const [lista, listaBalanco] = await Promise.all([
                listarAnalitico(),
                listarAtendimentosBalanco(aDe, aAte),
            ]);

            if (requisicao !== requisicaoAnaliticoRef.current) return;

            setDados(Array.isArray(lista) ? lista : []);
            setAtendimentosBalanco(Array.isArray(listaBalanco) ? listaBalanco : []);
        } catch (e: any) {
            if (requisicao !== requisicaoAnaliticoRef.current) return;

            setErro(e?.message || "Falha ao carregar dados da análise.");
            setDados([]);
            setAtendimentosBalanco([]);
        } finally {
            if (requisicao === requisicaoAnaliticoRef.current) {
                setBusy(false);
                setAnaliseInicialCarregada(true);
            }
        }
    }, [aDe, aAte]);


    React.useEffect(() => {

        if (!aberto) {

            // Invalida qualquer resposta que ainda esteja chegando após o fechamento.

            requisicaoAnaliticoRef.current += 1;

            cicloLogsRef.current += 1;

            inFlightRef.current.clear();

            setAnaliseInicialCarregada(false);

            return;

        }



        /*

         * Toda abertura começa um ciclo limpo. Assim o modal nunca mostra,

         * nem por um frame, números de uma abertura anterior.

         */

        setAnaliseInicialCarregada(false);

        resetarCacheTanato();

        void carregar();

    }, [aberto, carregar, resetarCacheTanato]);



    const handleRecarregar = React.useCallback(() => {

        setAnaliseInicialCarregada(false);

        resetarCacheTanato();



        // Mantém compatibilidade com o callback já usado pelo componente pai.

        onRecarregar?.();



        void carregar();

    }, [onRecarregar, carregar, resetarCacheTanato]);



    /*
     * Atendimentos do período:
     * o balanco.php já devolve somente os atendimentos cuja data_referencia
     * pertence ao intervalo solicitado. Portanto não repetimos no React a regra
     * antiga que escolhia data/data_inicio_velorio/ultima_datahora.
     *
     * Mesclamos os dados do balanço com o registro analítico correspondente.
     * Assim a quantidade e os convênios permanecem corretos mesmo quando
     * listarAnalitico() não contém um atendimento já finalizado/recolhido.
     */
    const dadosPorId = React.useMemo(() => {
        const map = new Map<string, RegistroAnalise>();

        for (const r of dados || []) {
            const ids = getIdsParaTentar(r);
            for (const id of ids) {
                if (id && !map.has(id)) map.set(id, r);
            }
        }

        return map;
    }, [dados]);

    const dadosPeriodo = React.useMemo(() => {
        return (atendimentosBalanco || []).map((atendimento) => {
            const id = getBalancoId(atendimento);
            const base = id ? dadosPorId.get(id) : undefined;

            return {
                ...(base || {}),
                id: (base as any)?.id ?? atendimento.id ?? atendimento.atendimento_id,
                atendimento_id:
                    (base as any)?.atendimento_id ??
                    atendimento.atendimento_id ??
                    atendimento.id,
                falecido:
                    atendimento.falecido ||
                    (base as any)?.falecido ||
                    "",
                convenio:
                    atendimento.convenio ??
                    (base as any)?.convenio ??
                    "",
                data_referencia: atendimento.data_referencia,
                assistencia_ativa: atendimento.assistencia_ativa,
                tanatopraxia_ativa: atendimento.tanatopraxia_ativa,
            } as RegistroAnalise;
        });
    }, [atendimentosBalanco, dadosPorId]);

    const registrosComEventoNoPeriodo = atendimentosBalanco.length;


    const rangeTanato = React.useMemo(() => makeRange(aDe, aAte), [aDe, aAte]);



    const tanatoEntities = React.useMemo(() => {

        const entityMap = new Map<string, Set<string>>();



        for (const r of dados || []) {

            if (!valorEhSim((r as any).tanato)) continue;



            const key = getEntityKey(r);

            if (!key) continue;



            const ids = getIdsParaTentar(r);

            if (!ids.length) continue;



            if (!entityMap.has(key)) entityMap.set(key, new Set());

            const set = entityMap.get(key)!;

            for (const id of ids) set.add(id);

        }




        // Inclui também atendimentos do balanço marcados com tanatopraxia,
        // inclusive os que já não aparecem na listagem operacional.
        for (const r of atendimentosBalanco || []) {
            if (!r.tanatopraxia_ativa) continue;

            const id = getBalancoId(r);
            if (!id) continue;

            if (!entityMap.has(id)) entityMap.set(id, new Set());
            entityMap.get(id)!.add(id);
        }

        const list = Array.from(entityMap.entries()).map(([key, idSet]) => ({

            key,

            idsToTry: Array.from(idSet),

        }));



        const keySet = new Set(list.map((x) => x.key));



        return { list, keySet };

    }, [dados, atendimentosBalanco]);



    // Mapa entidade -> nome do falecido (para o modal)

    const falecidoByEntity = React.useMemo(() => {

        const m: Record<string, string> = {};

        for (const r of dados || []) {

            const k = getEntityKey(r);

            if (!k) continue;

            if (m[k]) continue;

            const nome = getFalecidoNome(r);

            if (nome) m[k] = nome;

        }

        for (const r of atendimentosBalanco || []) {
            const k = getBalancoId(r);
            if (!k || m[k]) continue;
            const nome = String(r.falecido || "").trim();
            if (nome) m[k] = nome;
        }

        return m;

    }, [dados, atendimentosBalanco]);



    React.useEffect(() => {

        /*

         * Espera o analítico terminar. Isso elimina a corrida em que o modal

         * renderizava Tanatopraxia = 0 antes de os logs começarem a chegar.

         */

        if (!aberto || busy || !analiseInicialCarregada) return;



        const targets = tanatoEntities.list.filter(

            (e) => !cacheRef.current[e.key]?.fetched && !inFlightRef.current.has(e.key)

        );



        if (!targets.length) return;



        let cancelado = false;

        const ciclo = cicloLogsRef.current;



        async function run(maxConc = 4) {

            let i = 0;



            async function worker() {

                while (!cancelado && ciclo === cicloLogsRef.current) {

                    const idx = i++;

                    if (idx >= targets.length) break;



                    const item = targets[idx];



                    // Pode ter sido resolvido por outro ciclo/worker entre renders.

                    if (cacheRef.current[item.key]?.fetched) continue;

                    if (inFlightRef.current.has(item.key)) continue;



                    inFlightRef.current.add(item.key);



                    try {

                        let logs: any[] = [];



                        for (const id of item.idsToTry) {

                            if (cancelado || ciclo !== cicloLogsRef.current) break;



                            try {

                                const res = await listarLogPorId(id);

                                if (Array.isArray(res) && res.length) {

                                    logs = res;

                                    break;

                                }

                            } catch { }

                        }



                        /*

                         * Só grava se esta resposta ainda pertence à abertura atual.

                         * Isso evita um fetch antigo sobrescrever o cache após fechar

                         * e abrir novamente o modal.

                         */

                        if (!cancelado && ciclo === cicloLogsRef.current) {

                            cacheRef.current[item.key] = { logs, fetched: true };

                        }

                    } finally {

                        inFlightRef.current.delete(item.key);

                    }

                }

            }



            await Promise.all(

                Array.from(

                    { length: Math.max(1, Math.min(maxConc, targets.length)) },

                    () => worker()

                )

            );



            if (!cancelado && ciclo === cicloLogsRef.current) {

                /*

                 * Uma única atualização ao final é suficiente para recalcular

                 * tanatoCount, os agentes e liberar os cards já com o valor final.

                 */

                setCacheVersion((v) => v + 1);

            }

        }



        void run();



        return () => {

            cancelado = true;



            /*

             * O código antigo adicionava todos os targets ao inFlight antes de

             * processá-los. Se o efeito fosse cancelado, alguns IDs ficavam presos

             * no Set e nunca eram buscados na reabertura.

             */

            for (const item of targets) {

                inFlightRef.current.delete(item.key);

            }

        };

    }, [aberto, busy, analiseInicialCarregada, tanatoEntities]);



    const {

        tanatoCount,

        agentesOrdenados,

        tanatoItensPorAgente,

        assistTotal,

        ornNatural,

        ornArtificial,

        qtdArrumacaoFixas,

        convPref,

        convPart,

        convAssoc,

    } = React.useMemo(() => {

        const { start, end } = rangeTanato;



        const byKey: Record<string, number> = {};

        const displayByKey: Record<string, string> = {};

        const itensPorAgente: Record<string, TanatoItem[]> = {

            sandro: [],

            joseildo: [],

        };



        const assist = (atendimentosBalanco || []).reduce(
            (total, r) => total + (r.assistencia_ativa ? 1 : 0),
            0
        );

        let ornNat = 0;

        let ornArt = 0;



        const arr: Record<string, number> = Object.fromEntries(

            ARR_KEYS.map((k) => [k, 0])

        ) as Record<string, number>;



        let cPref = 0,
            cPart = 0,
            cAssoc = 0;

        for (const atendimento of atendimentosBalanco || []) {
            const convTxt = String(atendimento.convenio || "").toLowerCase();

            if (convTxt.includes("prefeitura")) cPref++;
            else if (convTxt.includes("associado") || convTxt.includes("associação")) cAssoc++;
            else if (convTxt.includes("particular")) cPart++;
        }



        // ===== TANATO (somente início PURO + somente Sandro/Joseildo) =====

        for (const [entityKey, entry] of Object.entries(cacheRef.current)) {

            if (!entry?.fetched) continue;

            if (!tanatoEntities.keySet.has(entityKey)) continue;



            const inicio = findPrimeiroInicioPuroNoPeriodo(entry.logs || [], start, end);

            if (!inicio) continue;



            const agente = agentePermitido(inicio);

            if (!agente) continue;



            const agenteK = norm(agente); // "sandro" | "joseildo"

            byKey[agenteK] = (byKey[agenteK] || 0) + 1;

            displayByKey[agenteK] = agente;



            // itens para auditoria no modal

            const ts = logTs(inicio);

            const falecido = falecidoByEntity[entityKey] || "";

            itensPorAgente[agenteK] = itensPorAgente[agenteK] || [];

            itensPorAgente[agenteK].push({ entityKey, falecido, ts });

        }



        // dedupe por entityKey dentro do agente (segurança extra)

        for (const k of Object.keys(itensPorAgente)) {

            const seen = new Set<string>();

            itensPorAgente[k] = (itensPorAgente[k] || []).filter((it) => {

                if (seen.has(it.entityKey)) return false;

                seen.add(it.entityKey);

                return true;

            });

        }



        // ===== RESTO (analítico filtrado por dadosPeriodo) =====

        for (const r of dadosPeriodo) {

            const ornTxt = String(

                (r as any).ornamentacao_tipo ||

                (r as any).ornamentacao ||

                (r as any).ornamentacao_tipo_nome ||

                ""

            ).toLowerCase();

            if (ornTxt.includes("natural")) ornNat++;

            else if (ornTxt.includes("artificial")) ornArt++;



            const estadosArr = extrairEstadoArrumacao(r);

            for (const k of ARR_KEYS) if (estadosArr[k]) arr[k] = (arr[k] || 0) + 1;



        }



        const agentesOrdenados = Object.entries(byKey)

            .map(([k, count]) => ({ key: k, display: displayByKey[k] || titleCase(k), count }))

            .sort((a, b) => b.count - a.count);



        const tanatoCount = agentesOrdenados.reduce((s, a) => s + a.count, 0);



        return {

            tanatoCount,

            agentesOrdenados,

            tanatoItensPorAgente: itensPorAgente,

            assistTotal: assist,

            ornNatural: ornNat,

            ornArtificial: ornArt,

            qtdArrumacaoFixas: arr,

            convPref: cPref,

            convPart: cPart,

            convAssoc: cAssoc,

        };

    }, [dadosPeriodo, atendimentosBalanco, rangeTanato, cacheVersion, tanatoEntities, falecidoByEntity]);



    /*

     * Enquanto existir ao menos um tanato sem log resolvido, não mostramos os

     * cards. Assim "0" só aparece quando o resultado final realmente for zero.

     */

    const tanatoPendente = React.useMemo(() => {

        if (!aberto || busy || !analiseInicialCarregada) return false;

        if (!tanatoEntities.list.length) return false;



        return tanatoEntities.list.some(

            (e) => !cacheRef.current[e.key]?.fetched

        );

    }, [aberto, busy, analiseInicialCarregada, tanatoEntities, cacheVersion]);



    const carregandoAnalise =

        busy ||

        !analiseInicialCarregada ||

        tanatoPendente;



    const ornTotal = (ornNatural || 0) + (ornArtificial || 0);



    const subTanato = React.useMemo(() => {

        if (!agentesOrdenados.length) return undefined;



        return (

            <div className="flex flex-wrap gap-x-2 gap-y-1">

                {agentesOrdenados.map((a, idx) => (

                    <React.Fragment key={a.key}>

                        <button

                            type="button"

                            className="underline decoration-dotted hover:opacity-80"

                            onClick={() => {

                                const itens = tanatoItensPorAgente?.[a.key] || [];

                                setTanatoModal({ aberto: true, agente: a.display, itens });

                            }}

                            title="Clique para ver a lista de falecidos"

                        >

                            {a.display}: {fmt0(a.count)}

                        </button>

                        {idx < agentesOrdenados.length - 1 ? <span>·</span> : null}

                    </React.Fragment>

                ))}

            </div>

        );

    }, [agentesOrdenados, tanatoItensPorAgente]);



    if (!aberto) return null;



    return (

        <>

            <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">

                <div className="bg-white w-[96%] md:w-[92%] lg:w-[84%] rounded-2xl shadow-2xl max-h-[95%] overflow-y-auto dark:bg-[#232B3F]">

                    {/* Cabeçalho */}

                    <div className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b bg-white/90 p-4 backdrop-blur dark:bg-[#232B3F]/90">

                        <div>

                            <h2 className="text-lg font-bold leading-tight">Análise Geral</h2>

                            <p className="text-xs text-gray-500 dark:text-[#AEB9CF]">

                                Período: {aDe || "-"} a {aAte || "-"} • {fmt0(registrosComEventoNoPeriodo)} registro(s)

                            </p>

                        </div>

                        <div className="flex items-center gap-2">

                            <button

                                onClick={handleRecarregar}

                                className="rounded-lg border px-3 py-1.5 text-sm hover:bg-gray-50 dark:hover:bg-[#1C2334]"

                            >

                                Recarregar

                            </button>

                            <button

                                onClick={onFechar}

                                className="rounded-lg border px-3 py-1.5 text-sm text-red-600 hover:bg-red-50 dark:text-[#FF9C92] dark:hover:bg-[#FF9C92]/15"

                            >

                                Fechar

                            </button>

                        </div>

                    </div>



                    {/* Filtros */}

                    <div className="p-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">

                        <label className="flex flex-col gap-1">

                            <span className="text-xs text-gray-500 dark:text-[#AEB9CF]">Data inicial</span>

                            <input

                                type="date"

                                value={aDe || ""}

                                onChange={(e) => setADe(e.target.value)}

                                className="rounded-md border px-3 py-2"

                            />

                        </label>

                        <label className="flex flex-col gap-1">

                            <span className="text-xs text-gray-500 dark:text-[#AEB9CF]">Data final</span>

                            <input

                                type="date"

                                value={aAte || ""}

                                onChange={(e) => setAAte(e.target.value)}

                                className="rounded-md border px-3 py-2"

                            />

                        </label>

                        <label className="flex items-center gap-2">

                            <input

                                type="checkbox"

                                checked={!!somenteTanato}

                                onChange={(e) => setSomenteTanato(e.target.checked)}

                            />

                            <span className="text-sm">Ocultar cards de itens</span>

                        </label>

                        <div className="text-sm text-gray-500 self-center dark:text-[#AEB9CF]">

                            Se informar apenas uma data, usamos <b>só aquele dia</b>.

                        </div>

                    </div>



                    {/* Corpo */}

                    <div className="p-4 pt-0">

                        {carregandoAnalise ? (

                            <div className="rounded-lg border p-6 text-center text-sm text-gray-500 dark:text-[#AEB9CF]">

                                Carregando análise completa…

                            </div>

                        ) : erro ? (

                            <div className="rounded-lg border p-6 text-center text-sm text-red-600 dark:text-[#FF9C92]">

                                {erro}

                            </div>

                        ) : dadosPeriodo.length === 0 ? (

                            <div className="rounded-lg border p-6 text-center text-sm text-gray-500 dark:text-[#AEB9CF]">

                                Nenhum dado para o período/filtro selecionado.

                            </div>

                        ) : (

                            <>

                                {/* ITENS PRINCIPAIS */}

                                <div className="rounded-2xl border overflow-hidden mb-6">

                                    <div className="flex items-center justify-between px-4 py-3 border-b bg-gray-50 dark:bg-[#1C2334]">

                                        <div className="text-sm font-semibold">Itens principais</div>

                                    </div>

                                    <div className="p-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">

                                        <ItemCard

                                            titulo="Tanatopraxia"

                                            valor={tanatoCount}

                                            subtexto={subTanato}

                                            tipo="Principal"

                                            destaque="indigo"

                                        />

                                        <ItemCard

                                            titulo="Assistências"

                                            valor={assistTotal}

                                            tipo="Principal"

                                            destaque="teal"

                                        />

                                        <ItemCard

                                            titulo="Ornamentações"

                                            valor={ornTotal}

                                            subtexto={`Natural: ${fmt0(ornNatural || 0)} · Artificial: ${fmt0(

                                                ornArtificial || 0

                                            )}`}

                                            tipo="Principal"

                                            destaque="rose"

                                        />

                                    </div>

                                </div>



                                {/* CONVÊNIOS */}

                                <div className="rounded-2xl border overflow-hidden mb-6">

                                    <div className="flex items-center justify-between px-4 py-3 border-b bg-gray-50 dark:bg-[#1C2334]">

                                        <div className="text-sm font-semibold">Atendimentos por convênio</div>

                                    </div>

                                    <div className="p-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">

                                        <ItemCard titulo="Prefeitura" valor={convPref} tipo="Convênio" destaque="indigo" />

                                        <ItemCard titulo="Particular" valor={convPart} tipo="Convênio" destaque="teal" />

                                        <ItemCard titulo="Associado" valor={convAssoc} tipo="Convênio" destaque="rose" />

                                    </div>

                                </div>



                                {/* 12 ITENS DE ARRUMAÇÃO */}

                                {!somenteTanato && (

                                    <div className="rounded-2xl border overflow-hidden mb-6">

                                        <div className="flex items-center justify-between px-4 py-3 border-b bg-gray-50 dark:bg-[#1C2334]">

                                            <div className="text-sm font-semibold">Itens consumidos (Arrumação)</div>

                                            <div className="text-xs text-gray-500 dark:text-[#AEB9CF]">Mostrando os 12 itens</div>

                                        </div>

                                        <div className="p-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">

                                            {ARR_KEYS.map((k, idx) => (

                                                <ItemCard

                                                    key={k}

                                                    titulo={ARR_LABELS[k]}

                                                    valor={qtdArrumacaoFixas[k] || 0}

                                                    tipo="Conservação do Corpo"

                                                    destaque={DESTAQUES[idx % DESTAQUES.length]}

                                                />

                                            ))}

                                        </div>

                                    </div>

                                )}

                            </>

                        )}

                    </div>

                </div>

            </div>



            {/* Modal de auditoria do Tanato */}

            <ModalListaTanato

                aberto={tanatoModal.aberto}

                agente={tanatoModal.agente}

                itens={tanatoModal.itens}

                onFechar={() => setTanatoModal({ aberto: false, agente: "", itens: [] })}

            />

        </>

    );

}
