import { createHmac } from "node:crypto";
import { NextResponse } from "next/server";
import { getWC } from "@/lib/woocommerce";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

type Meta = {
    key?: string;
    value?: unknown;
};

type WcLineItem = {
    id: number;
    name?: string;
    quantity?: number;
    total?: string | number;
    product_id?: number;
    variation_id?: number;
    sku?: string;
    meta_data?: Meta[];
    image?: {
        id?: number | string;
        src?: string;
    };
};

type WcOrderForProduction = {
    id: number;
    number?: string;
    status?: string;
    /** Total pago no site (com frete) e o frete — vão para o pedido de coroa e para a OS Cor (09/10/2026). */
    total?: string | number;
    shipping_total?: string | number;
    customer_note?: string;
    billing?: {
        first_name?: string;
        last_name?: string;
        phone?: string;
        email?: string;
    };
    shipping?: {
        first_name?: string;
        last_name?: string;
        address_1?: string;
        address_2?: string;
        city?: string;
        state?: string;
        postcode?: string;
    };
    meta_data?: Meta[];
    line_items?: WcLineItem[];
};

const COROAS_API = "https://api.planoassistencialintegrado.com.br/coroas.php";
const STATUS_CONFECCAO = new Set(["processing", "completed"]); // somente alterações feitas daqui para frente

const FRASE_KEYS = [
    "frase_para_a_faixa",
    "frase da coroa",
    "frase da faixa",
    "frase_faixa",
    "texto da faixa",
    "texto_faixa",
    "mensagem",
    "faixa",
];

const FALECIDO_KEYS = [
    "shipping_falecido_nome",
    "falecido_nome",
    "nome_falecido",
    "nome_do_falecido",
    "falecido",
];

function metaToString(value: unknown): string {
    if (typeof value === "string") return value.trim();
    if (typeof value === "number" || typeof value === "boolean") return String(value);
    if (value == null) return "";

    try {
        const json = JSON.stringify(value);
        return json === "{}" || json === "[]" ? "" : json;
    } catch {
        return "";
    }
}

function findMetaValue(metas: Meta[] | undefined, keys: string[]): string {
    if (!Array.isArray(metas) || metas.length === 0) return "";

    const needles = keys.map((key) => key.toLocaleLowerCase("pt-BR"));

    for (const meta of metas) {
        const key = String(meta?.key || "").toLocaleLowerCase("pt-BR");
        if (!needles.some((needle) => key.includes(needle))) continue;

        const value = metaToString(meta?.value);
        if (value) return value;
    }

    return "";
}

function pedidoLiberadoParaConfeccao(order: WcOrderForProduction): boolean {
    return STATUS_CONFECCAO.has(String(order?.status || "").trim().toLowerCase());
}

function nomeCliente(order: WcOrderForProduction): string {
    return [order.billing?.first_name, order.billing?.last_name]
        .map((value) => String(value || "").trim())
        .filter(Boolean)
        .join(" ");
}

function falecido(order: WcOrderForProduction): string {
    return (
        findMetaValue(order.meta_data, FALECIDO_KEYS) ||
        String(order.shipping?.first_name || "").trim()
    );
}

function localEntrega(order: WcOrderForProduction): string {
    return [
        order.shipping?.address_1,
        order.shipping?.address_2,
        order.shipping?.city,
        order.shipping?.state,
        order.shipping?.postcode,
    ]
        .map((value) => String(value || "").trim())
        .filter(Boolean)
        .join(", ");
}

function itensParaConfeccao(order: WcOrderForProduction) {
    const frasePedido = findMetaValue(order.meta_data, FRASE_KEYS);

    return (order.line_items || []).map((item) => ({
        wc_line_item_id: item.id,
        wc_product_id: item.product_id || null,
        wc_variation_id: item.variation_id || null,
        sku: String(item.sku || "").trim(),
        nome: String(item.name || "").trim(),
        quantidade: Math.max(1, Number(item.quantity || 1)),
        total: Number(item.total || 0),
        frase: findMetaValue(item.meta_data, FRASE_KEYS) || frasePedido,
        foto_url: String(item.image?.src || "").trim() || null,
    }));
}

/**
 * 22/10/2026: a loja vende também a adesão dos planos (SKU adesao-*). Só pedidos de coroa vão para a
 * Confecção, para a lista de Pedidos Online e para a notificação. O plugin "PAI · Formulários do Checkout"
 * grava pai_tipo_pedido (coroas, planos...) em cada pedido; pedidos antigos, sem esse campo, são coroa,
 * a não ser que tenham produto com SKU adesao-*.
 */
function ehPedidoDeCoroa(order: { meta_data?: Array<{ key?: string; value?: unknown }>; line_items?: Array<{ sku?: string }> } | null | undefined): boolean {
    const tipo = (order?.meta_data || []).find((m) => String(m?.key || "") === "pai_tipo_pedido");
    const valor = String(tipo?.value ?? "").trim().toLowerCase();
    if (valor) return valor === "coroas";
    return !(order?.line_items || []).some((i) => /^adesao-/i.test(String(i?.sku || "")));
}

async function enviarPedidoParaConfeccao(order: WcOrderForProduction, requestOrigin: string) {
    if (!order?.id) throw new Error("Pedido WooCommerce sem ID.");

    if (!ehPedidoDeCoroa(order)) {
        return { sincronizado: false, ignorado: true, motivo: "nao_e_pedido_de_coroa" };
    }

    if (!pedidoLiberadoParaConfeccao(order)) {
        return {
            sincronizado: false,
            ignorado: true,
            motivo: `status_${String(order.status || "desconhecido")}_nao_liberado`,
        };
    }

    const secret = String(process.env.WC_WEBHOOK_SECRET || "").trim();
    if (!secret) {
        throw new Error("WC_WEBHOOK_SECRET não configurado no Next.js.");
    }

    const itens = itensParaConfeccao(order);
    if (!itens.length) {
        throw new Error(`Pedido WooCommerce #${order.id} não possui itens.`);
    }

    const body = JSON.stringify({
        acao: "importar_online",
        woocommerce_order_id: String(order.id),
        solicitante: nomeCliente(order) || "Cliente Online",
        telefone: String(order.billing?.phone || "").trim(),
        local_entrega: localEntrega(order),
        observacoes: String(order.customer_note || "").trim(),
        falecido: falecido(order),
        status_pagamento: "pago",
        total_pago: Number(order.total || 0) || null,
        frete: Number(order.shipping_total || 0) || null,
        itens,
    });

    const signature = createHmac("sha256", secret)
        .update(body, "utf8")
        .digest("base64");

    const verifyUrl = new URL("/api/wc/orders?verify_internal=1", requestOrigin).toString();

    const res = await fetch(COROAS_API, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "X-PAI-Internal-Signature": signature,
            "X-PAI-Verify-Url": verifyUrl,
        },
        cache: "no-store",
        body,
    });

    const json = await res.json().catch(() => null);

    if (!res.ok || !json?.sucesso) {
        const detalhe = json?.msg || json?.message || `HTTP ${res.status}`;
        throw new Error(
            `Falha ao enviar pedido WooCommerce #${order.id} para Confecção: ${detalhe}`,
        );
    }

    return { sincronizado: true, resultado: json };
}

export async function GET(_: Request, { params }: { params: { id: string } }) {
    try {
        const wc = getWC();
        const { data } = await wc.get(`orders/${params.id}`);
        return NextResponse.json(data);
    } catch (err: any) {
        const status = err?.response?.status || 500;
        const data = err?.response?.data;

        console.error("WC order detail error:", status, data || err?.message);

        return NextResponse.json(
            {
                error: true,
                status,
                message: data?.message || err?.message || "Falha ao consultar pedido WooCommerce.",
                details: data || null,
            },
            { status },
        );
    }
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
    try {
        const wc = getWC();
        const body = await req.json();
        const { data } = await wc.put(`orders/${params.id}`, body);

        let confeccao: unknown = null;

        if (pedidoLiberadoParaConfeccao(data)) {
            try {
                confeccao = await enviarPedidoParaConfeccao(data, new URL(req.url).origin);
            } catch (syncError: any) {
                console.error(
                    `Pedido WC #${params.id} atualizado, mas falhou ao sincronizar com Confecção:`,
                    syncError?.message || syncError,
                );

                confeccao = {
                    sincronizado: false,
                    erro: syncError?.message || "Falha ao sincronizar com a Confecção.",
                };
            }
        }

        return NextResponse.json({
            ...data,
            _confeccao: confeccao,
        });
    } catch (err: any) {
        const status = err?.response?.status || 500;
        const data = err?.response?.data;

        console.error("WC order patch error:", status, data || err?.message);

        return NextResponse.json(
            {
                error: true,
                status,
                message: data?.message || err?.message || "Falha ao atualizar WooCommerce.",
                details: data || null,
            },
            { status },
        );
    }
}