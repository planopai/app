"use client";

/*
 * QUADRO TV — novo visual para TV (a partir de 1024 px de largura)
 * - tela desenhada em 1920×1080 e reduzida por igual; botão de tela cheia;
 * - por atendimento: situação atual em destaque, tempo nela, responsável,
 *   linha do tempo das etapas (atual piscando em verde), ocioso e total;
 * - alertas: vermelho quando está há 24 h+ na mesma situação; âmbar quando passou do
 *   horário marcado e o velório (fase08) ou o sepultamento (fase09) ainda não começou;
 * - coroas: âmbar quando passou do prazo de produção desde o pedido e a coroa ainda
 *   não ficou pronta (natural 2 h, artificial 1 h — COROA_PRAZO_*);
 * - coroas: linha discreta (0), faixa inferior (1–4 pedidos) ou coluna lateral (5+),
 *   com paginação automática; atendimentos compactam e paginam quando não cabem;
 *
 * QUADRO NO CELULAR/TABLET (abaixo de 1024 px)
 * - abas Atendimentos / Coroas / Avisos com contagem; aviso mais recente no topo da lista;
 * - em pé: cartão com bloco "Agora" (status, há quanto tempo, quem), alertas da TV,
 *   etapas com nome (vazia = ainda não aconteceu; tracejada = não se aplica), ocioso e total;
 * - deitado: uma linha por atendimento, como na TV; a troca segue o giro da tela;
 * - tema claro/escuro acompanha o fundo do app; botão de tela cheia onde o navegador permite.
 *
 * Base preservada:
 * - mantém relógio, ticker, modais, etapas, ícones, logs e tempos originais;
 * - Coroas: modelo + solicitante, Falecido, Entrega, Pagamento e timeline Ampulheta/Flor/Faixa/Concluída;
 * - Coroas finalizadas permanecem no quadro até a confirmação do status Entregue;
 * - atualização da fila de Coroas a cada 3 segundos, sem cache atrasando novos pedidos online;
 * - FIX STATUS PERSISTENTE: falha/timeout no histórico nunca apaga etapas já carregadas;
 * - FIX STATUS PERSISTENTE: histórico dos atendimentos é preservado no localStorage;
 * - FIX STATUS PERSISTENTE: status atual do atendimento nunca volta visualmente para fase01 por ausência temporária de logs;
 * - FIX STATUS PERSISTENTE: atualização imediata ao voltar para a aba, recuperar foco ou reconectar a internet;
 */

import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import AcaoModal, {
    type EstoqueInsuficienteAlerta,
    type EstoqueInsuficienteItem,
} from "../acompanhamento/components/AcaoModal";
import FotoAcaoModal, { type FotoAcaoTipo } from "../acompanhamento/components/FotoAcaoModal";
import TelemetriaModal, {
    type TipoTele,
    type TelemetriaHandle,
} from "../acompanhamento/components/TelemetriaModal";
import MateriaisConferenciaModal, {
    type MatCheckItem,
    type MateriaisConferenciaResult,
} from "../acompanhamento/components/MateriaisConferenciaModal";
import { enviarRegistroPHP, normalizeMateriaisState } from "../acompanhamento/components/helpers";
import type { MateriaisState } from "../acompanhamento/components/types";
import { getCurrentOfflineSession } from "@/lib/offline/session";
import { getOperationalTimestamp } from "@/lib/offline/clock";
import { getOfflineDeviceId } from "@/lib/offline/device";
import { newOfflineId } from "@/lib/offline/db";
import Visita, { consultarAcessoVisita, consultarStatusVisitas, type VisitaStatus } from "../acompanhamento/components/visita";
import { BotaoRegistrarAcao, BotaoEditar, BotaoOS, BotaoVisita, BotaoFechar } from "@/components/atendimentos/BotoesAtendimento";

/* =========================
   Cache rápido (memória + localStorage)
   ========================= */
type CacheEntry = { exp: number; data: any };
const MEM_CACHE = new Map<string, CacheEntry>();
const INFLIGHT = new Map<string, Promise<any>>();

function getMem<T>(k: string): T | null {
    const hit = MEM_CACHE.get(k);
    if (!hit) return null;
    if (Date.now() > hit.exp) {
        MEM_CACHE.delete(k);
        return null;
    }
    return hit.data as T;
}
function setMem(k: string, data: any, ttlMs: number) {
    MEM_CACHE.set(k, { exp: Date.now() + ttlMs, data });
}

function readLS<T>(k: string): T | null {
    if (typeof window === "undefined") return null;
    try {
        const raw = localStorage.getItem(k);
        if (!raw) return null;
        return JSON.parse(raw) as T;
    } catch {
        return null;
    }
}
function writeLS(k: string, v: any) {
    if (typeof window === "undefined") return;
    try {
        localStorage.setItem(k, JSON.stringify(v));
    } catch {
        // ignore
    }
}

async function fetchJsonFast<T = any>(
    url: string,
    opts?: { ttlMs?: number; timeoutMs?: number; cacheKey?: string }
): Promise<T> {
    const ttlMs = opts?.ttlMs ?? 8_000;
    const timeoutMs = opts?.timeoutMs ?? 12_000;
    const cacheKey = opts?.cacheKey ?? url;

    const cached = getMem<T>(cacheKey);
    if (cached) return cached;

    const inF = INFLIGHT.get(cacheKey);
    if (inF) return (await inF) as T;

    const p = (async () => {
        const ac = new AbortController();
        const t = setTimeout(() => ac.abort(), timeoutMs);
        try {
            const resp = await fetch(url, {
                cache: "no-store",
                credentials: "include",
                signal: ac.signal,
            });
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const data = (await resp.json()) as T;
            setMem(cacheKey, data, ttlMs);
            return data;
        } finally {
            clearTimeout(t);
            INFLIGHT.delete(cacheKey);
        }
    })();

    INFLIGHT.set(cacheKey, p);
    return (await p) as T;
}

/* =========================
   Tipos
   ========================= */
type Registro = {
    data?: string;
    falecido?: string;
    local_velorio?: string;
    data_inicio_velorio?: string;
    data_fim_velorio?: string;
    hora_fim_velorio?: string;
    hora_inicio_velorio?: string;
    agente?: string;
    status?: string;
    religiao?: string;
    contato?: string;
    convenio?: string;
    observacao?: string;
    observacao_atendimento?: string;
    observacao_itens?: string;
    observacao_velorio01?: string;
    observacao_velorio02?: string;

    urna?: string;
    roupa?: string;
    assistencia?: string;
    tanato?: string;

    // Rotas opcionais do atendimento.
    // Registros antigos podem vir NULL/ausentes; nesses casos o comportamento legado é considerar "Sim".
    realiza_velorio?: string | null;
    realiza_sepultamento?: string | null;

    invol?: any;

    ornamentacao?: string;
    ornamentacao_tipo?: string;

    local?: string;
    local_sepultamento?: string;

    materiais?: string;
    material?: string;

    materiais_json?: any;
    material_json?: any;

    tipo_atendimento?: "funerario" | "terceiro";

    [key: string]: any;
};

type Aviso = { usuario?: string; mensagem?: string };

type LogItem = {
    id?: number | string;
    datahora?: string;
    acao?: string;
    status_novo?: string;
    detalhes?: any;
    usuario?: string;
};

// Histórico visual persistente dos atendimentos.
// A lista principal já era preservada em qa_registros; agora os logs também são.
const STATUS_LOGS_STORAGE_KEY = "qa_status_logs_v2";
const STATUS_LOGS_STORAGE_MAX_ENTRIES = 250;

/* =========================
   Coroas de Flores — quadro TV
   ========================= */
type CoroaTvItem = {
    id?: number;
    ordem?: number;
    tipo_coroa?: "natural" | "artificial" | null;
    modelo_coroa?: string | null;
    frase?: string | null;
};

type CoroaTvPedido = {
    id: number;
    solicitante?: string | null;
    telefone?: string | null;
    local_entrega?: string | null;
    observacoes?: string | null;
    quantidade_coroas?: number | null;
    modelo_coroa?: string | null;
    frase?: string | null;
    falecido?: string | null;
    status_pagamento?: string | null;
    origem?: string | null;
    status?: string | null;
    comprovante_url?: string | null;
    criado_por?: string | null;
    criado_em?: string | null;
    atualizado_em?: string | null;
    coroa_inicio_em?: string | null;
    coroa_inicio_por?: string | null;
    faixa_inicio_em?: string | null;
    faixa_inicio_por?: string | null;
    finalizada_em?: string | null;
    finalizada_por?: string | null;
    entregue_em?: string | null;
    entregue_por?: string | null;
    itens?: CoroaTvItem[] | null;
};

type CoroasTvResponse = {
    sucesso?: boolean;
    dados?: CoroaTvPedido[];
    meta?: {
        page?: number;
        per_page?: number;
        total?: number;
        total_pages?: number;
    };
    msg?: string;
    erro?: string | boolean;
};

type QaDensity = "normal" | "compact" | "dense" | "ultra" | "micro";

/* Endereço da API (um código só para as duas rotas):
 * - as duas rotas (Quadro e TV) usam o endereço direto da API (13/10/2026).
 *   O proxy /api/php do site aponta para planoassistencialintegrado.com.br, onde ficou uma cópia
 *   antiga do informativo.php, sem o filtro dos cancelados: o Quadro mostrava atendimento cancelado.
 * A rota da TV é reconhecida pelo endereço da página (contém "tv") ou por ?tv=1.
 * Para forçar, troque FORCAR_ROTA_TV por true ou false. */
const FORCAR_ROTA_TV: boolean | null = null;
const API_DIRETA = "https://api.planoassistencialintegrado.com.br";
const URNA_SAIDA_API = `${API_DIRETA}/urna_saida.php`;

type BaixaCorpoProntoPayload = {
    registro_id: string;
    tipo: "" | "URNA" | "ROUPA" | "INVOL" | "CORDAO" | "VEU" | "KIT_LANCHE" | "COROA_ARTIFICIAL" | "INSUMOS";
    deposito_nome?: string;
    itens?: Array<{ produto_id: number; qtd: number }>;
};

class EstoqueInsuficienteQuadroError extends Error {
    readonly code = "ESTOQUE_INSUFICIENTE";
    readonly itens: EstoqueInsuficienteItem[];

    constructor(message: string, itens: EstoqueInsuficienteItem[]) {
        super(message);
        this.name = "EstoqueInsuficienteQuadroError";
        this.itens = itens;
    }
}

function isEstoqueInsuficienteQuadroError(error: unknown): error is EstoqueInsuficienteQuadroError {
    return (
        error instanceof EstoqueInsuficienteQuadroError ||
        String((error as any)?.code ?? "") === "ESTOQUE_INSUFICIENTE"
    );
}

async function baixarItensCorpoProntoQuadro(payload: BaixaCorpoProntoPayload): Promise<any> {
    const resp = await fetch(`${URNA_SAIDA_API}?_nocache=${Date.now()}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(payload),
        cache: "no-store",
    });

    if (resp.status === 401) {
        throw new Error("Sessão expirada. Faça login novamente.");
    }

    const json = await resp.json().catch(() => null);
    if (!json) {
        throw new Error("Resposta inválida do servidor ao processar a baixa do Corpo Pronto.");
    }
    if (json?.need_login) {
        throw new Error("Sessão expirada. Faça login novamente.");
    }

    if (!resp.ok || json?.ok === false) {
        const faltantesRaw = Array.isArray(json?.faltantes) ? json.faltantes : [];

        if (String(json?.error_code ?? "") === "ESTOQUE_INSUFICIENTE" || faltantesRaw.length > 0) {
            const itens: EstoqueInsuficienteItem[] = faltantesRaw
                .map((item: any) => {
                    const necessario = Math.max(
                        1,
                        Number(item?.necessario ?? item?.quantidade_solicitada ?? 1) || 1,
                    );
                    const disponivel = Math.max(
                        0,
                        Number(item?.disponivel ?? item?.saldo_atual ?? 0) || 0,
                    );

                    return {
                        produto_id: Number(item?.produto_id ?? 0) || 0,
                        produto_nome: String(
                            item?.produto_nome ?? item?.nome ?? (item?.produto_id ? `Produto ${item.produto_id}` : "Produto"),
                        ).trim() || "Produto",
                        deposito_nome: String(item?.deposito_nome ?? item?.deposito_origem ?? "").trim(),
                        disponivel,
                        necessario,
                        faltante: Math.max(0, Number(item?.faltante ?? necessario - disponivel) || 0),
                    };
                })
                .filter((item: EstoqueInsuficienteItem) => item.produto_id > 0);

            if (itens.length === 0 && Number(json?.produto_id ?? 0) > 0) {
                const necessario = Math.max(1, Number(json?.quantidade_solicitada ?? 1) || 1);
                const disponivel = Math.max(0, Number(json?.saldo_atual ?? 0) || 0);
                itens.push({
                    produto_id: Number(json.produto_id),
                    produto_nome: String(json?.produto_nome ?? `Produto ${json.produto_id}`).trim(),
                    deposito_nome: String(json?.deposito_nome ?? json?.deposito_origem ?? "").trim(),
                    disponivel,
                    necessario,
                    faltante: Math.max(0, necessario - disponivel),
                });
            }

            throw new EstoqueInsuficienteQuadroError(
                String(json?.msg ?? json?.erro ?? "Estoque insuficiente para concluir Corpo Pronto."),
                itens,
            );
        }

        throw new Error(String(json?.msg ?? json?.erro ?? "Falha ao processar as baixas do Corpo Pronto."));
    }

    return json;
}

async function carregarRegistrosAtuaisQuadro(): Promise<Registro[]> {
    const url = `${API_PHP}/informativo.php?listar=1&_ts=${Date.now()}`;
    const json = await fetchJsonFast<any>(url, {
        ttlMs: 0,
        timeoutMs: 12_000,
        cacheKey: `informativo_listar_acao_${Date.now()}`,
    });

    if (!Array.isArray(json)) {
        throw new Error("Resposta inválida ao atualizar os atendimentos.");
    }

    return json as Registro[];
}

function mapFaseToTipoQuadro(fase: string): TipoTele | null {
    if (fase === "fase01") return "remocao";
    if (fase === "fase07") return "para_velorio";
    if (fase === "fase09") return "para_sepultamento";
    return null;
}

function resolveFalecidoNomeQuadro(r?: Registro | null): string {
    return String(
        (r as any)?.falecido ??
        (r as any)?.nome_falecido ??
        (r as any)?.falecido_nome ??
        (r as any)?.nome_do_falecido ??
        (r as any)?.nome ??
        "",
    ).trim();
}

function parseMateriaisFromRegistroQuadro(r: Registro): MateriaisState {
    if ((r as any)?.materiais_json) {
        try {
            const parsed = JSON.parse(String((r as any).materiais_json));
            return normalizeMateriaisState(parsed);
        } catch {
            // fallback para colunas legadas abaixo
        }
    }

    const out: MateriaisState = {};
    try {
        for (const [k, v] of Object.entries(r as any)) {
            if (!k.startsWith("materiais_") || !k.endsWith("_qtd")) continue;
            const qtd = Math.max(0, Math.floor(Number(v ?? 0)));
            if (qtd <= 0) continue;

            const nomeBase = k.replace(/^materiais_/, "").replace(/_qtd$/, "");
            (out as any)[nomeBase] = {
                checked: true,
                qtd,
                nome: nomeBase.replace(/_/g, " "),
            };
        }
    } catch {
        // mantém objeto vazio
    }
    return out;
}

async function salvarConferenciaNoPHPQuadro(data: {
    registro_id: string | number | null | undefined;
    falecido_nome: string;
    observacao: string;
    itens: Array<{
        key: string;
        nome: string;
        qtd: number;
        ok: 0 | 1;
        nao_conforme: 0 | 1;
    }>;
}) {
    const registroId = data.registro_id != null ? String(data.registro_id) : "";
    if (!registroId) {
        throw new Error("Não foi possível identificar o atendimento (registro_id).");
    }

    const resp = await fetch(`${API_DIRETA}/materiais_admin.php?op=conferencia_create&_nocache=${Date.now()}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
            registro_id: registroId,
            falecido_nome: String(data.falecido_nome || "").trim(),
            observacao: String(data.observacao || "").trim(),
            itens: Array.isArray(data.itens) ? data.itens : [],
        }),
    });

    if (resp.status === 401) throw new Error("Sessão expirada. Faça login novamente.");
    const json = await resp.json().catch(() => null);
    if (!json) throw new Error("Resposta inválida do servidor.");
    if (json?.need_login) throw new Error("Sessão expirada. Faça login novamente.");
    if (!resp.ok || json?.erro) throw new Error(json?.msg || "Erro ao salvar conferência.");
    return json;
}

function ehRotaTv(): boolean {
    if (FORCAR_ROTA_TV !== null) return FORCAR_ROTA_TV;
    if (typeof window === "undefined") return false;
    try {
        if (new URLSearchParams(window.location.search).get("tv") === "1") return true;
    } catch {
        // ignore
    }
    return /tv/i.test(window.location.pathname);
}
const API_PHP = API_DIRETA;

/* ===== Endereços das telas do app =====
 * Pela skill do front (lista de páginas do pai_api.php): a tela de atendimento é a chave `atendimento` → rota "/atendimento".
 * Os PARÂMETROS que abrem "Registrar ação" e "Editar" direto no atendimento escolhido NÃO estão na skill:
 * deixei como estão abaixo e marquei com  >>> TROCAR AO SUBIR  para você ajustar ao que o app realmente usa.
 * A rota da TV também não está na skill: o padrão abaixo abre este mesmo Quadro em modo TV (?tv=1). */
const ROTA_ACOMPANHAMENTO = "/acompanhamento";

const rotaEditar = (id: string) =>
    `${ROTA_ACOMPANHAMENTO}?editar=${encodeURIComponent(id)}`;
const ROTA_TV = "/quadro-acompanhamento?tv=1"; // >>> TROCAR AO SUBIR (endereço da rota da TV)
const LOGO_PAI_URL = ""; // >>> TROCAR AO SUBIR (caminho do logo do PAI, ex.: "/logo-pai.png"). Vazio = não mostra o logo na TV.

const COROAS_TV_LOCAL =
    `${API_DIRETA}/coroas.php?listar=1&grupo=confeccao&page=1&per_page=100`;

const COROAS_TV_REMOTA =
    `${API_DIRETA}/coroas.php?listar=1&grupo=confeccao&page=1&per_page=100`;

/* =========================
   Helpers comuns
   ========================= */
function decodeHtmlEntitiesOnce(input: string): string {
    if (!input) return input;

    if (typeof window !== "undefined" && typeof document !== "undefined") {
        const ta = document.createElement("textarea");
        ta.innerHTML = input;
        return ta.value;
    }

    return input
        .replace(/&quot;/g, '"')
        .replace(/&apos;/g, "'")
        .replace(/&#039;/g, "'")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&amp;/g, "&")
        .replace(/&#x([0-9a-fA-F]+);/g, (_, hex) =>
            String.fromCharCode(parseInt(hex, 16))
        )
        .replace(/&#(\d+);/g, (_, num) =>
            String.fromCharCode(parseInt(num, 10))
        );
}

function decodeHtmlEntitiesDeep(input: string, maxPasses = 3): string {
    let s = String(input ?? "");
    for (let i = 0; i < maxPasses; i++) {
        const next = decodeHtmlEntitiesOnce(s);
        if (next === s) break;
        s = next;
    }
    return s;
}

const sanitize = (t?: any) => decodeHtmlEntitiesDeep(String(t ?? ""));

const shown = (v?: any, fallback = "a definir") => {
    const s = decodeHtmlEntitiesDeep(String(v ?? "")).trim();
    return s ? s : fallback;
};

/* =========================
   Materiais (normalização para exibir no modal)
   ========================= */

type MatLookupInfo = {
    catNome: string;
    catOrdem: number;
    itemOrdem: number;
};

type MatLine = { text: string; itemKey?: string };

function qtyPrefixFromAny(qtdRaw: any): string {
    const qtdStr = decodeHtmlEntitiesDeep(String(qtdRaw ?? "")).trim();
    if (!qtdStr) return "1x";

    const normalized = qtdStr.replace(",", ".").trim();
    const n = Number(normalized);

    if (Number.isFinite(n) && n > 0) {
        const isInt = Math.abs(n - Math.round(n)) < 1e-9;
        const val = isInt ? String(Math.round(n)) : normalized;
        return `${val}x`;
    }

    const m = normalized.match(/^(\d+(?:\.\d+)?)/);
    if (m?.[1]) return `${m[1]}x`;

    return `${normalized}x`;
}

function normalizeMatTextToQtyPrefix(text: string): string {
    const s = decodeHtmlEntitiesDeep(String(text ?? ""))
        .replace(/\s+/g, " ")
        .trim();
    if (!s) return s;

    let m = s.match(/^(\d+(?:[.,]\d+)?)\s*[xX]\s*(.+)$/);
    if (m) {
        const qtd = m[1].replace(",", ".");
        const nome = m[2].trim();
        return `${qtd}x ${nome}`;
    }

    m = s.match(/^(.+?)\s*\(\s*(\d+(?:[.,]\d+)?)\s*\)\s*$/);
    if (m) {
        const nome = m[1].trim();
        const qtd = m[2].replace(",", ".");
        return `${qtd}x ${nome}`;
    }

    return `1x ${s}`;
}

function isRealMaterialForClipboard(item: string): boolean {
    const s = decodeHtmlEntitiesDeep(String(item ?? "")).trim();
    if (!s) return false;

    const low = s.toLowerCase().replace(/\s+/g, " ").trim();

    if (low === "sim" || low === "não" || low === "nao") return false;
    if (low === "1x sim" || low === "1x não" || low === "1x nao") return false;
    if (low === "item" || low === "1x item") return false;
    if (low.includes("a definir")) return false;

    return true;
}

function isJsonNoiseLine(raw: any): boolean {
    const s = decodeHtmlEntitiesDeep(String(raw ?? "")).trim();
    if (!s) return false;

    const low = s.toLowerCase().replace(/\s+/g, " ").trim();
    return /^(\d+(?:[.,]\d+)?\s*[xX]\s*)?json\s*:/.test(low);
}

function normalizeMateriaisFromRegistro(registro: Registro): string[] {
    const out: string[] = [];
    const seen = new Set<string>();

    const pushItem = (raw: any) => {
        const s0 = String(raw ?? "");
        const s = decodeHtmlEntitiesDeep(s0).trim();
        if (!s) return;

        const low = s.toLowerCase().trim();

        if (isJsonNoiseLine(s)) return;

        if (low.startsWith("{") || low.startsWith("[")) return;
        if (looksLikeMateriaisJson(s)) return;

        if (["selecionar...", "selecione...", "a definir"].includes(low)) return;

        const withQtd = normalizeMatTextToQtyPrefix(s);
        if (!withQtd) return;

        if (isJsonNoiseLine(withQtd)) return;

        if (seen.has(withQtd)) return;
        seen.add(withQtd);
        out.push(withQtd);
    };

    const pushNomeQtd = (nomeRaw: any, qtdRaw?: any) => {
        const nome = decodeHtmlEntitiesDeep(String(nomeRaw ?? "")).trim();
        if (!nome) return;

        const prefix = qtyPrefixFromAny(qtdRaw);
        pushItem(`${prefix} ${nome}`);
    };

    const extractFromStructured = (raw: unknown): boolean => {
        const items: { nome: any; qtd?: any }[] = [];

        const walk = (node: any) => {
            if (node == null) return;

            if (Array.isArray(node)) {
                node.forEach(walk);
                return;
            }

            if (isPlainObject(node)) {
                const maybeNome =
                    (node as any).nome ??
                    (node as any).name ??
                    (node as any).descricao ??
                    (node as any).descrição ??
                    (node as any).material;

                const hasChecked = Object.prototype.hasOwnProperty.call(node, "checked");
                const checkedVal = (node as any).checked;
                const qtdVal =
                    (node as any).qtd ??
                    (node as any).quantidade ??
                    (node as any).qtd_item;

                if (maybeNome != null && (hasChecked ? asBool(checkedVal) : true)) {
                    items.push({ nome: maybeNome, qtd: qtdVal });
                }

                const containerKeys = [
                    "itens",
                    "items",
                    "materiais",
                    "materiais_json",
                    "material_json",
                    "data",
                ];
                for (const k of containerKeys) {
                    if ((node as any)[k] != null) walk((node as any)[k]);
                }

                for (const [, v] of Object.entries(node)) {
                    if (v == null) continue;
                    if (typeof v === "object") {
                        walk(v);
                    }
                }
            }
        };

        walk(raw);

        if (items.length === 0) return false;

        for (const it of items) pushNomeQtd(it.nome, it.qtd);
        return true;
    };

    const addFromBooleanMap = (obj: Record<string, unknown>) => {
        for (const [k, v] of Object.entries(obj)) {
            if (asBool(v)) {
                const nome = overrideCampoNome(k, titleCaseFromSnake(k));
                pushItem(`1x ${nome}`);
            }
        }
    };

    const addFromMixedObject = (obj: Record<string, unknown>) => {
        for (const [key, value] of Object.entries(obj)) {
            const m = key.match(/^materiais_(.+?)_qtd$/i);
            if (!m) continue;
            const valStr = decodeHtmlEntitiesDeep(String(value ?? "")).trim();
            if (!valStr) continue;

            const n = Number(valStr.replace(",", "."));
            if (!Number.isNaN(n) && n <= 0) continue;

            const base = m[1];
            const nome = overrideCampoNome(base, titleCaseFromSnake(base));
            pushItem(`${qtyPrefixFromAny(valStr)} ${nome}`);
        }

        for (const [key, value] of Object.entries(obj)) {
            if (/^materiais_.+?_qtd$/i.test(key)) continue;

            const m = key.match(/^materiais_(.+)$/i);
            if (!m) continue;

            const base = m[1];
            const nome = overrideCampoNome(base, titleCaseFromSnake(base));

            if (asBool(value)) {
                pushItem(`1x ${nome}`);
                continue;
            }

            const valStr = decodeHtmlEntitiesDeep(String(value ?? "")).trim();
            if (!valStr) continue;

            const n = Number(valStr.replace(",", "."));
            if (!Number.isNaN(n)) {
                if (n > 0) pushItem(`${qtyPrefixFromAny(valStr)} ${nome}`);
                continue;
            }

            pushItem(`1x ${nome}: ${valStr}`);
        }

        for (const [k, v] of Object.entries(obj)) {
            if (k === "materiais_json" || k === "material_json") continue;
            if (/^materiais_.+/i.test(k)) continue;
            if (v == null) continue;
            if (typeof v === "object") continue;

            const valStr = decodeHtmlEntitiesDeep(String(v)).trim();
            if (!valStr) continue;

            const nome = overrideCampoNome(k, titleCaseFromSnake(k));
            const maybeNum = Number(valStr.replace(",", "."));
            if (!Number.isNaN(maybeNum)) {
                if (maybeNum > 0) pushItem(`${qtyPrefixFromAny(valStr)} ${nome}`);
            } else if (asBool(valStr)) {
                pushItem(`1x ${nome}`);
            } else {
                pushItem(`1x ${nome}: ${valStr}`);
            }
        }
    };

    const addFromUnknown = ((raw: unknown) => {
        if (raw == null || raw === "") return;

        if (Array.isArray(raw)) {
            if (extractFromStructured(raw)) return;
            for (const it of raw) pushItem(it);
            return;
        }

        if (isPlainObject(raw)) {
            if (extractFromStructured(raw)) return;

            const obj = raw as Record<string, unknown>;
            if (isLikelyBooleanMap(obj)) addFromBooleanMap(obj);
            else addFromMixedObject(obj);
            return;
        }

        if (typeof raw === "string") {
            let s = decodeHtmlEntitiesDeep(raw).trim();
            if (!s) return;

            const original = s;
            s = s.replace(/^\s*json\s*:\s*/i, "").trim();

            const parsed = tryParseJsonFromStringMaybeEmbedded(s);
            if (parsed != null) {
                if (extractFromStructured(parsed)) return;
                return;
            }

            const extracted = extractMateriaisByRegex(s);
            if (extracted.length) {
                extracted.forEach((it) => pushNomeQtd(it.nome, it.qtd));
                return;
            }

            if (/^\s*json\s*:/i.test(original) || looksLikeMateriaisJson(s)) return;

            if (s.includes("\n")) {
                s.split("\n")
                    .map((x) => x.trim())
                    .filter(Boolean)
                    .filter((line) => {
                        const low = line.toLowerCase().trim();
                        if (low.startsWith("json:")) return false;
                        if (low.startsWith("{") || low.startsWith("[")) return false;
                        if (looksLikeMateriaisJson(line)) return false;
                        return true;
                    })
                    .forEach(pushItem);
                return;
            }
            if (s.includes(";")) {
                s.split(";")
                    .map((x) => x.trim())
                    .filter(Boolean)
                    .forEach(pushItem);
                return;
            }
            if (s.includes(",")) {
                s.split(",")
                    .map((x) => x.trim())
                    .filter(Boolean)
                    .forEach(pushItem);
                return;
            }

            pushItem(s);
            return;
        }

        if (typeof raw === "number") return;
        if (typeof raw === "boolean") return;

        pushItem(String(raw));
    }) as (raw: unknown) => void;

    addFromUnknown((registro as any).materiais_json);
    addFromUnknown((registro as any).material_json);
    addFromUnknown((registro as any).materiais);
    addFromUnknown((registro as any).material);

    if (isPlainObject(registro)) {
        const obj = registro as Record<string, unknown>;
        const picked: Record<string, unknown> = {};
        let hasAny = false;
        for (const k of Object.keys(obj)) {
            if (/^materiais_.+/i.test(k)) {
                picked[k] = obj[k];
                hasAny = true;
            }
        }
        if (hasAny) {
            if (isLikelyBooleanMap(picked)) addFromBooleanMap(picked);
            else addFromMixedObject(picked);
        }
    }

    return out;
}

function extractMateriaisStructuredWithKey(registro: Registro): MatLine[] {
    const out: MatLine[] = [];
    const seen = new Set<string>();

    const pushItem = (raw: any, itemKey?: string) => {
        const s0 = String(raw ?? "");
        const s = decodeHtmlEntitiesDeep(s0).trim();
        if (!s) return;

        const low = s.toLowerCase().trim();

        if (isJsonNoiseLine(s)) return;

        if (low.startsWith("{") || low.startsWith("[")) return;
        if (looksLikeMateriaisJson(s)) return;
        if (["selecionar...", "selecione...", "a definir"].includes(low)) return;

        const withQtd = normalizeMatTextToQtyPrefix(s);
        if (!withQtd) return;

        if (isJsonNoiseLine(withQtd)) return;

        if (seen.has(withQtd)) return;
        seen.add(withQtd);
        out.push({ text: withQtd, itemKey });
    };

    const pushNomeQtd = (nomeRaw: any, qtdRaw?: any, itemKey?: string) => {
        const nome = decodeHtmlEntitiesDeep(String(nomeRaw ?? "")).trim();
        if (!nome) return;

        const prefix = qtyPrefixFromAny(qtdRaw);
        pushItem(`${prefix} ${nome}`, itemKey);
    };

    const normalizeItemKeyFromAny = (v: any): string | undefined => {
        if (v == null) return undefined;
        const n = Number(v);
        if (Number.isFinite(n) && n > 0) return `item${n}`;
        const s = String(v).trim();
        if (/^item\d+$/i.test(s)) return s;
        return undefined;
    };

    const walk = (node: any, parentKey?: string) => {
        if (node == null) return;

        if (Array.isArray(node)) {
            node.forEach((x) => walk(x, parentKey));
            return;
        }

        if (isPlainObject(node)) {
            const maybeNome =
                (node as any).nome ??
                (node as any).name ??
                (node as any).descricao ??
                (node as any).descrição ??
                (node as any).material;

            const hasChecked = Object.prototype.hasOwnProperty.call(node, "checked");
            const checkedVal = (node as any).checked;
            const qtdVal =
                (node as any).qtd ??
                (node as any).quantidade ??
                (node as any).qtd_item;

            const inferredKey =
                normalizeItemKeyFromAny((node as any).item_id) ??
                normalizeItemKeyFromAny((node as any).itemId) ??
                normalizeItemKeyFromAny((node as any).item_key) ??
                normalizeItemKeyFromAny((node as any).id) ??
                (typeof parentKey === "string" && /^item\d+$/i.test(parentKey)
                    ? parentKey
                    : undefined);

            if (maybeNome != null && (hasChecked ? asBool(checkedVal) : true)) {
                pushNomeQtd(maybeNome, qtdVal, inferredKey);
            }

            const containerKeys = [
                "itens",
                "items",
                "materiais",
                "materiais_json",
                "material_json",
                "data",
            ];
            for (const k of containerKeys) {
                if ((node as any)[k] != null) walk((node as any)[k], k);
            }

            for (const [k, v] of Object.entries(node)) {
                if (v == null) continue;
                if (typeof v === "object") walk(v, k);
            }
        }
    };

    const add = (raw: unknown) => {
        if (raw == null || raw === "") return;

        if (typeof raw === "string") {
            const s = decodeHtmlEntitiesDeep(raw).trim();
            if (!s) return;
            const parsed = tryParseJsonFromStringMaybeEmbedded(s);
            if (parsed != null) walk(parsed, undefined);
            return;
        }

        walk(raw, undefined);
    };

    add((registro as any).materiais_json);
    add((registro as any).material_json);

    return out;
}

function MateriaisValue({
    registro,
    lookup = {},
    fallback = "a definir",
}: {
    registro: Registro;
    lookup?: Record<string, MatLookupInfo>;
    fallback?: string;
}) {
    const structured = extractMateriaisStructuredWithKey(registro);
    const flat = normalizeMateriaisFromRegistro(registro);

    const lines: MatLine[] = (() => {
        if (structured.length === 0) return flat.map((t) => ({ text: t }));
        const have = new Set(structured.map((x) => x.text));
        const extras = flat.filter((t) => !have.has(t)).map((t) => ({ text: t }));
        return [...structured, ...extras];
    })();

    const filteredLines = (lines ?? []).filter(
        (l) => isRealMaterialForClipboard(l.text) && !isJsonNoiseLine(l.text)
    );

    if (!filteredLines || filteredLines.length === 0) return <span>{fallback}</span>;

    const groups = new Map<
        string,
        { catNome: string; catOrdem: number; items: { text: string; itemOrdem: number }[] }
    >();

    for (const it of filteredLines) {
        const info = it.itemKey ? lookup[it.itemKey] : undefined;

        const catNome = (info?.catNome ?? "(Sem categoria)").trim() || "(Sem categoria)";
        const catOrdem = info?.catOrdem ?? 9999;
        const itemOrdem = info?.itemOrdem ?? 9999;

        if (!groups.has(catNome)) groups.set(catNome, { catNome, catOrdem, items: [] });
        groups.get(catNome)!.items.push({ text: it.text, itemOrdem });
    }

    const sortedCats = [...groups.values()].sort(
        (a, b) => a.catOrdem - b.catOrdem || a.catNome.localeCompare(b.catNome)
    );

    return (
        <div className="space-y-3">
            {sortedCats.map((g) => {
                const itemsSorted = [...g.items].sort(
                    (a, b) => a.itemOrdem - b.itemOrdem || a.text.localeCompare(b.text)
                );

                return (
                    <div key={g.catNome}>
                        <div className="font-bold">{g.catNome}</div>
                        <ul className="list-disc pl-4 space-y-0.5">
                            {itemsSorted.map((x, idx) => (
                                <li key={idx} className="break-words [overflow-wrap:anywhere]">
                                    {x.text}
                                </li>
                            ))}
                        </ul>
                    </div>
                );
            })}
        </div>
    );
}

/* =========================
   Local do Velório: rota (Google Maps)
   ========================= */
function ensureHttpsUrl(raw: string): string {
    const s = String(raw ?? "").trim();
    if (!s) return s;

    if (/^https?:\/\//i.test(s)) {
        return s.replace(/^http:\/\//i, "https://");
    }

    if (/^(www\.)/i.test(s)) return `https://${s}`;
    if (
        /^(google\.com|maps\.google\.com|www\.google\.com|maps\.app\.goo\.gl|goo\.gl\/maps)/i.test(s)
    )
        return `https://${s}`;

    return s;
}

function isGoogleMapsRota(raw?: string): boolean {
    const s = String(raw ?? "").trim().toLowerCase();
    if (!s) return false;

    const noProto = s.replace(/^https?:\/\//, "");
    if (noProto.includes("google.com/maps/dir")) return true;
    if (noProto.includes("maps.google.com/maps/dir")) return true;
    if (noProto.startsWith("maps.app.goo.gl/")) return true;
    if (noProto.startsWith("goo.gl/maps/")) return true;

    return false;
}

function LocalVelorioValue({ value, fallback = "a definir" }: { value?: string; fallback?: string }) {
    const raw = decodeHtmlEntitiesDeep(String(value ?? "")).trim();
    if (!raw) return <span>{fallback}</span>;

    if (isGoogleMapsRota(raw)) {
        const url = ensureHttpsUrl(raw);
        return (
            <a
                href={url}
                target="_blank"
                rel="noreferrer"
                className="font-semibold text-blue-600 hover:underline underline-offset-2"
                title="Abrir rota no Google Maps"
            >
                Abrir Rota
            </a>
        );
    }

    return <span>{shown(raw, fallback)}</span>;
}

/**
 * Local do velório no Quadro (15/10/2026).
 * - Memorial: "Memorial Senhor do Bonfim · Sala 02 - Encontro" (sala ainda vazia: "sala a definir").
 * - Outro local: tipo escolhido no registro (local_cerimonia) + endereço (local_velorio).
 * - Registro antigo sem local_cerimonia: Memorial se tiver sala ou endereço "Memorial…" (igual ao Editar registro).
 */
const NOMES_SALA_VELORIO: Record<string, string> = {
    "sala 01": "Sala 01 - Presença",
    "sala 02": "Sala 02 - Encontro",
    "sala 03": "Sala 03 - Refúgio",
};

function nomeSalaVelorio(sala?: string): string {
    const raw = decodeHtmlEntitiesDeep(String(sala ?? "")).trim();
    if (!raw) return "";
    const m = raw.match(/(\d+)/);
    const chave = m ? `sala ${m[1].padStart(2, "0")}` : raw.toLowerCase();
    return NOMES_SALA_VELORIO[chave] || raw;
}

function LocalVelorioQuadro({ r, fallback = "a definir" }: { r?: Registro | null; fallback?: string }) {
    const tipo = decodeHtmlEntitiesDeep(String((r as any)?.local_cerimonia ?? "")).trim();
    const endereco = decodeHtmlEntitiesDeep(String(r?.local_velorio ?? "")).trim();
    const sala = nomeSalaVelorio((r as any)?.sala_velorio);
    const memorial = tipo ? /memorial/i.test(tipo) : !!sala || /memorial/i.test(endereco);

    if (memorial) {
        return <span>Memorial Senhor do Bonfim · {sala || "sala a definir"}</span>;
    }

    const temTipo = !!tipo && !/^outro$/i.test(tipo);
    if (!temTipo) return <LocalVelorioValue value={endereco} fallback={fallback} />;

    return (
        <span>
            {tipo} · <LocalVelorioValue value={endereco} fallback="endereço a definir" />
        </span>
    );
}

/* Datas/horas → “a definir” para zeros e vazios */
const formatDateBr = (d?: string) =>
    !d ? "" : d.split("-").length === 3 ? `${d.split("-")[2]}/${d.split("-")[1]}/${d.split("-")[0]}` : d;

function dateOr(d?: string) {
    const raw = (d ?? "").trim();
    if (!raw || raw === "0000-00-00" || raw === "00/00/0000") return "a definir";
    const f = formatDateBr(raw);
    if (!f || f === "00/00/0000") return "a definir";
    return f;
}

/** ✅ mostra só dia/mês (17/12) para a coluna "Sepultamento" */
function dateDayMonthOr(d?: string) {
    const raw = (d ?? "").trim();
    if (!raw || raw === "0000-00-00" || raw === "00/00/0000") return "a definir";

    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
        const [, mm, dd] = raw.split("-");
        return `${dd}/${mm}`;
    }

    if (/^\d{2}\/\d{2}\/\d{4}$/.test(raw)) {
        const [dd, mm] = raw.split("/");
        return `${dd}/${mm}`;
    }

    const m2 = raw.match(/(\d{2})\/(\d{2})/);
    if (m2) return `${m2[1]}/${m2[2]}`;

    const m = raw.match(/(\d{4})-(\d{2})-(\d{2})/);
    if (m) return `${m[3]}/${m[2]}`;

    return raw;
}

function timeOr(t?: string) {
    const raw = (t ?? "").trim();
    if (!raw) return "a definir";
    const hhmm = raw.slice(0, 5);
    if (hhmm === "00:00") return "a definir";
    return hhmm;
}

/* ----------- Normalização de status (texto → faseNN) ----------- */
const ROTULO_PARA_FASE: Record<string, string> = {
    removendo: "fase01",
    "aguardando procedimento": "fase02",
    preparando: "fase03",
    "aguardando ornamentacao": "fase04",
    ornamentando: "fase05",
    "fim da ornamentacao": "fase06",
    "aguardando corpo pronto": "fase06",
    "corpo pronto": "fase12",
    transportando: "fase07",
    "transportando p/ velorio": "fase07",
    "transportando p/ velório": "fase07",
    velando: "fase08",
    sepultando: "fase09",
    "transportando p/ sepultamento": "fase09",
    "sepultamento concluido": "fase10",
    "sepultamento concluído": "fase10",
    "material recolhido": "fase11",
    concluido: "fase11",
    concluído: "fase11",
};
function normalizeKey(s: string) {
    return s
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();
}
function normalizarStatus(status?: string): string | undefined {
    if (!status) return undefined;
    const s = String(status).trim();
    if (s.toLowerCase().startsWith("fase")) {
        const digits = s.replace(/[^0-9]/g, "");
        if (!digits) return s.toLowerCase();
        return `fase${digits.padStart(2, "0")}`.toLowerCase();
    }
    const mapeado = ROTULO_PARA_FASE[normalizeKey(s)];
    return (mapeado || s).toLowerCase();
}

/* ---------------- Status badge ---------------- */
function capStatus(s?: string) {
    switch (normalizarStatus(s)) {
        case "fase01":
            return "Removendo";
        case "fase02":
            return "Aguardando Procedimento";
        case "fase03":
            return "Preparando";
        case "fase04":
            return "Aguardando Ornamentação";
        case "fase05":
            return "Ornamentando";
        case "fase06":
            return "Aguardando Corpo Pronto";
        case "fase12":
            return "Corpo Pronto";
        case "fase07":
            return "Transportando P/ Velório";
        case "fase08":
            return "Velando";
        case "fase09":
            return "Transportando P/ Sepultamento";
        case "fase10":
            return "Sepultamento Concluído";
        case "fase11":
            return "Material Recolhido";
        default:
            return s ? s.charAt(0).toUpperCase() + s.slice(1) : "";
    }
}

function badgeClass(s?: string) {
    const x = (normalizarStatus(s) || "").toLowerCase();
    if (x === "fase01") return "bg-amber-600";
    if (x === "fase02") return "bg-zinc-600";
    if (x === "fase03") return "bg-blue-600";
    if (x === "fase04") return "bg-fuchsia-600";
    if (x === "fase05") return "bg-rose-600";
    if (x === "fase06") return "bg-fuchsia-700";
    if (x === "fase12") return "bg-emerald-600";
    if (x === "fase07") return "bg-cyan-600";
    if (x === "fase08") return "bg-violet-600";
    if (x === "fase09") return "bg-orange-600";
    if (x === "fase10") return "bg-green-700";
    if (x === "fase11") return "bg-slate-700";
    return "bg-slate-500";
}

/* Identificação operacional do convênio: apresenta o plano real (LIGHT/FLEX/PLUS/MAX)
 * em lugar do rótulo genérico "Associado". Não altera o valor salvo no banco. */
type ConvenioKind = "Particular" | "Prefeitura" | "Associado" | "a definir";
function planoDoConvenio(s?: string): string | null {
    const v = String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().trim();
    if (!v || /PARTICULAR|PREFEITURA/.test(v)) return null;
    if (/\b(FLEX|PLUS|MAX)\b/.test(v)) return `Plano ${v.match(/\b(FLEX|PLUS|MAX)\b/)![1]}`;
    if (/\bLIGHT\b/.test(v)) return "Plano LIGHT";
    return null;
}
function normalizeConvenio(s?: string): ConvenioKind {
    const v = (s || "").toLowerCase();
    if (!v) return "a definir";
    if (v.includes("prefeitura")) return "Prefeitura";
    if (v.includes("particular")) return "Particular";
    if (planoDoConvenio(s) || v.includes("associad")) return "Associado";
    return "a definir";
}
/** Rótulo fiel aos dados do atendimento: nunca inventa um plano ausente no retorno. */
function nomePlanoRegistro(registro: Registro): string | null {
    const campos = [registro.convenio, registro.plano, registro.plano_nome,
        registro.cobertura, registro.convenio_os, registro.convenio_nome];
    for (const campo of campos) {
        if (typeof campo !== "string") continue;
        const plano = planoDoConvenio(campo);
        if (plano) return plano;
    }
    // Planos assistenciais antigos que não trazem LIGHT no nome.
    for (const campo of campos) {
        if (typeof campo !== "string") continue;
        const v = campo.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().trim();
        if (/\b(BASICO|BRONZE|MASTER|OURO|PRATA|PADRAO OURO|PAX LIGHT|PLANO LEM)\b/.test(v)) return "Plano LIGHT";
    }
    return null;
}

function rotuloConvenioRegistro(registro: Registro): string {
    const kind = normalizeConvenio(registro.convenio);
    if (kind === "Particular" || kind === "Prefeitura") return kind;
    return nomePlanoRegistro(registro) || kind;
}

function ConvenioBadge({convenio, registro, size = "sm"}: {convenio?: string; registro?: Registro; size?: "xs" | "sm"}) {
    const kind = normalizeConvenio(convenio);
    const cor = kind === "Prefeitura" ? "qa-tag-conv-pref" : kind === "Particular" ? "qa-tag-conv-part" : kind === "Associado" ? "qa-tag-conv-assoc" : "qa-tag-conv-adef";
    const texto = registro ? rotuloConvenioRegistro(registro) : (kind === "Associado" ? planoDoConvenio(convenio) || "Associado" : kind);
    return <span className={`qa-convenio-badge qa-tag ${size === "xs" ? "qa-tag-xs" : ""} ${cor}`} title={String(convenio || "Convênio")}>{texto}</span>;
}

/* ---------------- Etapas (bolinhas) ---------------- */
const STAGE_DOT_FILLED = [
    "bg-[#00AEEC] border-[#00AEEC]",
    "bg-[#00AEEC] border-[#00AEEC]",
    "bg-[#00AEEC] border-[#00AEEC]",
    "bg-[#00AEEC] border-[#00AEEC]",
];
const STAGE_DOT_EMPTY = "bg-transparent border-slate-300 dark:border-slate-600";

const LABELS: Record<string, string> = {
    falecido: "Falecido",
    contato: "Contato",
    religiao: "Religião",
    convenio: "Convênio",
    urna: "Urna",
    roupa: "Roupa",
    assistencia: "Assistência",
    tanato: "Tanatopraxia",
    invol: "Invol",
    local_velorio: "Local do Velório",
    data_inicio_velorio: "Data Início Velório",
    data_fim_velorio: "Data Fim Velório",
    hora_inicio_velorio: "Início Velório",
    hora_fim_velorio: "Fim Velório",
    local: "Local (Geral)",
    local_sepultamento: "Local Sepultamento",
};

const isFilled = (registro: Registro, key?: string) => {
    if (!key) return false;
    const v = registro[key];
    if (v == null) return false;
    const s = decodeHtmlEntitiesDeep(String(v)).trim().toLowerCase();
    if (!s) return false;
    if (["selecionar...", "selecione...", "a definir"].includes(s)) return false;
    if (key.startsWith("data") && (s === "0000-00-00" || s === "00/00/0000")) return false;
    if (key.startsWith("hora") && s.startsWith("00:00")) return false;
    return true;
};

function etapasPreenchidas(registro: Registro) {
    const d = [false, false, false, false];

    d[0] = ["falecido", "contato", "religiao", "convenio"].every((k) => isFilled(registro, k));
    d[1] = ["urna", "roupa", "assistencia", "tanato"].every((k) => isFilled(registro, k));
    d[2] =
        isFilled(registro, "local_velorio") &&
        isFilled(registro, "data_inicio_velorio") &&
        (isFilled(registro, "local_sepultamento") || isFilled(registro, "local"));
    d[3] =
        isFilled(registro, "hora_inicio_velorio") ||
        (isFilled(registro, "data_fim_velorio") && isFilled(registro, "hora_fim_velorio"));

    return d;
}

/* =========================
   Texto para copiar
   ========================= */
function buildClipboardText(r: Registro, lookup: Record<string, MatLookupInfo> = {}) {
    const v = (k: string) => decodeHtmlEntitiesDeep(String(r?.[k] ?? "")).trim();
    const atend = (v("convenio") || "A DEFINIR").toUpperCase();

    const ornTipoRaw = v("ornamentacao_tipo") || v("ornamentacao");
    const ornTipo = ornTipoRaw
        ? (ornTipoRaw.charAt(0).toUpperCase() + ornTipoRaw.slice(1)).replace(/\s+/g, " ")
        : "A DEFINIR";

    const involRaw = r?.invol;
    const involStr = decodeHtmlEntitiesDeep(String(involRaw ?? "")).trim().toLowerCase();
    const involYN = ["1", "true", "t", "sim", "s", "yes", "y"].includes(involStr) ? "SIM" : "NÃO";

    const localVelRaw = v("local_velorio") || "A DEFINIR";
    const localVelClipboard = isGoogleMapsRota(localVelRaw) ? ensureHttpsUrl(localVelRaw) : localVelRaw;

    const structured = extractMateriaisStructuredWithKey(r);
    const flat = normalizeMateriaisFromRegistro(r);

    const linesAll: MatLine[] = (() => {
        if (structured.length === 0) return flat.map((t) => ({ text: t }));
        const have = new Set(structured.map((x) => x.text));
        const extras = flat.filter((t) => !have.has(t)).map((t) => ({ text: t }));
        return [...structured, ...extras];
    })();

    const filtered = linesAll.filter((l) => isRealMaterialForClipboard(l.text) && !isJsonNoiseLine(l.text));

    const groups = new Map<string, { ordem: number; items: { text: string; itemOrdem: number }[] }>();

    for (const it of filtered) {
        const info = it.itemKey ? lookup[it.itemKey] : undefined;
        const catNome = (info?.catNome ?? "Materiais").trim() || "Materiais";
        const catOrdem = info?.catOrdem ?? 9999;
        const itemOrdem = info?.itemOrdem ?? 9999;

        if (!groups.has(catNome)) groups.set(catNome, { ordem: catOrdem, items: [] });
        groups.get(catNome)!.items.push({ text: it.text, itemOrdem });
    }

    const sortedCats = [...groups.entries()].sort(
        (a, b) => a[1].ordem - b[1].ordem || a[0].localeCompare(b[0])
    );

    const materiaisClipboardLines =
        sortedCats.length === 0
            ? []
            : [
                `*Materiais:*`,
                ...sortedCats.map(([cat, g]) => {
                    const items = [...g.items]
                        .sort((a, b) => a.itemOrdem - b.itemOrdem || a.text.localeCompare(b.text))
                        .map((x) => x.text);
                    return `*${cat}:* ${items.join(", ")}`;
                }),
            ];

    const lines = [
        `*ATENDIMENTO ${atend}*`,
        `*Falecido:* ${v("falecido") || "A DEFINIR"}`,
        `*Contato:* ${v("contato") || "A DEFINIR"}`,
        `*Religião:* ${v("religiao") || "A DEFINIR"}`,
        `*Urna:* ${v("urna") || "A DEFINIR"}`,
        `*Roupa:* ${v("roupa") || "A DEFINIR"}`,
        `*Assistência:* ${v("assistencia") || "A DEFINIR"}`,
        `*Tanato:* ${v("tanato") || "A DEFINIR"}`,
        `*Invol:* ${involYN}`,
        `*Ornamentação:* ${ornTipo || "A DEFINIR"}`,
        ...materiaisClipboardLines,
        `*Local do Velório:* ${localVelClipboard || "A DEFINIR"}`,
        `*Agente:* ${v("agente") || "A DEFINIR"}`,
        `*Observação:* ${v("observacao") || "A DEFINIR"}`,
    ];

    return lines.join("\n\n");
}

/* =========================
   Coroas — helpers visuais
   ========================= */
function normalizarTextoCoroa(v?: any): string {
    return decodeHtmlEntitiesDeep(String(v ?? ""))
        .trim()
        .toLocaleLowerCase("pt-BR")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/\s+/g, " ");
}

function coroaStatusLabel(v?: any): string {
    const s = normalizarTextoCoroa(v);
    if (s === "novo") return "Novo Pedido";
    if (s === "coroa") return "Confeccionando Coroa";
    if (s === "faixa") return "Confeccionando Faixa";
    if (s === "finalizada") return "Coroa Finalizada";
    if (s === "entregue") return "Entregue";
    return decodeHtmlEntitiesDeep(String(v ?? "")).trim() || "Em Confecção";
}

function coroaStatusClass(v?: any): string {
    const s = normalizarTextoCoroa(v);
    if (s === "novo") return "border-slate-600/70 bg-slate-700/65 text-slate-100";
    if (s === "coroa") return "border-sky-500/35 bg-sky-500/15 text-sky-200";
    if (s === "faixa") return "border-violet-500/35 bg-violet-500/15 text-violet-200";
    if (s === "finalizada") return "border-emerald-500/35 bg-emerald-500/15 text-emerald-200";
    if (s === "entregue") return "border-green-500/35 bg-green-500/15 text-green-200";
    return "border-slate-600/70 bg-slate-800/60 text-slate-200";
}

function coroaStatusIconType(v?: any): CoroaTvIconKey {
    const s = normalizarTextoCoroa(v);
    if (s === "coroa") return "flower";
    if (s === "faixa") return "ribbon";
    if (s === "finalizada" || s === "entregue") return "check";
    return "clipboard";
}

function coroaOrigemLabel(v?: any): string {
    const s = normalizarTextoCoroa(v).replace(/\s+/g, "_");

    if (s === "ordem_de_servico" || s === "ordem_servico") return "Ordem de Serviço";
    if (
        s === "venda_direta" ||
        s === "venda_direta_colaborador" ||
        s === "venda_direta_escritorio" ||
        s === "venda_direta_memorial"
    ) {
        return "Venda Direta";
    }

    if (s === "online" || s === "loja-online" || s === "loja_online" || s === "lojaonline") {
        return "Pedido Online";
    }

    return decodeHtmlEntitiesDeep(String(v ?? "")).trim() || "a definir";
}

function coroaQuantidade(order?: CoroaTvPedido | null): number {
    if (!order) return 0;

    const q = Number(order.quantidade_coroas ?? 0);
    if (Number.isFinite(q) && q > 0) return Math.floor(q);

    if (Array.isArray(order.itens) && order.itens.length > 0) {
        return order.itens.length;
    }

    return 1;
}

function coroaModelos(order?: CoroaTvPedido | null): string {
    if (!order) return "a definir";

    const itens = Array.isArray(order.itens) ? order.itens : [];
    const modelos = itens
        .map((it) => decodeHtmlEntitiesDeep(String(it?.modelo_coroa ?? "")).trim())
        .filter(Boolean);

    if (modelos.length === 1) return modelos[0];
    if (modelos.length > 1) return `${modelos[0]} +${modelos.length - 1}`;

    const principal = decodeHtmlEntitiesDeep(String(order.modelo_coroa ?? "")).trim();
    return principal || "a definir";
}

function coroaPagamentoLabel(order?: CoroaTvPedido | null): string {
    if (!order) return "Aguardando";

    if (String(order.comprovante_url ?? "").trim()) return "Pago";

    const status = normalizarTextoCoroa(order.status_pagamento);
    if (status === "pago") return "Pago";

    return "Aguardando";
}

function coroaPagamentoClass(order?: CoroaTvPedido | null): string {
    return coroaPagamentoLabel(order) === "Pago"
        ? "border-emerald-500/35 bg-emerald-500/15 text-emerald-200"
        : "border-amber-500/35 bg-amber-500/15 text-amber-200";
}

function coroaCriadoHora(v?: string | null): string {
    const raw = String(v ?? "").trim();
    if (!raw) return "";

    const d = new Date(raw.replace(" ", "T"));
    if (Number.isNaN(d.getTime())) return "";

    return d.toLocaleTimeString("pt-BR", {
        hour: "2-digit",
        minute: "2-digit",
    });
}

/* Data e hora do pedido no formato "dd/mm - hh:mm" (ex.: 02/10 - 14:05). */
function coroaDataHora(v?: string | null): string {
    const raw = String(v ?? "").trim();
    if (!raw) return "";
    const d = new Date(raw.replace(" ", "T"));
    if (Number.isNaN(d.getTime())) return "";
    const p = (n: number) => String(n).padStart(2, "0");
    return `${p(d.getDate())}/${p(d.getMonth() + 1)} - ${p(d.getHours())}:${p(d.getMinutes())}`;
}

/* Foto da coroa = foto do CADASTRO DO PRODUTO.
 *
 * IMPORTANTE:
 * Esta tela usa o MESMO fluxo da página de Coroas:
 *   materiais_gerais.php?init=1
 *
 * Não usar action=coroas_buscar, pois esse endpoint estava retornando HTTP 400.
 * Também não usar /api/php para essa consulta.
 */
function urlFotoProduto(arquivo?: string | null): string {
    const raw = String(arquivo ?? "").trim();

    if (!raw || raw === "null" || raw === "undefined") return "";

    // Já é uma URL pronta.
    if (
        /^data:image\//i.test(raw) ||
        /^blob:/i.test(raw) ||
        /^https?:\/\//i.test(raw)
    ) {
        return raw;
    }

    // Quando o backend devolve uploads/produtos/foto.webp ou /uploads/produtos/foto.webp,
    // não duplica a pasta uploads/produtos.
    const clean = raw.startsWith("/") ? raw : `/${raw}`;

    if (clean.startsWith("/uploads/")) {
        return `${API_DIRETA}${clean}`;
    }

    // Quando vem apenas o nome do arquivo.
    return `${API_DIRETA}/uploads/produtos/${raw.replace(/^\/+/, "")}`;
}

const normNomeProduto = (v: unknown) =>
    String(v ?? "")
        .trim()
        .toLocaleLowerCase("pt-BR")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/\s+/g, " ");

const FOTOS_MODELO_COROA = new Map<string, Promise<string>>();

let PRODUTOS_COROAS_PROMISE: Promise<any[]> | null = null;

/**
 * Carrega uma única vez o catálogo de produtos que contém as fotos.
 * É o mesmo endpoint usado pela tela de Coroas que exibe as imagens corretamente.
 */
async function carregarProdutosCoroas(): Promise<any[]> {
    if (PRODUTOS_COROAS_PROMISE) return PRODUTOS_COROAS_PROMISE;

    PRODUTOS_COROAS_PROMISE = (async () => {
        try {
            const url = `${API_DIRETA}/materiais_gerais.php?init=1&_ts=${Date.now()}`;

            const j = await fetchJsonFast<any>(url, {
                ttlMs: 60_000,
                timeoutMs: 15_000,
                cacheKey: "qa_produtos_coroas_init",
            });

            const produtos: any[] = Array.isArray(j?.produtos)
                ? j.produtos
                : [];

            return produtos;
        } catch (e) {
            PRODUTOS_COROAS_PROMISE = null;
            throw e;
        }
    })();

    return PRODUTOS_COROAS_PROMISE;
}

/**
 * Seleciona a foto principal do cadastro.
 * Primeiro respeita is_principal; depois ordem; por fim usa foto_url.
 */
function arquivoFotoPrincipalProduto(prod: any): string {
    if (!prod) return "";

    const fotos: any[] = Array.isArray(prod?.fotos)
        ? [...prod.fotos]
        : [];

    if (fotos.length > 0) {
        fotos.sort((a, b) => {
            const principalA =
                Number(a?.is_principal || 0) === 1 ? 0 : 1;

            const principalB =
                Number(b?.is_principal || 0) === 1 ? 0 : 1;

            if (principalA !== principalB) {
                return principalA - principalB;
            }

            return Number(a?.ordem || 0) - Number(b?.ordem || 0);
        });

        const primeira = fotos[0];

        return String(
            primeira?.foto_url ||
            primeira?.arquivo ||
            ""
        ).trim();
    }

    return String(prod?.foto_url || "").trim();
}

function buscarFotoModeloCoroa(
    modelo: string,
    tipo: "natural" | "artificial",
): Promise<string> {
    const chave = `${tipo}|${normNomeProduto(modelo)}`;

    const guardada = FOTOS_MODELO_COROA.get(chave);
    if (guardada) return guardada;

    const p = (async () => {
        try {
            const produtos = await carregarProdutosCoroas();

            const alvo = normNomeProduto(modelo);

            const categoriaEsperada =
                tipo === "artificial"
                    ? "coroas artificiais"
                    : "coroas naturais";

            // Primeiro tenta nome + categoria.
            // Caso o backend não devolva categoria_nome, usa somente o nome.
            const prod =
                produtos.find(
                    (r) =>
                        normNomeProduto(r?.nome) === alvo &&
                        normNomeProduto(r?.categoria_nome) === categoriaEsperada,
                ) ??
                produtos.find(
                    (r) => normNomeProduto(r?.nome) === alvo,
                );

            if (!prod) {
                return "";
            }

            const arquivo = arquivoFotoPrincipalProduto(prod);

            return urlFotoProduto(arquivo);
        } catch (e) {
            console.warn(
                `Não foi possível carregar a foto da coroa "${modelo}".`,
                e,
            );

            // Remove do cache para permitir nova tentativa posteriormente.
            FOTOS_MODELO_COROA.delete(chave);

            return "";
        }
    })();

    FOTOS_MODELO_COROA.set(chave, p);

    return p;
}

function coroaSomenteArtificial(order?: CoroaTvPedido | null): boolean {
    if (!order) return false;

    const itens = Array.isArray(order.itens) ? order.itens : [];
    if (itens.length === 0) return false;

    return itens.every(
        (item) =>
            String(item?.tipo_coroa || "")
                .trim()
                .toLowerCase() === "artificial",
    );
}

type CoroaTimelineData = {
    aguardandoMs: number;
    coroaMs: number;
    faixaMs: number;
    concluidaMs: number;

    aguardandoActive: boolean;
    coroaActive: boolean;
    faixaActive: boolean;
    concluidaActive: boolean;

    coroaSkipped: boolean;
};

function buildCoroaTimeline(
    order: CoroaTvPedido,
    nowMs: number,
): CoroaTimelineData {
    const coroaTs = parseLogTs(order.coroa_inicio_em || undefined);
    const faixaTs = parseLogTs(order.faixa_inicio_em || undefined);
    const finalizadaTs = parseLogTs(order.finalizada_em || undefined);
    const entregueTs = parseLogTs(order.entregue_em || undefined);

    const inicios = [coroaTs, faixaTs].filter((ts) => ts > 0);
    const primeiroInicio = inicios.length > 0 ? Math.min(...inicios) : 0;

    // Se criado_em não estiver disponível em algum registro legado,
    // usa o primeiro início conhecido para não inventar tempo anterior.
    const criadoOriginal = parseLogTs(order.criado_em || undefined);
    const criadoTs =
        criadoOriginal > 0
            ? criadoOriginal
            : primeiroInicio > 0
                ? primeiroInicio
                : finalizadaTs > 0
                    ? finalizadaTs
                    : nowMs;

    // Ampulheta: conta desde a chegada do pedido até a PRIMEIRA ação,
    // seja Coroa ou Faixa. Portanto a ordem pode mudar livremente.
    const fimAguardando =
        primeiroInicio > 0
            ? primeiroInicio
            : finalizadaTs > 0
                ? finalizadaTs
                : nowMs;

    const aguardandoMs = Math.max(0, fimAguardando - criadoTs);

    // Coroa e Faixa são cronômetros independentes.
    // Se Faixa começar antes, Faixa conta primeiro.
    // Se depois a Coroa começar, os dois passam a contar simultaneamente
    // até a finalização do pedido.
    const fimProducao = finalizadaTs > 0 ? finalizadaTs : nowMs;

    const coroaMs =
        coroaTs > 0
            ? Math.max(0, fimProducao - coroaTs)
            : 0;

    const faixaMs =
        faixaTs > 0
            ? Math.max(0, fimProducao - faixaTs)
            : 0;

    // Depois de finalizada, a coroa continua visível no quadro aguardando
    // a confirmação de entrega. O tempo abaixo mede exatamente esse período.
    // O pedido só deixa o quadro quando o status passa para "entregue".
    const concluidaMs =
        finalizadaTs > 0
            ? Math.max(0, (entregueTs > 0 ? entregueTs : nowMs) - finalizadaTs)
            : 0;

    const coroaSkipped = coroaSomenteArtificial(order);

    return {
        aguardandoMs,
        coroaMs,
        faixaMs,
        concluidaMs,

        aguardandoActive:
            primeiroInicio <= 0 &&
            finalizadaTs <= 0,

        coroaActive:
            !coroaSkipped &&
            coroaTs > 0 &&
            finalizadaTs <= 0,

        faixaActive:
            faixaTs > 0 &&
            finalizadaTs <= 0,

        concluidaActive:
            finalizadaTs > 0 &&
            entregueTs <= 0,

        coroaSkipped,
    };
}

function coroaEmConfeccao(order: CoroaTvPedido): boolean {
    const status = normalizarTextoCoroa(order.status);

    // Regra operacional do quadro:
    // novo, coroa, faixa e finalizada permanecem visíveis.
    // Somente depois da confirmação de entrega o pedido sai do quadro.
    return (
        status === "novo" ||
        status === "coroa" ||
        status === "faixa" ||
        status === "finalizada"
    );
}

/* =========================
   Regras do painel
   ========================= */
function isNao(v: unknown): boolean {
    const s = decodeHtmlEntitiesDeep(String(v ?? "")).trim().toLowerCase();
    return s === "não" || s === "nao" || s === "n";
}
function isSim(v: unknown): boolean {
    const s = decodeHtmlEntitiesDeep(String(v ?? "")).trim().toLowerCase();
    return s === "sim" || s === "s";
}
function isTerceiroRegistro(r: Registro) {
    const tipo = String((r as any).tipo_atendimento ?? "").trim().toLowerCase();
    if (tipo === "terceiro") return true;
    if (tipo === "funerario") return false;

    // Fallback somente para registros legados sem tipo_atendimento salvo.
    return isNao(r.assistencia) && isNao(r.tanato) && isNao(r.ornamentacao);
}

/**
 * Regras de compatibilidade para Velório / Sepultamento:
 * - "Não" desativa explicitamente a etapa;
 * - "Sim" ativa;
 * - NULL, undefined ou vazio são registros legados e continuam como "Sim".
 */
function rotaAtivaLegado(v: unknown): boolean {
    const s = decodeHtmlEntitiesDeep(String(v ?? "")).trim().toLowerCase();

    // Ausente/vazio = atendimento legado, cujo fluxo antigo possuía as duas etapas.
    if (!s) return true;

    return s !== "não" && s !== "nao" && s !== "n";
}

/**
 * Decide se o atendimento ainda possui alguma etapa operacional pendente
 * e, por isso, deve permanecer no quadro.
 *
 * Material Recolhido:
 * - Assistência = Sim e atendimento funerário: permanece até fase11.
 * - Terceiro ou Assistência != Sim: sai ao concluir a última rota aplicável.
 *
 * Última rota aplicável:
 * - Sepultamento = Sim: fase10.
 * - Sepultamento = Não e Velório = Sim: fase08.
 * - Velório = Não e Sepultamento = Não: fase12 (Corpo Pronto).
 */
function atendimentoDeveFicarNoQuadro(r: Registro): boolean {
    const status = normalizarStatus(r.status);

    // Sem status reconhecido, não escondemos preventivamente.
    if (!status) return true;

    // Material Recolhido é sempre o encerramento definitivo do quadro.
    if (status === "fase11") return false;

    const terceiro = isTerceiroRegistro(r);
    const precisaMaterialRecolhido = !terceiro && isSim(r.assistencia);

    // Quando ainda existe recolhimento de material, o atendimento permanece
    // independentemente de Velório/Sepultamento, até chegar à fase11.
    if (precisaMaterialRecolhido) return true;

    const realizaVelorio = rotaAtivaLegado(r.realiza_velorio);
    const realizaSepultamento = rotaAtivaLegado(r.realiza_sepultamento);

    // Há Sepultamento: a última etapa aplicável é Sepultamento Concluído.
    if (realizaSepultamento) {
        return status !== "fase10";
    }

    // Não há Sepultamento, mas há Velório: encerra ao chegar em Velando/Entrega de Corpo.
    if (realizaVelorio) {
        return !["fase08", "fase09", "fase10"].includes(status);
    }

    // Não há Velório nem Sepultamento: Corpo Pronto é a última etapa operacional.
    // Também ocultamos fases posteriores caso algum registro inconsistente/legado
    // tenha avançado além de fase12.
    return !["fase12", "fase07", "fase08", "fase09", "fase10"].includes(status);
}

function involSimNao(value: any): string {
    const s = decodeHtmlEntitiesDeep(String(value ?? "")).trim().toLowerCase();
    if (!s) return "Não";
    if (["1", "true", "t", "sim", "s", "yes", "y"].includes(s)) return "Sim";
    return "Não";
}

/* ===== Helpers Linha do Tempo ===== */
function parseRegistroDateTime(r: Registro) {
    const d = (r.data || "").trim();
    const h = (r.hora_fim_velorio || r.hora_inicio_velorio || "").trim() || "00:00";
    if (!d) return 0;
    const [yyyy, mm, dd] = d.split("-");
    const iso = `${yyyy}-${mm}-${dd}T${h}:00`;
    const ts = Date.parse(iso);
    return Number.isNaN(ts) ? 0 : ts;
}

function capitalize(str?: string): string {
    if (!str) return "";
    const s = str.toString().trim();
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : "";
}

function formatLogDateTime(value?: string): string {
    if (!value) return "";
    const s = value.replace(" ", "T");
    const d = new Date(s);
    if (Number.isNaN(d.getTime())) return value;
    const dd = d.getDate().toString().padStart(2, "0");
    const mm = (d.getMonth() + 1).toString().padStart(2, "0");
    const yyyy = d.getFullYear();
    const hh = d.getHours().toString().padStart(2, "0");
    const mi = d.getMinutes().toString().padStart(2, "0");
    return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
}

function parseLogTs(value?: string): number {
    if (!value) return 0;
    const ts = Date.parse(String(value).replace(" ", "T"));
    return Number.isNaN(ts) ? 0 : ts;
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
    return !!value && typeof value === "object" && !Array.isArray(value);
}

function asBool(val: unknown): boolean {
    if (typeof val === "boolean") return val;
    const s = decodeHtmlEntitiesDeep(String(val ?? "")).trim().toLowerCase();
    if (!s) return false;
    return ["1", "true", "t", "sim", "s", "yes", "y"].includes(s);
}

function titleCaseFromSnake(key: string): string {
    return key
        .split("_")
        .filter(Boolean)
        .map((p) => p.charAt(0).toUpperCase() + p.slice(1).toLowerCase())
        .join(" ");
}

function overrideCampoNome(_key: string, defaultName: string): string {
    return defaultName;
}

function substituirRotuloVisual(text: string): string {
    return text;
}

function formataSeDataIso(value: string): string {
    const v = value.trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(v)) {
        const [yyyy, mm, dd] = v.split("-");
        return `${dd}/${mm}/${yyyy}`;
    }
    if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(v)) {
        const [datePart, timePart] = v.split(" ");
        const [yyyy, mm, dd] = datePart.split("-");
        const hhmm = timePart.slice(0, 5);
        return `${dd}/${mm}/${yyyy} ${hhmm}`;
    }
    return v;
}

function traduzirFase(s?: string) {
    return capStatus(s) || (s ?? "");
}

function iconForAction(acao?: string, status?: string): string {
    const a = (acao || "").toLowerCase();
    if (a.includes("criou") || a.includes("novo") || a.includes("inser")) return "🟢";
    if (a.includes("edit") || a.includes("atualiz") || a.includes("alter")) return "✏️";
    if (a.includes("exclu") || a.includes("delet") || a.includes("remove")) return "🗑️";
    const st = (status || "").toLowerCase();
    if (st.startsWith("fase")) return "🔁";
    return "•";
}

/* ===== Status visual com tempo por etapa ===== */
type StatusIconKey = "hospital" | "testTube" | "flower" | "coffin" | "car" | "box" | "timer" | "hourglass" | "clock" | "clockPause" | "dot";
type StatusStepInfo = { key: string; label: string; shortLabel: string; icon: StatusIconKey };
type StatusSegment = { key: string; label: string; shortLabel: string; icon: StatusIconKey; start: number; end: number; active: boolean };

const STATUS_STEP_DEFS: StatusStepInfo[] = [
    // Resposta ao chamado: do cadastro até "Indo Retirar o Óbito" (fase01). Conta como tempo ocioso.
    { key: "aguardando", label: "Aguardando Remoção", shortLabel: "Aguard.", icon: "hourglass" },
    { key: "fase01", label: "Removendo", shortLabel: "Remov.", icon: "hospital" },
    { key: "fase02", label: "Aguardando Procedimento", shortLabel: "Aguard.", icon: "timer" },
    { key: "fase03", label: "Preparando", shortLabel: "Prep.", icon: "testTube" },
    { key: "fase04", label: "Aguardando Ornamentação", shortLabel: "A. Orn.", icon: "flower" },
    { key: "fase05", label: "Ornamentando", shortLabel: "Ornam.", icon: "flower" },
    { key: "fase06", label: "Aguardando Corpo Pronto", shortLabel: "A. Pronto", icon: "timer" },
    { key: "fase12", label: "Corpo Pronto", shortLabel: "Pronto", icon: "timer" },
    { key: "fase07", label: "Transportando P/ Velório", shortLabel: "T. Vel.", icon: "car" },
    { key: "fase08", label: "Velando", shortLabel: "Velando", icon: "coffin" },
    { key: "fase09", label: "Sepultando", shortLabel: "Sepult.", icon: "car" },
    { key: "fase10", label: "Sepultamento Concluído", shortLabel: "Concl.", icon: "timer" },
    { key: "fase11", label: "Material Recolhido", shortLabel: "Mat. Rec.", icon: "box" },
];

const STATUS_STEPS: StatusStepInfo[] = [
    { key: "fase01", label: "Removendo", shortLabel: "Remov.", icon: "hospital" },
    { key: "fase03", label: "Preparando", shortLabel: "Prep.", icon: "testTube" },
    { key: "fase05", label: "Ornamentando", shortLabel: "Ornam.", icon: "flower" },
    { key: "fase08", label: "Velando", shortLabel: "Velando", icon: "coffin" },
    { key: "fase09", label: "Sepultando", shortLabel: "Sepult.", icon: "car" },
    // Conta do comando "Sepultamento Concluído" até "Material Recolhido".
    { key: "fase10", label: "Material Recolhido", shortLabel: "Mat. Rec.", icon: "box" },
    // Soma os intervalos entre as etapas principais: aguardando procedimento,
    // aguardando ornamentação, aguardando Corpo Pronto, Corpo Pronto e transportando para velório.
    { key: "idle", label: "Tempo Ocioso", shortLabel: "Ocioso", icon: "clockPause" },
];

const STATUS_STEP_MAP = STATUS_STEP_DEFS.reduce<Record<string, StatusStepInfo>>((acc, step) => {
    acc[step.key] = step;
    return acc;
}, {});

function getStatusStepInfo(status?: string): StatusStepInfo {
    const key = normalizarStatus(status) || "";
    return STATUS_STEP_MAP[key] ?? { key: key || "indefinido", label: capStatus(status) || "a definir", shortLabel: "Status", icon: "dot" };
}

function getRegistroBackendId(r: Registro): string | undefined {
    const raw =
        (r as any).sepultamento_id ??
        (r as any).sepultamentoId ??
        (r as any).id ??
        (r as any).id_atendimento ??
        (r as any).codigo;

    const s = decodeHtmlEntitiesDeep(String(raw ?? "")).trim();
    return s || undefined;
}

function getRegistroTrackingId(r: Registro): string {
    return (
        getRegistroBackendId(r) ??
        `${decodeHtmlEntitiesDeep(String(r.falecido ?? "")).trim()}|${decodeHtmlEntitiesDeep(String(r.data ?? "")).trim()}|${decodeHtmlEntitiesDeep(String(r.hora_fim_velorio ?? "")).trim()}`
    );
}

function getStatusFromLog(log: LogItem): string | undefined {
    const detalhes = isPlainObject(log.detalhes) ? (log.detalhes as Record<string, unknown>) : {};
    const raw =
        log.status_novo ??
        (detalhes.status_novo as string | undefined) ??
        (detalhes.status as string | undefined) ??
        (detalhes.novo_status as string | undefined);

    const normalized = normalizarStatus(raw);
    return normalized?.startsWith("fase") ? normalized : undefined;
}

function formatDurationMs(msRaw: number): string {
    const ms = Math.max(0, Number.isFinite(msRaw) ? msRaw : 0);
    const totalMinutes = Math.floor(ms / 60000);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

const STATUS_MAIN_KEYS = new Set(["fase01", "fase03", "fase05", "fase08", "fase09", "fase10"]);
const STATUS_IDLE_KEYS = new Set(["aguardando", "fase02", "fase04", "fase06", "fase12", "fase07"]);

// Ordem operacional real. A fase12 (Corpo Pronto) acontece antes da fase07.
// Este ranking é usado somente para impedir regressões visuais causadas por
// resposta antiga, cache intermediário ou indisponibilidade temporária dos logs.
const STATUS_FLOW_ORDER = [
    "aguardando",
    "fase01",
    "fase02",
    "fase03",
    "fase04",
    "fase05",
    "fase06",
    "fase12",
    "fase07",
    "fase08",
    "fase09",
    "fase10",
    "fase11",
] as const;

const STATUS_FLOW_RANK = new Map<string, number>(
    STATUS_FLOW_ORDER.map((key, index) => [key, index])
);

function statusFlowRank(status?: string): number {
    const key = normalizarStatus(status);
    if (!key) return -1;
    return STATUS_FLOW_RANK.get(key) ?? -1;
}

function parseRegistroTimestampCandidate(value: unknown): number {
    const raw = decodeHtmlEntitiesDeep(String(value ?? "")).trim();
    if (!raw) return 0;

    const ts = Date.parse(raw.replace(" ", "T"));
    return Number.isNaN(ts) ? 0 : ts;
}

function getRegistroCreatedTs(registro: Registro, logs: LogItem[] | undefined, nowMs: number): number {
    // A primeira evidência do histórico é a melhor fonte para o início real.
    const logTimes = (logs ?? [])
        .map((log) => parseLogTs(log.datahora))
        .filter((ts) => ts > 0)
        .sort((a, b) => a - b);

    if (logTimes.length > 0) return logTimes[0];

    // Registros de APIs diferentes podem usar nomes diferentes para criação.
    // Preferimos um timestamp explícito em vez de hora de início/fim do velório.
    const explicitCandidates = [
        (registro as any).criado_em,
        (registro as any).criadoEm,
        (registro as any).created_at,
        (registro as any).createdAt,
        (registro as any).data_criacao,
        (registro as any).datahora_criacao,
        (registro as any).data_hora_criacao,
        (registro as any).aberto_em,
        (registro as any).inicio_em,
    ];

    for (const value of explicitCandidates) {
        const ts = parseRegistroTimestampCandidate(value);
        if (ts > 0 && ts <= nowMs + 5 * 60_000) return ts;
    }

    // Fallback estável para registros legados: usa apenas a DATA.
    // A implementação anterior usava hora_fim_velorio/hora_inicio_velorio,
    // que não representam a criação do atendimento e podiam zerar/distorcer tempos.
    const rawDate = decodeHtmlEntitiesDeep(String(registro.data ?? "")).trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) {
        const ts = Date.parse(`${rawDate}T00:00:00`);
        if (!Number.isNaN(ts) && ts > 0 && ts <= nowMs + 5 * 60_000) return ts;
    }

    return nowMs;
}

function getRegistroStatusUpdatedTs(registro: Registro, createdTs: number, nowMs: number): number {
    const candidates = [
        (registro as any).status_atualizado_em,
        (registro as any).status_alterado_em,
        (registro as any).status_updated_at,
        (registro as any).atualizado_em,
        (registro as any).updated_at,
        (registro as any).updatedAt,
    ];

    for (const value of candidates) {
        const ts = parseRegistroTimestampCandidate(value);
        if (ts >= createdTs && ts <= nowMs + 5 * 60_000) return ts;
    }

    return 0;
}

function buildStatusSegments(registro: Registro, logs: LogItem[] | undefined, nowMs: number): StatusSegment[] {
    const currentKeyRaw = normalizarStatus(registro.status);
    const currentKey = currentKeyRaw?.startsWith("fase") ? currentKeyRaw : undefined;
    const createdTs = getRegistroCreatedTs(registro, logs, nowMs);

    const statusEvents = (logs ?? [])
        .map((log) => ({ key: getStatusFromLog(log), ts: parseLogTs(log.datahora) }))
        .filter((x): x is { key: string; ts: number } => !!x.key && x.ts > 0)
        .sort((a, b) => a.ts - b.ts);

    // O atendimento nasce em "aguardando" (resposta ao chamado). Esse intervalo, até a
    // fase01 "Indo Retirar o Óbito", é tempo ocioso e não entra no tempo de Remoção.
    const unique: { key: string; ts: number }[] = [{ key: "aguardando", ts: createdTs }];

    for (const ev of statusEvents) {
        if (ev.ts < createdTs) continue;

        const last = unique[unique.length - 1];
        if (last?.key === ev.key) continue;

        // Nunca deixa um log antigo/tardio fazer a TV voltar para uma fase anterior.
        // Ex.: já vimos fase08; uma resposta atrasada contendo fase05 não regride a tela.
        const lastRank = statusFlowRank(last?.key);
        const nextRank = statusFlowRank(ev.key);
        if (lastRank >= 0 && nextRank >= 0 && nextRank < lastRank) continue;

        unique.push(ev);
    }

    const lastKnown = unique[unique.length - 1];
    const lastKnownRank = statusFlowRank(lastKnown?.key);
    const currentRank = statusFlowRank(currentKey);

    // Fonte de verdade visual:
    // - se o registro atual está mais avançado, usa o registro;
    // - se o histórico persistido está mais avançado, mantém o histórico;
    // - assim uma falha/atraso nunca devolve o atendimento para o começo.
    const effectiveCurrentKey =
        currentKey && currentRank >= lastKnownRank
            ? currentKey
            : lastKnown?.key || currentKey || "aguardando";

    if (effectiveCurrentKey && lastKnown?.key !== effectiveCurrentKey) {
        const explicitStatusTs = getRegistroStatusUpdatedTs(registro, createdTs, nowMs);
        const inferredStart = explicitStatusTs > 0
            ? explicitStatusTs
            : Math.max(createdTs, lastKnown?.ts || createdTs);

        unique.push({
            key: effectiveCurrentKey,
            ts: Math.min(nowMs, inferredStart),
        });
    }

    return unique.map((ev, idx) => {
        const info = getStatusStepInfo(ev.key);
        const isLast = idx === unique.length - 1;
        const nextStart = unique[idx + 1]?.ts ?? nowMs;
        const end = isLast ? nowMs : Math.max(ev.ts, nextStart);

        return {
            key: info.key,
            label: info.label,
            shortLabel: info.shortLabel,
            icon: info.icon,
            start: ev.ts,
            end,
            active: isLast && ev.key === effectiveCurrentKey,
        };
    });
}

function getStatusDisplayData(segments: StatusSegment[]) {
    const durations = new Map<string, number>();
    let activeKey: string | undefined;

    for (const seg of segments) {
        const duration = Math.max(0, seg.end - seg.start);
        const displayKey = STATUS_IDLE_KEYS.has(seg.key) ? "idle" : STATUS_MAIN_KEYS.has(seg.key) ? seg.key : undefined;
        if (!displayKey) continue;

        durations.set(displayKey, (durations.get(displayKey) ?? 0) + duration);
        if (seg.active) activeKey = displayKey;
    }

    return { durations, activeKey };
}

function compararCoroasPorOrdemDeChegada(a: CoroaTvPedido, b: CoroaTvPedido): number {
    const ta = parseLogTs(a.criado_em || undefined);
    const tb = parseLogTs(b.criado_em || undefined);

    // Quando ambos possuem data válida, a ordem cronológica real é soberana.
    if (ta > 0 && tb > 0 && ta !== tb) {
        return ta - tb;
    }

    // Fallback para registros legados: IDs menores chegaram primeiro.
    return Number(a.id || 0) - Number(b.id || 0);
}

/* =========================
   Página
   ========================= */
const DIAS = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];

// Atendimentos e coroas por página: definidos por calcularLayoutTv() conforme o volume.
const INTERVALO_PAGINACAO_ATENDIMENTOS_MS = 15_000;

const INTERVALO_PAGINACAO_COROAS_MS = 15_000;

export default function QuadroAtendimentoPage() {
    // Tema da gaveta de detalhes (segue a mesma escolha do quadro).
    const [coroaSel, setCoroaSel] = useState<CoroaTvPedido | null>(null);
    const fecharCoroa = useCallback(() => setCoroaSel(null), []);
    const [rotaTv, setRotaTv] = useState<boolean | null>(null);
    useEffect(() => setRotaTv(ehRotaTv()), []);
    const gavetaSentinelaRef = useRef<HTMLDivElement | null>(null);
    const escuroAppPagina = useTemaEscuroApp(gavetaSentinelaRef);
    const { tema: temaGaveta } = useTemaPai(escuroAppPagina);
    const [clockTime, setClockTime] = useState("");
    const [clockDate, setClockDate] = useState("");
    const [nowMs, setNowMs] = useState(() => Date.now());

    const [registros, setRegistros] = useState<Registro[]>(() => readLS<Registro[]>("qa_registros") ?? []);
    const [avisos, setAvisos] = useState<Aviso[]>(() => readLS<Aviso[]>("qa_avisos") ?? []);

    const [open, setOpen] = useState(false);
    const [detail, setDetail] = useState<Registro | null>(null);
    const [copied, setCopied] = useState(false);

    // Ação aberta diretamente dentro do Quadro, sem sair para /atendimento.
    const [acaoOpen, setAcaoOpen] = useState(false);
    const [acaoId, setAcaoId] = useState<string | number | null>(null);
    const [acaoMsg, setAcaoMsg] = useState<{ text: string; ok: boolean } | null>(null);
    const [acaoSubmitting, setAcaoSubmitting] = useState(false);
    const [estoqueInsuficiente, setEstoqueInsuficiente] = useState<EstoqueInsuficienteAlerta | null>(null);

    // Fluxos auxiliares do mesmo AcaoModal usado em /acompanhamento.
    const [fotoAcaoOpen, setFotoAcaoOpen] = useState(false);
    const [fotoAcaoId, setFotoAcaoId] = useState<string | number | null>(null);
    const [fotoAcaoFase, setFotoAcaoFase] = useState<string>("fase06");
    const [fotoAcaoTipo, setFotoAcaoTipo] = useState<FotoAcaoTipo | null>(null);

    const teleRef = useRef<TelemetriaHandle>(null);
    const [teleOpen, setTeleOpen] = useState(false);
    const [teleFase, setTeleFase] = useState<string>("fase01");
    const [teleTipo, setTeleTipo] = useState<TipoTele>("remocao");
    const [teleRegistroId, setTeleRegistroId] = useState<string | number | null>(null);

    const [matCheckOpen, setMatCheckOpen] = useState(false);
    const [matCheckItens, setMatCheckItens] = useState<MatCheckItem[]>([]);
    const [matCheckRegistroId, setMatCheckRegistroId] = useState<string | number | null>(null);
    const [matCheckFalecidoNome, setMatCheckFalecidoNome] = useState("");
    const [matCheckSaving, setMatCheckSaving] = useState(false);
    const [matCheckReturnToAcao, setMatCheckReturnToAcao] = useState(false);

    const [detailTimelineOpen, setDetailTimelineOpen] = useState(false);
    const [detailLogs, setDetailLogs] = useState<LogItem[]>([]);
    const [detailLogsLoading, setDetailLogsLoading] = useState(false);
    const [detailLogsError, setDetailLogsError] = useState<string | null>(null);

    const [matLookup, setMatLookup] = useState<Record<string, MatLookupInfo>>({});
    const [statusLogsById, setStatusLogsById] = useState<Record<string, LogItem[]>>(
        () => readLS<Record<string, LogItem[]>>(STATUS_LOGS_STORAGE_KEY) ?? {}
    );

    /* Paginação automática dos atendimentos */
    const [paginaAtendimentos, setPaginaAtendimentos] = useState(0);
    const paginationSignatureRef = useRef("");

    /* Coroas de Flores — painel inferior */
    const [coroasTv, setCoroasTv] = useState<CoroaTvPedido[]>(
        () => [...(readLS<CoroaTvPedido[]>("qa_coroas_tv") ?? [])].sort(compararCoroasPorOrdemDeChegada)
    );
    const [coroasTvError, setCoroasTvError] = useState<string | null>(null);

    /* Paginação automática das coroas */
    const [paginaCoroas, setPaginaCoroas] = useState(0);
    const coroasPaginationSignatureRef = useRef("");

    /* Ajuste automático de densidade da TV */
    const [qaDensity, setQaDensity] = useState<QaDensity>("normal");
    const dashboardContentRef = useRef<HTMLElement | null>(null);

    useEffect(() => {
        const update = () => {
            const now = new Date();
            setNowMs(now.getTime());
            const h = now.getHours().toString().padStart(2, "0");
            const m = now.getMinutes().toString().padStart(2, "0");
            const s = now.getSeconds().toString().padStart(2, "0");
            setClockTime(`${h}:${m}:${s}`);

            const dd = now.getDate().toString().padStart(2, "0");
            const mm = (now.getMonth() + 1).toString().padStart(2, "0");
            const yyyy = now.getFullYear();
            setClockDate(`${DIAS[now.getDay()]}, ${dd}/${mm}/${yyyy}`);
        };
        update();
        const id = setInterval(update, 1000);
        return () => clearInterval(id);
    }, []);

    useEffect(() => {
        let alive = true;
        const BASE_INFO = `${API_PHP}/informativo.php?listar=1`;

        async function load() {
            try {
                const url = `${BASE_INFO}&_ts=${Date.now()}`;
                const j = await fetchJsonFast<any>(url, {
                    ttlMs: 0,
                    timeoutMs: 12_000,
                    cacheKey: "informativo_listar",
                });

                if (!alive) return;

                // Não transforma erro de sessão/resposta inválida em lista vazia.
                // Uma resposta inválida mantém o último quadro conhecido.
                if (!Array.isArray(j)) {
                    throw new Error("Resposta inválida ao consultar atendimentos.");
                }

                const arr = j as Registro[];
                setRegistros(arr);
                writeLS("qa_registros", arr);
            } catch (err) {
                // Mantém o que já tem. A TV não deve apagar nem reiniciar o quadro
                // por timeout, perda de rede, suspensão do navegador ou erro momentâneo.
                console.warn("Não foi possível atualizar os atendimentos; mantendo último estado conhecido.", err);
            }
        }

        void load();

        const id = window.setInterval(() => {
            if (!document.hidden) void load();
        }, 8000);

        const refreshWhenActive = () => {
            if (!document.hidden) void load();
        };

        document.addEventListener("visibilitychange", refreshWhenActive);
        window.addEventListener("focus", refreshWhenActive);
        window.addEventListener("online", refreshWhenActive);

        return () => {
            alive = false;
            window.clearInterval(id);
            document.removeEventListener("visibilitychange", refreshWhenActive);
            window.removeEventListener("focus", refreshWhenActive);
            window.removeEventListener("online", refreshWhenActive);
        };
    }, []);

    useEffect(() => {
        let alive = true;

        async function loadCoroas() {
            const urls = [COROAS_TV_LOCAL, COROAS_TV_REMOTA];
            let lastError: unknown = null;

            for (const url of urls) {
                try {
                    // Força uma leitura nova da fila de Confecção.
                    // O _ts evita reaproveitamento por navegador/proxy e ttlMs 0
                    // impede que o cache em memória atrase a entrada de pedidos online.
                    const freshUrl = `${url}${url.includes("?") ? "&" : "?"}_ts=${Date.now()}`;
                    const j = await fetchJsonFast<CoroasTvResponse>(freshUrl, {
                        ttlMs: 0,
                        timeoutMs: 10_000,
                        cacheKey: url === COROAS_TV_LOCAL ? "qa_coroas_tv_local" : "qa_coroas_tv_remota",
                    });

                    if (!alive) return;

                    if (!j?.sucesso || !Array.isArray(j.dados)) {
                        throw new Error(j?.msg || "Resposta inválida ao consultar coroas.");
                    }

                    const arr = j.dados
                        .filter(coroaEmConfeccao)
                        .sort(compararCoroasPorOrdemDeChegada);

                    setCoroasTv(arr);
                    writeLS("qa_coroas_tv", arr);
                    setCoroasTvError(null);
                    return;
                } catch (err) {
                    lastError = err;
                }
            }

            if (!alive) return;

            // Não apaga o quadro em caso de oscilação.
            setCoroasTvError(
                lastError instanceof Error
                    ? lastError.message
                    : "Não foi possível atualizar as coroas."
            );
        }

        void loadCoroas();

        const id = window.setInterval(() => {
            if (!document.hidden) {
                void loadCoroas();
            }
        }, 30_000);

        const onVisibility = () => {
            if (!document.hidden) {
                void loadCoroas();
            }
        };

        const onFocus = () => {
            if (!document.hidden) {
                void loadCoroas();
            }
        };

        document.addEventListener("visibilitychange", onVisibility);
        window.addEventListener("focus", onFocus);

        return () => {
            alive = false;
            window.clearInterval(id);
            document.removeEventListener("visibilitychange", onVisibility);
            window.removeEventListener("focus", onFocus);
        };
    }, []);

    useEffect(() => {
        let alive = true;
        const BASE_AVISOS = `${API_PHP}/avisos.php?listar=1`;

        async function load() {
            if (!alive) return;

            try {
                const url = `${BASE_AVISOS}&_ts=${Date.now()}`;
                const j = await fetchJsonFast<any>(url, {
                    ttlMs: 5_000,
                    cacheKey: "avisos_listar",
                });

                if (!alive) return;

                const arr: Aviso[] = Array.isArray(j) ? j : [];

                setAvisos(arr);
                writeLS("qa_avisos", arr);
            } catch (err) {
                console.error("Erro ao carregar avisos:", err);

                if (!alive) return;

                // mantém a UI estável e limpa o cache persistido
                setAvisos([]);
                writeLS("qa_avisos", []);
            }
        }

        load();

        const id = window.setInterval(() => {
            void load();
        }, 10000);

        return () => {
            alive = false;
            window.clearInterval(id);
        };
    }, []);

    useEffect(() => {
        let alive = true;

        async function loadMateriaisCatalog() {
            try {
                const url = `${API_PHP}/materiais_admin.php?op=list&all=1&_ts=${Date.now()}`;
                const res = await fetchJsonFast<any>(url, { ttlMs: 60_000, cacheKey: "mat_catalog" });

                const tree = (res?.data ?? res) as any[];
                const map: Record<string, MatLookupInfo> = {};

                for (const cat of tree ?? []) {
                    const catNome = String(cat?.nome ?? "").trim();
                    const catOrdem = Number(cat?.ordem ?? 0);

                    for (const it of cat?.itens ?? []) {
                        const itemId = Number(it?.id);
                        if (!Number.isFinite(itemId) || itemId <= 0) continue;

                        const itemOrdem = Number(it?.ordem ?? 0);
                        const itemKey = `item${itemId}`;

                        map[itemKey] = { catNome, catOrdem, itemOrdem };
                    }
                }

                if (!alive) return;
                setMatLookup(map);
            } catch {
                if (!alive) return;
                setMatLookup({});
            }
        }

        loadMateriaisCatalog();
        return () => {
            alive = false;
        };
    }, []);

    const resetDetailTimeline = useCallback(() => {
        setDetailTimelineOpen(false);
        setDetailLogs([]);
        setDetailLogsLoading(false);
        setDetailLogsError(null);
    }, []);

    const showDetail = useCallback(
        (r: Registro) => {
            setDetail(r);
            setOpen(true);
            setCopied(false);
            resetDetailTimeline();
        },
        [resetDetailTimeline]
    );

    const closeDetail = useCallback(() => {
        setOpen(false);
        setDetail(null);
        setCopied(false);
        resetDetailTimeline();
    }, [resetDetailTimeline]);

    useEffect(() => {
        const onKey = (e: KeyboardEvent) => {
            if (e.key === "Escape") closeDetail();
        };
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
    }, [closeDetail]);

    const ativosOrdenados = useMemo(() => {
        const base = (registros || []).filter(atendimentoDeveFicarNoQuadro);

        const withTs = base.map((r) => ({ r, ts: parseRegistroDateTime(r) }));
        withTs.sort((a, b) => b.ts - a.ts);
        return withTs.map((x) => x.r);
    }, [registros]);

    /* Layout da TV: define quantos atendimentos e coroas cabem por página */
    const layoutTv = useMemo(
        () => calcularLayoutTv(ativosOrdenados.length, coroasTv.length),
        [ativosOrdenados.length, coroasTv.length]
    );
    // Se o texto de uma página não couber na TV, o quadro tira um item por página (volta ao padrão quando a quantidade muda).
    const [reducaoTv, setReducaoTv] = useState({ at: 0, cr: 0 });
    useEffect(() => {
        setReducaoTv({ at: 0, cr: 0 });
    }, [ativosOrdenados.length, coroasTv.length]);
    const tvNaoCoube = useCallback(
        (area: "at" | "cr") =>
            setReducaoTv((r) => {
                const base = area === "at" ? layoutTv.atendimentosPorPagina : layoutTv.coroasPorPagina;
                return base - r[area] <= 1 ? r : { ...r, [area]: r[area] + 1 };
            }),
        [layoutTv]
    );
    const atendimentosPorPagina = Math.max(1, layoutTv.atendimentosPorPagina - reducaoTv.at);
    const coroasPorPagina = Math.max(1, layoutTv.coroasPorPagina - reducaoTv.cr);

    /*
     * Paginação do quadro:
     * - no máximo 6 atendimentos por página;
     * - acima de 6, cria páginas adicionais;
     * - troca automaticamente a cada 15 segundos;
     * - quando entra/sai um atendimento, volta para a primeira página para
     *   mostrar imediatamente a composição mais recente do quadro.
     */
    const totalPaginasAtendimentos = Math.max(
        1,
        Math.ceil(ativosOrdenados.length / atendimentosPorPagina)
    );

    const paginaAtualAtendimentos = Math.min(
        paginaAtendimentos,
        totalPaginasAtendimentos - 1
    );

    const ativosPagina = useMemo(() => {
        const inicio = paginaAtualAtendimentos * atendimentosPorPagina;
        return ativosOrdenados.slice(
            inicio,
            inicio + atendimentosPorPagina
        );
    }, [ativosOrdenados, paginaAtualAtendimentos, atendimentosPorPagina]);

    const paginationSignature = useMemo(
        () =>
            ativosOrdenados
                .map((r, index) => getRegistroTrackingId(r) || `idx:${index}`)
                .join("|"),
        [ativosOrdenados]
    );

    useEffect(() => {
        const anterior = paginationSignatureRef.current;

        if (anterior && anterior !== paginationSignature) {
            setPaginaAtendimentos(0);
        }

        paginationSignatureRef.current = paginationSignature;
    }, [paginationSignature]);

    useEffect(() => {
        setPaginaAtendimentos((pagina) =>
            Math.min(pagina, totalPaginasAtendimentos - 1)
        );
    }, [totalPaginasAtendimentos]);

    useEffect(() => {
        if (totalPaginasAtendimentos <= 1) {
            setPaginaAtendimentos(0);
            return;
        }

        const id = window.setInterval(() => {
            if (document.hidden) return;

            setPaginaAtendimentos(
                (pagina) => (pagina + 1) % totalPaginasAtendimentos
            );
        }, INTERVALO_PAGINACAO_ATENDIMENTOS_MS);

        return () => window.clearInterval(id);
    }, [totalPaginasAtendimentos]);

    /*
     * Paginação das coroas:
     * - no máximo 3 pedidos por página;
     * - ordem sempre do pedido mais antigo para o mais novo;
     * - acima de 3, cria páginas adicionais;
     * - troca automaticamente a cada 15 segundos;
     * - quando entra/sai um pedido, volta para a primeira página para manter
     *   o pedido mais antigo imediatamente visível no início da fila.
     */
    const coroasOrdenadas = useMemo(
        () => [...coroasTv].sort(compararCoroasPorOrdemDeChegada),
        [coroasTv]
    );

    const totalPaginasCoroas = Math.max(
        1,
        Math.ceil(coroasOrdenadas.length / coroasPorPagina)
    );

    const paginaAtualCoroas = Math.min(
        paginaCoroas,
        totalPaginasCoroas - 1
    );

    const coroasPagina = useMemo(() => {
        const inicio = paginaAtualCoroas * coroasPorPagina;
        return coroasOrdenadas.slice(
            inicio,
            inicio + coroasPorPagina
        );
    }, [coroasOrdenadas, paginaAtualCoroas, coroasPorPagina]);

    const coroasPaginationSignature = useMemo(
        () => coroasOrdenadas.map((pedido) => String(pedido.id)).join("|"),
        [coroasOrdenadas]
    );

    useEffect(() => {
        const anterior = coroasPaginationSignatureRef.current;

        if (anterior && anterior !== coroasPaginationSignature) {
            setPaginaCoroas(0);
        }

        coroasPaginationSignatureRef.current = coroasPaginationSignature;
    }, [coroasPaginationSignature]);

    useEffect(() => {
        setPaginaCoroas((pagina) =>
            Math.min(pagina, totalPaginasCoroas - 1)
        );
    }, [totalPaginasCoroas]);

    useEffect(() => {
        if (totalPaginasCoroas <= 1) {
            setPaginaCoroas(0);
            return;
        }

        const id = window.setInterval(() => {
            if (document.hidden) return;

            setPaginaCoroas(
                (pagina) => (pagina + 1) % totalPaginasCoroas
            );
        }, INTERVALO_PAGINACAO_COROAS_MS);

        return () => window.clearInterval(id);
    }, [totalPaginasCoroas]);

    // Identidade estável dos atendimentos acompanhados pelo histórico.
    // A lista de registros é atualizada a cada 8s, mas o timer dos logs só precisa
    // ser recriado quando os IDs realmente mudarem.
    const statusTrackingTargets = ativosOrdenados
        .map((r) => ({
            id: getRegistroBackendId(r),
            trackingId: getRegistroTrackingId(r),
        }))
        .filter((x): x is { id: string; trackingId: string } => !!x.id);

    const statusTrackingSignature = statusTrackingTargets
        .map((x) => `${x.id}:${x.trackingId}`)
        .sort()
        .join("|");

    useEffect(() => {
        let alive = true;
        let loading = false;

        // A assinatura é a dependência do efeito. Se ela não mudou, os alvos
        // capturados aqui representam os mesmos IDs e não reiniciamos o timer.
        const targets = statusTrackingTargets;

        async function loadStatusLogs() {
            if (loading || !alive) return;
            loading = true;

            try {
                const updates: Record<string, LogItem[]> = {};

                await Promise.all(
                    targets.map(async ({ id, trackingId }) => {
                        try {
                            const BASE = `${API_PHP}/historico_sepultamentos.php?log=1&id=${encodeURIComponent(String(id))}`;
                            const url = `${BASE}&_ts=${Date.now()}`;

                            // ttl 0: o histórico é pequeno e deve refletir a etapa real.
                            const json: any = await fetchJsonFast<any>(url, {
                                ttlMs: 0,
                                timeoutMs: 12_000,
                                cacheKey: `hist_${id}`,
                            });

                            let logs: LogItem[] | null = null;
                            if (Array.isArray(json)) {
                                logs = json as LogItem[];
                            } else if (json?.sucesso && Array.isArray(json.dados)) {
                                logs = json.dados as LogItem[];
                            } else {
                                throw new Error("Resposta inválida do histórico.");
                            }

                            updates[trackingId] = [...logs].sort(
                                (a, b) => parseLogTs(a.datahora) - parseLogTs(b.datahora)
                            );
                        } catch (err) {
                            // REGRA CRÍTICA: nunca escrevemos [] em caso de erro.
                            // O último histórico válido continua em memória/localStorage.
                            console.warn(`Falha ao atualizar histórico do atendimento ${id}; mantendo histórico anterior.`, err);
                        }
                    })
                );

                if (!alive) return;

                // Se nenhuma consulta teve resposta válida, não toca no estado persistido.
                if (Object.keys(updates).length === 0) return;

                setStatusLogsById((prev) => {
                    const merged: Record<string, LogItem[]> = { ...prev };

                    for (const [trackingId, logs] of Object.entries(updates)) {
                        // Uma resposta vazia não apaga um histórico válido já conhecido.
                        // Isso protege contra respostas intermediárias/replicação atrasada.
                        if (logs.length === 0 && (prev[trackingId]?.length ?? 0) > 0) {
                            continue;
                        }

                        // Move o atendimento atualizado para o fim do objeto. Assim,
                        // quando houver compactação, os históricos mais recentes ficam.
                        delete merged[trackingId];
                        merged[trackingId] = logs;
                    }

                    // Mantém um histórico razoável de atendimentos anteriores e, ao mesmo
                    // tempo, impede crescimento ilimitado do localStorage ao longo dos meses.
                    // Os ativos são atualizados periodicamente e naturalmente ficam entre
                    // as entradas mais recentes.
                    const entries = Object.entries(merged);
                    const compactEntries = entries.slice(-STATUS_LOGS_STORAGE_MAX_ENTRIES);
                    const compact = Object.fromEntries(compactEntries) as Record<string, LogItem[]>;

                    writeLS(STATUS_LOGS_STORAGE_KEY, compact);
                    return compact;
                });
            } finally {
                loading = false;
            }
        }

        void loadStatusLogs();

        const id = window.setInterval(() => {
            if (!document.hidden) void loadStatusLogs();
        }, 30000);

        const refreshWhenActive = () => {
            if (!document.hidden) void loadStatusLogs();
        };

        document.addEventListener("visibilitychange", refreshWhenActive);
        window.addEventListener("focus", refreshWhenActive);
        window.addEventListener("online", refreshWhenActive);

        return () => {
            alive = false;
            window.clearInterval(id);
            document.removeEventListener("visibilitychange", refreshWhenActive);
            window.removeEventListener("focus", refreshWhenActive);
            window.removeEventListener("online", refreshWhenActive);
        };
        // A lista completa muda a cada polling de 8s; a assinatura evita reiniciar
        // este efeito sem necessidade.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [statusTrackingSignature]);

    const TAG_SERVICO = "Atendimento:";

    function normNome(s?: string) {
        return String(s ?? "")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function isServicoMsg(msg?: any) {
        const s = String(msg ?? "");
        return s.startsWith(TAG_SERVICO);
    }

    function extractServicoNome(msg?: string) {
        const s = String(msg ?? "");
        if (!s.startsWith(TAG_SERVICO)) return "";

        const rest = s.slice(TAG_SERVICO.length).trim();
        const idx = rest.indexOf(":");

        return (idx >= 0 ? rest.slice(0, idx) : rest).trim();
    }

    const nomesAtivos = useMemo(() => {
        const set = new Set<string>();

        for (const r of ativosOrdenados as Registro[]) {
            const nome = String(r?.falecido ?? "").trim();
            if (nome) set.add(normNome(nome));
        }

        return set;
    }, [ativosOrdenados]);

    const avisosParaExibir = useMemo(() => {
        const arr = Array.isArray(avisos) ? avisos : [];

        return arr.filter((a) => {
            const msg = String(a?.mensagem ?? "");

            // aviso comum: sempre exibe
            if (!isServicoMsg(msg)) return true;

            // aviso de serviço: só exibe se o nome ainda estiver entre os ativos
            const nome = extractServicoNome(msg);
            if (!nome) return true;

            return nomesAtivos.has(normNome(nome));
        });
    }, [avisos, nomesAtivos]);

    /* Visita de avaliação no Quadro: mesma permissão ("visita-avaliacao") e mesmo botão da lista de Atendimentos. */
    const [visitaPermitida, setVisitaPermitida] = useState(false);
    const [visitaStatusDetalhe, setVisitaStatusDetalhe] = useState<VisitaStatus>("indisponivel");
    const [visitaRegistro, setVisitaRegistro] = useState<Registro | null>(null);

    useEffect(() => {
        let cancel = false;
        consultarAcessoVisita(true)
            .then((me) => {
                if (!cancel) setVisitaPermitida(!!me.autorizado);
            })
            .catch(() => {
                if (!cancel) setVisitaPermitida(false);
            });
        return () => {
            cancel = true;
        };
    }, []);

    const detalheVisitaId = open && detail ? getRegistroBackendId(detail) : "";
    const carregarStatusVisitaDetalhe = useCallback(async (id: string) => {
        if (!id) return;
        try {
            const mapa = await consultarStatusVisitas([id]);
            setVisitaStatusDetalhe(mapa[String(id)] ?? "indisponivel");
        } catch {
            setVisitaStatusDetalhe("indisponivel");
        }
    }, []);
    useEffect(() => {
        setVisitaStatusDetalhe("indisponivel");
        if (!visitaPermitida || !detalheVisitaId) return;
        void carregarStatusVisitaDetalhe(String(detalheVisitaId));
    }, [visitaPermitida, detalheVisitaId, carregarStatusVisitaDetalhe]);

    const abrirVisita = useCallback((r: Registro) => {
        const id = getRegistroBackendId(r);
        if (!id) return;
        setVisitaRegistro({ ...(r as any), id } as Registro);
        // Fecha a gaveta de detalhes; a janela da visita assume a interface (igual ao Registrar ação).
        setOpen(false);
    }, []);

    const abrirRegistrarAcao = useCallback((r: Registro) => {
        const id = getRegistroBackendId(r);
        if (!id) return;

        setAcaoMsg(null);
        setAcaoId(id);
        setAcaoOpen(true);

        // Fecha a gaveta de detalhes; o AcaoModal assume a interface.
        setOpen(false);
    }, []);

    /**
     * Registra a ação diretamente no backend sem sair do Quadro.
     *
     * O fluxo antigo montava /atendimento?registrar_acao=... e navegava para
     * outra tela. Agora o próprio Quadro persiste o status usando o mesmo
     * helper de backend da página de Atendimento, atualiza a lista e fecha
     * o AcaoModal somente depois de confirmação do servidor.
     *
     * A fase12 continua usando o checkpoint único de baixa de estoque antes
     * da alteração de status. Em falta de saldo, o AcaoModal exibe o mesmo
     * alerta estruturado de estoque insuficiente.
     */
    const registrarAcaoDoQuadro = useCallback(
        async (
            acao: string,
            opts?: {
                skipMaterialCheck?: boolean;
                skipConfirm?: boolean;
                extra?: Record<string, any>;
            },
        ): Promise<boolean> => {
            if (acaoSubmitting) return false;
            if (acaoId == null) {
                setAcaoMsg({ text: "Atendimento não selecionado.", ok: false });
                return false;
            }

            const statusCode = normalizarStatus(String(acao)) || String(acao).toLowerCase();
            const extraPayload = opts?.extra && typeof opts.extra === "object" ? opts.extra : {};
            const needsBackendConfirm = statusCode === "fase03" || statusCode === "fase04";

            // Material Recolhido: exige a conferência antes de efetivar fase11.
            if (statusCode === "fase11" && !opts?.skipMaterialCheck) {
                const reg = registros.find((x) => String((x as any).id) === String(acaoId));
                const mats = reg ? parseMateriaisFromRegistroQuadro(reg) : ({} as MateriaisState);
                const itens: MatCheckItem[] = Object.entries((mats as any) || {})
                    .map(([k, it]: any) => ({
                        key: String(k),
                        nome: String(it?.nome || k),
                        qtd: Number(it?.qtd ?? 0),
                        checked: !!it?.checked,
                    }))
                    .filter((x: any) => x.checked && x.qtd > 0)
                    .map((x: any) => ({ key: x.key, nome: x.nome, qtd: x.qtd }));

                setMatCheckItens(itens);
                setMatCheckRegistroId(reg && (reg as any).id != null ? String((reg as any).id) : String(acaoId));
                setMatCheckFalecidoNome(reg ? resolveFalecidoNomeQuadro(reg) : "");
                setMatCheckReturnToAcao(true);
                setAcaoOpen(false);
                setMatCheckOpen(true);
                return false;
            }

            if (!opts?.skipConfirm) {
                const confirmou = window.confirm("Deseja confirmar essa ação?");
                if (!confirmou) return false;
            }

            setAcaoSubmitting(true);
            setAcaoMsg(null);
            setEstoqueInsuficiente(null);

            try {
                // Corpo Pronto: primeiro executa a baixa transacional de estoque.
                // O endpoint valida todos os itens antes de efetivar qualquer saída.
                if (statusCode === "fase12") {
                    try {
                        await baixarItensCorpoProntoQuadro({
                            registro_id: String(acaoId),
                            tipo: "",
                        });
                    } catch (e: any) {
                        if (isEstoqueInsuficienteQuadroError(e)) {
                            setAcaoMsg(null);
                            setEstoqueInsuficiente({
                                titulo: "Estoque insuficiente",
                                mensagem:
                                    "Não é possível avançar para Corpo Pronto enquanto houver item sem quantidade suficiente no estoque.",
                                itens: Array.isArray(e.itens) ? e.itens : [],
                            });
                            return false;
                        }
                        throw e;
                    }
                }

                // Metadados operacionais equivalentes aos utilizados no Atendimento.
                let session: Awaited<ReturnType<typeof getCurrentOfflineSession>> = null;
                try {
                    session = await getCurrentOfflineSession({
                        refreshIfOnline: true,
                        allowCachedOnNetworkFailure: true,
                    });
                } catch {
                    session = null;
                }

                let ocorreuEm = new Date().toISOString();
                try {
                    const stamp = await getOperationalTimestamp();
                    ocorreuEm = stamp.occurredAt || ocorreuEm;
                } catch {
                    // fallback para o relógio local
                }

                let deviceId = "";
                try {
                    deviceId = await getOfflineDeviceId();
                } catch {
                    // backend continua podendo identificar a sessão mesmo sem device_id
                }

                const registroAtual = registros.find((x) => String((x as any).id) === String(acaoId));
                const commonMeta = {
                    id: acaoId,
                    operation_id: String(extraPayload.operationId || newOfflineId("status-op")),
                    ocorreu_em: String(extraPayload.occurredAt || ocorreuEm),
                    ...(deviceId ? { device_id: deviceId } : {}),
                    ...(session?.userId ? { usuario_id: session.userId } : {}),
                    origem: "online",
                    status_anterior: registroAtual?.status || undefined,
                };

                const requestPayload =
                    statusCode === "fase11"
                        ? {
                            acao: "material_recolhido",
                            ...commonMeta,
                            ...extraPayload,
                        }
                        : {
                            acao: "atualizar_status",
                            status: statusCode || acao,
                            ...commonMeta,
                            ...extraPayload,
                            ...(needsBackendConfirm ? { confirmar: true } : {}),
                        };

                const json = await enviarRegistroPHP(requestPayload as any);

                if (!json?.sucesso) {
                    const msg = String(json?.msg || json?.erro || "Erro ao atualizar status.");
                    setAcaoMsg({ text: msg, ok: false });
                    return false;
                }

                setAcaoMsg({
                    text: `Status alterado para "${capStatus(statusCode || acao)}"`,
                    ok: true,
                });

                // Atualiza imediatamente o Quadro, sem esperar o polling de 8 segundos.
                try {
                    const atualizados = await carregarRegistrosAtuaisQuadro();
                    setRegistros(atualizados);
                    writeLS("qa_registros", atualizados);
                } catch (refreshError) {
                    // A gravação já foi confirmada pelo servidor. Não transforma um
                    // problema de refresh em falso erro de persistência.
                    console.warn("A ação foi registrada, mas o Quadro não conseguiu atualizar imediatamente.", refreshError);
                }

                setAcaoOpen(false);
                return true;
            } catch (e: any) {
                const msg = e?.message || "Não foi possível registrar a ação.";
                setAcaoMsg({ text: msg, ok: false });
                return false;
            } finally {
                setAcaoSubmitting(false);
            }
        },
        [acaoId, acaoSubmitting, registros],
    );

    const handleFotoAcaoRequired = useCallback(
        (id: string | number | null | undefined, fase: string, tipo: FotoAcaoTipo) => {
            const normalizedId = id != null ? String(id) : null;
            setAcaoMsg(null);
            setAcaoId(normalizedId);
            setFotoAcaoId(normalizedId);
            setFotoAcaoFase(fase);
            setFotoAcaoTipo(tipo);
            setAcaoOpen(false);
            setFotoAcaoOpen(true);
        },
        [],
    );

    const handleVeiculoRequired = useCallback(
        (id: string | number | null | undefined, fase: string) => {
            const normalizedId = id != null ? String(id) : null;
            const tipo = mapFaseToTipoQuadro(fase);

            setAcaoId(normalizedId);
            if (!tipo) {
                void registrarAcaoDoQuadro(fase);
                return;
            }

            setTeleRegistroId(normalizedId);
            setTeleFase(fase);
            setTeleTipo(tipo);
            setTeleOpen(true);
            setAcaoOpen(false);
        },
        [registrarAcaoDoQuadro],
    );

    const confirmarAcaoSilenciosaQuadro = useCallback(
        async (fase: string) => {
            const id = teleRegistroId ?? acaoId;
            if (id == null) return;

            const statusCode = normalizarStatus(fase) || fase;
            const current = registros.find((x) => String((x as any).id) === String(id));

            let session: Awaited<ReturnType<typeof getCurrentOfflineSession>> = null;
            try {
                session = await getCurrentOfflineSession({
                    refreshIfOnline: true,
                    allowCachedOnNetworkFailure: false,
                });
            } catch {
                session = null;
            }

            let ocorreuEm = new Date().toISOString();
            try {
                ocorreuEm = (await getOperationalTimestamp()).occurredAt || ocorreuEm;
            } catch {
                // fallback local
            }

            let deviceId = "";
            try {
                deviceId = await getOfflineDeviceId();
            } catch {
                // opcional
            }

            const json = await enviarRegistroPHP({
                acao: "atualizar_status",
                id,
                status: statusCode,
                operation_id: newOfflineId("status-op"),
                ocorreu_em: ocorreuEm,
                ...(deviceId ? { device_id: deviceId } : {}),
                ...(session?.userId ? { usuario_id: session.userId } : {}),
                origem: "online",
                status_anterior: current?.status || undefined,
                ...(statusCode === "fase03" || statusCode === "fase04" ? { confirmar: true } : {}),
            } as any);

            if (!json?.sucesso) {
                throw new Error(String(json?.msg || json?.erro || "Erro ao atualizar status."));
            }

            const atualizados = await carregarRegistrosAtuaisQuadro();
            setRegistros(atualizados);
            writeLS("qa_registros", atualizados);
        },
        [teleRegistroId, acaoId, registros],
    );

    const handleCopy = useCallback(async () => {
        if (!detail) return;
        const text = buildClipboardText(detail, matLookup);
        try {
            await navigator.clipboard.writeText(text);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch {
            const ta = document.createElement("textarea");
            ta.value = text;
            ta.style.position = "fixed";
            ta.style.left = "-9999px";
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            try {
                document.execCommand("copy");
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
            } finally {
                document.body.removeChild(ta);
            }
        }
    }, [detail, matLookup]);

    const carregarHistoricoDoDetalhe = useCallback(async (r: Registro) => {
        setDetailLogs([]);
        setDetailLogsError(null);
        setDetailLogsLoading(true);

        try {
            const sepId =
                (r as any).sepultamento_id ??
                (r as any).sepultamentoId ??
                (r as any).id ??
                (r as any).id_atendimento ??
                (r as any).codigo;

            if (!sepId) {
                console.warn("Registro sem sepultamento_id para histórico:", r);
                setDetailLogs([]);
                return;
            }

            const BASE = `${API_PHP}/historico_sepultamentos.php?log=1&id=${encodeURIComponent(String(sepId))}`;
            const url = `${BASE}&_ts=${Date.now()}`;

            const json: any = await fetchJsonFast<any>(url, { ttlMs: 20_000, cacheKey: `hist_${sepId}` });

            let logs: LogItem[] = [];
            if (Array.isArray(json)) logs = json as LogItem[];
            else if (json?.sucesso && Array.isArray(json.dados)) logs = json.dados as LogItem[];

            logs = [...logs].sort((a, b) => parseLogTs(a.datahora) - parseLogTs(b.datahora));
            setDetailLogs(logs);
        } catch (e) {
            console.error(e);
            setDetailLogsError("Não foi possível carregar o histórico deste atendimento.");
        } finally {
            setDetailLogsLoading(false);
        }
    }, []);

    const toggleTimelineDetalhe = useCallback(async () => {
        if (!detail) return;
        const next = !detailTimelineOpen;
        setDetailTimelineOpen(next);

        if (next && !detailLogsLoading && detailLogs.length === 0 && !detailLogsError) {
            await carregarHistoricoDoDetalhe(detail);
        }
    }, [detail, detailTimelineOpen, detailLogsLoading, detailLogs.length, detailLogsError, carregarHistoricoDoDetalhe]);

    const obsList = useCallback(
        (missing: string[]) => (missing.length ? `Pendências: ${missing.map((k) => LABELS[k] ?? k).join(", ")}.` : "Completo."),
        []
    );

    const missingEtapa0 = useCallback((r: Registro) => ["falecido", "contato", "religiao", "convenio"].filter((k) => !isFilled(r, k)), []);
    const missingEtapa1 = useCallback((r: Registro) => ["urna", "roupa", "assistencia", "tanato"].filter((k) => !isFilled(r, k)), []);
    const missingEtapa2 = useCallback((r: Registro) => {
        const miss: string[] = [];
        if (!isFilled(r, "local_velorio")) miss.push("local_velorio");
        if (!isFilled(r, "data_inicio_velorio")) miss.push("data_inicio_velorio");
        if (!(isFilled(r, "local_sepultamento") || isFilled(r, "local"))) miss.push("local_sepultamento");
        return miss;
    }, []);
    const noteEtapa3 = useCallback((r: Registro) => {
        const hasInicio = isFilled(r, "hora_inicio_velorio");
        const hasFim = isFilled(r, "data_fim_velorio") && isFilled(r, "hora_fim_velorio");
        if (hasInicio && hasFim) return "Horários definidos.";
        if (hasInicio) return "Horário de início definido.";
        if (hasFim) return "Horário de encerramento definido.";
        return "Pendências de horário.";
    }, []);


    const recalcularDensidadeTv = useCallback(() => {
        const el = dashboardContentRef.current;
        if (!el || typeof window === "undefined") return;

        const niveis: QaDensity[] = ["normal", "compact", "dense", "ultra", "micro"];

        let escolhido: QaDensity = "micro";

        for (const nivel of niveis) {
            el.dataset.qaDensity = nivel;

            // Pequena tolerância evita ficar alternando níveis por 1px.
            const cabe = el.scrollHeight <= el.clientHeight + 3;

            if (cabe) {
                escolhido = nivel;
                break;
            }
        }

        el.dataset.qaDensity = escolhido;
        setQaDensity((atual) => (atual === escolhido ? atual : escolhido));
    }, []);

    useLayoutEffect(() => {
        let raf = 0;

        const schedule = () => {
            window.cancelAnimationFrame(raf);
            raf = window.requestAnimationFrame(recalcularDensidadeTv);
        };

        schedule();

        const observer =
            typeof ResizeObserver !== "undefined"
                ? new ResizeObserver(schedule)
                : null;

        if (dashboardContentRef.current) {
            observer?.observe(dashboardContentRef.current);
        }

        window.addEventListener("resize", schedule);

        return () => {
            window.cancelAnimationFrame(raf);
            observer?.disconnect();
            window.removeEventListener("resize", schedule);
        };
    }, [
        recalcularDensidadeTv,
        ativosPagina.length,
        paginaAtualAtendimentos,
        totalPaginasAtendimentos,
        coroasPagina.length,
        paginaAtualCoroas,
        totalPaginasCoroas,
        coroasTv.length,
        clockDate,
    ]);

    return (
        <>
            <style jsx global>{`
                html,
                body,
                #__next,
                body > div {
                    max-width: 100vw !important;
                    overflow: hidden !important;
                }
                * {
                    box-sizing: border-box;
                }
                .qa-page-root {
                    /* A largura vem do espaço que sobra ao lado da barra lateral FIXA (272 px), e não de 100dvw - 132px:
                       aquela conta supunha a barra recolhida em ícones e deixava o quadro 150 px mais largo que a tela. */
                    width: 100% !important;
                    max-width: 1420px !important;
                    margin-left: auto !important;
                    margin-right: auto !important;
                    min-width: 0 !important;
                    overflow: hidden !important;
                }
                @media (max-width: 900px) {
                    .qa-page-root {
                        width: calc(100dvw - 18px) !important;
                        max-width: calc(100dvw - 18px) !important;
                        margin-left: auto !important;
                        margin-right: auto !important;
                    }
                }
                @keyframes qa-drawer-in { from { transform: translateX(32px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
                .qa-drawer-btn { display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; padding: 6px 12px; font-size: 12px; font-weight: 800; text-decoration: none; border: 1px solid transparent; }
                .qa-drawer-btn-main { background: #313C55; color: #FFFFFF; border-color: rgba(255, 255, 255, .28); }
                .qa-drawer-btn-edit { background: #F2CB3F; color: #313C55; }
                .qa-drawer-panel { animation: qa-drawer-in .22s ease-out; border-top-left-radius: 20px; border-bottom-left-radius: 20px; }
                @media (max-width: 640px) { .qa-drawer-panel { border-radius: 0; } }
                @media (prefers-reduced-motion: reduce) { .qa-drawer-panel { animation: none; } }
                /* ===== Gaveta (atendimento e coroa): paleta da marca, nos dois temas ===== */
                .qa-drawer-root[data-tema="claro"] {
                    --d-panel: #F6F8FB; --d-card: #FFFFFF; --d-sunk: #F1F4F8; --d-line: #E3E8F0; --d-text: #313C55; --d-muted: #5B6478;
                    --d-acc: #00AEEC; --d-acctext: #0086B8; --d-accbg: #E6F7FE; --d-ok: #5C7A12; --d-okbg: #EEF5D6; --d-warn: #B45309; --d-warnbg: #FFF1DC; --d-crit: #D93636; --d-critbg: #FDECEC;
                    --d-shadow: 0 1px 2px rgba(49, 60, 85, .06), 0 6px 18px rgba(49, 60, 85, .06);
                }
                .qa-drawer-root[data-tema="escuro"] {
                    --d-panel: #161C2A; --d-card: #232B3F; --d-sunk: #1C2334; --d-line: rgba(255, 255, 255, .12); --d-text: #FFFFFF; --d-muted: #AEB9CF;
                    --d-acc: #00AEEC; --d-acctext: #5CCBF4; --d-accbg: rgba(0, 174, 236, .20); --d-ok: #B3CE52; --d-okbg: rgba(179, 206, 82, .18); --d-warn: #ffb020; --d-warnbg: rgba(255, 176, 32, .14); --d-crit: #ff5a5f; --d-critbg: rgba(255, 90, 95, .15);
                    --d-shadow: none;
                }
                .qa-drawer-root .qa-panel-premium { background: var(--d-panel); border-color: var(--d-line); box-shadow: -10px 0 30px rgba(0, 0, 0, .22); color: var(--d-text); }
                .qa-drawer-root .qa-card-soft { background: var(--d-card); border-color: var(--d-line); }
                .qa-drawer-root .qa-text-muted, .qa-drawer-root .text-muted-foreground { color: var(--d-muted) !important; }
                .qa-drawer-root .text-slate-100, .qa-drawer-root .text-slate-200 { color: var(--d-text) !important; }
                .qa-drawer-root .text-slate-300, .qa-drawer-root .text-slate-400, .qa-drawer-root .text-slate-500 { color: var(--d-muted) !important; }
                .qa-drawer-root [class~="bg-slate-950/70"] { background-color: var(--d-card) !important; }
                .qa-drawer-root [class~="bg-slate-950/35"] { background-color: var(--d-card) !important; box-shadow: var(--d-shadow); }
                .qa-drawer-root [class~="bg-slate-950/55"], .qa-drawer-root [class~="bg-slate-950/45"] { background-color: var(--d-sunk) !important; }
                .qa-drawer-root [class~="bg-slate-900/50"] { background-color: var(--d-card) !important; }
                .qa-drawer-root .bg-slate-800, .qa-drawer-root [class~="bg-slate-800/45"] { background-color: var(--d-sunk) !important; }
                .qa-drawer-root [class~="hover:bg-slate-800"]:hover { background-color: var(--d-sunk) !important; }
                .qa-drawer-root [class~="border-slate-700/70"], .qa-drawer-root [class~="border-slate-700/60"], .qa-drawer-root [class~="border-slate-700/50"], .qa-drawer-root [class~="border-slate-700/45"] { border-color: var(--d-line) !important; }
                .qa-drawer-root .log-entry { background-color: var(--d-card) !important; border-color: var(--d-line) !important; box-shadow: none; }
                .qa-drawer-root .bg-primary\/10 { background-color: var(--d-accbg) !important; }
                .qa-drawer-root .text-primary { color: var(--d-acctext) !important; }
                .qa-drawer-root .rounded-lg.border.bg-background { background-color: var(--d-sunk) !important; border-color: var(--d-line) !important; }
                .qa-drawer-root h4 { text-transform: uppercase; letter-spacing: .08em; font-size: 11px; }

                /* Gaveta da coroa */
                .qc-foto { width: 100%; max-height: 420px; object-fit: contain; border-radius: 12px; background: var(--d-sunk); border: 1px solid var(--d-line); display: block; }
                .qc-sem-foto { border: 1.5px dashed var(--d-line); border-radius: 12px; padding: 22px 14px; text-align: center; font-size: 13px; font-weight: 700; color: var(--d-muted); background: var(--d-sunk); }
                .qc-frase { border-left: 4px solid #F2CB3F; background: var(--d-sunk); border-radius: 10px; padding: 12px 14px; font-size: 16px; font-weight: 800; line-height: 1.35; color: var(--d-text); overflow-wrap: anywhere; }
                .qc-legenda { margin-top: 6px; font-size: 12px; font-weight: 800; color: var(--d-muted); text-align: center; }
                .qc-link { color: var(--d-acctext); font-weight: 800; text-decoration: underline; }

                /* Etiquetas (status e convênio) */
                .qa-tag { display: inline-flex; align-items: center; border-radius: 999px; padding: 3px 10px; font-size: 11px; font-weight: 800; line-height: 1.25; white-space: nowrap; }
                .qa-tag-xs { padding: 2px 8px; font-size: 10px; }
                .qa-tag-status { background: var(--d-accbg, #E6F7FE); color: var(--d-acctext, #0086B8); border: 1px solid var(--d-acc, #00AEEC); }
                .qa-tag-ok { background: var(--d-okbg); color: var(--d-ok); }
                .qa-tag-warn { background: var(--d-warnbg); color: var(--d-warn); }
                .qa-tag-info { background: var(--d-accbg); color: var(--d-acctext); }
                .qa-tag-conv-part { background: #F2CB3F; color: #1d1405; }
                .qa-tag-conv-pref { background: #00AEEC; color: #10233F; }
                .qa-tag-conv-assoc { background: #B3CE52; color: #1d2a05; }
                .qa-tag-conv-adef { background: transparent; color: var(--d-muted, #5B6478); border: 1px dashed currentColor; }

                /* Ícones da linha do tempo */
                .qa-log-ic { flex: none; width: 30px; height: 30px; border-radius: 50%; display: grid; place-items: center; background: var(--d-accbg); color: var(--d-acctext); border: 1.5px solid var(--d-acc); }
                .qa-log-ic span { display: inline-flex; width: 16px; height: 16px; }
                .qa-log-ic svg { width: 100%; height: 100%; }
                .qa-log-ic-dot { background: var(--d-sunk); color: var(--d-muted); border-color: var(--d-line); }
                .qa-panel-premium {
                    background:
                        radial-gradient(circle at top left, rgba(59, 130, 246, 0.12), transparent 34%),
                        linear-gradient(180deg, rgba(15, 23, 42, 0.96), rgba(2, 6, 23, 0.9));
                    border-color: rgba(148, 163, 184, 0.18);
                    box-shadow: 0 18px 50px rgba(0, 0, 0, 0.22);
                }
                .qa-card-soft {
                    background: rgba(15, 23, 42, 0.72);
                    border-color: rgba(148, 163, 184, 0.14);
                }
                .qa-text-muted {
                    color: rgba(203, 213, 225, 0.68);
                }
                .qa-no-scrollbar,
                .qa-no-scrollbar * {
                    scrollbar-width: none !important;
                }
                .qa-no-scrollbar::-webkit-scrollbar,
                .qa-no-scrollbar *::-webkit-scrollbar {
                    display: none !important;
                }
                .qa-truncate-2 {
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                    overflow: hidden;
                }

                /*
                 * COLUNA DATA — alinhamento protegido.
                 * Evita bolinhas, data e convênio invadirem a linha seguinte.
                 */
                .qa-data-cell {
                    display: flex !important;
                    height: 100%;
                    min-height: 0;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    gap: 3px;
                    overflow: hidden;
                    line-height: 1;
                }
                .qa-data-dots,
                .qa-data-date,
                .qa-data-convenio {
                    flex: 0 0 auto;
                    min-height: 0;
                    margin: 0 !important;
                }
                .qa-etapas-dots {
                    gap: 4px !important;
                    line-height: 1;
                }
                .qa-convenio-badge {
                    white-space: nowrap;
                    line-height: 1 !important;
                }

                /*
                 * COROAS — alinhamento compacto padrão.
                 */
                .qa-coroa-field {
                    height: 100%;
                    align-items: center;
                    line-height: 1;
                }
                .qa-coroa-field-icon,
                .qa-coroa-badge-icon {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    flex: 0 0 auto;
                }
                .qa-coroa-field-text {
                    display: flex;
                    min-height: 0;
                    align-items: center;
                }
                .qa-coroa-row > div {
                    min-width: 0;
                    align-self: center;
                }
                .qa-coroa-row .qa-coroa-sub {
                    line-height: 1 !important;
                }

                .qa-coroa-timeline {
                    min-width: 0;
                    white-space: nowrap;
                }

                .qa-coroa-stage-pill {
                    flex: 0 0 auto;
                }

                .qa-coroa-stage-ring,
                .qa-coroa-stage-icon {
                    flex: 0 0 auto;
                }

                /*
                 * AUTO-FIT DA TV
                 *
                 * O visual de Atendimentos permanece normal até faltar espaço.
                 * A coluna Data recebe redução própria para nunca se sobrepor.
                 */
                [data-qa-density="compact"] .qa-atendimento-head {
                    height: 29px !important;
                    font-size: 10px !important;
                }
                [data-qa-density="compact"] .qa-atendimento-row {
                    height: 50px !important;
                    min-height: 50px !important;
                    font-size: 11px !important;
                }
                [data-qa-density="compact"] .qa-atendimento-row .text-\[12px\] {
                    font-size: 11px !important;
                }
                [data-qa-density="compact"] .qa-status-pill {
                    height: 31px !important;
                    width: 29px !important;
                }
                [data-qa-density="compact"] .qa-status-pill-ring {
                    height: 20px !important;
                    width: 20px !important;
                }
                [data-qa-density="compact"] .qa-status-pill-icon {
                    height: 15px !important;
                    width: 15px !important;
                }
                [data-qa-density="compact"] .qa-status-pill-time {
                    font-size: 8px !important;
                }
                [data-qa-density="compact"] .qa-dashboard-content {
                    gap: 10px !important;
                }
                [data-qa-density="compact"] .qa-coroa-head {
                    height: 29px !important;
                    font-size: 10px !important;
                }
                [data-qa-density="compact"] .qa-coroa-row {
                    height: 38px !important;
                    min-height: 38px !important;
                    padding-top: 3px !important;
                    padding-bottom: 3px !important;
                    font-size: 9.5px !important;
                }
                [data-qa-density="compact"] .qa-coroa-sub {
                    font-size: 9.5px !important;
                }

                [data-qa-density="dense"] .qa-atendimento-head {
                    height: 26px !important;
                    font-size: 9.5px !important;
                }
                [data-qa-density="dense"] .qa-atendimento-row {
                    height: 46px !important;
                    min-height: 46px !important;
                    font-size: 10px !important;
                }
                [data-qa-density="dense"] .qa-atendimento-row .text-\[12px\] {
                    font-size: 10px !important;
                }
                [data-qa-density="dense"] .qa-atendimento-row .text-\[11px\] {
                    font-size: 9px !important;
                }
                [data-qa-density="dense"] .qa-status-pill {
                    height: 27px !important;
                    width: 26px !important;
                }
                [data-qa-density="dense"] .qa-status-pill-ring {
                    height: 18px !important;
                    width: 18px !important;
                }
                [data-qa-density="dense"] .qa-status-pill-icon {
                    height: 13px !important;
                    width: 13px !important;
                }
                [data-qa-density="dense"] .qa-status-pill-time {
                    font-size: 7.5px !important;
                }
                [data-qa-density="dense"] .qa-dashboard-content {
                    gap: 8px !important;
                }
                [data-qa-density="dense"] .qa-coroa-titlebar {
                    padding-top: 5px !important;
                    padding-bottom: 5px !important;
                }
                [data-qa-density="dense"] .qa-coroa-head {
                    height: 26px !important;
                    font-size: 9.5px !important;
                }
                [data-qa-density="dense"] .qa-coroa-row {
                    height: 34px !important;
                    min-height: 34px !important;
                    padding-top: 2px !important;
                    padding-bottom: 2px !important;
                    font-size: 9px !important;
                }
                [data-qa-density="dense"] .qa-coroa-sub {
                    margin-top: 0 !important;
                    font-size: 9px !important;
                }

                [data-qa-density="ultra"] .qa-atendimento-head {
                    height: 23px !important;
                    font-size: 8.5px !important;
                }
                [data-qa-density="ultra"] .qa-atendimento-row {
                    height: 42px !important;
                    min-height: 42px !important;
                    font-size: 9px !important;
                }
                [data-qa-density="ultra"] .qa-atendimento-row .text-\[12px\] {
                    font-size: 9px !important;
                }
                [data-qa-density="ultra"] .qa-atendimento-row .text-\[11px\] {
                    font-size: 8px !important;
                }
                [data-qa-density="ultra"] .qa-status-pill {
                    height: 24px !important;
                    width: 23px !important;
                }
                [data-qa-density="ultra"] .qa-status-pill-ring {
                    height: 16px !important;
                    width: 16px !important;
                }
                [data-qa-density="ultra"] .qa-status-pill-icon {
                    height: 12px !important;
                    width: 12px !important;
                }
                [data-qa-density="ultra"] .qa-status-pill-time {
                    margin-top: 1px !important;
                    font-size: 7px !important;
                }
                [data-qa-density="ultra"] .qa-dashboard-content {
                    gap: 6px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-titlebar {
                    padding-top: 4px !important;
                    padding-bottom: 4px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-head {
                    height: 23px !important;
                    font-size: 8.5px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-row {
                    height: 30px !important;
                    min-height: 30px !important;
                    padding-top: 1px !important;
                    padding-bottom: 1px !important;
                    font-size: 8px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-iconbox {
                    height: 24px !important;
                    width: 24px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-sub {
                    margin-top: 0 !important;
                    font-size: 8px !important;
                }

                [data-qa-density="micro"] .qa-atendimento-head {
                    height: 21px !important;
                    font-size: 7.5px !important;
                }
                [data-qa-density="micro"] .qa-atendimento-row {
                    height: 38px !important;
                    min-height: 38px !important;
                    font-size: 8px !important;
                }
                [data-qa-density="micro"] .qa-atendimento-row .text-\[12px\] {
                    font-size: 8px !important;
                }
                [data-qa-density="micro"] .qa-atendimento-row .text-\[11px\] {
                    font-size: 7.5px !important;
                }
                [data-qa-density="micro"] .qa-status-pill {
                    height: 21px !important;
                    width: 20px !important;
                }
                [data-qa-density="micro"] .qa-status-pill-ring {
                    height: 14px !important;
                    width: 14px !important;
                }
                [data-qa-density="micro"] .qa-status-pill-icon {
                    height: 10px !important;
                    width: 10px !important;
                }
                [data-qa-density="micro"] .qa-status-pill-time {
                    margin-top: 0 !important;
                    font-size: 6.5px !important;
                }
                [data-qa-density="micro"] .qa-dashboard-content {
                    gap: 4px !important;
                }
                [data-qa-density="micro"] .qa-coroa-titlebar {
                    padding-top: 3px !important;
                    padding-bottom: 3px !important;
                }
                [data-qa-density="micro"] .qa-coroa-title {
                    font-size: 10px !important;
                }
                [data-qa-density="micro"] .qa-coroa-head {
                    height: 20px !important;
                    font-size: 7.5px !important;
                }
                [data-qa-density="micro"] .qa-coroa-row {
                    height: 27px !important;
                    min-height: 27px !important;
                    padding-top: 1px !important;
                    padding-bottom: 1px !important;
                    font-size: 7.5px !important;
                }
                [data-qa-density="micro"] .qa-coroa-iconbox {
                    height: 20px !important;
                    width: 20px !important;
                }
                [data-qa-density="micro"] .qa-coroa-sub {
                    margin-top: 0 !important;
                    font-size: 7px !important;
                }

                /* DATA: redução interna proporcional, sem colisão. */
                [data-qa-density="compact"] .qa-data-cell {
                    gap: 2px !important;
                }
                [data-qa-density="compact"] .qa-data-date {
                    font-size: 10px !important;
                }
                [data-qa-density="compact"] .qa-convenio-badge {
                    padding: 2px 5px !important;
                    font-size: 8px !important;
                }
                [data-qa-density="compact"] .qa-etapa-dot {
                    width: 5px !important;
                    height: 5px !important;
                }

                [data-qa-density="dense"] .qa-data-cell {
                    gap: 1.5px !important;
                }
                [data-qa-density="dense"] .qa-data-date {
                    font-size: 9px !important;
                }
                [data-qa-density="dense"] .qa-convenio-badge {
                    padding: 1.5px 4px !important;
                    font-size: 7px !important;
                }
                [data-qa-density="dense"] .qa-etapas-dots {
                    gap: 3px !important;
                }
                [data-qa-density="dense"] .qa-etapa-dot {
                    width: 4px !important;
                    height: 4px !important;
                }

                [data-qa-density="ultra"] .qa-data-cell {
                    gap: 1px !important;
                }
                [data-qa-density="ultra"] .qa-data-date {
                    font-size: 8px !important;
                }
                [data-qa-density="ultra"] .qa-convenio-badge {
                    padding: 1px 4px !important;
                    font-size: 6.5px !important;
                }
                [data-qa-density="ultra"] .qa-etapas-dots {
                    gap: 2.5px !important;
                }
                [data-qa-density="ultra"] .qa-etapa-dot {
                    width: 3.5px !important;
                    height: 3.5px !important;
                }

                [data-qa-density="micro"] .qa-data-cell {
                    gap: 0.5px !important;
                }
                [data-qa-density="micro"] .qa-data-date {
                    font-size: 7px !important;
                }
                [data-qa-density="micro"] .qa-convenio-badge {
                    padding: 1px 3px !important;
                    font-size: 6px !important;
                }
                [data-qa-density="micro"] .qa-etapas-dots {
                    gap: 2px !important;
                }
                [data-qa-density="micro"] .qa-etapa-dot {
                    width: 3px !important;
                    height: 3px !important;
                }

                /* COROAS: ícones diminuem junto com a densidade. */
                [data-qa-density="compact"] .qa-coroa-field-icon {
                    width: 12px !important;
                    height: 12px !important;
                }
                [data-qa-density="compact"] .qa-coroa-badge-icon {
                    width: 9px !important;
                    height: 9px !important;
                }
                [data-qa-density="compact"] .qa-coroa-stage-pill {
                    width: 31px !important;
                    height: 31px !important;
                }
                [data-qa-density="compact"] .qa-coroa-stage-ring {
                    width: 19px !important;
                    height: 19px !important;
                }
                [data-qa-density="compact"] .qa-coroa-stage-icon {
                    width: 14px !important;
                    height: 14px !important;
                }
                [data-qa-density="compact"] .qa-coroa-stage-time {
                    font-size: 7.5px !important;
                }
                [data-qa-density="dense"] .qa-coroa-field-icon {
                    width: 11px !important;
                    height: 11px !important;
                }
                [data-qa-density="dense"] .qa-coroa-badge-icon {
                    width: 8px !important;
                    height: 8px !important;
                }
                [data-qa-density="dense"] .qa-coroa-stage-pill {
                    width: 28px !important;
                    height: 28px !important;
                }
                [data-qa-density="dense"] .qa-coroa-stage-ring {
                    width: 17px !important;
                    height: 17px !important;
                }
                [data-qa-density="dense"] .qa-coroa-stage-icon {
                    width: 12px !important;
                    height: 12px !important;
                }
                [data-qa-density="dense"] .qa-coroa-stage-time {
                    font-size: 7px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-field-icon,
                [data-qa-density="micro"] .qa-coroa-field-icon {
                    width: 10px !important;
                    height: 10px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-badge-icon,
                [data-qa-density="micro"] .qa-coroa-badge-icon {
                    width: 7px !important;
                    height: 7px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-stage-pill {
                    width: 25px !important;
                    height: 25px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-stage-ring {
                    width: 15px !important;
                    height: 15px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-stage-icon {
                    width: 11px !important;
                    height: 11px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-stage-time {
                    font-size: 6.5px !important;
                }

                [data-qa-density="micro"] .qa-coroa-stage-pill {
                    width: 22px !important;
                    height: 22px !important;
                }
                [data-qa-density="micro"] .qa-coroa-stage-ring {
                    width: 13px !important;
                    height: 13px !important;
                }
                [data-qa-density="micro"] .qa-coroa-stage-icon {
                    width: 9px !important;
                    height: 9px !important;
                }
                [data-qa-density="micro"] .qa-coroa-stage-time {
                    margin-top: 1px !important;
                    font-size: 6px !important;
                }

                /* Mobile: só compacta os cartões quando realmente faltar altura. */
                [data-qa-density="compact"] .qa-mobile-card {
                    padding: 10px !important;
                }
                [data-qa-density="dense"] .qa-mobile-card {
                    padding: 8px !important;
                }
                [data-qa-density="dense"] .qa-mobile-cards {
                    gap: 6px !important;
                }
                [data-qa-density="ultra"] .qa-mobile-card,
                [data-qa-density="micro"] .qa-mobile-card {
                    padding: 6px !important;
                }
                [data-qa-density="ultra"] .qa-mobile-cards,
                [data-qa-density="micro"] .qa-mobile-cards {
                    gap: 4px !important;
                }
                [data-qa-density="compact"] .qa-coroa-mobile-card {
                    padding: 8px !important;
                }
                [data-qa-density="dense"] .qa-coroa-mobile-card {
                    padding: 6px !important;
                }
                [data-qa-density="ultra"] .qa-coroa-mobile-card,
                [data-qa-density="micro"] .qa-coroa-mobile-card {
                    padding: 5px !important;
                    font-size: 9px !important;
                }

                @media (max-width: 640px) {
                    html,
                    body,
                    #__next,
                    body > div {
                        overflow: hidden !important;
                    }
                }
            `}</style>

            <div className="qa-page-root qa-no-scrollbar mx-auto flex h-[calc(100dvh-var(--header-height)-56px)] max-h-[calc(100dvh-var(--header-height)-56px)] min-w-0 flex-col md:h-[calc(100dvh-var(--header-height)-36px)] md:max-h-[calc(100dvh-var(--header-height)-36px)] gap-4 overflow-hidden px-2 pt-5 pb-2 sm:px-3 sm:pt-6">
                <div ref={gavetaSentinelaRef} className="hidden" aria-hidden />
                {/* Celular e tablet: quadro em abas; muda sozinho entre em pé e deitado */}
                <div className="flex min-h-0 flex-1 flex-col lg:hidden">
                    <QuadroMobile
                        ativos={ativosOrdenados}
                        coroas={coroasOrdenadas}
                        coroasError={coroasTvError}
                        statusLogsById={statusLogsById}
                        nowMs={nowMs}
                        clockTime={clockTime}
                        clockDate={clockDate}
                        avisos={avisosParaExibir}
                        onSelect={showDetail}
                        onSelectCoroa={setCoroaSel}
                    />
                </div>

                {/* Telas largas: rota da TV = quadro de TV; demais rotas = quadro do desktop (cartões) */}
                {rotaTv !== null && (
                    <div className="hidden min-h-0 flex-1 lg:flex">
                        {!rotaTv ? (
                            <QuadroDesktop
                                ativos={ativosOrdenados}
                                coroas={coroasOrdenadas}
                                coroasError={coroasTvError}
                                statusLogsById={statusLogsById}
                                nowMs={nowMs}
                                clockTime={clockTime}
                                clockDate={clockDate}
                                avisos={avisosParaExibir}
                                onSelect={showDetail}
                                onSelectCoroa={setCoroaSel}
                            />
                        ) : (
                            <QuadroTv
                                layout={layoutTv}
                                ativos={ativosPagina}
                                todosAtivos={ativosOrdenados}
                                paginaAtendimentos={paginaAtualAtendimentos}
                                totalPaginasAtendimentos={totalPaginasAtendimentos}
                                coroas={coroasPagina}
                                todasCoroas={coroasOrdenadas}
                                paginaCoroas={paginaAtualCoroas}
                                totalPaginasCoroas={totalPaginasCoroas}
                                coroasError={coroasTvError}
                                statusLogsById={statusLogsById}
                                nowMs={nowMs}
                                clockTime={clockTime}
                                clockDate={clockDate}
                                avisos={avisosParaExibir}
                                onSelect={showDetail}
                                onNaoCoube={tvNaoCoube}
                            />
                        )}
                    </div>
                )}

                {coroaSel && <CoroaDrawer pedido={coroaSel} tema={temaGaveta} nowMs={nowMs} onClose={fecharCoroa} />}

                {acaoOpen && (
                    <AcaoModal
                        open={acaoOpen}
                        setOpen={setAcaoOpen}
                        registros={registros as any}
                        acaoId={acaoId as any}
                        registrarAcao={registrarAcaoDoQuadro}
                        acaoMsg={acaoMsg}
                        acaoSubmitting={acaoSubmitting}
                        estoqueInsuficiente={estoqueInsuficiente}
                        onCloseEstoqueInsuficiente={() => setEstoqueInsuficiente(null)}
                        onVeiculoRequired={handleVeiculoRequired}
                        onFotoAcaoRequired={handleFotoAcaoRequired}
                        onAbrirCadastro={(id) => {
                            window.location.assign(rotaEditar(String(id)));
                        }}
                    />
                )}

                <FotoAcaoModal
                    open={fotoAcaoOpen}
                    onClose={() => setFotoAcaoOpen(false)}
                    registro={
                        fotoAcaoId != null
                            ? ((registros.find((r) => String((r as any).id) === String(fotoAcaoId)) as any) ?? null)
                            : null
                    }
                    registroId={fotoAcaoId as any}
                    fase={fotoAcaoFase}
                    tipo={fotoAcaoTipo}
                    onSaved={async ({ id, fase, offline, photoId, occurredAt }) => {
                        setAcaoId(id != null ? String(id) : null);
                        setFotoAcaoOpen(false);
                        await registrarAcaoDoQuadro(fase, {
                            skipConfirm: true,
                            extra: {
                                offlinePhotoId: offline ? photoId : undefined,
                                photoAlreadyUploaded: !offline,
                                occurredAt,
                            },
                        });
                    }}
                />

                <MateriaisConferenciaModal
                    open={matCheckOpen}
                    itens={matCheckItens}
                    onClose={() => {
                        setMatCheckOpen(false);
                        setMatCheckSaving(false);
                        if (matCheckReturnToAcao) setAcaoOpen(true);
                        setMatCheckReturnToAcao(false);
                    }}
                    onConfirm={async (result?: MateriaisConferenciaResult) => {
                        if (!result) return;
                        try {
                            setMatCheckSaving(true);
                            const registroId = matCheckRegistroId ?? acaoId;
                            if (!registroId) {
                                throw new Error("Não foi possível identificar o atendimento (registro_id).");
                            }

                            let nomeFinal = matCheckFalecidoNome.trim();
                            if (!nomeFinal) {
                                const reg = registros.find((x) => String((x as any).id) === String(registroId));
                                nomeFinal = reg ? resolveFalecidoNomeQuadro(reg) : "";
                            }

                            const itensNormalizados = (result.itens || []).map((it) => ({
                                key: String(it.key),
                                nome: String(it.nome),
                                qtd: Number(it.qtd ?? 0),
                                ok: it.ok ? (1 as const) : (0 as const),
                                nao_conforme: it.naoConforme ? (1 as const) : (0 as const),
                            }));

                            await salvarConferenciaNoPHPQuadro({
                                registro_id: registroId,
                                falecido_nome: nomeFinal,
                                observacao: result.observacao,
                                itens: itensNormalizados,
                            });

                            setMatCheckOpen(false);
                            setMatCheckReturnToAcao(false);
                            setMatCheckSaving(false);

                            await registrarAcaoDoQuadro("fase11", {
                                skipMaterialCheck: true,
                                skipConfirm: true,
                                extra: { materialCheckAlreadyUploaded: true },
                            });
                        } catch (e: any) {
                            setMatCheckSaving(false);
                            window.alert(e?.message || "Erro ao salvar conferência de materiais.");
                        }
                    }}
                />

                <TelemetriaModal
                    ref={teleRef}
                    open={teleOpen}
                    onClose={async () => {
                        setTeleOpen(false);
                        try {
                            const atualizados = await carregarRegistrosAtuaisQuadro();
                            setRegistros(atualizados);
                            writeLS("qa_registros", atualizados);
                        } catch {
                            // polling normal fará nova tentativa
                        }
                    }}
                    registro={
                        teleRegistroId != null
                            ? ((registros.find((r) => String((r as any).id) === String(teleRegistroId)) as any) ?? null)
                            : null
                    }
                    fase={teleFase}
                    tipo={teleTipo}
                    onConfirmAcao={confirmarAcaoSilenciosaQuadro}
                    onStarted={() => undefined}
                    onSaved={async () => {
                        try {
                            const atualizados = await carregarRegistrosAtuaisQuadro();
                            setRegistros(atualizados);
                            writeLS("qa_registros", atualizados);
                        } catch {
                            // polling normal fará nova tentativa
                        }
                    }}
                />

                {matCheckSaving ? (
                    <div className="fixed inset-0 z-[100] grid place-items-center bg-black/20" aria-live="polite">
                        <div className="rounded-xl bg-white px-5 py-3 text-sm font-bold text-[#313C55] shadow-xl dark:bg-[#232B3F] dark:text-white">
                            Salvando conferência…
                        </div>
                    </div>
                ) : null}

                {open && detail && (
                    <DetalheAtendimentoDrawer
                        detail={detail}
                        tema={temaGaveta}
                        nowMs={nowMs}
                        logs={statusLogsById[getRegistroTrackingId(detail)]}
                        onClose={closeDetail}
                        copied={copied}
                        onCopy={handleCopy}
                        timelineOpen={detailTimelineOpen}
                        onToggleTimeline={toggleTimelineDetalhe}
                        onHideTimeline={() => setDetailTimelineOpen(false)}
                        timelineLogs={detailLogs}
                        timelineLoading={detailLogsLoading}
                        timelineError={detailLogsError}
                        matLookup={matLookup}
                        faltam={[...missingEtapa0(detail), ...missingEtapa1(detail), ...missingEtapa2(detail)].map((k) => LABELS[k] ?? k)}
                        onRegistrarAcao={() => abrirRegistrarAcao(detail)}
                        visita={visitaPermitida ? { status: visitaStatusDetalhe, onClick: () => abrirVisita(detail) } : null}
                    />
                )}

                {visitaPermitida && (
                    <Visita
                        open={!!visitaRegistro}
                        onClose={() => setVisitaRegistro(null)}
                        registro={visitaRegistro as any}
                        onSaved={async () => {
                            if (visitaRegistro) await carregarStatusVisitaDetalhe(String(visitaRegistro.id ?? ""));
                        }}
                    />
                )}
            </div>
        </>
    );
}

/* ===== Janela "Informações do atendimento" (padrão do mockup Quadro.dc.html) =====
 * Fundo na cor da marca (#313C55 a 45 %), janela à direita de 540 px, cabeçalho com nome e etiquetas,
 * seções RESUMO · TEMPOS · ETAPAS · LOCAIS · ITENS · OBSERVAÇÕES e rodapé com Registrar ação / Editar / Fechar.
 * No celular ocupa a tela toda e respeita as bordas de cima e de baixo. */
function DetalheAtendimentoDrawer({
    detail,
    tema,
    nowMs,
    logs,
    onClose,
    copied,
    onCopy,
    timelineOpen,
    onToggleTimeline,
    onHideTimeline,
    timelineLogs,
    timelineLoading,
    timelineError,
    matLookup,
    faltam,
    onRegistrarAcao,
    visita,
}: {
    detail: Registro;
    tema: string;
    nowMs: number;
    logs: LogItem[] | undefined;
    onClose: () => void;
    copied: boolean;
    onCopy: () => void;
    timelineOpen: boolean;
    onToggleTimeline: () => void;
    onHideTimeline: () => void;
    timelineLogs: LogItem[];
    timelineLoading: boolean;
    timelineError: string | null | undefined;
    matLookup: any;
    faltam: string[];
    /** Abre o Registrar ação dentro do Quadro (a função é a do Quadro: fecha esta janela e abre o AcaoModal). */
    onRegistrarAcao: () => void;
    /** Botão da visita de avaliação (só para quem tem a permissão). null = não mostra. */
    visita?: { status: VisitaStatus; onClick: () => void } | null;
}) {
    const resumo = useMemo(() => resumirAtendimentoTv(detail, logs, nowMs), [detail, logs, nowMs]);
    const backendId = getRegistroBackendId(detail);

    // Esc fecha; o fundo da página não rola enquanto a janela está aberta.
    useEffect(() => {
        const aoTecla = (e: KeyboardEvent) => {
            if (e.key === "Escape") onClose();
        };
        window.addEventListener("keydown", aoTecla);
        const html = document.documentElement;
        const antes = html.style.overflow;
        html.style.overflow = "hidden";
        return () => {
            window.removeEventListener("keydown", aoTecla);
            html.style.overflow = antes;
        };
    }, [onClose]);

    const statusRaw = String(detail.status || "").toLowerCase();
    const concluido = statusRaw === "fase10" || statusRaw === "fase11" || statusRaw === "concluido";
    const novo = statusRaw === "fase00" || statusRaw === "";
    const chipFundo = concluido ? "bg-[var(--d-okbg)]" : novo ? "bg-[#FCF3CC] dark:bg-[#F2CB3F]/16" : "bg-[var(--d-accbg)]";
    const chipPonto = concluido ? "bg-[#B3CE52]" : novo ? "bg-[#F2CB3F]" : "bg-[#00AEEC]";

    const historico = useMemo(() => {
        return (logs ?? [])
            .map((l) => ({ st: getStatusFromLog(l), ts: parseLogTs(l.datahora), quem: shown(l.usuario, "") }))
            .filter((x) => !!x.st && x.ts > 0)
            .sort((a, b) => a.ts - b.ts)
            .slice(-40);
    }, [logs]);

    const observacoes = [
        ["Atendimento", detail.observacao_atendimento],
        ["Itens", detail.observacao_itens],
        ["Velório", detail.observacao_velorio01],
        ["Sepultamento", detail.observacao_velorio02],
    ]
        .map(([k, v]) => [k, shown(v as string, "")] as const)
        .filter(([, v]) => !!String(v).trim());

    const itens: Array<[string, React.ReactNode]> = [
        ["Urna", shown(detail.urna)],
        ["Roupa", shown(detail.roupa)],
        ["Assistência", shown(detail.assistencia)],
        ["Tanatopraxia", shown(detail.tanato)],
        ["Invol", involSimNao(detail.invol)],
        ["Ornamentação", shown((detail.ornamentacao_tipo ?? detail.ornamentacao) as string)],
    ];
    if (normalizeMateriaisFromRegistro(detail).filter((x) => isRealMaterialForClipboard(x) && !isJsonNoiseLine(x)).length > 0) {
        itens.push(["Materiais", <MateriaisValue key="mat" registro={detail} lookup={matLookup} />]);
    }

    const rotulo = "mb-2 mt-5 text-xs font-extrabold uppercase tracking-[0.12em] text-[var(--d-muted)]";
    const botaoIcone =
        "grid size-11 shrink-0 place-items-center rounded-xl text-[var(--d-text)] hover:bg-black/5 dark:hover:bg-white/10";

    return (
        <div
            className="qa-drawer-root fixed inset-0 z-50 flex items-stretch justify-end overflow-hidden"
            data-tema={tema}
            data-pai-overlay
            data-pai-sem-folga
            role="dialog"
            aria-modal="true"
            aria-label="Informações do atendimento"
            style={{ background: "rgba(49, 60, 85, .45)" }}
            onClick={(e) => {
                if (e.target === e.currentTarget) onClose();
            }}
        >
            <aside
                className="flex h-full w-[540px] max-w-full flex-col bg-[var(--d-card)] text-[var(--d-text)] shadow-[-8px_0_24px_rgba(49,60,85,.18)]"
                style={{ paddingTop: "env(safe-area-inset-top)", animation: "qa-drawer-in .22s ease-out" }}
            >
                {/* Cabeçalho */}
                <div className="flex shrink-0 items-start gap-3 border-b border-[var(--d-line)] px-5 pb-3.5 pt-5 sm:px-6">
                    <div className="min-w-0 flex-1">
                        <div className="text-xs font-extrabold uppercase tracking-[0.12em] text-[var(--d-muted)]">Informações do atendimento</div>
                        <h2 className="mt-1 break-words text-2xl font-extrabold leading-tight">{shown(detail.falecido)}</h2>
                        <div className="mt-2.5 flex flex-wrap items-center gap-2">
                            <ConvenioBadge convenio={detail.convenio} registro={detail} size="xs" />
                            <span className={`inline-flex min-h-7 items-center gap-2 rounded-[14px] px-3 py-1 text-[13px] font-bold ${chipFundo}`}>
                                <span className={`size-2 rounded-full ${chipPonto}`} />
                                {capStatus(detail.status)}
                            </span>
                        </div>
                    </div>
                    <div className="-mr-2 -mt-1.5 flex shrink-0 items-center">
                        <button type="button" onClick={onCopy} className={botaoIcone} aria-label="Copiar informações" title={copied ? "Copiado!" : "Copiar informações"}>
                            {copied ? (
                                <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5" /></svg>
                            ) : (
                                <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>
                            )}
                        </button>
                        <button type="button" onClick={onToggleTimeline} className={`${botaoIcone} ${timelineOpen ? "bg-black/5 dark:bg-white/10" : ""}`} aria-label="Linha do tempo" aria-pressed={timelineOpen} title="Ver linha do tempo deste atendimento">
                            <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" /></svg>
                        </button>
                        <button type="button" onClick={onClose} className={botaoIcone} aria-label="Fechar">
                            <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
                        </button>
                    </div>
                </div>

                {/* Corpo */}
                <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-5 pt-1 sm:px-6" style={{ WebkitOverflowScrolling: "touch" }}>
                    {faltam.length > 0 && (
                        <div className="mt-4 rounded-[14px] border-[1.5px] border-[#F2CB3F] bg-[#FCF3CC] px-3.5 py-3 text-[13px] leading-snug text-[#313C55] dark:bg-[#F2CB3F]/16 dark:text-white">
                            <b>Faltam dados:</b> {faltam.join(", ")}.
                        </div>
                    )}

                    <div className={rotulo}>Resumo</div>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-2.5 text-sm">
                        {([
                            ["Aberto em", tvDataHora(resumo.criadoTs) || "—"],
                            ["Agente", shown(detail.agente)],
                            ["Contato", <ContatoDoAtendimento key="contato" nome={(detail as any).nome_responsavel} telefone={detail.contato} vazio={shown(detail.contato)} />],
                            ["Religião", shown(detail.religiao)],
                            ["Convênio", shown(detail.convenio)],
                            ["Situação", `${resumo.atualLabel} · há ${tvDuracaoTexto(resumo.atualDesdeMs)}`],
                        ] as Array<[string, React.ReactNode]>).map(([k, v]) => (
                            <div key={k} className="min-w-0">
                                <div className="text-xs font-bold text-[var(--d-muted)]">{k}</div>
                                <div className="break-words font-extrabold [overflow-wrap:anywhere]">{v}</div>
                            </div>
                        ))}
                    </div>

                    <div className={rotulo}>Tempos</div>
                    <div className="grid grid-cols-4 gap-2">
                        {TV_ETAPAS.map((step) => {
                            const ms = resumo.durations.get(step.key) ?? 0;
                            const ativo = resumo.activeKey === step.key;
                            const feito = !ativo && ms > 0;
                            return (
                                <div
                                    key={step.key}
                                    className={`rounded-xl border px-1.5 py-2 text-center ${ativo ? "border-[#F2CB3F] bg-[#FCF3CC] dark:bg-[#F2CB3F]/16" : feito ? "border-[#B3CE52] bg-[var(--d-okbg)]" : "border-[var(--d-line)] bg-[var(--d-sunk)]"}`}
                                >
                                    <div className="text-[11px] font-bold leading-tight text-[var(--d-muted)]">{step.label}</div>
                                    <div className="mt-0.5 text-sm font-extrabold tabular-nums">{ativo || feito ? formatDurationMs(ms) : "—"}</div>
                                </div>
                            );
                        })}
                        <div className="rounded-xl border border-[var(--d-line)] bg-[var(--d-sunk)] px-1.5 py-2 text-center">
                            <div className="text-[11px] font-bold leading-tight text-[var(--d-muted)]">Ocioso</div>
                            <div className="mt-0.5 text-sm font-extrabold tabular-nums">{formatDurationMs(resumo.durations.get("idle") ?? 0)}</div>
                        </div>
                        <div className="rounded-xl border border-[var(--d-line)] bg-[var(--d-sunk)] px-1.5 py-2 text-center">
                            <div className="text-[11px] font-bold leading-tight text-[var(--d-muted)]">Total</div>
                            <div className="mt-0.5 text-sm font-extrabold tabular-nums">{formatDurationMs(resumo.totalMs)}</div>
                        </div>
                    </div>

                    {historico.length > 0 && (
                        <>
                            <div className={rotulo}>Etapas registradas</div>
                            <div className="overflow-hidden rounded-[14px] border border-[var(--d-line)]">
                                {historico.map((h, i) => (
                                    <div key={`${h.ts}-${i}`} className="flex items-center gap-3 border-t border-[var(--d-line)] px-3.5 py-2.5 text-sm first:border-t-0">
                                        <span className="min-w-0 flex-1 font-bold">{capStatus(h.st)}</span>
                                        <span className="shrink-0 text-[13px] font-extrabold text-[var(--d-acctext)]">{tvDataHora(h.ts)}</span>
                                        <span className="w-[110px] shrink-0 truncate text-right text-xs text-[var(--d-muted)]">{h.quem}</span>
                                    </div>
                                ))}
                            </div>
                        </>
                    )}

                    <div className={rotulo}>Locais</div>
                    <div className="grid grid-cols-[96px_1fr] gap-x-2 gap-y-1.5 text-sm">
                        <span className="font-extrabold text-[var(--d-muted)]">Velório</span>
                        <span className="font-extrabold">
                            <LocalVelorioQuadro r={detail} />
                            {" · "}
                            {dateOr(detail.data_inicio_velorio)} {timeOr(detail.hora_inicio_velorio)}
                        </span>
                        <span className="font-extrabold text-[var(--d-muted)]">Sepultamento</span>
                        <span className="font-extrabold">
                            {shown(detail.local_sepultamento || detail.local)}
                            {" · "}
                            {dateOr(detail.data_fim_velorio)} {timeOr(detail.hora_fim_velorio)}
                        </span>
                    </div>

                    <div className={rotulo}>Itens</div>
                    <div className="overflow-hidden rounded-[14px] border border-[var(--d-line)]">
                        {itens.map(([k, v]) => (
                            <div key={k} className="flex gap-3 border-t border-[var(--d-line)] px-3.5 py-2.5 text-sm first:border-t-0">
                                <span className="flex-1 font-bold">{k}</span>
                                <span className="max-w-[260px] shrink-0 break-words text-right font-extrabold [overflow-wrap:anywhere]">{v}</span>
                            </div>
                        ))}
                    </div>

                    <div className={rotulo}>Observações</div>
                    <div className="rounded-[14px] bg-[var(--d-sunk)] px-3.5 py-3 text-sm leading-relaxed">
                        {observacoes.length === 0 ? (
                            <span className="text-[var(--d-muted)]">Sem observações.</span>
                        ) : (
                            observacoes.map(([k, v]) => (
                                <p key={k} className="m-0 [&:not(:first-child)]:mt-1.5">
                                    <b>{k}:</b> {v}
                                </p>
                            ))
                        )}
                    </div>

                    <div className={rotulo}>Cadastro preenchido</div>
                    <div className="rounded-[14px] border border-[var(--d-line)] bg-[var(--d-sunk)] p-3">
                        <EtapasRow registro={detail} />
                    </div>

                    {timelineOpen && (
                        <>
                            <div className="mb-2 mt-5 flex items-center justify-between gap-2">
                                <div className="text-xs font-extrabold uppercase tracking-[0.12em] text-[var(--d-muted)]">Linha do tempo</div>
                                <button type="button" onClick={onHideTimeline} className="h-9 rounded-xl border-[1.5px] border-[var(--d-line)] px-3 text-xs font-bold hover:bg-black/5 dark:hover:bg-white/10">
                                    Ocultar
                                </button>
                            </div>
                            <div className="rounded-[14px] border border-[var(--d-line)] p-3">
                                {timelineLoading && <p className="text-sm text-[var(--d-muted)]">Carregando histórico…</p>}
                                {timelineError && <p className="text-sm text-[var(--d-crit)]">{timelineError}</p>}
                                {!timelineLoading && !timelineError && timelineLogs.length === 0 && (
                                    <p className="text-sm text-[var(--d-muted)]">Nenhum log encontrado para este atendimento.</p>
                                )}
                                {!timelineLoading && !timelineError && timelineLogs.length > 0 && <LinhaDoTempoLogs logs={timelineLogs} usuarioVisivel />}
                            </div>
                        </>
                    )}
                </div>

                {/* Rodapé: Registrar ação · Editar · OS · Visita · Fechar — botões padrão (components/atendimentos/BotoesAtendimento.tsx), tamanho grande (48 px) */}
                <div className="flex shrink-0 items-center gap-2.5 border-t border-[var(--d-line)] px-5 pt-3.5 sm:px-6" style={{ paddingBottom: "calc(1.25rem + env(safe-area-inset-bottom))" }}>
                    {backendId ? (
                        <>
                            <BotaoRegistrarAcao grande onClick={onRegistrarAcao} />
                            <BotaoEditar grande href={rotaEditar(backendId)} />
                            {/* OS do atendimento (documento com cifrão): abre a folha da OS; o X volta para o Quadro (08/10/2026) */}
                            <BotaoOS grande href={`/os/minhas?atendimento=${backendId}`} />
                            {visita && <BotaoVisita grande status={visita.status} onClick={visita.onClick} />}
                        </>
                    ) : null}
                    <BotaoFechar grande onClick={onClose} className="ml-auto" />
                </div>
            </aside>
        </div>
    );
}

/* ===== ✅ Avisos em ticker (uma linha, rolando direita -> esquerda) ===== */
function AvisosTicker({ avisos }: { avisos: Aviso[] }) {
    const items = useMemo(() => {
        return (avisos ?? [])
            .map((a) => ({
                usuario: shown(a?.usuario, "").trim(),
                mensagem: shown(a?.mensagem, "").trim(),
            }))
            .filter((x) => x.usuario || x.mensagem);
    }, [avisos]);

    const durationSec = useMemo(() => {
        const totalChars = items.reduce((acc, it) => acc + it.usuario.length + it.mensagem.length + 10, 0);
        const sec = Math.round(totalChars / 10);
        return Math.max(18, Math.min(60, sec));
    }, [items]);

    if (items.length === 0) {
        return <p className="text-[11px] text-muted-foreground">Nenhum aviso no momento.</p>;
    }

    const RenderItems = ({ ariaHidden = false }: { ariaHidden?: boolean }) => (
        <div className="flex items-center gap-7 px-2 py-1 whitespace-nowrap" aria-hidden={ariaHidden ? true : undefined}>
            {items.map((x, i) => (
                <div key={i} className="flex items-center gap-2 text-[12px] font-semibold text-slate-200">
                    {x.usuario ? <strong className="font-bold text-slate-100">{x.usuario}</strong> : null}
                    {x.mensagem ? <span className="text-slate-200">{x.mensagem}</span> : null}
                    <span className="text-slate-500">•</span>
                </div>
            ))}
        </div>
    );

    return (
        <div className="relative w-full overflow-hidden">
            <div className="qa-avisos-track flex w-max" style={{ animationDuration: `${durationSec}s` }}>
                <RenderItems />
                <RenderItems ariaHidden />
            </div>

            <style jsx global>{`
                @keyframes qa-avisos-marquee {
                    0% {
                        transform: translateX(0);
                    }
                    100% {
                        transform: translateX(-50%);
                    }
                }
                .qa-avisos-track {
                    will-change: transform;
                    animation-name: qa-avisos-marquee;
                    animation-timing-function: linear;
                    animation-iteration-count: infinite;
                }
                .qa-avisos-track:hover {
                    animation-play-state: paused;
                }
                @media (prefers-reduced-motion: reduce) {
                    .qa-avisos-track {
                        animation: none !important;
                        transform: none !important;
                    }
                }
            `}</style>
        </div>
    );
}

/* ===== Listas Memoizadas ===== */
const DesktopTable = React.memo(function DesktopTable({
    ativos,
    hiddenCount = 0,
    onSelect,
    statusLogsById,
    nowMs,
}: {
    ativos: Registro[];
    hiddenCount?: number;
    onSelect: (r: Registro) => void;
    statusLogsById: Record<string, LogItem[]>;
    nowMs: number;
}) {
    return (
        <section className="qa-atendimentos-table hidden min-h-0 w-full max-w-full overflow-hidden rounded-xl border qa-panel-premium sm:flex sm:flex-col">
            <div className="qa-atendimento-head grid h-8 shrink-0 grid-cols-[88px_220px_260px_106px_108px_320px] items-center gap-2 border-b border-slate-700/50 bg-slate-800/45 px-3 text-[11px] font-bold text-slate-300">
                <div>Data</div>
                <div>Falecido(a)</div>
                <div>Local</div>
                <div>Sepultamento</div>
                <div>Agente</div>
                <div>Status</div>
            </div>

            <div className="min-h-0 overflow-hidden">
                {ativos.length === 0 ? (
                    <div className="flex h-40 items-center justify-center text-sm qa-text-muted">Nenhum atendimento encontrado.</div>
                ) : (
                    ativos.map((r, i) => {
                        const preenchidas = etapasPreenchidas(r);
                        const trackingId = getRegistroTrackingId(r);
                        return (
                            <div
                                key={trackingId || i}
                                className="qa-atendimento-row grid h-[58px] grid-cols-[88px_220px_260px_106px_108px_320px] items-center gap-2 border-b border-slate-700/45 px-3 text-[12px] text-slate-100 last:border-b-0"
                            >
                                <div className="qa-data-cell min-w-0">
                                    <div className="qa-data-dots flex justify-center">
                                        <EtapasInlineDots filled={preenchidas} />
                                    </div>
                                    <div className="qa-data-date text-center text-[12px] font-semibold leading-none tabular-nums text-slate-100">
                                        {dateOr(r.data)}
                                    </div>
                                    <div className="qa-data-convenio flex justify-center">
                                        <ConvenioBadge convenio={r.convenio} registro={r} size="xs" />
                                    </div>
                                </div>

                                <button
                                    className="min-w-0 text-left text-[12px] font-bold leading-tight text-slate-100 underline-offset-2 hover:underline"
                                    onClick={() => onSelect(r)}
                                    title={shown(r.falecido)}
                                >
                                    <span className="block truncate">{shown(r.falecido)}</span>
                                </button>

                                <div className="min-w-0 text-[12px] font-medium leading-tight text-slate-200" title={shown(r.local_velorio)}>
                                    <div className="qa-truncate-2"><LocalVelorioValue value={r.local_velorio} /></div>
                                </div>

                                <div className="min-w-0 leading-tight">
                                    <div className="text-[11px] font-semibold text-slate-400">{dateDayMonthOr(r.data_fim_velorio)}</div>
                                    <div className="mt-0.5 truncate text-[12px] font-semibold tabular-nums text-slate-100">{timeOr(r.hora_fim_velorio)}</div>
                                </div>

                                <div className="min-w-0 truncate text-[12px] font-semibold text-slate-200" title={shown(r.agente)}>{shown(r.agente)}</div>

                                <StatusTimelineCell registro={r} logs={statusLogsById[trackingId]} nowMs={nowMs} />
                            </div>
                        );
                    })
                )}
            </div>

        </section>
    );
});

const MobileCards = React.memo(function MobileCards({
    ativos,
    hiddenCount = 0,
    onSelect,
    statusLogsById,
    nowMs,
}: {
    ativos: Registro[];
    hiddenCount?: number;
    onSelect: (r: Registro) => void;
    statusLogsById: Record<string, LogItem[]>;
    nowMs: number;
}) {
    return (
        <section className="qa-mobile-cards flex h-full min-h-0 flex-col gap-2 overflow-hidden sm:hidden">
            {ativos.length === 0 ? (
                <div className="qa-panel-premium rounded-2xl border p-4 text-center text-sm qa-text-muted">Nenhum atendimento encontrado.</div>
            ) : (
                ativos.map((r, i) => {
                    const preenchidas = etapasPreenchidas(r);
                    const trackingId = getRegistroTrackingId(r);
                    return (
                        <article key={trackingId || i} className="qa-mobile-card qa-panel-premium overflow-hidden rounded-2xl border p-3">
                            <div className="flex items-start justify-between gap-3">
                                <button
                                    className="min-w-0 text-left text-base font-bold leading-snug text-slate-100"
                                    onClick={() => onSelect(r)}
                                    title={shown(r.falecido)}
                                >
                                    <span className="block truncate">{shown(r.falecido)}</span>
                                </button>
                                <div className="shrink-0 text-right">
                                    <EtapasInlineDots filled={preenchidas} />
                                    <div className="mt-1 text-xs font-bold tabular-nums text-slate-200">{dateOr(r.data)}</div>
                                    <div className="mt-1"><ConvenioBadge convenio={r.convenio} registro={r} size="xs" /></div>
                                </div>
                            </div>

                            <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
                                <div className="min-w-0 rounded-xl border border-slate-700/50 bg-slate-950/35 p-2">
                                    <div className="qa-text-muted">Local</div>
                                    <div className="mt-1 truncate font-semibold text-slate-100"><LocalVelorioValue value={r.local_velorio} /></div>
                                </div>
                                <div className="min-w-0 rounded-xl border border-slate-700/50 bg-slate-950/35 p-2">
                                    <div className="qa-text-muted">Sepultamento</div>
                                    <div className="mt-1 font-semibold text-slate-100">{dateDayMonthOr(r.data_fim_velorio)} • {timeOr(r.hora_fim_velorio)}</div>
                                </div>
                            </div>

                            <div className="mt-2 flex items-center justify-between gap-2 text-xs">
                                <div className="min-w-0 truncate qa-text-muted">Agente: <b className="text-slate-200">{shown(r.agente)}</b></div>
                            </div>

                            <div className="mt-2 rounded-xl border border-slate-700/50 bg-slate-950/35 p-2">
                                <StatusTimelineCell registro={r} logs={statusLogsById[trackingId]} nowMs={nowMs} variant="mobile" />
                            </div>
                        </article>
                    );
                })
            )}

            {hiddenCount > 0 && (
                <div className="qa-panel-premium rounded-xl border px-3 py-2 text-center text-xs font-semibold qa-text-muted">
                    + {hiddenCount} atendimento{hiddenCount === 1 ? "" : "s"} oculto{hiddenCount === 1 ? "" : "s"}
                </div>
            )}
        </section>
    );
});


/* ===== Coroas de Flores — painel inferior da TV ===== */
type CoroaTvIconKey =
    | "flower"
    | "ribbon"
    | "hourglass"
    | "check"
    | "clipboard"
    | "coffin"
    | "person"
    | "pin"
    | "wallet"
    | "package";

function CoroaTvIcon({ type }: { type: CoroaTvIconKey }) {
    const common = {
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: 2,
        strokeLinecap: "round" as const,
        strokeLinejoin: "round" as const,
        className: "h-full w-full",
    };

    switch (type) {
        case "flower":
            return (
                <svg {...common}>
                    <circle cx="12" cy="12" r="2" />
                    <path d="M12 4.5c1.7 1.7 1.7 3.3 0 5-1.7-1.7-1.7-3.3 0-5Z" />
                    <path d="M12 19.5c-1.7-1.7-1.7-3.3 0-5 1.7 1.7 1.7 3.3 0 5Z" />
                    <path d="M4.5 12c1.7-1.7 3.3-1.7 5 0-1.7 1.7-3.3 1.7-5 0Z" />
                    <path d="M19.5 12c-1.7 1.7-3.3 1.7-5 0 1.7-1.7 3.3-1.7 5 0Z" />
                </svg>
            );

        case "ribbon":
            return (
                <svg {...common}>
                    <path d="M8 3h8v8l-4 3-4-3V3Z" />
                    <path d="m8 10-3 11 7-4 7 4-3-11" />
                </svg>
            );

        case "hourglass":
            return (
                <svg {...common}>
                    <path d="M6 3h12" />
                    <path d="M6 21h12" />
                    <path d="M8 3c0 5 8 5 8 9s-8 4-8 9" />
                    <path d="M16 3c0 5-8 5-8 9s8 4 8 9" />
                    <path d="M10 8h4" />
                    <path d="M10 16h4" />
                </svg>
            );

        case "check":
            return (
                <svg {...common}>
                    <circle cx="12" cy="12" r="9" />
                    <path d="m8 12 2.5 2.5L16.5 9" />
                </svg>
            );

        case "clipboard":
            return (
                <svg {...common}>
                    <rect x="5" y="4" width="14" height="17" rx="2" />
                    <path d="M9 4.5V3h6v1.5" />
                    <path d="M8.5 9h7" />
                    <path d="M8.5 13h7" />
                    <path d="M8.5 17h4" />
                </svg>
            );

        case "coffin":
            return (
                <svg {...common}>
                    <path d="M9 3h6l3 5-1.5 13h-9L6 8l3-5Z" />
                    <path d="M12 7v8" />
                    <path d="M9.8 10h4.4" />
                </svg>
            );

        case "person":
            return (
                <svg {...common}>
                    <circle cx="12" cy="8" r="3" />
                    <path d="M5.5 21a6.5 6.5 0 0 1 13 0" />
                </svg>
            );

        case "pin":
            return (
                <svg {...common}>
                    <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
                    <circle cx="12" cy="10" r="2.5" />
                </svg>
            );

        case "wallet":
            return (
                <svg {...common}>
                    <path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H18a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H6.5A2.5 2.5 0 0 1 4 17.5v-10Z" />
                    <path d="M4 9h16" />
                    <path d="M15 14h3" />
                </svg>
            );

        case "package":
        default:
            return (
                <svg {...common}>
                    <path d="M4 8.5 12 4l8 4.5-8 4.5L4 8.5Z" />
                    <path d="M4 8.5V16l8 4 8-4V8.5" />
                    <path d="M12 13v7" />
                </svg>
            );
    }
}

function CoroaIconField({
    icon,
    children,
    title,
}: {
    icon: CoroaTvIconKey;
    children: React.ReactNode;
    title?: string;
}) {
    return (
        <div className="qa-coroa-field flex min-w-0 items-center gap-1.5" title={title}>
            <span className="qa-coroa-field-icon flex h-3.5 w-3.5 shrink-0 items-center justify-center text-[#00AEEC]">
                <CoroaTvIcon type={icon} />
            </span>
            <div className="qa-coroa-field-text min-w-0 truncate leading-none">{children}</div>
        </div>
    );
}

function CoroaTimelinePill({
    icon,
    label,
    time,
    active = false,
    muted = false,
    skipped = false,
}: {
    icon: CoroaTvIconKey;
    label: string;
    time: string;
    active?: boolean;
    muted?: boolean;
    skipped?: boolean;
}) {
    return (
        <div
            className="qa-coroa-stage-pill relative flex h-[34px] w-[34px] shrink-0 flex-col items-center justify-center text-center leading-none"
            title={`${label} • ${skipped ? "Não se aplica" : time}`}
        >
            <div
                className={`qa-coroa-stage-ring relative flex h-[21px] w-[21px] items-center justify-center rounded-full ${active
                    ? "qa-status-active-ring border border-[#22C55E]/90 shadow-[0_0_8px_rgba(34,197,94,.45)]"
                    : "border border-transparent"
                    }`}
            >
                <div
                    className={`qa-coroa-stage-icon relative flex h-[16px] w-[16px] items-center justify-center ${active
                        ? "qa-status-blink text-[#22C55E]"
                        : "text-[#00AEEC]"
                        } ${muted ? "opacity-[0.14]" : ""}`}
                    aria-hidden="true"
                >
                    <CoroaTvIcon type={icon} />
                </div>
            </div>

            <div
                className={`qa-coroa-stage-time mt-[2px] w-full truncate text-[8px] font-black leading-none tabular-nums ${muted
                    ? "text-slate-500/35"
                    : active
                        ? "text-[#22C55E]"
                        : "text-slate-100"
                    }`}
            >
                {time}
            </div>

            {skipped && (
                <span className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center text-[36px] font-semibold leading-none text-[#00AEEC]">
                    ×
                </span>
            )}
        </div>
    );
}

function CoroaTimelineCell({
    pedido,
    nowMs,
    variant = "desktop",
}: {
    pedido: CoroaTvPedido;
    nowMs: number;
    variant?: "desktop" | "mobile";
}) {
    const data = buildCoroaTimeline(pedido, nowMs);

    const etapas = [
        {
            key: "aguardando",
            icon: "hourglass" as CoroaTvIconKey,
            label: "Aguardando",
            ms: data.aguardandoMs,
            active: data.aguardandoActive,
            skipped: false,
        },
        {
            key: "coroa",
            icon: "flower" as CoroaTvIconKey,
            label: "Confecção da Coroa",
            ms: data.coroaMs,
            active: data.coroaActive,
            skipped: data.coroaSkipped,
        },
        {
            key: "faixa",
            icon: "ribbon" as CoroaTvIconKey,
            label: "Confecção da Faixa",
            ms: data.faixaMs,
            active: data.faixaActive,
            skipped: false,
        },
        {
            key: "concluida",
            icon: "check" as CoroaTvIconKey,
            label: "Concluída",
            ms: data.concluidaMs,
            active: data.concluidaActive,
            skipped: false,
        },
    ];

    if (variant === "mobile") {
        return (
            <div className="qa-coroa-timeline flex min-w-0 items-center justify-end gap-1 overflow-hidden">
                {etapas.map((etapa) => {
                    const temTempo = etapa.ms > 0;
                    return (
                        <CoroaTimelinePill
                            key={etapa.key}
                            icon={etapa.icon}
                            label={etapa.label}
                            time={
                                etapa.skipped
                                    ? "00:00"
                                    : temTempo
                                        ? formatDurationMs(etapa.ms)
                                        : "00:00"
                            }
                            active={etapa.active}
                            muted={!etapa.active && !temTempo}
                            skipped={etapa.skipped}
                        />
                    );
                })}
                <StatusBlinkStyle />
            </div>
        );
    }

    return (
        <div className="qa-coroa-timeline flex min-w-0 items-center justify-start gap-1 overflow-visible">
            {etapas.map((etapa) => {
                const temTempo = etapa.ms > 0;

                return (
                    <CoroaTimelinePill
                        key={etapa.key}
                        icon={etapa.icon}
                        label={etapa.label}
                        time={
                            etapa.skipped
                                ? "00:00"
                                : temTempo
                                    ? formatDurationMs(etapa.ms)
                                    : "00:00"
                        }
                        active={etapa.active}
                        muted={!etapa.active && !temTempo}
                        skipped={etapa.skipped}
                    />
                );
            })}

            <StatusBlinkStyle />
        </div>
    );
}

const CoroasTvBoard = React.memo(function CoroasTvBoard({
    pedidos,
    totalPedidos,
    paginaAtual,
    totalPaginas,
    error,
    nowMs,
}: {
    pedidos: CoroaTvPedido[];
    totalPedidos: number;
    paginaAtual: number;
    totalPaginas: number;
    error?: string | null;
    nowMs: number;
}) {
    return (
        <section className="qa-coroas-board shrink-0 overflow-hidden rounded-xl border qa-panel-premium">
            <div className="qa-coroa-titlebar flex h-8 items-center justify-between gap-3 border-b border-slate-700/50 bg-slate-800/45 px-3">
                <div className="flex min-w-0 items-center gap-2">
                    <span className="qa-coroa-iconbox flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-[#00AEEC]/35 bg-[#00AEEC]/10 p-0.5 text-[#00AEEC]">
                        <CoroaTvIcon type="flower" />
                    </span>

                    <div className="min-w-0">
                        <div className="qa-coroa-title truncate text-[12px] font-bold text-slate-100">
                            Coroas de Flores em Confecção
                        </div>
                    </div>

                    <span className="inline-flex min-w-5 shrink-0 items-center justify-center rounded-full bg-slate-700 px-1.5 py-0.5 text-[9px] font-black text-slate-200">
                        {totalPedidos}
                    </span>
                </div>

                <div className="flex shrink-0 items-center gap-2 text-[9px] qa-text-muted">
                    {totalPaginas > 1 && (
                        <span className="hidden sm:inline whitespace-nowrap">
                            Página {paginaAtual + 1}/{totalPaginas} • troca a cada 15s
                        </span>
                    )}

                    {error ? (
                        <>
                            <span className="h-2 w-2 rounded-full bg-amber-400" />
                            <span className="hidden sm:inline">Últimos dados mantidos</span>
                        </>
                    ) : (
                        <>
                            <span className="h-2 w-2 rounded-full bg-emerald-400" />
                            <span className="hidden sm:inline">Atualizado</span>
                        </>
                    )}
                </div>
            </div>

            {/* Desktop/TV — modelo, falecido, entrega, pagamento e timeline */}
            <div className="hidden sm:block">
                <div className="qa-coroa-head grid h-7 grid-cols-[minmax(0,1.45fr)_minmax(0,1.05fr)_minmax(0,1.1fr)_135px_190px] items-center gap-3 border-b border-slate-700/50 bg-slate-900/35 px-4 text-[9px] font-bold leading-none text-slate-400">
                    <div>Coroa(s)</div>
                    <div>Falecido(a)</div>
                    <div>Entrega</div>
                    <div>Pagamento</div>
                    <div>Status</div>
                </div>

                {pedidos.length === 0 ? (
                    <div className="flex h-14 items-center justify-center text-[11px] qa-text-muted">
                        Nenhuma coroa em confecção no momento.
                    </div>
                ) : (
                    <div>
                        {pedidos.map((pedido) => {
                            const modelo = coroaModelos(pedido);
                            const solicitante = shown(pedido.solicitante, "a definir");

                            return (
                                <div
                                    key={pedido.id}
                                    className="qa-coroa-row grid h-[42px] min-h-[42px] grid-cols-[minmax(0,1.45fr)_minmax(0,1.05fr)_minmax(0,1.1fr)_135px_190px] items-center gap-3 overflow-hidden border-b border-slate-700/45 px-4 py-1 text-[10px] leading-none text-slate-100 last:border-b-0"
                                >
                                    {/* Coroa: nome do modelo + solicitante abaixo */}
                                    <div className="min-w-0 overflow-hidden">
                                        <CoroaIconField icon="flower" title={modelo}>
                                            <span className="block truncate font-semibold text-slate-100">
                                                {modelo}
                                            </span>
                                        </CoroaIconField>

                                        <div
                                            className="qa-coroa-sub mt-1 truncate pl-5 text-[8px] leading-none qa-text-muted"
                                            title={`Solicitante: ${solicitante}`}
                                        >
                                            {solicitante}
                                        </div>
                                    </div>

                                    {/* Falecido antes de Entrega */}
                                    <div className="min-w-0 overflow-hidden">
                                        <CoroaIconField
                                            icon="coffin"
                                            title={shown(pedido.falecido, "a definir")}
                                        >
                                            <span className="block truncate font-medium text-slate-200">
                                                {shown(pedido.falecido, "a definir")}
                                            </span>
                                        </CoroaIconField>
                                    </div>

                                    <div className="min-w-0 overflow-hidden">
                                        <CoroaIconField
                                            icon="pin"
                                            title={shown(pedido.local_entrega, "a definir")}
                                        >
                                            <span className="block truncate font-medium text-slate-200">
                                                {shown(pedido.local_entrega, "a definir")}
                                            </span>
                                        </CoroaIconField>
                                    </div>

                                    <div className="min-w-0 overflow-hidden">
                                        <span
                                            className={`inline-flex max-w-full items-center gap-1 whitespace-nowrap rounded-full border px-2 py-0.5 text-[8.5px] font-bold leading-none ${coroaPagamentoClass(
                                                pedido
                                            )}`}
                                        >
                                            <span className="qa-coroa-badge-icon h-2.5 w-2.5 shrink-0">
                                                <CoroaTvIcon type="wallet" />
                                            </span>
                                            <span>{coroaPagamentoLabel(pedido)}</span>
                                        </span>
                                    </div>

                                    <div className="min-w-0 overflow-visible">
                                        <CoroaTimelineCell
                                            pedido={pedido}
                                            nowMs={nowMs}
                                        />
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            {/* Mobile — mesmas informações essenciais e timeline */}
            <div className="grid gap-2 p-2 sm:hidden">
                {pedidos.length === 0 ? (
                    <div className="rounded-xl border border-slate-700/50 bg-slate-950/35 p-3 text-center text-xs qa-text-muted">
                        Nenhuma coroa em confecção.
                    </div>
                ) : (
                    pedidos.map((pedido) => {
                        const modelo = coroaModelos(pedido);
                        const solicitante = shown(pedido.solicitante, "a definir");

                        return (
                            <article
                                key={pedido.id}
                                className="qa-coroa-mobile-card overflow-hidden rounded-xl border border-slate-700/50 bg-slate-950/35 p-2.5"
                            >
                                <div className="min-w-0">
                                    <CoroaIconField icon="flower" title={modelo}>
                                        <span className="block truncate font-semibold text-slate-100">
                                            {modelo}
                                        </span>
                                    </CoroaIconField>
                                    <div className="qa-coroa-sub mt-1 truncate pl-5 text-[8px] leading-none qa-text-muted">
                                        {solicitante}
                                    </div>
                                </div>

                                <div className="mt-2 grid min-w-0 grid-cols-2 gap-2 text-[10px]">
                                    <div className="min-w-0 overflow-hidden">
                                        <CoroaIconField
                                            icon="coffin"
                                            title={shown(pedido.falecido, "a definir")}
                                        >
                                            <span className="block truncate">
                                                {shown(pedido.falecido, "a definir")}
                                            </span>
                                        </CoroaIconField>
                                    </div>

                                    <div className="min-w-0 overflow-hidden">
                                        <CoroaIconField
                                            icon="pin"
                                            title={shown(pedido.local_entrega, "a definir")}
                                        >
                                            <span className="block truncate">
                                                {shown(pedido.local_entrega, "a definir")}
                                            </span>
                                        </CoroaIconField>
                                    </div>
                                </div>

                                <div className="mt-2 flex min-w-0 items-center justify-between gap-2">
                                    <span
                                        className={`inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full border px-2 py-0.5 text-[8.5px] font-bold leading-none ${coroaPagamentoClass(
                                            pedido
                                        )}`}
                                    >
                                        <span className="qa-coroa-badge-icon h-2.5 w-2.5 shrink-0">
                                            <CoroaTvIcon type="wallet" />
                                        </span>
                                        {coroaPagamentoLabel(pedido)}
                                    </span>

                                    <CoroaTimelineCell
                                        pedido={pedido}
                                        nowMs={nowMs}
                                        variant="mobile"
                                    />
                                </div>
                            </article>
                        );
                    })
                )}
            </div>
        </section>
    );
});

/* =========================================================
   QUADRO TV — novo visual (tela 1920×1080 reduzida por igual)
   Usa os mesmos dados, histórico e regras do quadro:
   buildStatusSegments, getStatusDisplayData, isStatusStepSkipped,
   atendimentoDeveFicarNoQuadro, buildCoroaTimeline.
   ========================================================= */

/** Limites dos alertas visuais — ajuste aqui. */
const TV_LIMITE_PARADO_MS = 24 * 60 * 60 * 1000; // vermelho: mesma situação há 24 h ou mais
const TV_TOLERANCIA_HORARIO_MS = 0; // âmbar: passou do horário marcado para INICIAR o velório/sepultamento sem a fase de início

type TvLayout = {
    coroasModo: "nenhuma" | "faixa" | "lado";
    compacto: boolean;
    atendimentosPorPagina: number;
    coroasPorPagina: number;
};

/**
 * Distribuição da tela conforme o volume:
 * - sem coroas: linha discreta; até 4 pedidos: faixa embaixo; 5+: coluna à direita;
 * - atendimentos ficam compactos quando não cabem no tamanho normal;
 * - o que não couber vai para a próxima página (troca automática).
 */
function calcularLayoutTv(totalAtendimentos: number, totalPedidosCoroa: number): TvLayout {
    const coroasModo: TvLayout["coroasModo"] =
        totalPedidosCoroa === 0 ? "nenhuma" : totalPedidosCoroa <= 4 ? "faixa" : "lado";
    const limiteNormal = coroasModo === "faixa" ? 3 : 4;
    const compacto = coroasModo === "lado" || totalAtendimentos > limiteNormal;
    // Compacto: 5 por página (4 com a faixa de coroas), para caber o local do velório e do sepultamento.
    const atendimentosPorPagina = compacto ? (coroasModo === "faixa" ? 4 : 5) : limiteNormal;
    // Coluna lateral: 4 pedidos por página, com espaço para a linha de atraso.
    const coroasPorPagina = 4;
    return { coroasModo, compacto, atendimentosPorPagina, coroasPorPagina };
}

const TV_ETAPAS = STATUS_STEPS.filter((s) => s.key !== "idle");
function tvDataHora(ts: number): string {
    if (!ts || !Number.isFinite(ts)) return "";
    const d = new Date(ts);
    return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function tvDuracaoTexto(ms: number): string {
    const min = Math.max(0, Math.floor(ms / 60000));
    const h = Math.floor(min / 60);
    const m = min % 60;
    return h ? `${h} h ${String(m).padStart(2, "0")} min` : `${m} min`;
}

function tvHorarioMarcado(data?: string, hora?: string): number {
    const d = String(data ?? "").trim();
    const h = String(hora ?? "").trim();
    if (!/^\d{4}-\d{2}-\d{2}/.test(d) || d.startsWith("0000")) return 0;
    if (!h || h.startsWith("00:00")) return 0;
    return parseLogTs(`${d.slice(0, 10)} ${h.length === 5 ? `${h}:00` : h}`);
}

type TvResumo = {
    registro: Registro;
    trackingId: string;
    durations: Map<string, number>;
    activeKey?: string;
    atualKey: string;
    atualLabel: string;
    atualDesdeMs: number;
    atualResponsavel: string;
    totalMs: number;
    criadoTs: number;
    /** Quem abriu o atendimento (histórico "criou"). O campo agente do registro é o da última ação. */
    abertoPor: string;
    alerta?: { nivel: "crit" | "warn"; texto: string };
};

/** Quem abriu: autor do registro "criou" do histórico. Sem ele (histórico ainda não carregado), fica vazio e a tela usa o agente. */
function quemAbriuAtendimento(logs: LogItem[] | undefined): string {
    const criou = (logs ?? []).find((log) => String(log.acao ?? "").trim().toLowerCase() === "criou" && String(log.usuario ?? "").trim() !== "");
    return criou ? shown(criou.usuario, "") : "";
}

function resumirAtendimentoTv(r: Registro, logs: LogItem[] | undefined, nowMs: number): TvResumo {
    const segments = buildStatusSegments(r, logs, nowMs);
    const { durations, activeKey } = getStatusDisplayData(segments);
    const atual = segments[segments.length - 1];
    const atualKey = atual?.key ?? normalizarStatus(r.status) ?? "aguardando";
    const atualDesdeMs = atual ? Math.max(0, nowMs - atual.start) : 0;
    const totalMs = Math.max(0, nowMs - (segments[0]?.start ?? nowMs));

    let atualResponsavel = "";
    for (const log of [...(logs ?? [])].reverse()) {
        if (getStatusFromLog(log) === atualKey && log.usuario) {
            atualResponsavel = shown(log.usuario, "");
            break;
        }
    }

    let alerta: TvResumo["alerta"];
    if (atualDesdeMs >= TV_LIMITE_PARADO_MS) {
        alerta = { nivel: "crit", texto: "Na mesma situação há mais de 24 h" };
    } else {
        // Atraso conta para o INÍCIO da ação: o velório começa na Entrega de corpo (fase08)
        // e o sepultamento no Transportando p/ sepultamento (fase09). Depois de iniciado,
        // a demora (por opção da família, por exemplo) não conta como atraso da empresa.
        const rank = statusFlowRank(atualKey);
        const sepMarcado = tvHorarioMarcado(r.data_fim_velorio, r.hora_fim_velorio);
        const velMarcado = tvHorarioMarcado(r.data_inicio_velorio, r.hora_inicio_velorio);
        if (rotaAtivaLegado(r.realiza_sepultamento) && sepMarcado && rank < statusFlowRank("fase09") && nowMs > sepMarcado + TV_TOLERANCIA_HORARIO_MS) {
            alerta = { nivel: "warn", texto: `${tvDuracaoTexto(nowMs - sepMarcado)} de atraso para iniciar o sepultamento (${timeOr(r.hora_fim_velorio)})` };
        } else if (rotaAtivaLegado(r.realiza_velorio) && velMarcado && rank < statusFlowRank("fase08") && nowMs > velMarcado + TV_TOLERANCIA_HORARIO_MS) {
            alerta = { nivel: "warn", texto: `${tvDuracaoTexto(nowMs - velMarcado)} de atraso para iniciar o velório (${timeOr(r.hora_inicio_velorio)})` };
        }
    }

    return {
        registro: r,
        trackingId: getRegistroTrackingId(r),
        durations,
        activeKey,
        atualKey,
        atualLabel: getStatusStepInfo(atualKey).label,
        atualDesdeMs,
        atualResponsavel,
        totalMs,
        criadoTs: getRegistroCreatedTs(r, logs, nowMs),
        abertoPor: quemAbriuAtendimento(logs),
        alerta,
    };
}

/* Prazo de produção das coroas: conta do pedido até a coroa ficar pronta (finalizada).
 * Natural: 2 h. Artificial (pedido só com coroas artificiais): 1 h. */
const COROA_PRAZO_NATURAL_MS = 120 * 60 * 1000;
const COROA_PRAZO_ARTIFICIAL_MS = 60 * 60 * 1000;

type CoroaAtraso = { longo: string };


/** Coroa atrasada: passou do prazo de produção desde o pedido e ainda não ficou pronta. */
function coroaAtrasoTv(pedido: CoroaTvPedido, nowMs: number): CoroaAtraso | undefined {
    if (parseLogTs(pedido.finalizada_em || undefined) > 0 || parseLogTs(pedido.entregue_em || undefined) > 0) return undefined;
    const st = normalizarTextoCoroa(pedido.status);
    if (st === "finalizada" || st === "entregue") return undefined;
    const criadoTs = parseLogTs(pedido.criado_em || undefined);
    if (!criadoTs) return undefined;
    const artificial = coroaSomenteArtificial(pedido);
    const prazo = artificial ? COROA_PRAZO_ARTIFICIAL_MS : COROA_PRAZO_NATURAL_MS;
    const decorrido = nowMs - criadoTs;
    if (decorrido <= prazo) return undefined;
    return { longo: `Atrasada: ${tvDuracaoTexto(decorrido)} do pedido (prazo ${artificial ? "1 h" : "2 h"})` };
}

function tvConvenioClasse(convenio?: string): string {
    const kind = normalizeConvenio(convenio);
    if (kind === "Prefeitura") return "tv-chip tv-chip-pref";
    if (kind === "Particular") return "tv-chip tv-chip-part";
    if (kind === "Associado") return "tv-chip tv-chip-assoc";
    return "tv-chip tv-chip-adef";
}

function TvLinhaAtendimento({ resumo, onSelect }: { resumo: TvResumo; onSelect: (r: Registro) => void }) {
    const r = resumo.registro;
    const rankAtual = statusFlowRank(resumo.atualKey);
    const ocioso = resumo.durations.get("idle") ?? 0;
    const semVelorio = !rotaAtivaLegado(r.realiza_velorio);
    const semSepultamento = !rotaAtivaLegado(r.realiza_sepultamento);
    const sepultamentoTxt = semSepultamento
        ? "Sem sepultamento pelo PAI"
        : `${shown(r.local_sepultamento || r.local)} · ${dateDayMonthOr(r.data_fim_velorio)} ${timeOr(r.hora_fim_velorio)}`;

    return (
        <article
            className={`tv-row ${resumo.alerta ? `tv-row-${resumo.alerta.nivel}` : ""} ${mobClasseConv(r.convenio).replace("qm-conv-", "tv-conv-")}`}
            onClick={() => onSelect(r)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => (e.key === "Enter" ? onSelect(r) : undefined)}
            title="Ver detalhes do atendimento"
        >
            <div className="tv-who">
                <div className="tv-name">{shown(r.falecido)}</div>
                <div className="tv-meta">
                    <span className={tvConvenioClasse(r.convenio)}>{rotuloConvenioRegistro(r)}</span>
                    <span>Aberto {tvDataHora(resumo.criadoTs)} · {resumo.abertoPor || shown(r.agente)}</span>
                </div>
                <div className="tv-place">
                    <span className="tv-place-vel">{semVelorio ? "Sem velório" : <LocalVelorioValue value={r.local_velorio} />}</span>
                    <span className="tv-place-sep">→ {sepultamentoTxt}</span>
                </div>
            </div>

            <div className="tv-now">
                <div className="tv-state"><span className="tv-pulse" />{resumo.atualLabel}</div>
                <div className="tv-since">
                    há <b>{tvDuracaoTexto(resumo.atualDesdeMs)}</b>
                    {resumo.atualResponsavel ? ` · ${resumo.atualResponsavel}` : ""}
                </div>
                {resumo.alerta && (
                    <div className={`tv-flag tv-flag-${resumo.alerta.nivel}`}>{resumo.alerta.nivel === "crit" ? "⚠" : "⏱"} {resumo.alerta.texto}</div>
                )}
            </div>

            <div className="tv-track">
                {TV_ETAPAS.map((step) => {
                    const skipped = isStatusStepSkipped(r, step.key);
                    const duracao = resumo.durations.get(step.key) ?? 0;
                    const ativo = !skipped && resumo.activeKey === step.key;
                    const feito = !skipped && !ativo && (duracao > 0 || rankAtual > statusFlowRank(step.key));
                    const cls = skipped ? "tv-step tv-step-na" : ativo ? "tv-step tv-step-live" : feito ? "tv-step tv-step-done" : "tv-step";
                    return (
                        <div key={step.key} className={cls} title={`${step.label} • ${skipped ? "Não se aplica" : formatDurationMs(duracao)}`}>
                            <div className={`tv-node ${ativo ? "qa-status-active-ring" : ""}`}>
                                <span className={`tv-node-icon ${ativo ? "qa-status-blink" : ""}`}><StatusIcon type={step.icon} /></span>
                            </div>
                            <div className="tv-t">{skipped ? "não se aplica" : ativo || feito ? formatDurationMs(duracao) : "—"}</div>
                        </div>
                    );
                })}
                <div className="tv-tot">
                    <div
                        className={`tv-box tv-box-ocioso ${resumo.activeKey === "idle" ? "tv-box-live qa-status-active-ring" : ""} ${ocioso >= TV_LIMITE_PARADO_MS ? "tv-box-crit" : ""}`}
                        title="Tempo ocioso"
                    >
                        <span className={`tv-box-ic ${resumo.activeKey === "idle" ? "qa-status-blink" : ""}`} aria-label="Ocioso"><StatusIcon type="clockPause" /></span>
                        <b>{formatDurationMs(ocioso)}</b>
                    </div>
                    <div className="tv-box" title="Tempo total">
                        <span className="tv-box-ic" aria-label="Total"><StatusIcon type="clock" /></span>
                        <b>{formatDurationMs(resumo.totalMs)}</b>
                    </div>
                </div>
            </div>
        </article>
    );
}

function TvCartaoCoroa({ pedido, nowMs, atraso }: { pedido: CoroaTvPedido; nowMs: number; atraso?: CoroaAtraso }) {
    const t = buildCoroaTimeline(pedido, nowMs);
    const etapas = [
        { key: "aguardando", icon: "hourglass" as CoroaTvIconKey, label: "Aguardando", ms: t.aguardandoMs, ativo: t.aguardandoActive, pulado: false },
        { key: "coroa", icon: "flower" as CoroaTvIconKey, label: "Coroa", ms: t.coroaMs, ativo: t.coroaActive, pulado: t.coroaSkipped },
        { key: "faixa", icon: "ribbon" as CoroaTvIconKey, label: "Faixa", ms: t.faixaMs, ativo: t.faixaActive, pulado: false },
        { key: "concluida", icon: "check" as CoroaTvIconKey, label: "Concluída, aguardando entrega", ms: t.concluidaMs, ativo: t.concluidaActive, pulado: false },
    ];
    const ativas = etapas.filter((e) => e.ativo);
    const qtd = coroaQuantidade(pedido);
    const pago = coroaPagamentoLabel(pedido) === "Pago";
    const agora = ativas.length
        ? ativas.map((e) => `${e.label} há ${tvDuracaoTexto(e.ms)}`).join(" · ")
        : coroaStatusLabel(pedido.status);
    const hora = coroaDataHora(pedido.criado_em);

    return (
        <div className={`tv-cr ${atraso ? "tv-cr-late" : ""}`}>
            <div className="tv-cr-m">{qtd > 1 ? `${qtd}× ` : ""}{coroaModelos(pedido)}</div>
            <div className="tv-cr-s">Solicitante: <b>{shown(pedido.solicitante, "a definir")}</b></div>
            <div className="tv-cr-f">
                {shown(pedido.falecido, "a definir")} · {shown(pedido.local_entrega, "entrega a definir")}
                {hora ? ` · ${hora}` : ""}
            </div>
            <div className="tv-cr-foot">
                <span className="tv-origem">Origem: {coroaOrigemLabel(pedido.origem)}</span>
                <span className={`tv-pay ${pago ? "tv-pay-ok" : "tv-pay-pend"}`}>{pago ? "Pago" : "Aguardando pagamento"}</span>
                {atraso && <span className="tv-cr-late-t">⏱ {atraso.longo}</span>}
            </div>
            <div className="tv-cr-e">{agora}</div>
            <div className="tv-mini">
                {etapas.map((e) => (
                    <i key={e.key} title={`${e.label} • ${e.pulado ? "Não se aplica" : formatDurationMs(e.ms)}`}
                        className={e.pulado ? "tv-mini-na" : e.ativo ? "tv-mini-live qa-status-active-ring" : e.ms > 0 ? "tv-mini-done" : ""}>
                        <span className={e.ativo ? "qa-status-blink" : ""}><CoroaTvIcon type={e.icon} /></span>
                    </i>
                ))}
            </div>
        </div>
    );
}

function TvPaginador({ atual, total, segundos }: { atual: number; total: number; segundos: number }) {
    if (total <= 1) return null;
    return (
        <div className="tv-pager">
            Página {atual + 1} de {total}
            {Array.from({ length: total }, (_, k) => <i key={k} className={k === atual ? "on" : ""} />)}
            <span className="tv-bar"><span key={atual} style={{ animationDuration: `${segundos}s` }} /></span>
        </div>
    );
}

function QuadroTv({
    layout,
    ativos,
    todosAtivos,
    paginaAtendimentos,
    totalPaginasAtendimentos,
    coroas,
    todasCoroas,
    paginaCoroas,
    totalPaginasCoroas,
    coroasError,
    statusLogsById,
    nowMs,
    clockTime,
    clockDate,
    avisos,
    onSelect,
    onNaoCoube,
}: {
    layout: TvLayout;
    ativos: Registro[];
    todosAtivos: Registro[];
    paginaAtendimentos: number;
    totalPaginasAtendimentos: number;
    coroas: CoroaTvPedido[];
    todasCoroas: CoroaTvPedido[];
    paginaCoroas: number;
    totalPaginasCoroas: number;
    coroasError?: string | null;
    statusLogsById: Record<string, LogItem[]>;
    nowMs: number;
    clockTime: string;
    clockDate: string;
    avisos: Aviso[];
    onSelect: (r: Registro) => void;
    onNaoCoube?: (area: "at" | "cr") => void;
}) {
    const hostRef = useRef<HTMLDivElement | null>(null);
    const linhasRef = useRef<HTMLElement | null>(null);
    const coroasListaRef = useRef<HTMLDivElement | null>(null);

    // Nada é cortado: se o texto de uma página não couber na tela, a página passa a ter um item a menos.
    useLayoutEffect(() => {
        if (!onNaoCoube) return;
        const l = linhasRef.current;
        if (l && l.clientHeight > 0 && l.scrollHeight > l.clientHeight + 2 && ativos.length > 1) onNaoCoube("at");
        const c = coroasListaRef.current;
        if (c && c.clientHeight > 0 && c.scrollHeight > c.clientHeight + 2 && coroas.length > 1) onNaoCoube("cr");
    });
    const [escala, setEscala] = useState(0.5);
    const [topo, setTopo] = useState(0);
    const [telaCheia, setTelaCheia] = useState(false);

    // A tela é sempre desenhada em 1920×1080 e reduzida por igual para caber no espaço disponível.
    useLayoutEffect(() => {
        const host = hostRef.current;
        if (!host) return;
        const calc = () => {
            const w = host.clientWidth, h = host.clientHeight;
            if (w > 0 && h > 0) {
                const s = Math.min(w / 1920, h / 1080);
                setEscala(s);
                setTopo(Math.max(0, (h - 1080 * s) / 2));
            }
        };
        calc();
        const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(calc) : null;
        ro?.observe(host);
        window.addEventListener("resize", calc);
        const onFs = () => setTelaCheia(document.fullscreenElement === host);
        document.addEventListener("fullscreenchange", onFs);
        return () => { ro?.disconnect(); window.removeEventListener("resize", calc); document.removeEventListener("fullscreenchange", onFs); };
    }, []);

    const alternarTelaCheia = useCallback(() => {
        const host = hostRef.current;
        if (!host) return;
        if (document.fullscreenElement) void document.exitFullscreen?.();
        else void host.requestFullscreen?.().catch(() => undefined);
    }, []);

    // A janela de detalhes fica fora do quadro; sai da tela cheia antes para ela aparecer.
    const abrirDetalhe = useCallback((r: Registro) => {
        if (document.fullscreenElement) void document.exitFullscreen?.().catch(() => undefined);
        onSelect(r);
    }, [onSelect]);

    const resumos = useMemo(
        () => ativos.map((r) => resumirAtendimentoTv(r, statusLogsById[getRegistroTrackingId(r)], nowMs)),
        [ativos, statusLogsById, nowMs]
    );
    const parados = useMemo(
        () => todosAtivos.filter((r) => resumirAtendimentoTv(r, statusLogsById[getRegistroTrackingId(r)], nowMs).alerta?.nivel === "crit").length,
        [todosAtivos, statusLogsById, nowMs]
    );
    const totalCoroas = todasCoroas.reduce((s, p) => s + coroaQuantidade(p), 0);
    const pagamentosPendentes = todasCoroas.filter((p) => coroaPagamentoLabel(p) !== "Pago").length;

    const coroasAtrasadas = todasCoroas.filter((p) => coroaAtrasoTv(p, nowMs)).length;

    const blocoCoroas = (
        <>
            <h2 className="tv-cor-title">
                Coroas em confecção <span className="tv-n">{totalCoroas}</span>
                {coroasError ? <span className="tv-cor-stale">últimos dados mantidos</span> : null}
            </h2>
            <div className="tv-sum">
                {coroasAtrasadas > 0 ? <b className="tv-sum-late">{coroasAtrasadas} {coroasAtrasadas === 1 ? "atrasada" : "atrasadas"} · </b> : null}
                {pagamentosPendentes} aguardando pagamento · ordem de chegada
            </div>
            <div className="tv-clist" ref={coroasListaRef}>
                {coroas.map((p) => (
                    <TvCartaoCoroa key={p.id} pedido={p} nowMs={nowMs} atraso={coroaAtrasoTv(p, nowMs)} />
                ))}
            </div>
            <TvPaginador atual={paginaCoroas} total={totalPaginasCoroas} segundos={INTERVALO_PAGINACAO_COROAS_MS / 1000} />
        </>
    );

    return (
        <div ref={hostRef} className={`tv-host ${telaCheia ? "tv-host-fs" : ""}`} data-tema="escuro">
            <div className="tv" style={{ top: topo, transform: `translateX(-50%) scale(${escala})` }}>
                <header className="tv-top">
                    {LOGO_PAI_URL ? (
                        <div className="tv-logo"><img src={LOGO_PAI_URL} alt="PAI" /></div>
                    ) : null}
                    <div className="tv-brand">
                        <h1>Quadro de Atendimentos</h1>
                        <div className="tv-sub"><span className="tv-dot-live" />Atualizado em tempo real</div>
                    </div>
                    <div className="tv-counters">
                        <div className="tv-ctr"><b>{todosAtivos.length}</b><span>em andamento</span></div>
                        <div className={`tv-ctr ${parados ? "tv-ctr-alert" : ""}`}><b>{parados}</b><span>parados há mais de 24 h</span></div>
                        <div className="tv-ctr"><b>{totalCoroas}</b><span>coroas em confecção</span></div>
                    </div>
                    <div className="tv-clock">
                        <div className="tv-h">{clockTime}</div>
                        <div className="tv-d">{clockDate}</div>
                    </div>
                </header>

                <section className="tv-body">
                    <div className={`tv-main ${layout.compacto ? "tv-compact" : ""} ${layout.coroasModo === "lado" ? "tv-narrow" : ""}`}>
                        <div className="tv-head">
                            <span>Atendimento</span>
                            <span>Agora</span>
                            <div className="tv-steps-h">
                                {/* etapas identificadas só pelos ícones */}
                            </div>
                        </div>
                        <main className="tv-rows" ref={linhasRef}>
                            {resumos.length === 0 ? (
                                <div className="tv-empty">Nenhum atendimento em andamento.</div>
                            ) : (
                                resumos.map((res, i) => <TvLinhaAtendimento key={res.trackingId || i} resumo={res} onSelect={abrirDetalhe} />)
                            )}
                        </main>
                        <TvPaginador atual={paginaAtendimentos} total={totalPaginasAtendimentos} segundos={INTERVALO_PAGINACAO_ATENDIMENTOS_MS / 1000} />
                    </div>
                    {layout.coroasModo === "lado" && <aside className="tv-side">{blocoCoroas}</aside>}
                </section>

                {layout.coroasModo === "faixa" && <section className="tv-band">{blocoCoroas}</section>}
                {layout.coroasModo === "nenhuma" && (
                    <div className="tv-coroas-line">Coroas de flores em confecção <span className="tv-n">0</span><span className="tv-muted">· nenhuma no momento</span></div>
                )}

                <footer className="tv-ticker">
                    <div className="tv-tag">Avisos</div>
                    <div className="tv-lane"><AvisosTicker avisos={avisos} /></div>
                </footer>
            </div>

            <button type="button" className="tv-fs-btn" onClick={alternarTelaCheia} title={telaCheia ? "Sair da tela cheia" : "Tela cheia"}>
                {telaCheia ? "Sair da tela cheia" : "⛶ Tela cheia"}
            </button>

            <TvStyles />
            <StatusBlinkStyle />
        </div>
    );
}

function TvStyles() {
    return (
        <style jsx global>{`
            .tv-host { position: relative; flex: 1 1 auto; min-height: 0; width: 100%; overflow: hidden; border-radius: 14px; background: var(--page); }
            .tv-host-fs { border-radius: 0; }
            .tv { position: absolute; top: 0; left: 50%; width: 1920px; height: 1080px; transform-origin: top center;
                background: var(--page);
                display: flex; flex-direction: column; gap: 20px; padding: 32px 44px 0; overflow: hidden; color: var(--text); font-variant-numeric: tabular-nums; }
            .tv-fs-btn { position: absolute; right: 10px; bottom: 10px; z-index: 5; font-size: 12px; font-weight: 700; color: var(--text2); background: var(--card);
                border: 1px solid var(--line2); border-radius: 8px; padding: 4px 10px; opacity: .35; transition: opacity .2s; }
            .tv-host:hover .tv-fs-btn { opacity: 1; }

            .tv-top { display: flex; align-items: center; justify-content: space-between; gap: 24px; }
            .tv-logo { flex: none; margin: 0 0 0 -44px; width: 270px; height: 88px; background: #FFFFFF; border-radius: 0 44px 44px 0; display: flex; align-items: center; padding: 0 0 0 44px; box-sizing: border-box; }
            .tv-logo img { height: 60px; width: auto; display: block; }
            .tv-brand { flex: 1; min-width: 0; }
            .tv-brand h1 { margin: 0; font-size: 40px; font-weight: 900; letter-spacing: -.01em; line-height: 1.1; }
            .tv-sub { display: flex; align-items: center; gap: 10px; margin-top: 4px; font-size: 20px; color: var(--text2); font-weight: 700; }
            .tv-dot-live { width: 12px; height: 12px; border-radius: 50%; background: var(--ok); animation: tv-ping 1.6s infinite; }
            @keyframes tv-ping { 0% { box-shadow: 0 0 0 0 rgba(53,224,138,.55); } 70% { box-shadow: 0 0 0 12px rgba(53,224,138,0); } 100% { box-shadow: 0 0 0 0 rgba(53,224,138,0); } }
            .tv-counters { display: flex; gap: 14px; }
            .tv-ctr { background: var(--card); border: 1px solid var(--line); border-radius: 16px; padding: 10px 20px; display: flex; align-items: baseline; gap: 10px; white-space: nowrap; }
            .tv-ctr b { font-size: 36px; font-weight: 900; }
            .tv-ctr span { font-size: 18px; color: var(--text2); font-weight: 700; }
            .tv-ctr-alert b { color: var(--crit); }
            .tv-clock { text-align: right; }
            .tv-h { font-size: 64px; font-weight: 900; line-height: 1; letter-spacing: -.02em; }
            .tv-d { font-size: 20px; color: var(--text2); font-weight: 700; margin-top: 4px; }

            .tv-body { flex: 1; display: flex; gap: 20px; min-height: 0; }
            .tv-main { flex: 1; display: flex; flex-direction: column; gap: 12px; min-width: 0; min-height: 0; }
            .tv-head, .tv-row { display: grid; grid-template-columns: 480px 390px 1fr; gap: 24px; }
            .tv-head { padding: 0 28px; color: var(--text3); font-size: 16px; font-weight: 800; letter-spacing: .12em; text-transform: uppercase; }
            .tv-steps-h, .tv-track { display: grid; grid-template-columns: repeat(6, 1fr) 316px; align-items: center; }
            .tv-steps-h span { text-align: center; font-size: 13px; letter-spacing: 0; white-space: nowrap; }
            .tv-steps-h .tv-steps-h-tot { text-align: right; padding-right: 10px; }
            .tv-rows { flex: 1; display: flex; flex-direction: column; gap: 14px; min-height: 0; overflow: hidden; }
            .tv-empty { font-size: 26px; color: var(--text3); text-align: center; padding: 60px 0; }
            .tv-row { flex: 0 0 auto; min-height: 150px; align-items: center; cursor: pointer;
                background: var(--card); border: 1px solid var(--line); border-radius: 22px; padding: 18px 28px; box-shadow: var(--shadow); }
            .tv-row:hover { border-color: var(--acc); }
            .tv-row-crit { border-color: var(--crit-bd); box-shadow: inset 6px 0 0 var(--crit); }
            .tv-row-warn { border-color: var(--warn-bd); box-shadow: inset 6px 0 0 var(--warn); }

            .tv-who { min-width: 0; }
            .tv-name { font-size: 34px; font-weight: 900; line-height: 1.1; overflow-wrap: anywhere; }
            .tv-meta { display: flex; flex-wrap: wrap; align-items: center; gap: 2px 12px; margin-top: 8px; font-size: 19px; color: var(--text2); font-weight: 700; overflow-wrap: anywhere; }
            .tv-chip { font-size: 17px; font-weight: 900; padding: 3px 12px; border-radius: 999px; color: #1B2640; flex: none; }
            .tv-chip-pref { background: #00AEEC; } .tv-chip-part { background: #F2CB3F; } .tv-chip-assoc { background: #B3CE52; }
            .tv-chip-adef { background: transparent; color: var(--text2); border: 2px dashed var(--text2); }
            .tv-place { margin-top: 8px; font-size: 19px; font-weight: 700; line-height: 1.35; }
            .tv-place span { display: block; overflow-wrap: anywhere; }
            .tv-place-sep { color: var(--text2); }
            .tv-place a { color: var(--acc-text); }

            .tv-now { min-width: 0; border-radius: 16px; padding: 10px 14px; }
            .tv-conv-assoc .tv-now { background: rgba(179, 206, 82, .28); }
            .tv-conv-pref .tv-now { background: rgba(0, 174, 236, .22); }
            .tv-conv-part .tv-now { background: rgba(242, 203, 63, .28); }
            .tv-state { display: flex; align-items: center; gap: 12px; font-size: 27px; font-weight: 900; line-height: 1.1; }
            .tv-pulse { width: 16px; height: 16px; border-radius: 50%; background: var(--live-bd); flex: none; animation: tv-ping-live 1.6s infinite; }
            .tv-since { font-size: 20px; color: var(--text2); font-weight: 700; margin-top: 6px; overflow-wrap: anywhere; }
            .tv-since b { color: var(--text); font-weight: 900; }
            .tv-flag { display: inline-flex; align-items: center; gap: 8px; margin-top: 8px; font-size: 17px; font-weight: 900; padding: 5px 12px; border-radius: 10px; }
            .tv-flag-crit { background: var(--critbg); color: var(--crit); }
            .tv-flag-warn { background: var(--warnbg); color: var(--warn); }

            .tv-step { display: flex; flex-direction: column; align-items: center; gap: 8px; position: relative; }
            .tv-step::before { content: ""; position: absolute; top: 30px; left: calc(-50% + 36px); width: calc(100% - 72px); height: 4px; background: var(--line2); z-index: 0; }
            .tv-step:first-child::before { display: none; }
            .tv-step-done::before, .tv-step-live::before { background: var(--done-bd); }
            .tv-node { position: relative; z-index: 1; width: 64px; height: 64px; border-radius: 50%; display: grid; place-items: center; border: 3px solid var(--line2); background: var(--sunk); color: var(--text3); }
            .tv-t { position: relative; z-index: 1; }
            .tv-node-icon { display: inline-flex; width: 32px; height: 32px; }
            .tv-node-icon svg, .tv-mini-icon svg, .tv-mini i svg { width: 100%; height: 100%; }
            .tv-t { font-size: 21px; font-weight: 900; color: var(--text3); white-space: nowrap; }
            .tv-step-done .tv-node { background: var(--done-bg); border-color: var(--done-bd); color: var(--done-fg); }
            .tv-step-done .tv-t { color: var(--text); }
            .tv-step-live .tv-node { border-color: var(--live-bd); color: var(--live-fg); background: var(--live-bg); }
            .tv-step-live .tv-t { color: var(--live-fg); }
            .tv-step-na .tv-node { border-style: dashed; border-color: var(--line2); background: var(--sunk); color: var(--line2); }
            .tv-step-na .tv-t { font-size: 13px; color: var(--text3); font-weight: 800; text-transform: uppercase; letter-spacing: .06em; text-align: center; white-space: normal; line-height: 1.1; }

            .tv-tot { display: flex; gap: 10px; justify-content: flex-end; padding-left: 18px; }
            .tv-box { border-radius: 14px; padding: 8px 12px; border: 2px solid var(--line2); flex: 1 1 0; min-width: max-content; display: flex; align-items: center; justify-content: center; gap: 8px; }
            .tv-box-ic { display: inline-flex; flex: none; width: 28px; height: 28px; color: inherit; }
            .tv-box-ic svg { width: 100%; height: 100%; }
            .tv-box-live .tv-box-ic { color: var(--live-fg); }
            .tv-box small { display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 14px; font-weight: 900; color: var(--text3); text-transform: uppercase; letter-spacing: .08em; }
            .tv-mini-icon { display: inline-flex; width: 18px; height: 18px; }
            .tv-box b { display: block; font-size: 30px; font-weight: 900; }
            .tv-box-crit .tv-box-ic { color: var(--crit); }
            .tv-box-live { border-color: var(--live-bd) !important; background: var(--live-bg); }
            .tv-box-live b, .tv-box-live small { color: var(--live-fg); }
            .tv-box-crit b { color: var(--crit); }

            /* compacto */
            .tv-compact .tv-row { padding: 6px 22px; border-radius: 16px; min-height: 96px; }
            .tv-compact .tv-name { font-size: 26px; }
            .tv-compact .tv-since { margin-top: 2px; font-size: 17px; }
            .tv-compact .tv-rows { gap: 10px; }
            .tv-compact .tv-name { line-height: 1.15; }
            .tv-compact .tv-place { margin-top: 3px; font-size: 16px; line-height: 1.25; }
            .tv-compact .tv-meta { margin-top: 2px; font-size: 16px; }
            .tv-compact .tv-state { font-size: 23px; }
            .tv-compact .tv-flag { margin-top: 4px; font-size: 15px; padding: 3px 10px; }
            .tv-compact .tv-node { width: 48px; height: 48px; } .tv-compact .tv-node-icon { width: 24px; height: 24px; }
            .tv-compact .tv-step::before { top: 22px; left: calc(-50% + 28px); width: calc(100% - 56px); }
            .tv-compact .tv-t { font-size: 18px; }
            .tv-compact .tv-step-na .tv-t { visibility: hidden; }
            .tv-compact .tv-box { padding: 4px 10px; } .tv-compact .tv-box-ic { width: 24px; height: 24px; } .tv-compact .tv-box b { font-size: 24px; }

            /* com coluna de coroas ao lado */
            .tv-narrow .tv-row, .tv-narrow .tv-head { grid-template-columns: 370px 280px 1fr; gap: 18px; }
            .tv-narrow .tv-name { font-size: 26px; }
            .tv-narrow .tv-state { font-size: 21px; }
            .tv-narrow .tv-tot { padding-left: 8px; }
            .tv-narrow .tv-tot { flex-direction: column; gap: 6px; align-items: stretch; }
            .tv-narrow .tv-box { padding: 3px 8px; flex: none; justify-content: flex-start; } .tv-narrow .tv-box-ic { width: 21px; height: 21px; } .tv-narrow .tv-box b { font-size: 22px; } .tv-narrow .tv-box small { font-size: 12px; }
            .tv-narrow .tv-track, .tv-narrow .tv-steps-h { grid-template-columns: repeat(6, 1fr) 132px; }
            .tv-narrow .tv-steps-h span { font-size: 11px; letter-spacing: 0; }
            .tv-narrow .tv-node { width: 44px; height: 44px; } .tv-narrow .tv-node-icon { width: 22px; height: 22px; }
            .tv-narrow .tv-step::before { top: 20px; left: calc(-50% + 26px); width: calc(100% - 52px); }
            .tv-narrow .tv-t { font-size: 16px; }

            /* coroas */
            .tv-side { width: 500px; flex: none; display: flex; flex-direction: column; gap: 10px; background: var(--sunk); border: 1px solid var(--line); border-radius: 22px; padding: 18px 18px 14px; min-height: 0; }
            .tv-band { background: var(--sunk); border: 1px solid var(--line); border-radius: 22px; padding: 14px 18px; display: flex; flex-direction: column; gap: 10px; }
            .tv-cor-title { margin: 0; font-size: 24px; font-weight: 900; display: flex; align-items: center; gap: 10px; }
            .tv-cor-stale { font-size: 15px; color: var(--warn); font-weight: 800; }
            .tv-n { background: var(--acc); border-radius: 999px; padding: 0 12px; font-size: 20px; font-weight: 900; color: #10233F; }
            .tv-sum { font-size: 17px; color: var(--text2); font-weight: 700; }
            .tv-clist { flex: 1; display: flex; flex-direction: column; gap: 10px; min-height: 0; overflow: hidden; }
            .tv-side .tv-pager { flex: none; }
            .tv-band .tv-clist { flex-direction: row; }
            .tv-band .tv-cr { flex: 1; }
            .tv-cr { background: var(--card); border: 1px solid var(--line); border-radius: 16px; padding: 10px 14px; display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 4px 12px; min-width: 0; }
            .tv-cr-m { grid-column: 1 / -1; font-size: 20px; font-weight: 900; overflow-wrap: anywhere; }
            .tv-cr-s { grid-column: 1 / -1; font-size: 17px; font-weight: 700; color: var(--text2); overflow-wrap: anywhere; }
            .tv-cr-s b { color: var(--text); font-weight: 900; }
            .tv-cr-f { grid-column: 1 / -1; font-size: 17px; color: var(--text2); font-weight: 700; overflow-wrap: anywhere; }
            .tv-cr-e { font-size: 17px; font-weight: 800; color: var(--live-fg); overflow-wrap: anywhere; }
            .tv-cr-late { box-shadow: inset 5px 0 0 var(--warn); border-color: var(--warn-bd); }
            .tv-origem { font-size: 14px; font-weight: 900; padding: 2px 10px; border-radius: 999px; background: var(--infobg); color: var(--acc-text); white-space: nowrap; }
            .tv-cr-foot { grid-column: 1 / -1; display: flex; flex-wrap: wrap; align-items: center; gap: 6px 8px; }
            .tv-cr-late-t { font-size: 16px; font-weight: 900; color: var(--warn); background: var(--warnbg); border-radius: 8px; padding: 2px 8px; justify-self: start; overflow-wrap: anywhere; max-width: 100%; }
            .tv-sum-late { color: var(--warn); font-weight: 900; }
            .tv-pay { font-size: 14px; font-weight: 900; padding: 2px 10px; border-radius: 999px; align-self: start; justify-self: end; white-space: nowrap; }
            .tv-pay-ok { background: var(--okbg); color: var(--ok); }
            .tv-pay-pend { background: var(--warnbg); color: var(--warn); }
            .tv-mini { display: flex; gap: 6px; align-items: center; justify-self: end; }
            .tv-mini i { width: 30px; height: 30px; border-radius: 50%; display: grid; place-items: center; border: 2px solid var(--line2); color: var(--text3); font-style: normal; }
            .tv-mini i span { display: inline-flex; width: 17px; height: 17px; }
            .tv-mini .tv-mini-done { background: var(--done-bg); border-color: var(--done-bd); color: var(--done-fg); }
            .tv-mini .tv-mini-live { border-color: var(--live-bd); color: var(--live-fg); background: var(--live-bg); }
            .tv-mini .tv-mini-na { border-style: dashed; opacity: .35; }
            .tv-coroas-line { display: flex; align-items: center; gap: 12px; font-size: 20px; color: var(--text2); font-weight: 700; padding: 0 6px; }
            .tv-muted { color: var(--text3); }

            .tv-pager { display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 16px; font-weight: 800; color: var(--text3); }
            .tv-pager i { width: 10px; height: 10px; border-radius: 50%; background: var(--line2); }
            .tv-pager i.on { background: var(--acc); }
            .tv-bar { height: 4px; width: 80px; background: var(--line2); border-radius: 2px; overflow: hidden; }
            .tv-bar span { display: block; height: 100%; background: var(--acc); animation: tv-fill linear forwards; }
            @keyframes tv-fill { from { width: 0; } to { width: 100%; } }

            .tv-ticker { margin: 0 -44px; height: 64px; flex: none; background: #313C55; border-top: 1px solid var(--line); display: flex; align-items: center; overflow: hidden; }
            .tv-tag { flex: none; height: 100%; display: flex; align-items: center; padding: 0 22px; background: #00AEEC; color: #10233F; font-size: 20px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; position: relative; z-index: 1; }
            .tv-lane { flex: 1; min-width: 0; overflow: hidden; height: 100%; display: flex; align-items: center; }
            .tv-lane [class*="text-["] { font-size: 24px !important; }


            /* ===== Tema da TV: somente Escuro (sem troca de tema). ===== */
            .tv-host {
                --page: #161C2A; --card: #232B3F; --sunk: #1C2334; --line: rgba(255,255,255,.12); --line2: rgba(255,255,255,.26);
                --text: #FFFFFF; --text2: #AEB9CF; --text3: #8893AA;
                --acc: #00AEEC; --acc-text: #5CCBF4; --infobg: rgba(0,174,236,.20);
                --done-bg: rgba(0,174,236,.30); --done-bd: #00AEEC; --done-fg: #BDEBFB;
                --live-bg: rgba(242,203,63,.16); --live-bd: #F2CB3F; --live-fg: #F2CB3F;
                --ok: #B3CE52; --okbg: rgba(179,206,82,.18);
                --crit: #ff5a5f; --critbg: rgba(255,90,95,.15); --crit-bd: rgba(255,90,95,.55);
                --warn: #ffb020; --warnbg: rgba(255,176,32,.14); --warn-bd: rgba(255,176,32,.55);
                --shadow: none;
            }
            .tv-ctr, .tv-cr { box-shadow: var(--shadow); }

            /* etapa em curso: amarelo da marca piscando (só dentro do quadro) */
            @keyframes pai-blink { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: .45; transform: scale(1.08); } }
            @keyframes pai-ring { 0%, 100% { opacity: 1; box-shadow: 0 0 0 0 rgba(242,203,63,0); } 50% { opacity: .85; box-shadow: 0 0 10px rgba(242,203,63,.65); } }
            @keyframes tv-ping-live { 0% { box-shadow: 0 0 0 0 rgba(242,203,63,.6); } 70% { box-shadow: 0 0 0 12px rgba(242,203,63,0); } 100% { box-shadow: 0 0 0 0 rgba(242,203,63,0); } }
            .tv-host .qa-status-blink { animation-name: pai-blink; }
            .tv-host .qa-status-active-ring { animation-name: pai-ring; }

            @media (prefers-reduced-motion: reduce) {
                .tv-dot-live, .tv-pulse, .tv-bar span { animation: none !important; }
            }
        `}</style>
    );
}


/* ===== Quadro no celular e tablet (telas abaixo de 1024 px) =====
 * Em pé: cartões com abas Atendimentos / Coroas / Avisos.
 * Deitado: uma linha por atendimento, como na TV. A troca é automática pela orientação da tela.
 * O tema (claro/escuro) acompanha o fundo do app: a cor é lida da página e observada quando muda.
 */
type MobAba = "at" | "cr" | "av";

function mobCorEhEscura(cor: string): boolean | null {
    const m = cor.match(/rgba?\(([^)]+)\)/i);
    if (!m) return null;
    const p = m[1].split(/[\s,\/]+/).filter(Boolean).map(Number);
    if (p.length >= 4 && p[3] === 0) return null; // transparente
    const [r, g, b] = p;
    if (![r, g, b].every(Number.isFinite)) return null;
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 < 0.45;
}

function useTemaEscuroApp(ref: React.RefObject<HTMLElement | null>): boolean {
    const [escuro, setEscuro] = useState(false);
    useEffect(() => {
        if (typeof window === "undefined") return;
        const mq = window.matchMedia?.("(prefers-color-scheme: dark)");
        const calc = () => {
            let el: HTMLElement | null = ref.current?.parentElement ?? document.body;
            while (el) {
                const r = mobCorEhEscura(getComputedStyle(el).backgroundColor);
                if (r !== null) { setEscuro(r); return; }
                el = el.parentElement;
            }
            setEscuro(!!mq?.matches);
        };
        calc();
        // Rechecagem com atraso: o fundo pode mudar com transição de cor depois da troca de tema.
        let t = 0;
        const agendar = () => { calc(); window.clearTimeout(t); t = window.setTimeout(calc, 400); };
        const intervalo = window.setInterval(calc, 5000);
        const obs = new MutationObserver(agendar);
        obs.observe(document.documentElement, { attributes: true, attributeFilter: ["class", "style", "data-theme", "data-mode"] });
        obs.observe(document.body, { attributes: true, attributeFilter: ["class", "style", "data-theme", "data-mode"] });
        mq?.addEventListener?.("change", agendar);
        return () => { obs.disconnect(); window.clearTimeout(t); window.clearInterval(intervalo); mq?.removeEventListener?.("change", agendar); };
    }, [ref]);
    return escuro;
}

/* ===== Tema Claro/Escuro do app PAI =====
 * A escolha fica no navegador (chave "pai_tema") e vale para as telas já migradas.
 * Sem escolha salva: celular segue o fundo do app (como antes); desktop abre em Claro; TV abre em Escuro. */
const TEMA_STORAGE_KEY = "pai_tema";
const TEMA_EVENTO = "pai_tema_change";
type TemaPai = "claro" | "escuro";

function lerTemaSalvo(): TemaPai | null {
    if (typeof window === "undefined") return null;
    try {
        const v = window.localStorage.getItem(TEMA_STORAGE_KEY);
        return v === "claro" || v === "escuro" ? v : null;
    } catch {
        return null;
    }
}

function useTemaPai(autoEscuro: boolean): { tema: TemaPai; alternar: () => void; fixo: boolean } {
    const [salvo, setSalvo] = useState<TemaPai | null>(null);
    const [rotaTv, setRotaTv] = useState(false);
    const [estreita, setEstreita] = useState(false);
    useEffect(() => {
        setRotaTv(ehRotaTv());
        const mq = window.matchMedia?.("(max-width: 1023.98px)");
        const medir = () => setEstreita(!!mq?.matches);
        medir();
        mq?.addEventListener?.("change", medir);
        const ler = () => setSalvo(lerTemaSalvo());
        ler();
        const onStorage = (e: StorageEvent) => { if (e.key === TEMA_STORAGE_KEY) ler(); };
        window.addEventListener("storage", onStorage);
        window.addEventListener(TEMA_EVENTO, ler);
        return () => { mq?.removeEventListener?.("change", medir); window.removeEventListener("storage", onStorage); window.removeEventListener(TEMA_EVENTO, ler); };
    }, []);
    // Rota da TV: sempre Escuro, sem troca de tema (ignora a escolha salva).
    // Demais rotas: sem escolha salva, telas estreitas (celular/tablet) seguem o fundo do app e o desktop abre Claro.
    const padrao: TemaPai = estreita ? (autoEscuro ? "escuro" : "claro") : "claro";
    const tema: TemaPai = rotaTv ? "escuro" : salvo ?? padrao;
    const alternar = useCallback(() => {
        if (rotaTv) return;
        const novo: TemaPai = tema === "escuro" ? "claro" : "escuro";
        try { window.localStorage.setItem(TEMA_STORAGE_KEY, novo); } catch { /* ignore */ }
        setSalvo(novo);
        window.dispatchEvent(new Event(TEMA_EVENTO));
    }, [tema, rotaTv]);
    return { tema, alternar, fixo: rotaTv };
}

function BotaoTema({ tema, onClick, className }: { tema: TemaPai; onClick: () => void; className: string }) {
    const rotulo = tema === "escuro" ? "Mudar para o tema claro" : "Mudar para o tema escuro";
    return (
        <button type="button" className={className} onClick={onClick} aria-label={rotulo} title={rotulo}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                {tema === "escuro" ? (
                    <>
                        <circle cx="12" cy="12" r="4" />
                        <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
                    </>
                ) : (
                    <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
                )}
            </svg>
        </button>
    );
}

function mobClasseConv(convenio?: string): string {
    const kind = normalizeConvenio(convenio);
    if (kind === "Prefeitura") return "qm-conv-pref";
    if (kind === "Particular") return "qm-conv-part";
    if (kind === "Associado") return "qm-conv-assoc";
    return "qm-conv-adef";
}

function mobChipConvenio(convenio?: string): string {
    const kind = normalizeConvenio(convenio);
    if (kind === "Prefeitura") return "qm-chip qm-chip-pref";
    if (kind === "Particular") return "qm-chip qm-chip-part";
    if (kind === "Associado") return "qm-chip qm-chip-assoc";
    return "qm-chip qm-chip-adef";
}

function MobCartaoAtendimento({ resumo, onSelect }: { resumo: TvResumo; onSelect: (r: Registro) => void }) {
    const r = resumo.registro;
    const rankAtual = statusFlowRank(resumo.atualKey);
    const ocioso = resumo.durations.get("idle") ?? 0;
    const ociosoAtivo = resumo.activeKey === "idle";
    const semVelorio = !rotaAtivaLegado(r.realiza_velorio);
    const semSepultamento = !rotaAtivaLegado(r.realiza_sepultamento);
    const sepultamentoTxt = semSepultamento
        ? "Sem sepultamento pelo PAI"
        : `${shown(r.local_sepultamento || r.local)} · ${dateDayMonthOr(r.data_fim_velorio)} ${timeOr(r.hora_fim_velorio)}`;
    const nivel = resumo.alerta?.nivel;

    return (
        <article
            className={`qm-card ${nivel ? `qm-card-${nivel}` : ""} ${mobClasseConv(r.convenio)}`}
            role="button"
            tabIndex={0}
            onClick={() => onSelect(r)}
            onKeyDown={(e) => (e.key === "Enter" || e.key === " " ? onSelect(r) : undefined)}
            aria-label={`${shown(r.falecido)}: ${resumo.atualLabel}. Toque para ver os detalhes.`}
        >
            <h3 className="qm-name">{shown(r.falecido)}</h3>

            <div className="qm-tot">
                <b title="Tempo total"><span className="qm-tot-ic" aria-label="Total"><StatusIcon type="clock" /></span>{formatDurationMs(resumo.totalMs)}</b>
                <span
                    className={`qm-oc ${ociosoAtivo ? "qm-oc-live" : ""} ${ocioso >= TV_LIMITE_PARADO_MS ? "qm-oc-crit" : ""}`}
                    title="Tempo ocioso"
                >
                    <span className={`qm-oc-ic ${ociosoAtivo ? "qa-status-blink" : ""}`} aria-label="Ocioso"><StatusIcon type="clockPause" /></span>
                    {formatDurationMs(ocioso)}
                </span>
            </div>

            <div className="qm-meta">
                <span className={mobChipConvenio(r.convenio)}>{rotuloConvenioRegistro(r)}</span>
                <span className="qm-meta-t">Aberto {tvDataHora(resumo.criadoTs)} · {resumo.abertoPor || shown(r.agente)}</span>
            </div>

            <div className="qm-now">
                <span className="qm-dot qa-status-blink" aria-hidden />
                <div className="qm-now-t">
                    <b>{resumo.atualLabel}</b>
                    <span>
                        há {tvDuracaoTexto(resumo.atualDesdeMs)}
                        {resumo.atualResponsavel ? ` · ${resumo.atualResponsavel}` : ""}
                    </span>
                </div>
            </div>

            {resumo.alerta && (
                <div className={`qm-flag qm-flag-${resumo.alerta.nivel}`}>
                    {resumo.alerta.nivel === "crit" ? "⚠" : "⏱"} {resumo.alerta.texto}
                </div>
            )}

            <ol className="qm-steps">
                {TV_ETAPAS.map((step) => {
                    const pulada = isStatusStepSkipped(r, step.key);
                    const duracao = resumo.durations.get(step.key) ?? 0;
                    const ativa = !pulada && resumo.activeKey === step.key;
                    const feita = !pulada && !ativa && (duracao > 0 || rankAtual > statusFlowRank(step.key));
                    const estado = pulada ? "na" : ativa ? "live" : feita ? "done" : "pend";
                    const texto = pulada ? "sem" : ativa || feita ? formatDurationMs(duracao) : "—";
                    return (
                        <li
                            key={step.key}
                            className={`qm-s qm-s-${estado}`}
                            title={`${step.label} • ${pulada ? "Não se aplica" : ativa || feita ? formatDurationMs(duracao) : "Ainda não aconteceu"}`}
                        >
                            <span className={`qm-ic ${ativa ? "qa-status-active-ring" : ""}`}>
                                <span className={`qm-ic-svg ${ativa ? "qa-status-blink" : ""}`}><StatusIcon type={step.icon} /></span>
                            </span>
                            <b>{texto}</b>
                        </li>
                    );
                })}
            </ol>

            <dl className="qm-where">
                <div>
                    <dt>Velório</dt>
                    <dd>{semVelorio ? "Sem velório" : <LocalVelorioQuadro r={r} />}</dd>
                </div>
                <div>
                    <dt>Sepult.</dt>
                    <dd>{sepultamentoTxt}</dd>
                </div>
            </dl>
        </article>
    );
}

function MobCartaoCoroa({ pedido, nowMs, atraso, onSelect }: { pedido: CoroaTvPedido; nowMs: number; atraso?: CoroaAtraso; onSelect?: (p: CoroaTvPedido) => void }) {
    const t = buildCoroaTimeline(pedido, nowMs);
    const etapas = [
        { key: "aguardando", icon: "hourglass" as CoroaTvIconKey, label: "Aguardando", ms: t.aguardandoMs, ativo: t.aguardandoActive, pulado: false },
        { key: "coroa", icon: "flower" as CoroaTvIconKey, label: "Coroa", ms: t.coroaMs, ativo: t.coroaActive, pulado: t.coroaSkipped },
        { key: "faixa", icon: "ribbon" as CoroaTvIconKey, label: "Faixa", ms: t.faixaMs, ativo: t.faixaActive, pulado: false },
        { key: "concluida", icon: "check" as CoroaTvIconKey, label: "Concluída, aguardando entrega", ms: t.concluidaMs, ativo: t.concluidaActive, pulado: false },
    ];
    const ativas = etapas.filter((e) => e.ativo);
    const qtd = coroaQuantidade(pedido);
    const pago = coroaPagamentoLabel(pedido) === "Pago";
    const agora = ativas.length
        ? ativas.map((e) => `${e.label} há ${tvDuracaoTexto(e.ms)}`).join(" · ")
        : coroaStatusLabel(pedido.status);
    const hora = coroaDataHora(pedido.criado_em);
    const clicavel = !!onSelect;

    return (
        <div
            className={`qm-cr ${atraso ? "qm-cr-late" : ""} ${clicavel ? "qm-cr-click" : ""}`}
            {...(clicavel
                ? {
                    role: "button",
                    tabIndex: 0,
                    onClick: () => onSelect?.(pedido),
                    onKeyDown: (e: React.KeyboardEvent) => (e.key === "Enter" || e.key === " " ? (e.preventDefault(), onSelect?.(pedido)) : undefined),
                    "aria-label": `Ver informações da coroa de ${shown(pedido.falecido, "a definir")}`,
                }
                : {})}
        >
            {atraso && <div className="qm-flag qm-flag-warn">⏱ {atraso.longo}</div>}
            <div className="qm-cr-m">{qtd > 1 ? `${qtd}× ` : ""}{coroaModelos(pedido)}</div>
            <div className="qm-cr-s">Solicitante: <b>{shown(pedido.solicitante, "a definir")}</b></div>
            <div className="qm-cr-f">
                {shown(pedido.falecido, "a definir")} · {shown(pedido.local_entrega, "entrega a definir")}
                {hora ? ` · ${hora}` : ""}
            </div>
            <div className="qm-cr-r">
                <span className="qm-cr-e">{agora}</span>
                <span className="qm-mini">
                    {etapas.map((e) => (
                        <i
                            key={e.key}
                            title={`${e.label} • ${e.pulado ? "Não se aplica" : formatDurationMs(e.ms)}`}
                            className={e.pulado ? "qm-mini-na" : e.ativo ? "qm-mini-live qa-status-active-ring" : e.ms > 0 ? "qm-mini-done" : ""}
                        >
                            <span className={e.ativo ? "qa-status-blink" : ""}><CoroaTvIcon type={e.icon} /></span>
                        </i>
                    ))}
                </span>
            </div>
            <div className="qm-cr-foot">
                <span className="qm-origem">Origem: {coroaOrigemLabel(pedido.origem)}</span>
                <span className={`qm-pay ${pago ? "qm-pay-ok" : "qm-pay-pend"}`}>{pago ? "Pago" : "Aguardando pagamento"}</span>
            </div>
        </div>
    );
}

function QuadroMobile({
    ativos,
    coroas,
    coroasError,
    statusLogsById,
    nowMs,
    clockTime,
    clockDate,
    avisos,
    onSelect,
    onSelectCoroa,
}: {
    ativos: Registro[];
    coroas: CoroaTvPedido[];
    coroasError?: string | null;
    statusLogsById: Record<string, LogItem[]>;
    nowMs: number;
    clockTime: string;
    clockDate: string;
    avisos: Aviso[];
    onSelect: (r: Registro) => void;
    onSelectCoroa?: (p: CoroaTvPedido) => void;
}) {
    const rootRef = useRef<HTMLDivElement | null>(null);
    const escuroApp = useTemaEscuroApp(rootRef);
    const { tema, alternar: alternarTema, fixo: temaFixo } = useTemaPai(escuroApp);
    const escuro = tema === "escuro";
    const [aba, setAba] = useState<MobAba>("at");
    const [podeTelaCheia, setPodeTelaCheia] = useState(false);
    const [telaCheia, setTelaCheia] = useState(false);

    useEffect(() => {
        setPodeTelaCheia(!!document.fullscreenEnabled);
        const onFs = () => setTelaCheia(!!document.fullscreenElement);
        document.addEventListener("fullscreenchange", onFs);
        return () => document.removeEventListener("fullscreenchange", onFs);
    }, []);

    // Tela cheia na página inteira (não só no quadro) para a janela de detalhes continuar aparecendo.
    const alternarTelaCheia = useCallback(() => {
        if (document.fullscreenElement) void document.exitFullscreen?.();
        else void document.documentElement.requestFullscreen?.().catch(() => undefined);
    }, []);

    const resumos = useMemo(
        () => ativos.map((r) => resumirAtendimentoTv(r, statusLogsById[getRegistroTrackingId(r)], nowMs)),
        [ativos, statusLogsById, nowMs]
    );
    const parados = resumos.filter((x) => x.alerta?.nivel === "crit").length;
    const totalCoroas = coroas.reduce((s, p) => s + coroaQuantidade(p), 0);
    const pagamentosPendentes = coroas.filter((p) => coroaPagamentoLabel(p) !== "Pago").length;
    const coroasAtrasadas = coroas.filter((p) => coroaAtrasoTv(p, nowMs)).length;
    const listaAvisos = useMemo(
        () =>
            (avisos ?? [])
                .map((a) => ({ usuario: shown(a?.usuario, "").trim(), mensagem: shown(a?.mensagem, "").trim() }))
                .filter((x) => x.usuario || x.mensagem),
        [avisos]
    );

    const aba_ = (id: MobAba, rotulo: string, n: number) => (
        <button type="button" role="tab" aria-selected={aba === id} className="qm-tab" onClick={() => setAba(id)}>
            {rotulo}
            <span>{n}</span>
        </button>
    );

    return (
        <div ref={rootRef} className="qm-root" data-tema={escuro ? "escuro" : "claro"}>
            <header className="qm-top">
                <div className="qm-tit">
                    <h1>Quadro de Atendimentos</h1>
                    <div className="qm-live"><i />Atualizado em tempo real</div>
                </div>
                <div className="qm-clk">
                    <b>{clockTime}</b>
                    <small>{clockDate}</small>
                </div>
                <div className="qm-kpis">
                    <span className="qm-kpi"><b>{ativos.length}</b>em andamento</span>
                    {parados > 0 && <span className="qm-kpi qm-kpi-crit"><b>{parados}</b>parados +24 h</span>}
                    {!temaFixo && <BotaoTema tema={tema} onClick={alternarTema} className="qm-fs qm-th" />}
                    {podeTelaCheia && (
                        <button
                            type="button"
                            className="qm-fs"
                            onClick={alternarTelaCheia}
                            aria-label={telaCheia ? "Sair da tela cheia" : "Tela cheia"}
                            title={telaCheia ? "Sair da tela cheia" : "Tela cheia"}
                        >
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
                                {telaCheia
                                    ? <path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5" />
                                    : <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />}
                            </svg>
                        </button>
                    )}
                </div>
                <div className="qm-tabs" role="tablist">
                    {aba_("at", "Atendimentos", ativos.length)}
                    {aba_("cr", "Coroas", coroas.length)}
                    {aba_("av", "Avisos", listaAvisos.length)}
                </div>
            </header>

            <div className="qm-body">
                {aba === "at" && (
                    <>
                        {listaAvisos.length > 0 && (
                            <button type="button" className="qm-aviso" onClick={() => setAba("av")}>
                                <b>Aviso</b>
                                <span>{listaAvisos[0].usuario ? `${listaAvisos[0].usuario}: ` : ""}{listaAvisos[0].mensagem}</span>
                            </button>
                        )}
                        {resumos.length > 0 && (
                            <div className="qm-colhd" aria-hidden>
                                <span>Atendimento</span>
                                <span>Agora</span>
                                <span />
                                <span />
                            </div>
                        )}
                        <div className="qm-list">
                            {resumos.length === 0 && <p className="qm-empty">Nenhum atendimento em andamento.</p>}
                            {resumos.map((resumo, i) => (
                                <MobCartaoAtendimento key={resumo.trackingId || i} resumo={resumo} onSelect={onSelect} />
                            ))}
                        </div>
                    </>
                )}

                {aba === "cr" && (
                    <>
                        {coroasError && <p className="qm-note qm-note-warn">Dados das coroas podem estar desatualizados.</p>}
                        {coroas.length > 0 ? (
                            <>
                                <p className="qm-note">
                                    {totalCoroas} {totalCoroas === 1 ? "coroa" : "coroas"} em {coroas.length} {coroas.length === 1 ? "pedido" : "pedidos"}
                                    {pagamentosPendentes ? ` · ${pagamentosPendentes} aguardando pagamento` : ""}
                                    {coroasAtrasadas ? ` · ${coroasAtrasadas} ${coroasAtrasadas === 1 ? "atrasada" : "atrasadas"}` : ""} · ordem de chegada
                                </p>
                                <div className="qm-grid">
                                    {coroas.map((p, i) => (
                                        <MobCartaoCoroa
                                            key={String(p.id ?? i)}
                                            pedido={p}
                                            nowMs={nowMs}
                                            atraso={coroaAtrasoTv(p, nowMs)}
                                            onSelect={onSelectCoroa}
                                        />
                                    ))}
                                </div>
                            </>
                        ) : (
                            <p className="qm-empty">Nenhuma coroa em confecção.</p>
                        )}
                    </>
                )}

                {aba === "av" && (
                    <div className="qm-grid">
                        {listaAvisos.length === 0 && <p className="qm-empty">Nenhum aviso no momento.</p>}
                        {listaAvisos.map((a, i) => (
                            <article key={i} className="qm-av">
                                {a.usuario && <b>{a.usuario}</b>}
                                <p>{a.mensagem}</p>
                            </article>
                        ))}
                    </div>
                )}
            </div>

            <MobStyles />
            <StatusBlinkStyle />
        </div>
    );
}

function MobStyles() {
    return (
        <style jsx global>{`
            .qm-root {
                --qm-page: #F6F8FB; --qm-surface: #ffffff; --qm-s2: #F1F4F8; --qm-line: #E3E8F0; --qm-text: #313C55; --qm-muted: #5B6478;
                --qm-acc: #00AEEC; --qm-accbg: #E6F7FE; --qm-acctext: #0086B8;
                --qm-ok: #5C7A12; --qm-okbg: #EEF5D6; --qm-warn: #b45309; --qm-warnbg: #FFF1DC; --qm-crit: #dc2626; --qm-critbg: #fdecec;
                --qm-donebg: rgba(0, 174, 236, .16); --qm-donefg: #0086B8; --qm-live: #8A6A00; --qm-livebg: #FCF3CC; --qm-livebd: #F2CB3F;
                --qm-shadow: 0 1px 2px rgba(49, 60, 85, .06), 0 6px 18px rgba(49, 60, 85, .06);
                flex: 1; min-height: 0; display: flex; flex-direction: column; gap: 10px; color: var(--qm-text);
                background: var(--qm-page); border-radius: 22px; padding: 8px;
            }
            .qm-root[data-tema="escuro"] {
                --qm-page: #161C2A; --qm-surface: #232B3F; --qm-s2: #1C2334; --qm-line: rgba(255, 255, 255, .12); --qm-text: #FFFFFF; --qm-muted: #AEB9CF;
                --qm-acc: #00AEEC; --qm-accbg: rgba(0, 174, 236, .20); --qm-acctext: #5CCBF4;
                --qm-ok: #B3CE52; --qm-okbg: rgba(179, 206, 82, .18); --qm-warn: #ffb020;
                --qm-donebg: rgba(0, 174, 236, .30); --qm-donefg: #BDEBFB; --qm-live: #F2CB3F; --qm-livebg: rgba(242, 203, 63, .16); --qm-livebd: #F2CB3F; --qm-warnbg: rgba(255, 176, 32, .12); --qm-crit: #ff5a5f; --qm-critbg: rgba(255, 90, 95, .13);
                --qm-shadow: none;
            }
            .qm-root button { font: inherit; color: inherit; }

            .qm-top { flex: none; background: var(--qm-surface); border: 1px solid var(--qm-line); border-radius: 18px; box-shadow: var(--qm-shadow);
                padding: 12px 14px 10px; display: grid; gap: 10px; grid-template-columns: minmax(0, 1fr) auto; grid-template-areas: "tit clk" "kpi kpi" "tab tab"; }
            .qm-tit { grid-area: tit; min-width: 0; }
            .qm-tit h1 { margin: 0; font-size: 16px; font-weight: 900; line-height: 1.2; overflow-wrap: anywhere; }
            .qm-live { display: flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 800; color: var(--qm-ok); overflow-wrap: anywhere; }
            .qm-live i { flex: none; }
            .qm-live i { width: 7px; height: 7px; border-radius: 50%; background: var(--qm-ok); }
            .qm-clk { grid-area: clk; text-align: right; line-height: 1.1; }
            .qm-clk b { display: block; font-size: 20px; font-weight: 900; font-variant-numeric: tabular-nums; }
            .qm-clk small { font-size: 11px; font-weight: 800; color: var(--qm-muted); }
            .qm-kpis { grid-area: kpi; display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
            .qm-kpi { white-space: nowrap; display: flex; align-items: baseline; gap: 5px; padding: 3px 10px; border-radius: 999px; background: var(--qm-s2); border: 1px solid var(--qm-line); font-size: 12px; font-weight: 800; color: var(--qm-muted); }
            .qm-kpi b { font-size: 15px; color: var(--qm-text); font-variant-numeric: tabular-nums; }
            .qm-kpi-crit { background: var(--qm-critbg); border-color: transparent; color: var(--qm-crit); }
            .qm-kpi-crit b { color: var(--qm-crit); }
            .qm-fs { margin-left: auto; flex: none; width: 30px; height: 30px; display: grid; place-items: center; border: 1px solid var(--qm-line); background: transparent; border-radius: 999px; padding: 0; color: var(--qm-muted) !important; cursor: pointer; }
            .qm-fs svg { width: 16px; height: 16px; }
            .qm-th + .qm-fs { margin-left: 0; }
            @keyframes pai-blink { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: .45; transform: scale(1.08); } }
            @keyframes pai-ring { 0%, 100% { opacity: 1; box-shadow: 0 0 0 0 rgba(242, 203, 63, 0); } 50% { opacity: .85; box-shadow: 0 0 10px rgba(242, 203, 63, .65); } }
            .qm-root .qa-status-blink { animation-name: pai-blink; }
            .qm-root .qa-status-active-ring { animation-name: pai-ring; }
            .qm-tabs { grid-area: tab; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 3px; padding: 3px; background: var(--qm-s2); border: 1px solid var(--qm-line); border-radius: 12px; }
            .qm-tab { min-width: 0; border: 0; background: transparent; border-radius: 9px; padding: 7px 2px; font-size: 12px !important; font-weight: 800; color: var(--qm-muted) !important; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; white-space: nowrap; }
            .qm-tab span { flex: none; background: var(--qm-line); color: var(--qm-text); border-radius: 999px; padding: 0 7px; font-size: 11px; font-variant-numeric: tabular-nums; }
            .qm-tab[aria-selected="true"] { background: var(--qm-surface); color: var(--qm-text) !important; box-shadow: var(--qm-shadow); }
            .qm-tab[aria-selected="true"] span { background: var(--qm-acc); color: #10233F; }
            .qm-tab:focus-visible, .qm-card:focus-visible, .qm-aviso:focus-visible, .qm-fs:focus-visible { outline: 2px solid var(--qm-acc); outline-offset: 2px; }

            .qm-body { flex: 1; min-height: 0; overflow-y: auto; overscroll-behavior: contain; -webkit-overflow-scrolling: touch; display: flex; flex-direction: column; gap: 10px; padding-bottom: calc(12px + env(safe-area-inset-bottom, 0px)); }
            .qm-body > * { flex: none; }
            .qm-aviso { display: flex; gap: 10px; align-items: center; width: 100%; text-align: left; border: 0; cursor: pointer; background: var(--qm-accbg); border-radius: 14px; padding: 9px 12px; font-size: 13px !important; font-weight: 700; }
            .qm-aviso b { flex: none; font-size: 11px; font-weight: 900; text-transform: uppercase; letter-spacing: .08em; color: var(--qm-acctext); }
            .qm-aviso span { min-width: 0; overflow-wrap: anywhere; }
            .qm-colhd { display: none; }
            .qm-list, .qm-grid { display: grid; gap: 10px; }
            .qm-empty { margin: 0; padding: 20px 12px; text-align: center; font-size: 14px; font-weight: 700; color: var(--qm-muted); background: var(--qm-surface); border: 1px dashed var(--qm-line); border-radius: 16px; }
            .qm-note { margin: 0; text-align: center; font-size: 12px; font-weight: 800; color: var(--qm-muted); }
            .qm-note-warn { color: var(--qm-warn); }

            .qm-card { position: relative; overflow: hidden; cursor: pointer; background: var(--qm-surface); border: 1px solid var(--qm-line); border-radius: 18px; box-shadow: var(--qm-shadow);
                padding: 12px 12px 12px 14px; display: grid; gap: 6px 10px; grid-template-columns: minmax(0, 1fr) auto;
                grid-template-areas: "name tot" "meta tot" "now now" "flag flag" "steps steps" "where where"; }
            .qm-card-crit { box-shadow: inset 4px 0 0 var(--qm-crit), var(--qm-shadow); }
            .qm-card-warn { box-shadow: inset 4px 0 0 var(--qm-warn), var(--qm-shadow); }
            .qm-name { grid-area: name; margin: 0; align-self: end; font-size: 17px; font-weight: 900; line-height: 1.2; overflow-wrap: anywhere; }
            .qm-meta { grid-area: meta; display: flex; flex-wrap: wrap; align-items: center; gap: 2px 6px; min-width: 0; font-size: 12px; font-weight: 700; color: var(--qm-muted); }
            .qm-meta-t { overflow-wrap: anywhere; }
            .qm-chip { flex: none; font-size: 11px; font-weight: 900; line-height: 1.5; color: #fff; border-radius: 999px; padding: 0 8px; }
            .qm-chip-pref { background: #00AEEC; color: #10233F; }
            .qm-chip-part { background: #F2CB3F; color: #1d1405; }
            .qm-chip-assoc { background: #B3CE52; color: #1d2a05; }
            .qm-chip-adef { background: transparent; color: var(--qm-muted); border: 1px dashed var(--qm-muted); }
            .qm-tot { grid-area: tot; align-self: start; text-align: right; display: grid; gap: 2px; justify-items: end; }
            .qm-tot small { font-size: 10px; font-weight: 900; text-transform: uppercase; letter-spacing: .08em; color: var(--qm-muted); }
            .qm-tot b { display: inline-flex; align-items: center; gap: 4px; font-size: 18px; font-weight: 900; line-height: 1; font-variant-numeric: tabular-nums; }
            .qm-tot-ic { display: inline-flex; width: 18px; height: 18px; color: inherit; }
            .qm-tot-ic svg, .qm-oc-ic svg { width: 100%; height: 100%; }
            .qm-oc { display: inline-flex; align-items: center; gap: 3px; font-size: 11px; font-weight: 800; color: var(--qm-muted); font-variant-numeric: tabular-nums; }
            .qm-oc-ic { width: 13px; height: 13px; display: inline-flex; }
            .qm-oc-live { color: var(--qm-live); }
            .qm-oc-crit { color: var(--qm-crit); }
            .qm-now { grid-area: now; display: flex; align-items: center; gap: 10px; min-width: 0; background: var(--qm-okbg); border-radius: 12px; padding: 7px 10px; }
            .qm-conv-assoc .qm-now { background: rgba(179, 206, 82, .28); }
            .qm-conv-pref .qm-now { background: rgba(0, 174, 236, .22); }
            .qm-conv-part .qm-now { background: rgba(242, 203, 63, .28); }
            .qm-dot { flex: none; width: 10px; height: 10px; border-radius: 50%; background: var(--qm-livebd); }
            .qm-now-t { min-width: 0; }
            .qm-now-t b { display: block; font-size: 15px; font-weight: 900; line-height: 1.2; }
            .qm-now-t span { display: block; font-size: 12px; font-weight: 700; color: var(--qm-muted); overflow-wrap: anywhere; }
            .qm-flag { grid-area: flag; font-size: 12px; font-weight: 800; border-radius: 10px; padding: 5px 10px; }
            .qm-flag-crit { background: var(--qm-critbg); color: var(--qm-crit); }
            .qm-flag-warn { background: var(--qm-warnbg); color: var(--qm-warn); }
            .qm-steps { grid-area: steps; list-style: none; margin: 2px 0 0; padding: 8px 2px 6px; display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); background: var(--qm-s2); border: 1px solid var(--qm-line); border-radius: 14px; }
            .qm-s { position: relative; min-width: 0; display: flex; flex-direction: column; align-items: center; gap: 2px; }
            .qm-s:not(:first-child)::before { content: ""; position: absolute; top: 16px; right: 50%; width: 100%; height: 2px; background: var(--qm-line); }
            .qm-s-done::before, .qm-s-live::before { background: var(--qm-acc) !important; }
            .qm-ic { position: relative; z-index: 1; width: 32px; height: 32px; border-radius: 50%; display: grid; place-items: center; border: 2px solid var(--qm-line); background: var(--qm-surface); color: var(--qm-muted); }
            .qm-ic-svg { width: 16px; height: 16px; display: inline-block; }
            .qm-s-done .qm-ic { background: var(--qm-donebg); border-color: var(--qm-acc); color: var(--qm-donefg); }
            .qm-s-live .qm-ic { border-color: var(--qm-livebd); background: linear-gradient(var(--qm-livebg), var(--qm-livebg)), var(--qm-surface); color: var(--qm-live); }
            .qm-s-na .qm-ic { border-style: dashed; background: var(--qm-surface); }
            .qm-s-na .qm-ic-svg { opacity: .45; }
            .qm-s em { font-style: normal; margin-top: 2px; font-size: 9px; font-weight: 900; text-transform: uppercase; letter-spacing: 0; color: var(--qm-muted); white-space: nowrap; }
            .qm-s b { font-size: 12px; font-weight: 900; font-variant-numeric: tabular-nums; }
            .qm-s-pend b, .qm-s-na b { color: var(--qm-muted); font-weight: 700; }
            .qm-s-live b, .qm-s-live em { color: var(--qm-live); }
            .qm-where { grid-area: where; margin: 0; display: grid; gap: 3px; font-size: 12px; }
            .qm-where div { display: flex; gap: 6px; min-width: 0; }
            .qm-where dt { flex: none; width: 58px; font-weight: 800; color: var(--qm-muted); }
            .qm-where dd { margin: 0; font-weight: 700; overflow-wrap: anywhere; }

            .qm-cr, .qm-av { background: var(--qm-surface); border: 1px solid var(--qm-line); border-radius: 16px; box-shadow: var(--qm-shadow); padding: 10px 12px; display: grid; gap: 5px; min-width: 0; }
            .qm-cr-click { cursor: pointer; }
            .qm-cr-click:hover { border-color: var(--qm-acc); }
            .qm-cr-click:focus-visible { outline: 2px solid var(--qm-acc); outline-offset: 2px; }
            .qm-cr-late { box-shadow: inset 4px 0 0 var(--qm-warn), var(--qm-shadow); }
            .qm-cr .qm-flag { grid-area: auto; justify-self: start; }
            .qm-cr-m { font-size: 14px; font-weight: 900; overflow-wrap: anywhere; }
            .qm-cr-s { font-size: 12px; font-weight: 700; color: var(--qm-muted); overflow-wrap: anywhere; }
            .qm-cr-s b { color: var(--qm-text); font-weight: 900; }
            .qm-cr-f { font-size: 12px; font-weight: 700; color: var(--qm-muted); overflow-wrap: anywhere; }
            .qm-cr-r { display: flex; align-items: center; justify-content: space-between; gap: 8px; min-width: 0; }
            .qm-cr-e { min-width: 0; overflow-wrap: normal; font-size: 12px; font-weight: 800; color: var(--qm-live); overflow-wrap: anywhere; }
            .qm-mini { flex: none; display: flex; gap: 4px; }
            .qm-mini i { width: 24px; height: 24px; border-radius: 50%; border: 1.5px solid var(--qm-line); color: var(--qm-muted); display: grid; place-items: center; }
            .qm-mini i > span { width: 12px; height: 12px; display: inline-block; }
            .qm-mini-done { background: var(--qm-donebg); border-color: var(--qm-acc) !important; color: var(--qm-donefg) !important; }
            .qm-mini-live { background: var(--qm-livebg); border-color: var(--qm-livebd) !important; color: var(--qm-live) !important; }
            .qm-mini-na { border-style: dashed !important; opacity: .5; }
            .qm-cr-foot { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }
            .qm-origem { font-size: 11px; font-weight: 900; border-radius: 999px; padding: 1px 8px; background: var(--qm-accbg); color: var(--qm-acctext); }
            .qm-pay { justify-self: start; font-size: 11px; font-weight: 900; border-radius: 999px; padding: 1px 8px; }
            .qm-pay-ok { background: var(--qm-okbg); color: var(--qm-ok); }
            .qm-pay-pend { background: var(--qm-warnbg); color: var(--qm-warn); }
            .qm-av b { font-size: 14px; font-weight: 900; }
            .qm-av p { margin: 0; font-size: 14px; font-weight: 600; line-height: 1.45; }

            /* Tablet em pé: duas colunas de cartões */
            @media (min-width: 640px) and (orientation: portrait) {
                .qm-list, .qm-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            }

            /* Deitado: uma linha por atendimento, como na TV */
            @media (orientation: landscape) {
                .qm-root { gap: 6px; }
                .qm-top { grid-template-columns: minmax(0, 1fr) auto minmax(250px, 300px) auto; grid-template-areas: "tit kpi tab clk"; align-items: center; padding: 6px 12px; gap: 12px; border-radius: 14px; }
                .qm-tit h1 { font-size: 15px; }
                .qm-live { display: none; }
                .qm-clk b { font-size: 18px; }
                .qm-clk small { display: none; }
                .qm-kpis { flex-wrap: nowrap; justify-content: flex-end; }
                .qm-kpi:not(.qm-kpi-crit) { display: none; }
                .qm-fs { margin-left: 0; }
                .qm-tab { padding: 5px 4px; font-size: 12px !important; }
                .qm-body { gap: 6px; }
                .qm-aviso { padding: 6px 10px; }
                .qm-list { gap: 6px; }
                .qm-colhd, .qm-card { grid-template-columns: minmax(0, 1.4fr) minmax(0, 1fr) 264px 82px; }
                .qm-colhd { display: grid; gap: 10px; position: sticky; top: 0; z-index: 3; padding: 4px 12px 2px 16px; font-size: 8.5px; font-weight: 900; text-transform: uppercase; letter-spacing: 0; white-space: nowrap; color: var(--qm-muted); background: var(--qm-s2); border-radius: 8px; }
                .qm-colhd-st { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); text-align: center; }
                .qm-colhd > span:last-child { text-align: right; }
                .qm-card { grid-template-areas: "name now steps tot" "meta flag steps tot" "where where where where"; align-items: center; gap: 4px 10px; padding: 8px 12px 8px 16px; border-radius: 14px; }
                .qm-name { font-size: 14px; line-height: 1.2; }
                .qm-meta { font-size: 11px; }
                .qm-now { grid-row: 1 / span 2; align-self: center; background: transparent; padding: 0; gap: 8px; }
                .qm-card:has(.qm-flag) .qm-now { grid-row: 1; align-self: end; }
                .qm-now-t b { font-size: 13px; }
                .qm-now-t span { font-size: 11px; }
                .qm-flag { align-self: start; font-size: 10.5px; padding: 2px 8px; overflow-wrap: anywhere; }
                .qm-steps { background: transparent; border: 0; padding: 0; margin: 0; }
                .qm-s em { display: none; }
                .qm-ic { width: 28px; height: 28px; }
                .qm-ic-svg { width: 14px; height: 14px; }
                .qm-s:not(:first-child)::before { top: 14px; }
                .qm-s b { font-size: 11px; }
                .qm-tot { align-self: center; }
                .qm-tot b { font-size: 16px; }
                .qm-where { display: flex; gap: 18px; font-size: 11px; border-top: 1px dashed var(--qm-line); padding-top: 5px; margin-top: 2px; }
                .qm-where div { flex: 1 1 0; }
                .qm-where dt { width: auto; }
                .qm-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            }
        `}</style>
    );
}

/* ===== Gaveta da coroa (desktop e celular): foto, frase da faixa e andamento do pedido ===== */
function CoroaDrawer({ pedido, tema, nowMs, onClose }: { pedido: CoroaTvPedido; tema: TemaPai; nowMs: number; onClose: () => void }) {
    const itensPedido = [...(pedido.itens ?? [])].sort((a, b) => (a.ordem ?? 0) - (b.ordem ?? 0));
    // modelos distintos do pedido (cada um com a foto do seu cadastro de produto)
    const modelos = useMemo(() => {
        const mapa = new Map<string, { chave: string; modelo: string; tipo: "natural" | "artificial" }>();
        const add = (modelo?: string | null, tipoRaw?: string | null) => {
            const nome = String(modelo ?? "").trim();
            if (!nome) return;
            const tipo: "natural" | "artificial" = tipoRaw === "artificial" ? "artificial" : "natural";
            const chave = `${tipo}|${normNomeProduto(nome)}`;
            if (!mapa.has(chave)) mapa.set(chave, { chave, modelo: nome, tipo });
        };
        for (const it of itensPedido) add(it.modelo_coroa, it.tipo_coroa);
        if (mapa.size === 0) add(pedido.modelo_coroa, coroaSomenteArtificial(pedido) ? "artificial" : "natural");
        return [...mapa.values()];
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [pedido]);
    const [fotos, setFotos] = useState<Record<string, string>>({});
    const [fotosCarregando, setFotosCarregando] = useState(true);
    const [fotosComErro, setFotosComErro] = useState<Record<string, boolean>>({});
    useEffect(() => {
        let vivo = true;
        setFotosCarregando(true);
        setFotosComErro({});
        Promise.all(modelos.map(async (m) => [m.chave, await buscarFotoModeloCoroa(m.modelo, m.tipo)] as const)).then((pares) => {
            if (!vivo) return;
            setFotos(Object.fromEntries(pares));
            setFotosCarregando(false);
        });
        return () => { vivo = false; };
    }, [modelos]);
    useEffect(() => {
        const aoTeclar = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
        window.addEventListener("keydown", aoTeclar);
        return () => window.removeEventListener("keydown", aoTeclar);
    }, [onClose]);

    const itens = itensPedido;
    const qtd = coroaQuantidade(pedido);
    const pago = coroaPagamentoLabel(pedido) === "Pago";
    const atraso = coroaAtrasoTv(pedido, nowMs);
    const tipoTxt = (t?: string | null) => (t === "natural" ? "Natural" : t === "artificial" ? "Artificial" : "");
    const andamento = [
        { rotulo: "Pedido recebido", em: pedido.criado_em, por: pedido.criado_por },
        { rotulo: "Coroa iniciada", em: pedido.coroa_inicio_em, por: pedido.coroa_inicio_por },
        { rotulo: "Faixa iniciada", em: pedido.faixa_inicio_em, por: pedido.faixa_inicio_por },
        { rotulo: "Coroa finalizada", em: pedido.finalizada_em, por: pedido.finalizada_por },
        { rotulo: "Entregue", em: pedido.entregue_em, por: pedido.entregue_por },
    ].filter((l) => String(l.em ?? "").trim());

    return (
        <div className="qa-drawer-root fixed inset-0 z-50 flex items-stretch justify-end overflow-hidden" data-tema={tema} aria-modal role="dialog" aria-label="Informações da coroa">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} aria-hidden />
            <div className="qa-panel-premium qa-drawer-panel relative z-10 flex h-full w-full max-w-[640px] flex-col overflow-hidden border-l shadow-2xl">
                <div className="shrink-0 border-b border-slate-700/60 bg-slate-950/70 px-4 py-3 sm:px-5">
                    <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                            <div className="text-[11px] font-semibold uppercase tracking-[0.18em] qa-text-muted">Informações da coroa</div>
                            <h3 className="mt-1 text-lg font-bold leading-tight text-slate-100 sm:text-xl">{qtd > 1 ? `${qtd}× ` : ""}{coroaModelos(pedido)}</h3>
                            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs qa-text-muted">
                                <span>Solicitante: <b className="text-slate-200">{shown(pedido.solicitante, "a definir")}</b></span>
                                {coroaDataHora(pedido.criado_em) && <span>Pedido: <b className="text-slate-200">{coroaDataHora(pedido.criado_em)}</b></span>}
                            </div>
                            <div className="mt-2 flex flex-wrap items-center gap-2">
                                <span className="qa-tag qa-tag-status qa-tag-xs">{coroaStatusLabel(pedido.status)}</span>
                                <span className="qa-tag qa-tag-info qa-tag-xs">{coroaOrigemLabel(pedido.origem)}</span>
                                <span className={`qa-tag qa-tag-xs ${pago ? "qa-tag-ok" : "qa-tag-warn"}`}>{pago ? "Pago" : "Aguardando pagamento"}</span>
                            </div>
                            {atraso && <div className="qd-flag qd-flag-warn" style={{ background: "var(--d-warnbg)", color: "var(--d-warn)" }}>⏱ {atraso.longo}</div>}
                        </div>
                        <button
                            onClick={onClose}
                            className="shrink-0 rounded-lg border border-slate-700/70 bg-slate-900/50 px-3 py-1.5 text-xs font-semibold text-slate-200 transition hover:bg-slate-800"
                            aria-label="Fechar"
                        >
                            Fechar
                        </button>
                    </div>
                </div>

                <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 sm:px-5">
                    <div className="grid gap-3">
                        <Topic title={modelos.length > 1 ? "FOTOS DAS COROAS" : "FOTO DA COROA"} note="foto do cadastro do produto">
                            <div className="grid gap-3">
                                {modelos.length === 0 && <div className="qc-sem-foto">Pedido sem modelo definido.</div>}
                                {modelos.map((m) => {
                                    const url = fotos[m.chave];
                                    return (
                                        <figure key={m.chave} className="m-0">
                                            {url && !fotosComErro[m.chave] ? (
                                                <a href={url} target="_blank" rel="noreferrer" title="Abrir a foto em tamanho maior" className="block">
                                                    <img src={url} alt={`Foto da coroa ${m.modelo}`} className="qc-foto" onError={() => setFotosComErro((v) => ({ ...v, [m.chave]: true }))} />
                                                </a>
                                            ) : (
                                                <div className="qc-sem-foto">
                                                    {fotosCarregando ? "Carregando foto…" : fotosComErro[m.chave] ? "Não foi possível carregar a foto deste modelo." : "Este modelo não tem foto no cadastro do produto."}
                                                </div>
                                            )}
                                            <figcaption className="qc-legenda">{m.modelo}</figcaption>
                                        </figure>
                                    );
                                })}
                            </div>
                        </Topic>

                        <Topic title={itens.length > 1 ? "FRASES DAS FAIXAS" : "FRASE DA FAIXA"}>
                            {itens.length > 0 ? (
                                <div className="grid gap-2">
                                    {itens.map((it, k) => (
                                        <div key={String(it.id ?? k)}>
                                            {itens.length > 1 && (
                                                <div className="mb-1 text-xs font-bold text-slate-400">
                                                    Coroa {k + 1}{tipoTxt(it.tipo_coroa) ? ` · ${tipoTxt(it.tipo_coroa)}` : ""}{it.modelo_coroa ? ` · ${it.modelo_coroa}` : ""}
                                                </div>
                                            )}
                                            <div className="qc-frase">{String(it.frase ?? "").trim() ? sanitize(it.frase) : "Sem frase informada"}</div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="qc-frase">{String(pedido.frase ?? "").trim() ? sanitize(pedido.frase) : "Sem frase informada"}</div>
                            )}
                        </Topic>

                        <Topic title="PEDIDO">
                            <div className="grid grid-cols-1 gap-x-8 gap-y-2 sm:grid-cols-2">
                                <Field label="Solicitante" value={shown(pedido.solicitante, "a definir")} />
                                <Field label="Telefone" value={shown(pedido.telefone, "a definir")} />
                                <Field label="Falecido" value={shown(pedido.falecido, "a definir")} className="sm:col-span-2" />
                                <Field label="Entrega" value={shown(pedido.local_entrega, "a definir")} className="sm:col-span-2" />
                                <Field label="Origem" value={coroaOrigemLabel(pedido.origem)} />
                                <Field
                                    label="Pagamento"
                                    value={
                                        <>
                                            {pago ? "Pago" : "Aguardando"}
                                            {String(pedido.comprovante_url ?? "").trim() ? (
                                                <>
                                                    {" · "}
                                                    <a href={String(pedido.comprovante_url)} target="_blank" rel="noreferrer" className="qc-link">Ver comprovante</a>
                                                </>
                                            ) : null}
                                        </>
                                    }
                                />
                                {String(pedido.observacoes ?? "").trim() && <Field label="Observações" value={sanitize(pedido.observacoes)} className="sm:col-span-2" />}
                            </div>
                        </Topic>

                        <Topic title="ANDAMENTO">
                            <div className="grid gap-2">
                                {andamento.map((l) => (
                                    <Field key={l.rotulo} label={l.rotulo} value={`${coroaDataHora(l.em)}${String(l.por ?? "").trim() ? ` · ${shown(l.por, "")}` : ""}`} />
                                ))}
                            </div>
                        </Topic>
                    </div>
                </div>
            </div>
        </div>
    );
}

/* ===== Quadro do desktop (telas a partir de 1024 px, fora da rota da TV) =====
 * Cartões um abaixo do outro: identificação | etapas com tempos | Total e Ocioso.
 * Clique no cartão abre a gaveta de detalhes (a mesma do celular). Coroas em grade de 3 colunas. */
function DeskCartaoAtendimento({ resumo, onSelect }: { resumo: TvResumo; onSelect: (r: Registro) => void }) {
    const r = resumo.registro;
    const rankAtual = statusFlowRank(resumo.atualKey);
    const ocioso = resumo.durations.get("idle") ?? 0;
    const ociosoAtivo = resumo.activeKey === "idle";
    const semVelorio = !rotaAtivaLegado(r.realiza_velorio);
    const semSepultamento = !rotaAtivaLegado(r.realiza_sepultamento);
    const sepultamentoTxt = semSepultamento
        ? "Sem sepultamento pelo PAI"
        : `${shown(r.local_sepultamento || r.local)} · ${dateDayMonthOr(r.data_fim_velorio)} ${timeOr(r.hora_fim_velorio)}`;
    const nivel = resumo.alerta?.nivel;

    return (
        <article
            className={`qd-card ${nivel ? `qd-card-${nivel}` : ""} ${mobClasseConv(r.convenio).replace("qm-conv-", "qd-conv-")}`}
            role="button"
            tabIndex={0}
            onClick={() => onSelect(r)}
            onKeyDown={(e) => (e.key === "Enter" || e.key === " " ? onSelect(r) : undefined)}
            aria-label={`${shown(r.falecido)}: ${resumo.atualLabel}. Clique para ver os detalhes.`}
        >
            <div className="qd-id">
                <h3 className="qd-name">{shown(r.falecido)}</h3>
                <div className="qd-meta">
                    <span className={mobChipConvenio(r.convenio)}>{rotuloConvenioRegistro(r)}</span>
                    <span>Aberto {tvDataHora(resumo.criadoTs)} · {resumo.abertoPor || shown(r.agente)}</span>
                </div>
                <div className="qd-now">
                    <span className="qd-dot qa-status-blink" aria-hidden />
                    <div>
                        <b>{resumo.atualLabel}</b>
                        <span>há {tvDuracaoTexto(resumo.atualDesdeMs)}{resumo.atualResponsavel ? ` · ${resumo.atualResponsavel}` : ""}</span>
                    </div>
                </div>
                {resumo.alerta && (
                    <div className={`qd-flag qd-flag-${resumo.alerta.nivel}`}>{resumo.alerta.nivel === "crit" ? "⚠" : "⏱"} {resumo.alerta.texto}</div>
                )}
            </div>

            <div className="qd-mid">
                <ol className="qd-steps">
                    {TV_ETAPAS.map((step) => {
                        const pulada = isStatusStepSkipped(r, step.key);
                        const duracao = resumo.durations.get(step.key) ?? 0;
                        const ativa = !pulada && resumo.activeKey === step.key;
                        const feita = !pulada && !ativa && (duracao > 0 || rankAtual > statusFlowRank(step.key));
                        const estado = pulada ? "na" : ativa ? "live" : feita ? "done" : "pend";
                        const texto = pulada ? "sem" : ativa || feita ? formatDurationMs(duracao) : "—";
                        return (
                            <li
                                key={step.key}
                                className={`qd-s qd-s-${estado}`}
                                title={`${step.label} • ${pulada ? "Não se aplica" : ativa || feita ? formatDurationMs(duracao) : "Ainda não aconteceu"}`}
                            >
                                <span className={`qd-c ${ativa ? "qa-status-active-ring" : ""}`}>
                                    <span className={`qd-c-svg ${ativa ? "qa-status-blink" : ""}`}><StatusIcon type={step.icon} /></span>
                                </span>
                                <b>{texto}</b>
                            </li>
                        );
                    })}
                </ol>
                <dl className="qd-where">
                    <div><dt>Velório</dt><dd>{semVelorio ? "Sem velório" : <LocalVelorioQuadro r={r} />}</dd></div>
                    <div><dt>Sepult.</dt><dd>{sepultamentoTxt}</dd></div>
                </dl>
            </div>

            <div className="qd-tot">
                <div className="qd-box">
                    <small>Total</small>
                    <b title="Tempo total"><span className="qd-box-ic" aria-hidden><StatusIcon type="clock" /></span>{formatDurationMs(resumo.totalMs)}</b>
                </div>
                <div className={`qd-box qd-box-oc ${ociosoAtivo ? "qd-box-live" : ""} ${ocioso >= TV_LIMITE_PARADO_MS ? "qd-box-crit" : ""}`}>
                    <small>Ocioso</small>
                    <b title="Tempo ocioso"><span className={`qd-box-ic ${ociosoAtivo ? "qa-status-blink" : ""}`} aria-hidden><StatusIcon type="clockPause" /></span>{formatDurationMs(ocioso)}</b>
                </div>
            </div>
        </article>
    );
}

function QuadroDesktop({
    ativos,
    coroas,
    coroasError,
    statusLogsById,
    nowMs,
    clockTime,
    clockDate,
    avisos,
    onSelect,
    onSelectCoroa,
}: {
    ativos: Registro[];
    coroas: CoroaTvPedido[];
    coroasError?: string | null;
    statusLogsById: Record<string, LogItem[]>;
    nowMs: number;
    clockTime: string;
    clockDate: string;
    avisos: Aviso[];
    onSelect: (r: Registro) => void;
    onSelectCoroa?: (p: CoroaTvPedido) => void;
}) {
    const rootRef = useRef<HTMLDivElement | null>(null);
    const escuroApp = useTemaEscuroApp(rootRef);
    const { tema, alternar: alternarTema } = useTemaPai(escuroApp);
    const [avisosAbertos, setAvisosAbertos] = useState(false);

    const resumos = useMemo(
        () => ativos.map((r) => resumirAtendimentoTv(r, statusLogsById[getRegistroTrackingId(r)], nowMs)),
        [ativos, statusLogsById, nowMs]
    );
    const parados = resumos.filter((x) => x.alerta?.nivel === "crit").length;
    const totalCoroas = coroas.reduce((s, p) => s + coroaQuantidade(p), 0);
    const pagamentosPendentes = coroas.filter((p) => coroaPagamentoLabel(p) !== "Pago").length;
    const coroasAtrasadas = coroas.filter((p) => coroaAtrasoTv(p, nowMs)).length;
    const listaAvisos = useMemo(
        () =>
            (avisos ?? [])
                .map((a) => ({ usuario: shown(a?.usuario, "").trim(), mensagem: shown(a?.mensagem, "").trim() }))
                .filter((x) => x.usuario || x.mensagem),
        [avisos]
    );

    return (
        <div ref={rootRef} className="qm-root qd-root" data-tema={tema}>
            <div className="qd-scroll">
                <header className="qd-head">
                    <div className="qd-ico" aria-hidden>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></svg>
                    </div>
                    <div className="qd-title">
                        <h1>Quadro de Atendimentos</h1>
                        <div className="qd-sub">
                            <span className="qd-live"><i />Atualizado em tempo real</span>
                            <span className="qd-pill"><b>{ativos.length}</b>em andamento</span>
                            {parados > 0 && <span className="qd-pill qd-pill-crit"><b>{parados}</b>parados +24 h</span>}
                            <span className="qd-hint">Clique em um atendimento para ver as informações completas.</span>
                        </div>
                    </div>
                    <div className="qd-actions">
                        <a className="qd-btn" href={ROTA_TV} title="Abrir o quadro em modo TV">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden><rect x="2" y="4" width="20" height="13" rx="2" /><path d="M8 21h8M12 17v4" /></svg>
                            Modo TV
                        </a>
                        <BotaoTema tema={tema} onClick={alternarTema} className="qd-btn qd-ib" />
                        <div className="qd-clock"><b>{clockTime}</b><small>{clockDate}</small></div>
                    </div>
                </header>

                {listaAvisos.length > 0 && (
                    <>
                        <div className="qd-aviso">
                            <b className="qd-aviso-tag">AVISO</b>
                            <span className="qd-aviso-txt">{listaAvisos[0].usuario ? `${listaAvisos[0].usuario}: ` : ""}{listaAvisos[0].mensagem}</span>
                            <span className="qd-aviso-n">1 de {listaAvisos.length}</span>
                            {listaAvisos.length > 1 && (
                                <button type="button" className="qd-btn qd-btn-sm" aria-expanded={avisosAbertos} onClick={() => setAvisosAbertos((v) => !v)}>
                                    {avisosAbertos ? "Recolher" : "Ver todos"}
                                </button>
                            )}
                        </div>
                        {avisosAbertos && (
                            <div className="qd-avlist">
                                {listaAvisos.map((a, i) => (
                                    <div key={i} className="qd-avitem">
                                        <span className="qd-aviso-tag qd-avitem-tag">AVISO</span>
                                        <div><b>{a.usuario}</b><p>{a.mensagem}</p></div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </>
                )}

                <div className="qd-list">
                    {resumos.length === 0 && <p className="qm-empty">Nenhum atendimento em andamento.</p>}
                    {resumos.map((resumo, i) => (
                        <DeskCartaoAtendimento key={resumo.trackingId || i} resumo={resumo} onSelect={onSelect} />
                    ))}
                </div>
                {resumos.length > 0 && <p className="qm-note">Mostrando os atendimentos mais recentes (máximo de 60)</p>}

                <section className="qd-cor" aria-label="Coroas de Flores em Confecção">
                    <h2>Coroas de Flores em Confecção <span className="qd-n">{totalCoroas}</span></h2>
                    {coroasError && <p className="qm-note qm-note-warn">Dados das coroas podem estar desatualizados.</p>}
                    {coroas.length > 0 ? (
                        <>
                            <p className="qm-note qd-cor-note">
                                {totalCoroas} {totalCoroas === 1 ? "coroa" : "coroas"} em {coroas.length} {coroas.length === 1 ? "pedido" : "pedidos"}
                                {pagamentosPendentes ? ` · ${pagamentosPendentes} aguardando pagamento` : ""}
                                {coroasAtrasadas ? ` · ${coroasAtrasadas} ${coroasAtrasadas === 1 ? "atrasada" : "atrasadas"}` : ""} · ordem de chegada
                            </p>
                            <div className="qd-cgrid">
                                {coroas.map((p, i) => (
                                    <MobCartaoCoroa key={String(p.id ?? i)} pedido={p} nowMs={nowMs} atraso={coroaAtrasoTv(p, nowMs)} onSelect={onSelectCoroa} />
                                ))}
                            </div>
                        </>
                    ) : (
                        <p className="qm-empty">Nenhuma coroa em confecção.</p>
                    )}
                </section>
            </div>

            <DeskStyles />
            <MobStyles />
            <StatusBlinkStyle />
        </div>
    );
}

function DeskStyles() {
    return (
        <style jsx global>{`
            .qd-root { padding: 16px 18px 0; gap: 0; border-radius: 22px; }
            .qd-scroll { flex: 1; min-height: 0; overflow-y: auto; overscroll-behavior: contain; display: flex; flex-direction: column; gap: 16px; padding: 4px 6px 24px 2px; }
            .qd-scroll > * { flex: none; }
            .qd-head { display: flex; align-items: center; gap: 16px; }
            .qd-ico { flex: none; width: 56px; height: 56px; border-radius: 18px; background: #313C55; color: #fff; display: grid; place-items: center; }
            .qd-root[data-tema="escuro"] .qd-ico { border: 1px solid var(--qm-line); }
            .qd-ico svg { width: 28px; height: 28px; }
            .qd-title { flex: 1; min-width: 0; }
            .qd-title h1 { margin: 0; font-size: 30px; font-weight: 800; line-height: 1.1; }
            .qd-sub { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 12px; margin-top: 6px; }
            .qd-live { display: inline-flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 800; color: var(--qm-ok); }
            .qd-live i { width: 8px; height: 8px; border-radius: 50%; background: var(--qm-ok); }
            .qd-pill { display: inline-flex; align-items: center; gap: 6px; height: 32px; padding: 0 14px; border-radius: 16px; border: 1.5px solid var(--qm-line); background: var(--qm-surface); font-size: 13px; font-weight: 700; color: var(--qm-muted); }
            .qd-pill b { font-size: 15px; font-weight: 800; color: var(--qm-text); }
            .qd-pill-crit { color: var(--qm-crit); background: var(--qm-critbg); border-color: transparent; }
            .qd-pill-crit b { color: var(--qm-crit); }
            .qd-hint { font-size: 13px; color: var(--qm-muted); }
            .qd-actions { flex: none; display: flex; align-items: center; gap: 8px; }
            .qd-btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; height: 44px; padding: 0 16px; border-radius: 12px; border: 1.5px solid var(--qm-text); background: var(--qm-surface); color: var(--qm-text); font-size: 14px; font-weight: 800; text-decoration: none; cursor: pointer; }
            .qd-btn:hover { background: var(--qm-s2); }
            .qd-btn svg { width: 18px; height: 18px; }
            .qd-ib { width: 44px; padding: 0; border-color: var(--qm-line); }
            .qd-btn-sm { height: 40px; padding: 0 14px; font-size: 13px; }
            .qd-btn:focus-visible, .qd-card:focus-visible { outline: 2px solid var(--qm-acc); outline-offset: 2px; }
            .qd-clock { text-align: right; margin-left: 8px; }
            .qd-clock b { display: block; font-size: 30px; font-weight: 800; line-height: 1; font-variant-numeric: tabular-nums; }
            .qd-clock small { display: block; margin-top: 4px; font-size: 13px; font-weight: 700; color: var(--qm-muted); }

            .qd-aviso { display: flex; align-items: center; gap: 12px; padding: 8px 8px 8px 16px; border-radius: 16px; background: var(--qm-accbg); }
            .qd-aviso-tag { font-size: 12px; font-weight: 800; letter-spacing: .12em; }
            .qd-aviso-txt { flex: 1; min-width: 0; font-size: 14px; overflow-wrap: anywhere; }
            .qd-aviso-n { font-size: 12px; font-weight: 700; color: var(--qm-muted); }
            .qd-avlist { background: var(--qm-surface); border: 1px solid var(--qm-line); border-radius: 16px; overflow: hidden; margin-top: -8px; }
            .qd-avitem { display: flex; gap: 12px; align-items: flex-start; padding: 12px 16px; border-top: 1px solid var(--qm-line); }
            .qd-avitem:first-child { border-top: 0; }
            .qd-avitem-tag { flex: none; padding: 4px 8px; border-radius: 8px; background: var(--qm-accbg); font-size: 11px; }
            .qd-avitem b { font-size: 14px; font-weight: 800; }
            .qd-avitem p { margin: 2px 0 0; font-size: 14px; overflow-wrap: anywhere; }

            .qd-list { display: flex; flex-direction: column; gap: 14px; }
            .qd-card { display: grid; grid-template-columns: minmax(250px, 300px) minmax(0, 1fr) 150px; gap: 28px; align-items: center; padding: 18px 22px; background: var(--qm-surface); border: 1px solid var(--qm-line); border-radius: 22px; box-shadow: var(--qm-shadow); cursor: pointer; text-align: left; }
            .qd-card:hover { border-color: var(--qm-text); }
            .qd-card-crit { box-shadow: inset 5px 0 0 var(--qm-crit), var(--qm-shadow); }
            .qd-card-warn { box-shadow: inset 5px 0 0 var(--qm-warn), var(--qm-shadow); }
            .qd-id, .qd-mid { min-width: 0; }
            .qd-name { margin: 0; font-size: 18px; font-weight: 800; line-height: 1.2; overflow-wrap: anywhere; }
            .qd-meta { display: flex; flex-wrap: wrap; align-items: center; gap: 4px 8px; margin-top: 6px; font-size: 12px; font-weight: 600; color: var(--qm-muted); }
            .qd-now { display: flex; align-items: center; gap: 12px; margin-top: 12px; padding: 12px 14px; border-radius: 16px; background: var(--qm-s2); }
            .qd-conv-assoc .qd-now { background: rgba(179, 206, 82, .28); }
            .qd-conv-pref .qd-now { background: rgba(0, 174, 236, .22); }
            .qd-conv-part .qd-now { background: rgba(242, 203, 63, .28); }
            .qd-dot { flex: none; width: 12px; height: 12px; border-radius: 50%; background: var(--qm-livebd); }
            .qd-now b { display: block; font-size: 16px; font-weight: 800; line-height: 1.2; }
            .qd-now span { display: block; margin-top: 2px; font-size: 12px; font-weight: 700; overflow-wrap: anywhere; }
            .qd-flag { display: inline-block; margin-top: 8px; font-size: 12px; font-weight: 800; border-radius: 10px; padding: 5px 10px; }
            .qd-flag-crit { background: var(--qm-critbg); color: var(--qm-crit); }
            .qd-flag-warn { background: var(--qm-warnbg); color: var(--qm-warn); }

            .qd-steps { list-style: none; margin: 0; padding: 14px 8px 12px; display: flex; background: var(--qm-s2); border: 1px solid var(--qm-line); border-radius: 18px; }
            .qd-s { flex: 1; min-width: 0; position: relative; display: flex; flex-direction: column; align-items: center; gap: 7px; }
            .qd-s:not(:first-child)::before { content: ""; position: absolute; top: 23px; right: calc(50% + 26px); width: calc(100% - 52px); height: 3px; border-radius: 2px; background: var(--qm-line); }
            .qd-s-done::before, .qd-s-live::before { background: var(--qm-acc) !important; }
            .qd-c { position: relative; z-index: 1; width: 48px; height: 48px; border-radius: 50%; display: grid; place-items: center; box-sizing: border-box; border: 2px solid var(--qm-line); background: var(--qm-surface); color: var(--qm-muted); }
            .qd-c-svg { width: 22px; height: 22px; display: inline-block; }
            .qd-s-done .qd-c { background: var(--qm-donebg); border-color: var(--qm-acc); color: var(--qm-donefg); }
            .qd-s-live .qd-c { background: var(--qm-livebg); border-color: var(--qm-livebd); color: var(--qm-live); }
            .qd-s-na .qd-c { border-style: dashed; }
            .qd-s-na .qd-c-svg { opacity: .45; }
            .qd-s b { font-size: 14px; font-weight: 800; line-height: 1; font-variant-numeric: tabular-nums; }
            .qd-s-pend b, .qd-s-na b { color: var(--qm-muted); font-weight: 700; }
            .qd-s-live b { color: var(--qm-live); }
            .qd-where { margin: 10px 0 0; display: grid; grid-template-columns: 1fr 1fr; gap: 6px 18px; font-size: 13px; }
            .qd-where div { display: flex; gap: 8px; min-width: 0; }
            .qd-where dt { flex: none; font-weight: 800; color: var(--qm-muted); }
            .qd-where dd { margin: 0; font-weight: 700; min-width: 0; overflow-wrap: anywhere; }

            .qd-tot { display: grid; gap: 12px; justify-items: end; }
            .qd-box { text-align: right; }
            .qd-box small { display: block; font-size: 11px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; color: var(--qm-muted); }
            .qd-box b { display: inline-flex; align-items: center; gap: 6px; font-size: 24px; font-weight: 800; line-height: 1.1; font-variant-numeric: tabular-nums; }
            .qd-box-ic { display: inline-flex; width: 22px; height: 22px; }
            .qd-box-ic svg { width: 100%; height: 100%; }
            .qd-box-oc b { color: var(--qm-ok); }
            .qd-box-live b { color: var(--qm-live); }
            .qd-box-crit b { color: var(--qm-crit); }

            .qd-cor h2 { margin: 6px 0 8px; display: flex; align-items: center; gap: 10px; font-size: 20px; font-weight: 800; }
            .qd-n { background: var(--qm-acc); color: #10233F; border-radius: 999px; padding: 0 12px; font-size: 15px; font-weight: 800; }
            .qd-cor-note { margin-bottom: 10px; text-align: left; }
            .qd-cgrid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }

            @media (max-width: 1435px) {
                .qd-card { grid-template-columns: minmax(210px, 250px) minmax(0, 1fr) 118px; gap: 18px; padding: 16px 18px; }
                .qd-c { width: 40px; height: 40px; }
                .qd-c-svg { width: 19px; height: 19px; }
                .qd-s:not(:first-child)::before { top: 19px; right: calc(50% + 22px); width: calc(100% - 44px); }
                .qd-box b { font-size: 20px; }
                .qd-hint { display: none; }
                .qd-cgrid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            }
        `}</style>
    );
}

/* ===== Componentes auxiliares ===== */
function Topic({ title, children, note }: { title: string; children: React.ReactNode; note?: string }) {
    return (
        <section className="rounded-xl border border-slate-700/60 bg-slate-950/35 p-3">
            <div className="flex items-start justify-between gap-2">
                <h4 className="mb-3 text-xs font-bold tracking-wide text-slate-300">{title}</h4>
                {note && <div className="text-[11px] sm:text-xs text-muted-foreground italic">{note}</div>}
            </div>
            {children}
        </section>
    );
}

function Field({ label, value, className = "" }: { label: string; value: React.ReactNode; className?: string }) {
    return (
        <div className={`flex items-baseline gap-2 ${className}`}>
            <span className="min-w-[120px] shrink-0 text-xs font-bold text-slate-400">{label}:</span>
            <span className="min-w-0 text-xs font-semibold text-slate-100 break-words [overflow-wrap:anywhere]">{value}</span>
        </div>
    );
}

function EtapasInlineDots({ filled }: { filled: boolean[] }) {
    return (
        <div className="qa-etapas-dots flex items-center gap-1" title="Etapas preenchidas">
            {[0, 1, 2, 3].map((k) => (
                <span
                    key={k}
                    className={`qa-etapa-dot h-1.5 w-1.5 rounded-full border ${filled[k] ? STAGE_DOT_FILLED[k] : STAGE_DOT_EMPTY
                        }`}
                />
            ))}
        </div>
    );
}

function StatusTimelineCell({
    registro,
    logs,
    nowMs,
    variant = "desktop",
}: {
    registro: Registro;
    logs?: LogItem[];
    nowMs: number;
    variant?: "desktop" | "mobile";
}) {
    const segments = buildStatusSegments(registro, logs, nowMs);
    const firstStart = segments[0]?.start ?? nowMs;
    const totalMs = Math.max(0, nowMs - firstStart);
    const current = segments[segments.length - 1];

    const { durations, activeKey } = getStatusDisplayData(segments);

    if (variant === "mobile") {
        const activeStep = STATUS_STEPS.find((step) => step.key === activeKey) ?? STATUS_STEPS[0];
        const activeDuration = durations.get(activeStep.key) ?? 0;
        return (
            <div className="flex min-w-0 items-center gap-1 overflow-hidden">
                <StatusPill icon={activeStep.icon} label={activeStep.shortLabel} time={formatDurationMs(activeDuration)} active={!!activeKey} />
                <StatusPill icon="timer" label="Total" time={formatDurationMs(totalMs)} total />
                <StatusBlinkStyle />
            </div>
        );
    }

    return (
        <div className="-ml-6 flex w-full min-w-0 items-center justify-start gap-1 overflow-visible px-0 pr-1">
            {STATUS_STEPS.map((step) => {
                const duration = durations.get(step.key) ?? 0;
                const skipped = isStatusStepSkipped(registro, step.key);
                const isActive = !skipped && activeKey === step.key;
                return (
                    <StatusPill
                        key={step.key}
                        icon={step.icon}
                        label={step.shortLabel}
                        time={skipped ? "00:00" : duration > 0 ? formatDurationMs(duration) : "00:00"}
                        active={isActive}
                        muted={!isActive && (duration <= 0 || skipped)}
                        skipped={skipped}
                        title={`${step.label} • ${skipped ? "Não realizado neste atendimento" : duration > 0 ? formatDurationMs(duration) : "00:00"}`}
                    />
                );
            })}
            <StatusPill icon="timer" label="Total" time={formatDurationMs(totalMs)} total title="Tempo total em atendimento" />
            <StatusBlinkStyle />
        </div>
    );
}

function isStatusStepSkipped(registro: Registro, stepKey: string): boolean {
    // Tanatopraxia explicitamente marcada como "Não".
    if (stepKey === "fase03") return isNao(registro.tanato);

    // Ornamentação explicitamente marcada como "Não".
    if (stepKey === "fase05") return isNao(registro.ornamentacao);

    // Velório explicitamente marcado como "Não".
    // Campo vazio/NULL continua preservando a compatibilidade dos registros legados.
    if (stepKey === "fase08") return isNao(registro.realiza_velorio);

    // Sepultamento explicitamente marcado como "Não".
    // Campo vazio/NULL continua preservando a compatibilidade dos registros legados.
    if (stepKey === "fase09") return isNao(registro.realiza_sepultamento);

    // Assistência (materiais) explicitamente marcada como "Não":
    // a etapa visual de Material Recolhido não se aplica.
    if (stepKey === "fase10") return isNao(registro.assistencia);

    return false;
}

function StatusPill({
    icon,
    label,
    time,
    active = false,
    muted = false,
    total = false,
    skipped = false,
    title,
}: {
    icon: StatusIconKey;
    label: string;
    time: string;
    active?: boolean;
    muted?: boolean;
    total?: boolean;
    skipped?: boolean;
    title?: string;
}) {
    return (
        <div
            className={`qa-status-pill relative flex h-[35px] w-[32px] shrink-0 flex-col items-center justify-center px-0 text-center leading-none transition ${total ? "ml-0.5 mr-1" : ""}`}
            title={title ?? `${label} • ${time}`}
        >
            <div className={`qa-status-pill-ring relative flex h-[22px] w-[22px] items-center justify-center rounded-full ${active ? "qa-status-active-ring border border-[#22C55E]/90 shadow-[0_0_8px_rgba(34,197,94,.45)]" : "border border-transparent"}`}>
                <div
                    className={`qa-status-pill-icon relative flex h-[17px] w-[17px] items-center justify-center ${active ? "qa-status-blink text-[#22C55E]" : "text-[#00AEEC]"} ${muted ? "opacity-[0.12]" : ""}`}
                    aria-hidden="true"
                >
                    <StatusIcon type={icon} />
                </div>
            </div>
            <div className={`qa-status-pill-time mt-[3px] w-full truncate text-[8.5px] font-black leading-none tabular-nums ${muted ? "text-slate-500/35" : active ? "text-[#22C55E]" : "text-slate-100"}`}>{time}</div>
            {skipped && (
                <span className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center text-[43px] font-semibold leading-none text-[#00AEEC]">
                    ×
                </span>
            )}
        </div>
    );
}

function StatusIcon({ type }: { type: StatusIconKey }) {
    const common = {
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: 2.15,
        strokeLinecap: "round" as const,
        strokeLinejoin: "round" as const,
        className: "h-full w-full",
    };

    switch (type) {
        case "hospital":
            return (
                <svg {...common}>
                    <path d="M4 21V6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5V21" />
                    <path d="M9 21v-5a3 3 0 0 1 6 0v5" />
                    <path d="M12 7.5v5" />
                    <path d="M9.5 10h5" />
                    <path d="M6.5 21h11" />
                </svg>
            );
        case "testTube":
            return (
                <svg {...common}>
                    <path d="M10 2h7" />
                    <path d="M14 2v6.6l4.5 7.8A3.7 3.7 0 0 1 15.3 22H8.7a3.7 3.7 0 0 1-3.2-5.6L10 8.6V2" />
                    <path d="M8.2 15h7.6" />
                </svg>
            );
        case "flower":
            return (
                <svg {...common}>
                    <circle cx="12" cy="12" r="2" />
                    <path d="M12 4.5c1.7 1.7 1.7 3.3 0 5-1.7-1.7-1.7-3.3 0-5Z" />
                    <path d="M12 19.5c-1.7-1.7-1.7-3.3 0-5 1.7 1.7 1.7 3.3 0 5Z" />
                    <path d="M4.5 12c1.7-1.7 3.3-1.7 5 0-1.7 1.7-3.3 1.7-5 0Z" />
                    <path d="M19.5 12c-1.7 1.7-3.3 1.7-5 0 1.7-1.7 3.3-1.7 5 0Z" />
                </svg>
            );
        case "coffin":
            return (
                <svg {...common}>
                    <path d="M9 3h6l3 5-1.5 13h-9L6 8l3-5Z" />
                    <path d="M12 7v8" />
                    <path d="M9.8 10h4.4" />
                </svg>
            );
        case "car":
            return (
                <svg {...common}>
                    <path d="M5 16h14" />
                    <path d="M6.5 16l1.4-5.2A3 3 0 0 1 10.8 8h2.4a3 3 0 0 1 2.9 2.8L17.5 16" />
                    <circle cx="8" cy="17" r="2" />
                    <circle cx="16" cy="17" r="2" />
                    <path d="M9 12h6" />
                </svg>
            );
        case "box":
            return (
                <svg {...common}>
                    <path d="M4 8.5 12 4l8 4.5-8 4.5L4 8.5Z" />
                    <path d="M4 8.5V16l8 4 8-4V8.5" />
                    <path d="M12 13v7" />
                    <path d="M8.2 6.2 16 10.6" />
                </svg>
            );
        case "hourglass":
            return (
                <svg {...common}>
                    <path d="M6 3h12" />
                    <path d="M6 21h12" />
                    <path d="M8 3c0 5 8 5 8 9s-8 4-8 9" />
                    <path d="M16 3c0 5-8 5-8 9s8 4 8 9" />
                    <path d="M10 8h4" />
                    <path d="M10 16h4" />
                </svg>
            );
        case "clock":
            // Tempo total: relógio comum
            return (
                <svg {...common}>
                    <circle cx="12" cy="12" r="9" />
                    <path d="M12 7v5l3 2" />
                </svg>
            );
        case "clockPause":
            // Tempo ocioso: relógio em pausa
            return (
                <svg {...common}>
                    <circle cx="12" cy="12" r="9" />
                    <path d="M10 9v6" />
                    <path d="M14 9v6" />
                </svg>
            );
        case "timer":
            return (
                <svg {...common}>
                    <circle cx="12" cy="13" r="7" />
                    <path d="M12 13V9" />
                    <path d="M12 13l3 2" />
                    <path d="M9 2h6" />
                    <path d="M12 2v3" />
                </svg>
            );
        default:
            return (
                <svg {...common}>
                    <circle cx="12" cy="12" r="3" fill="currentColor" stroke="none" />
                </svg>
            );
    }
}

function StatusBlinkStyle() {
    return (
        <style jsx global>{`
            @keyframes qa-status-pulse {
                0%, 100% { opacity: 1; transform: scale(1); filter: drop-shadow(0 0 4px rgba(34, 197, 94, 0.95)); }
                50% { opacity: 0.55; transform: scale(1.1); filter: drop-shadow(0 0 8px rgba(34, 197, 94, 0.9)); }
            }
            @keyframes qa-status-ring-pulse {
                0%, 100% { opacity: 1; transform: scale(1); box-shadow: 0 0 6px rgba(34, 197, 94, 0.42); border-color: rgba(34, 197, 94, 0.92); }
                50% { opacity: 0.72; transform: scale(1.07); box-shadow: 0 0 9px rgba(34, 197, 94, 0.68); border-color: rgba(34, 197, 94, 1); }
            }
            .qa-status-blink {
                display: inline-block;
                animation: qa-status-pulse 1.05s ease-in-out infinite;
            }
            .qa-status-active-ring {
                animation: qa-status-ring-pulse 1.05s ease-in-out infinite;
            }
            @media (prefers-reduced-motion: reduce) {
                .qa-status-blink,
                .qa-status-active-ring { animation: none !important; }
            }
        `}</style>
    );
}

function EtapasRow({ registro }: { registro: Registro }) {
    const preenchidas = etapasPreenchidas(registro);
    const labels = ["D", "I", "V", "S"];
    return (
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
            {labels.map((label, k) => (
                <div key={k} className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">{label}</span>
                    <span className={`h-4 w-4 rounded-full border ${preenchidas[k] ? STAGE_DOT_FILLED[k] : STAGE_DOT_EMPTY}`} />
                </div>
            ))}
        </div>
    );
}

/* ===== Linha do Tempo (Logs) ===== */
function isLikelyBooleanMap(obj: Record<string, unknown>) {
    const entries = Object.entries(obj);
    if (entries.length === 0) return false;
    let boolish = 0;
    for (const [, v] of entries) {
        const s = decodeHtmlEntitiesDeep(String(v ?? "")).trim().toLowerCase();
        if (typeof v === "boolean" || ["true", "false", "1", "0", "sim", "nao", "não"].includes(s)) boolish++;
    }
    return boolish / entries.length >= 0.8;
}

function looksLikeMateriaisJson(s: string) {
    const t = (s || "").toLowerCase();
    return (t.includes('"nome"') && t.includes('"checked"')) || t.includes('"item');
}

function extractMateriaisByRegex(text: string): Array<{ nome: string; qtd?: string }> {
    const s = decodeHtmlEntitiesDeep(text).replace(/[“”]/g, '"').replace(/[‘’]/g, "'");

    const out: Array<{ nome: string; qtd?: string }> = [];

    const reNome = /(?:^|[,{]\s*)"?nome"?\s*:\s*["']([^"']+)["']/gi;
    let m: RegExpExecArray | null;

    while ((m = reNome.exec(s))) {
        const nome = (m[1] || "").trim();
        const near = s.slice(m.index, m.index + 260);
        const qtd = near.match(/"?qtd"?\s*:\s*["']?([0-9]+(?:[.,][0-9]+)?)["']?/i)?.[1];
        if (nome) out.push({ nome, qtd });
    }

    return out;
}

function tryParseJsonFromStringMaybeEmbedded(raw: string): unknown | null {
    const decoded = decodeHtmlEntitiesDeep(raw);
    const trimmed = decoded.trim().replace(/^\s*json\s*:\s*/i, "").trim();

    if ((trimmed.startsWith("{") && trimmed.endsWith("}")) || (trimmed.startsWith("[") && trimmed.endsWith("]"))) {
        try {
            return JSON.parse(trimmed);
        } catch {
            /* ignore */
        }
    }

    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start >= 0 && end > start) {
        const slice = trimmed.slice(start, end + 1);
        try {
            return JSON.parse(slice);
        } catch {
            /* ignore */
        }
    }
    return null;
}

function buildDetalhesNodes(raw: unknown): React.ReactNode {
    if (raw == null || raw === "") return null;

    let obj: unknown = raw;

    if (typeof raw === "string") {
        const parsed = tryParseJsonFromStringMaybeEmbedded(raw);
        if (parsed != null) obj = parsed;
        else {
            const text = substituirRotuloVisual(decodeHtmlEntitiesDeep(raw).trim());
            return text ? (
                <div className="mt-2 text-sm whitespace-pre-wrap break-words [overflow-wrap:anywhere]">{text}</div>
            ) : null;
        }
    }

    if (isPlainObject(obj)) {
        const plainObj = obj as Record<string, unknown>;

        if (isLikelyBooleanMap(plainObj)) {
            const arrItems = Object.entries(plainObj)
                .filter(([, v]) => asBool(v))
                .map(([k]) => titleCaseFromSnake(k));

            return arrItems.length ? (
                <div className="mt-3 w-full min-w-0">
                    <div className="rounded-lg border bg-background px-3 py-2 text-xs">
                        <div className="font-semibold mb-1">Arrumação:</div>
                        <ul className="list-disc pl-4 space-y-0.5">
                            {arrItems.map((t, idx) => (
                                <li key={idx} className="break-words [overflow-wrap:anywhere]">
                                    {t}
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            ) : null;
        }

        const arrItems: string[] = [];
        const rows: { id: string; label: string; value: string }[] = [];

        for (const key of Object.keys(plainObj)) {
            if (["materiais_json", "id", "acao"].includes(key)) continue;

            const value = plainObj[key];

            if (/^arrum[aã]cao(\s*json|_json)?$/i.test(key) && value && isPlainObject(value)) {
                for (const [k, v] of Object.entries(value)) {
                    if (asBool(v)) arrItems.push(titleCaseFromSnake(k));
                }
                continue;
            }

            const m = key.match(/^materiais_(.+?)_qtd$/i);
            if (m) {
                const valRaw = value;
                if (valRaw != null && String(valRaw).trim() !== "") {
                    const nomeBase = titleCaseFromSnake(m[1]);
                    const nome = overrideCampoNome(m[1], nomeBase);
                    const valFmt = formataSeDataIso(String(valRaw));
                    rows.push({ id: key, label: nome, value: valFmt });
                }
                continue;
            }

            if (value == null) continue;
            if (typeof value === "object") continue;

            const valStr = decodeHtmlEntitiesDeep(String(value)).trim();
            if (!valStr) continue;

            let nome = key.replace(/_/g, " ");
            nome = overrideCampoNome(key, titleCaseFromSnake(nome));
            let valFmt = valStr;

            const maybeEmbedded = tryParseJsonFromStringMaybeEmbedded(valFmt);
            if (maybeEmbedded && isPlainObject(maybeEmbedded) && isLikelyBooleanMap(maybeEmbedded as Record<string, unknown>)) {
                const map = maybeEmbedded as Record<string, unknown>;
                const items = Object.entries(map)
                    .filter(([, v]) => asBool(v))
                    .map(([k]) => titleCaseFromSnake(k));
                if (items.length) arrItems.push(...items);
                continue;
            }

            if (valFmt.toLowerCase().startsWith("fase")) valFmt = traduzirFase(valFmt);
            valFmt = formataSeDataIso(valFmt);

            nome = substituirRotuloVisual(nome);
            valFmt = substituirRotuloVisual(valFmt);

            rows.push({ id: key, label: nome, value: valFmt });
        }

        if (rows.length === 0 && arrItems.length === 0) return null;

        return (
            <div className="mt-3 space-y-2 w-full min-w-0">
                {arrItems.length > 0 && (
                    <div className="rounded-lg border bg-background px-3 py-2 text-xs">
                        <div className="font-semibold mb-1">Arrumação:</div>
                        <ul className="list-disc pl-4 space-y-0.5">
                            {[...new Set(arrItems)].map((t, idx) => (
                                <li key={idx} className="break-words [overflow-wrap:anywhere]">
                                    {t}
                                </li>
                            ))}
                        </ul>
                    </div>
                )}

                {rows.map((row) => (
                    <div
                        key={row.id}
                        className="rounded-lg border bg-background px-3 py-2 text-xs whitespace-pre-wrap break-words [overflow-wrap:anywhere] min-w-0"
                    >
                        <span className="font-semibold">{row.label}: </span>
                        <span className="break-words [overflow-wrap:anywhere]">{row.value}</span>
                    </div>
                ))}
            </div>
        );
    }

    const text = substituirRotuloVisual(decodeHtmlEntitiesDeep(String(obj)));
    return text.trim() ? (
        <div className="mt-2 text-sm whitespace-pre-wrap break-words [overflow-wrap:anywhere]">{text}</div>
    ) : null;
}

/* Ícone da linha do tempo: o mesmo conjunto de ícones das etapas (fase), ou ponto para as demais ações. */
function LogIcone({ acao, status }: { acao?: string; status?: string }) {
    const fase = normalizarStatus(status);
    const info = fase && fase.startsWith("fase") ? getStatusStepInfo(fase) : null;
    const tipo: StatusIconKey = info ? info.icon : "dot";
    return (
        <div className={`qa-log-ic ${info ? "" : "qa-log-ic-dot"}`} title={info ? info.label : capitalize(acao || "")} aria-hidden>
            <span><StatusIcon type={tipo} /></span>
        </div>
    );
}

function LinhaDoTempoLogs({ logs, usuarioVisivel = true }: { logs: LogItem[]; usuarioVisivel?: boolean }) {
    if (!logs || logs.length === 0) {
        return <div className="p-4 text-center text-muted-foreground">Nenhum log encontrado.</div>;
    }

    return (
        <div className="space-y-2 w-full min-w-0 overflow-x-hidden">
            {logs.map((ent, i) => {
                const acao = ent.acao ? capitalize(ent.acao) : "";
                const statusLabel = ent.status_novo ? traduzirFase(ent.status_novo) : "";
                const detalhes = buildDetalhesNodes(ent.detalhes);

                return (
                    <div key={i} className="log-entry rounded-xl border bg-background/60 p-2.5 shadow-sm overflow-hidden min-w-0">
                        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 min-w-0">
                            <LogIcone acao={ent.acao} status={ent.status_novo} />

                            <div className="flex-1 min-w-0">
                                <div className="text-[11px] text-muted-foreground">{formatLogDateTime(ent.datahora)}</div>

                                <div className="text-sm flex flex-wrap items-center gap-1 min-w-0">
                                    <span className="break-words [overflow-wrap:anywhere]">{acao}</span>
                                    {statusLabel && (
                                        <span className="rounded bg-primary/10 px-1.5 py-0.5 text-[11px] font-semibold text-primary break-words [overflow-wrap:anywhere]">
                                            {statusLabel}
                                        </span>
                                    )}
                                </div>

                                {usuarioVisivel && (
                                    <div className="text-[11px] text-muted-foreground break-words [overflow-wrap:anywhere]">
                                        Usuário: {ent.usuario ?? ""}
                                    </div>
                                )}

                                {detalhes}
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
}

/** Contato no resumo: nome do responsável e, embaixo, o telefone. Sem nome, mostra só o telefone (como antes). */
function ContatoDoAtendimento({ nome, telefone, vazio }: { nome?: unknown; telefone?: unknown; vazio: React.ReactNode }) {
    const n = String(nome ?? "").trim();
    const t = String(telefone ?? "").trim();
    if (!n) return <>{vazio}</>;
    return (
        <>
            {n}
            {t && <span className="block text-[13px] font-bold text-[var(--d-muted)]">{t}</span>}
        </>
    );
}
