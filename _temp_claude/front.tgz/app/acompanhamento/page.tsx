// FASE12 CORPO PRONTO - CHECKPOINT ÚNICO DE BAIXA DE ESTOQUE
"use client";

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  ArrumacaoState,
  MateriaisState,
  Registro,
  Aviso,
  CoroaAtendimentoItem,
} from "./components/types";
import {
  API,
  obrigatorios as obrigatoriosPadrao,
  steps as stepsPadrao,
  wizardStepIndexes as wizardStepIndexesPadrao,
  wizardStepTitles as wizardStepTitlesPadrao,
  localCerimoniaEfetivo,
} from "./components/constants";
import {
  defaultArrumacao,
  defaultMateriais,
  jsonWith401,
  enviarRegistroPHP,
  capitalizeStatus,
  normalizarStatus,
  normalizeMateriaisState,
} from "./components/helpers";

import TabelaAtendimentos from "./components/TabelaAtendimentos";
import OSDoAtendimento from "@/app/os/components/OSDoAtendimento";
import { BotoesTopoAtendimentos } from "@/components/atendimentos/BotoesAtendimento";
import { BotaoAtendimentosCancelados } from "@/components/correcoes/CorrecoesAtendimento";
import {
  OS_CAMPOS_VAZIO,
  SecaoOSAtendimento,
  carregarCamposOS,
  salvarLocalCerimonia,
  salvarEsincronizarOS,
  tipoConvenio,
  validarCamposOS,
  type OsCampos, type ParteOS,
  ConvenioVinculo,
  resolverVinculo,
  useOpcoesConvenio,
} from "./components/OsAtendimento";
import Visita, {
  consultarAcessoVisita,
  consultarStatusVisitas,
  type VisitaStatus,
} from "./components/visita";

import Wizard, { type CampoFaltando, type TravaItens } from "./components/Wizard";
// Orçamento → Novo registro (13/10/2026): as ferramentas ficam na pasta do Orçamento.
import { camposDoOrcamento, marcarOrcamentoConvertido } from "@/app/orcamento/components/paraAtendimento";
import MateriaisModal from "./components/MateriaisModal";
import ArrumacaoModal from "./components/ArrumacaoModal";
import AcaoModal, {
  type EstoqueInsuficienteAlerta,
  type EstoqueInsuficienteItem,
} from "./components/AcaoModal";
import InfoModal from "./components/InfoModal";
import SignatureModal from "./components/SignatureModal";
import CompartilharModal from "./components/CompartilharModal";
import TelemetriaModal, {
  TipoTele,
  TelemetriaHandle,
  remapOfflineTelemetryRecordId,
} from "./components/TelemetriaModal";
import FotoAcaoModal, { FotoAcaoTipo } from "./components/FotoAcaoModal";

// ✅ modal de conferência antes do fase11
import MateriaisConferenciaModal, {
  MatCheckItem,
  MateriaisConferenciaResult,
} from "./components/MateriaisConferenciaModal";

import {
  loadCachedRegistros,
  saveRegistrosSnapshot,
} from "@/lib/offline/registros";
import {
  applyPendingActionsToRegistros,
  isOperationalOfflineCommand,
  queueOperationalAction,
} from "@/lib/offline/actions";
import {
  browserSaysOnline,
  getCurrentOfflineSession,
} from "@/lib/offline/session";
import { getOperationalTimestamp } from "@/lib/offline/clock";
import { getOfflineDeviceId } from "@/lib/offline/device";
import { newOfflineId } from "@/lib/offline/db";
import { saveOfflineMaterialCheck } from "@/lib/offline/material-checks";
import {
  createLocalAttendance,
  getLocalAttendance,
  isLocalAttendanceId,
  markLocalAttendancePhase01,
  markLocalAttendancePhase01Synced,
  mergeLocalAttendancesWithRecords,
  removeLocalAttendance,
  setLocalAttendanceServerId,
} from "@/lib/offline/local-attendances";
import {
  installOperationalSyncListeners,
  syncOperationalQueue,
} from "@/lib/offline/sync-engine";

type TipoAtendimento = "funerario" | "terceiro";

// ✅ endpoint da baixa automática (novo PHP independente)
const ENDPOINT = "https://api.planoassistencialintegrado.com.br";

// ✅ endpoint da baixa automática (novo PHP independente)
const URNA_SAIDA_API = `${ENDPOINT}/urna_saida.php`;
const COROAS_API = `${ENDPOINT}/coroas.php`;
const ME_API = `${ENDPOINT}/informativo.php?me=1`;

/*
 * Trava dos itens no Corpo Pronto (fase12), no mesmo momento da baixa no estoque.
 * Vale para a fase12 e as etapas depois dela (fase07 a fase11); durante a ornamentação ainda se edita.
 * Só quem tem a página Gestão (ou o administrador) altera. O informativo.php confere a mesma regra
 * ao salvar (pode_alterar_itens_travados vem do ?me=1). Ids dos passos do Wizard (constants.ts → steps).
 */
const FASE_TRAVA_ITENS = 7;
const CAMPOS_TRAVADOS_APOS_CORPO_PRONTO = [
  "urna",
  "roupa",
  "veu",
  "veu_item",
  "cordao",
  "cordao_item",
  "invol",
  "invol_item",
  "tanato",
  "ornamentacao",
  "ornamentacao_tipo",
  "kit_lanche",
  "coroa_flores",
  "coroa_tipo",
  "coroa_modelo",
  "coroas_itens",
  "arrumacao",
];

// ===== Helpers de baixa (fase12: URNA / ROUPA / INVOL / INSUMOS) =====
type BaixaTipo =
  | ""
  | "URNA"
  | "ROUPA"
  | "INVOL"
  | "CORDAO"
  | "VEU"
  | "KIT_LANCHE"
  | "COROA_ARTIFICIAL"
  | "INSUMOS";

class EstoqueInsuficienteError extends Error {
  readonly code = "ESTOQUE_INSUFICIENTE";
  readonly itens: EstoqueInsuficienteItem[];

  constructor(message: string, itens: EstoqueInsuficienteItem[]) {
    super(message);
    this.name = "EstoqueInsuficienteError";
    this.itens = itens;
  }
}

function isEstoqueInsuficienteError(
  error: unknown,
): error is EstoqueInsuficienteError {
  return (
    error instanceof EstoqueInsuficienteError ||
    String((error as any)?.code ?? "") === "ESTOQUE_INSUFICIENTE"
  );
}

function isSim(v: any): boolean {
  const s = String(v ?? "")
    .trim()
    .toLowerCase();
  return s === "sim" || s === "s" || s === "1" || s === "true";
}

function isNao(v: any): boolean {
  const s = String(v ?? "")
    .trim()
    .toLowerCase();
  return s === "não" || s === "nao" || s === "n" || s === "0" || s === "false";
}

function normNoAccLower(v: any): string {
  return String(v ?? "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function isRoupaPropria(v: any): boolean {
  return normNoAccLower(v) === "roupa propria";
}

type InsumoItem = { produto_id: number; qtd: number };

function parseInsumosFromArrumacaoJson(
  raw: any,
): { deposito_nome: string; itens: InsumoItem[] } | null {
  try {
    if (!raw) return null;
    const obj = typeof raw === "string" ? JSON.parse(raw) : raw;
    if (!obj || typeof obj !== "object") return null;

    const deposito_nome = String(
      obj.deposito_nome ?? obj.deposito ?? "",
    ).trim();
    const itensRaw = obj.itens ?? obj.items ?? null;
    if (!itensRaw) return null;

    let itens: InsumoItem[] = [];

    // ✅ formato array
    if (Array.isArray(itensRaw)) {
      itens = itensRaw
        .map((x: any) => ({
          produto_id: Number(x?.produto_id ?? 0) || 0,
          qtd: Math.max(1, Math.floor(Number(x?.qtd ?? 0) || 0)),
        }))
        .filter((x) => x.produto_id > 0 && x.qtd > 0);
    }

    // ✅ formato objeto/dict
    if (!Array.isArray(itensRaw) && typeof itensRaw === "object") {
      itens = Object.entries(itensRaw)
        .map(([k, v]: any) => {
          const pid =
            Number(v?.produto_id ?? 0) ||
            Number(String(k).match(/\d+/)?.[0] ?? 0) ||
            0;
          const qtd = Math.max(1, Math.floor(Number(v?.qtd ?? 0) || 0));
          const checked = v?.checked;
          if (
            checked === false ||
            checked === 0 ||
            checked === "0" ||
            checked === "false"
          )
            return null;
          return pid > 0 ? { produto_id: pid, qtd } : null;
        })
        .filter(Boolean) as InsumoItem[];
    }

    if (!itens.length) return null;
    return { deposito_nome, itens };
  } catch {
    return null;
  }
}


function normalizeRestrictIds(v: any): string[] | null {
  if (v == null || v === "") return null;

  let raw = v;

  if (typeof raw === "string") {
    const s = raw.trim();
    if (!s) return null;

    try {
      const parsed = JSON.parse(s);
      raw = parsed;
    } catch {
      raw = s.split(",");
    }
  }

  if (!Array.isArray(raw)) return null;

  const ids = raw
    .map((x) => String(x ?? "").trim())
    .filter(Boolean);

  return ids.length ? Array.from(new Set(ids)) : null;
}

function scopeHasAny(scopeIds: string[] | null, ids: string[]): boolean {
  if (!scopeIds) return true;
  return ids.some((id) => scopeIds.includes(id));
}

/* -------------------- utils sessão (IDs de terceiros) -------------------- */
function addTerceiroIdToSession(id: string | number | undefined | null) {
  try {
    if (id == null) return;
    const raw = sessionStorage.getItem("terceiro_ids");
    const arr: Array<string> = raw ? JSON.parse(raw) : [];
    const sid = String(id);
    if (!arr.includes(sid)) {
      arr.push(sid);
      sessionStorage.setItem("terceiro_ids", JSON.stringify(arr));
    }
  } catch { }
}

/* ----------- resolve tipo a partir de um registro existente ----------- */
function resolveTipoFromRegistro(r?: Registro | null): TipoAtendimento {
  if (!r) return "funerario";

  const tipoSalvo = String((r as any)?.tipo_atendimento ?? "")
    .trim()
    .toLowerCase();

  // Um atendimento só é "terceiro" quando isso estiver explicitamente
  // salvo no registro. Os campos Assistência, Tanatopraxia e Ornamentação
  // podem estar todos como "Não" em um atendimento funerário normal.
  return tipoSalvo === "terceiro" ? "terceiro" : "funerario";
}

/* -------------------- Config dinâmico por tipo -------------------- */
function getWizardConfig(tipo: TipoAtendimento) {
  if (tipo === "terceiro") {
    const wizardStepIndexes = [
      // Atendimento (nome + contato + dados do falecido/responsável)
      [0, 1, 27, 28, 29, 30, 31],

      // Velório (local velório + sala + velório online + data/hora início + data/hora fim)
      // 18 local_velorio | 32 sala_velorio | 33 velorio_online | 19 data início | 21 hora início | 20 data fim | 22 hora fim
      [18, 32, 33, 19, 21, 20, 22],

      // Sepultamento (local sepultamento)
      [17],
    ];

    const wizardStepTitles = ["Atendimento", "Velório", "Sepultamento"];
    const obrigatorios: string[] = [];
    return {
      wizardStepIndexes,
      wizardStepTitles,
      obrigatorios,
      steps: stepsPadrao,
    };
  }

  return {
    wizardStepIndexes: wizardStepIndexesPadrao as number[][],
    wizardStepTitles: wizardStepTitlesPadrao as string[],
    obrigatorios: obrigatoriosPadrao as string[],
    steps: stepsPadrao,
  };
}

/* -------------------- Mapas de telemetria -------------------- */
function mapFaseToTipo(fase: string): TipoTele | null {
  if (fase === "fase01") return "remocao";
  if (fase === "fase07") return "para_velorio";
  if (fase === "fase09") return "para_sepultamento";
  return null;
}

// "fase que PARA" a telemetria iniciada por:
const STOP_BY_START: Record<string, string> = {
  fase01: "fase02",
  fase07: "fase08",
  fase09: "fase10",
};

/* =======================================================================
   ✅ MODO OFFLINE (fila local + reenvio automático ao voltar a internet)
   ======================================================================= */
type OfflineQueueItem = {
  qid: string;
  createdAt: number;
  tries: number;
  lastError?: string;
  payload: any;

  /**
   * Presente quando este item representa um atendimento criado offline.
   * O registro temporário fica separado da lista recebida do servidor.
   */
  localRecordId?: string;
  userId?: string;
};

const OFFLINE_QUEUE_KEY = "acomp_offline_queue_v1";

function safeReadQueue(): OfflineQueueItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as OfflineQueueItem[]) : [];
  } catch {
    return [];
  }
}

function safeWriteQueue(items: OfflineQueueItem[]) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(items));
  } catch { }
}

function genQid() {
  return `${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

function isOnlineNow() {
  if (typeof window === "undefined") return true;
  return navigator.onLine !== false;
}

function enqueueOffline(
  payload: any,
  errMsg?: string,
  meta?: {
    localRecordId?: string;
    userId?: string;
  },
) {
  const items = safeReadQueue();

  const item: OfflineQueueItem = {
    qid: genQid(),
    createdAt: Date.now(),
    tries: 0,
    lastError: errMsg,
    payload,
    localRecordId: meta?.localRecordId,
    userId: meta?.userId,
  };

  items.push(item);
  safeWriteQueue(items);

  return item;
}

// ✅ tenta resolver nome do falecido
function resolveFalecidoNome(r: any): string {
  return String(
    r?.falecido ??
    r?.nome_falecido ??
    r?.falecido_nome ??
    r?.nome_do_falecido ??
    r?.nome ??
    "",
  ).trim();
}

/* =========================
   ✅ helpers DOM (Wizard inputs)
   (mantidos para campos comuns; URNA META não depende mais deles)
   ========================= */
function readDomValue(id: string): string {
  if (typeof document === "undefined") return "";
  const el = document.getElementById(id) as
    | HTMLInputElement
    | HTMLTextAreaElement
    | HTMLSelectElement
    | null;
  return (el?.value ?? "").toString();
}

/* =========================================================
   ✅ NORMALIZAÇÃO FORTE DO STATUS (igual ao backend)
========================================================= */
function normalizeStatusCode(v: any): string {
  const raw = String(v ?? "").trim();
  if (!raw) return "";

  const low = raw.toLowerCase();
  if (low.startsWith("fase")) {
    const num = low.replace(/\D+/g, "");
    if (!num) return low;
    return `fase${num.padStart(2, "0")}`;
  }

  const noAcc = low.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const key = noAcc.trim();

  const map: Record<string, string> = {
    removendo: "fase01",
    "aguardando procedimento": "fase02",
    preparando: "fase03",
    "aguardando ornamentacao": "fase04",
    ornamentando: "fase05",
    "fim da ornamentacao": "fase06",
    "aguardando corpo pronto": "fase06",
    "corpo pronto": "fase12",
    transportando: "fase07",
    "transportando obito p/velorio": "fase07",
    "transportando obito para velorio": "fase07",
    velando: "fase08",
    sepultando: "fase09",
    "sepultamento concluido": "fase10",
    "material recolhido": "fase11",
  };

  if (map[key]) return map[key];

  const helper = normalizarStatus?.(raw);
  return helper ? String(helper) : raw;
}

function getNumeroFase(status: any): number {
  const normalizado = normalizeStatusCode(status);
  const m = String(normalizado || "").match(/^fase(\d+)$/i);
  return m ? Number(m[1]) || 0 : 0;
}

function obrigatoriedadeAtivaNoWizard({
  wizardEditing,
  wizardData,
  wizardIdx,
  registros,
}: {
  wizardEditing: boolean;
  wizardData: Registro;
  wizardIdx: number | null;
  registros: Registro[];
}): boolean {
  if (!wizardEditing) return false;

  const status =
    (wizardData as any)?.status ??
    (typeof wizardIdx === "number" ? (registros[wizardIdx] as any)?.status : "");

  return getNumeroFase(status) >= 2;
}

// ==============================
// ✅ Snapshot do registro original (para comparar no EDITAR)
// ==============================
type RoupaSnapshot = {
  roupa: string;
  roupa_produto_id: number;
  roupa_deposito_nome: string;
  roupa_codigo_barras: string;
  roupa_propria: number;
};

type CoroaSnapshot = {
  coroa_flores: string;
  itens: CoroaAtendimentoItem[];
};

type LegacyRoutingSnapshot = {
  coroa_flores: string;
  realiza_velorio: string;
  realiza_sepultamento: string;
};

const COROA_SCOPE_IDS = [
  "coroa_flores",
  "coroas_itens",
  "coroa_tipo",
  "coroa_produto_id",
  "coroa_modelo",
  "coroa_codigo_barras",
  "coroa_deposito_nome",
];

function normalizarCoroasParaComparacao(items: any): CoroaAtendimentoItem[] {
  if (!Array.isArray(items)) return [];
  return items.map((item: any, index: number) => ({
    ordem: index + 1,
    tipo_coroa: item?.tipo_coroa === "artificial" ? "artificial" : item?.tipo_coroa === "natural" ? "natural" : "",
    produto_id: Number(item?.produto_id || 0) || 0,
    modelo_coroa: String(item?.modelo_coroa || "").trim(),
    codigo_barras: String(item?.codigo_barras || item?.codigo_barras_produto || "").trim(),
    deposito_nome: String(item?.deposito_nome || "").trim().toUpperCase(),
    frase: String(item?.frase || "").trim(),
    valor: Number(item?.valor ?? 0),
    foto_produto_url: String(item?.foto_produto_url || "").trim(),
  }));
}

function coroasSnapshotIgual(a: CoroaSnapshot | null, flagAtual: any, itensAtuais: any): boolean {
  if (!a) return false;
  const atual = {
    coroa_flores: String(flagAtual ?? "").trim(),
    itens: normalizarCoroasParaComparacao(itensAtuais),
  };
  return JSON.stringify(a) === JSON.stringify(atual);
}

const ROUPA_SCOPE_IDS = [
  "roupa",
  "roupa_produto_id",
  "roupa_deposito_nome",
  "roupa_codigo_barras",
  "roupa_propria",
];

function scrubRoupaNoEditar(payload: any, original: RoupaSnapshot | null) {
  if (!original) return;

  const rNow = String(payload.roupa ?? "").trim();
  const rOrig = String(original.roupa ?? "").trim();

  const pidNow = Number(payload.roupa_produto_id ?? 0) || 0;
  const pidOrig = Number(original.roupa_produto_id ?? 0) || 0;

  const depNow = String(payload.roupa_deposito_nome ?? "").trim();
  const depOrig = String(original.roupa_deposito_nome ?? "").trim();

  const cbNow = String(payload.roupa_codigo_barras ?? "").trim();
  const cbOrig = String(original.roupa_codigo_barras ?? "").trim();

  const propNow = Number(payload.roupa_propria ?? 0) ? 1 : 0;
  const propOrig = Number(original.roupa_propria ?? 0) ? 1 : 0;

  const mudou =
    rNow !== rOrig ||
    pidNow !== pidOrig ||
    depNow !== depOrig ||
    cbNow !== cbOrig ||
    propNow !== propOrig;

  // ✅ se não mudou -> NÃO MANDA roupa nenhuma no payload do editar
  if (!mudou) {
    delete payload.roupa;
    delete payload.roupa_produto_id;
    delete payload.roupa_deposito_nome;
    delete payload.roupa_codigo_barras;
    delete payload.roupa_propria;
    return;
  }

  // ✅ mudou e virou ROUPA PRÓPRIA
  if (rNow && isRoupaPropria(rNow)) {
    payload.roupa = "ROUPA PRÓPRIA";
    payload.roupa_propria = 1;
    payload.roupa_produto_id = null;
    payload.roupa_deposito_nome = null;
    payload.roupa_codigo_barras = null;
    return;
  }

  // ✅ mudou e não é própria: exige combo completo (front safety)
  if (rNow) {
    const pid = Number(payload.roupa_produto_id ?? 0) || 0;
    const dep = String(payload.roupa_deposito_nome ?? "").trim();
    if (pid <= 0) {
      throw new Error(
        'Roupa: selecione uma roupa da lista (estoque) ou use "ROUPA PRÓPRIA".',
      );
    }
    if (!dep) {
      throw new Error(
        "Roupa: selecione o local de saída (ARMARIO SANDRO, ARMARIO ILDO ou FUNERARIA).",
      );
    }
  }
}

export default function AcompanhamentoPage() {
  // Tabela
  const [registros, setRegistros] = useState<Registro[]>([]);

  // Avisos
  const [avisos, setAvisos] = useState<Aviso[]>([]);
  const [avisoMsg, setAvisoMsg] = useState<{
    text: string;
    ok: boolean;
  } | null>(null);
  const avisoInputRef = useRef<HTMLInputElement>(null);

  // Tipo do cadastro atual
  const [tipoAtendimento, setTipoAtendimento] =
    useState<TipoAtendimento>("funerario");

  // Wizard
  const [wizardOpen, setWizardOpen] = useState(false);
  const [wizardTitle, setWizardTitle] = useState("Novo Registro");
  const [wizardEditing, setWizardEditing] = useState(false);
  const [wizardIdx, setWizardIdx] = useState<number | null>(null);
  const [wizardRestrictGroup, setWizardRestrictGroup] = useState<number | null>(
    null,
  );
  const [wizardStep, setWizardStep] = useState(0);
  const [wizardData, setWizardData] = useState<Registro>({});
  const [wizardMsg, setWizardMsg] = useState<{
    text: string;
    ok: boolean;
    /** Campos obrigatórios que impediram o salvamento (aparecem no rodapé do Wizard, com atalho para a aba). */
    faltando?: CampoFaltando[];
  } | null>(null);
  const [wizardSubmitting, setWizardSubmitting] = useState(false);
  /** OS do atendimento aberta direto pela lista (botão do documento com cifrão). */
  const [osDoAtendimentoId, setOsDoAtendimentoId] = useState<string | number | null>(null);
  // ✅ snapshot do registro original (para não revalidar / não reenviar roupa no EDITAR)
  const wizardOriginalRoupaRef = useRef<RoupaSnapshot | null>(null);
  const wizardOriginalCoroasRef = useRef<CoroaSnapshot | null>(null);
  const wizardOriginalLegacyRef = useRef<LegacyRoutingSnapshot | null>(null);

  // selects
  const [assistenciaVal, setAssistenciaVal] = useState<string>("");
  const [tanatoVal, setTanatoVal] = useState<string>("");

  /* -------------------- OS no atendimento (Editar registro) -------------------- */
  const [osCampos, setOsCampos] = useState<OsCampos>(OS_CAMPOS_VAZIO);
  // true quando o Local do velório já foi lido do banco (ou é registro novo): só então ele é gravado.
  const localCerimoniaCarregadoRef = useRef(false);
  const [osColunasFaltando, setOsColunasFaltando] = useState<string[]>([]);
  const [osVersao, setOsVersao] = useState(0);
  /** Novo registro aberto a partir de um orçamento (?orcamento=<id>): campos da OS a preencher e o orçamento a marcar como convertido. */
  const orcamentoOsRef = useRef<Partial<OsCampos> | null>(null);
  const orcamentoEmUsoRef = useRef<{ id: number; numero: string } | null>(null);
  // Convênios e pacotes do cadastro (os_previa.php). Uma busca só, compartilhada com o campo Convênio e a prévia da OS.
  const opcoesConv = useOpcoesConvenio(wizardOpen);

  // Materiais
  const [materiaisOpen, setMateriaisOpen] = useState(false);
  const [materiais, setMateriais] =
    useState<MateriaisState>(defaultMateriais());

  // Arrumação
  const [arrumacaoOpen, setArrumacaoOpen] = useState(false);
  const [arrumacao, setArrumacao] =
    useState<ArrumacaoState>(defaultArrumacao());

  // Ações (por ID)
  const [acaoOpen, setAcaoOpen] = useState(false);
  const [acaoId, setAcaoId] = useState<Registro["id"] | null>(null);
  const [acaoMsg, setAcaoMsg] = useState<{ text: string; ok: boolean } | null>(
    null,
  );
  const [acaoSubmitting, setAcaoSubmitting] = useState(false);
  const [estoqueInsuficiente, setEstoqueInsuficiente] =
    useState<EstoqueInsuficienteAlerta | null>(null);

  // Foto obrigatória antes de confirmar fase06/fase08
  const [fotoAcaoOpen, setFotoAcaoOpen] = useState(false);
  const [fotoAcaoId, setFotoAcaoId] = useState<Registro["id"] | null>(null);
  const [fotoAcaoFase, setFotoAcaoFase] = useState<string>("fase06");
  const [fotoAcaoTipo, setFotoAcaoTipo] = useState<FotoAcaoTipo | null>(null);

  // Conferência de materiais antes do fase11
  const [matCheckOpen, setMatCheckOpen] = useState(false);
  const [matCheckItens, setMatCheckItens] = useState<MatCheckItem[]>([]);
  const [matCheckReturnToAcao, setMatCheckReturnToAcao] = useState(false);

  // contexto da conferência
  const [matCheckRegistroId, setMatCheckRegistroId] = useState<
    Registro["id"] | null
  >(null);
  const [matCheckFalecidoNome, setMatCheckFalecidoNome] = useState<string>("");

  const [matCheckSaving, setMatCheckSaving] = useState(false);

  // Info
  const [infoOpen, setInfoOpen] = useState(false);
  const [infoId, setInfoId] = useState<Registro["id"] | null>(null);

  // Compartilhar
  const [shareOpen, setShareOpen] = useState(false);
  const [shareId, setShareId] = useState<Registro["id"] | null>(null);

  // Visita de avaliação — permissão individual "visita-avaliacao"
  const [visitaPermitida, setVisitaPermitida] = useState(false);
  const [visitaOpen, setVisitaOpen] = useState(false);
  const [visitaId, setVisitaId] = useState<Registro["id"] | null>(null);
  const [visitaStatusById, setVisitaStatusById] = useState<
    Record<string, VisitaStatus>
  >({});

  // Assinatura
  const [signOpen, setSignOpen] = useState(false);
  const [signTipo, setSignTipo] = useState<"recebimento" | "requisicao">(
    "recebimento",
  );
  const [signIdx, setSignIdx] = useState<number | null>(null);

  // Telemetria
  const teleRef = useRef<TelemetriaHandle>(null);
  const [teleOpen, setTeleOpen] = useState(false);
  const [teleFase, setTeleFase] = useState<string>("fase01");
  const [teleTipo, setTeleTipo] = useState<TipoTele>("remocao");
  const [teleRegistroId, setTeleRegistroId] = useState<Registro["id"] | null>(
    null,
  );

  const [teleActive, setTeleActive] = useState(false);
  const [teleStartFase, setTeleStartFase] = useState<string | null>(null);

  // ✅ refs para evitar estado atrasado no momento de encerrar a telemetria
  const teleActiveRef = useRef(false);
  const teleStartFaseRef = useRef<string | null>(null);
  const teleRegistroIdRef = useRef<Registro["id"] | null>(null);

  const definirTeleRegistroId = useCallback(
    (id: Registro["id"] | null | undefined) => {
      const normalized = id != null ? String(id) : null;
      teleRegistroIdRef.current = normalized;
      setTeleRegistroId(normalized);
    },
    [],
  );

  const marcarTeleAtiva = useCallback((fase: string) => {
    teleActiveRef.current = true;
    teleStartFaseRef.current = fase;
    setTeleActive(true);
    setTeleStartFase(fase);
  }, []);

  const limparTeleAtiva = useCallback(() => {
    teleActiveRef.current = false;
    teleStartFaseRef.current = null;
    setTeleActive(false);
    setTeleStartFase(null);
  }, []);


  /* -------------------- Config por tipo -------------------- */
  const {
    wizardStepIndexes: wizardStepIndexesForTipo,
    wizardStepTitles: wizardStepTitlesForTipo,
    obrigatorios: obrigatoriosBaseForTipo,
    steps: stepsForTipo,
  } = useMemo(() => getWizardConfig(tipoAtendimento), [tipoAtendimento]);

  const obrigatoriosForTipo = useMemo(() => {
    const ativo = obrigatoriedadeAtivaNoWizard({
      wizardEditing,
      wizardData,
      wizardIdx,
      registros,
    });

    if (!ativo) return [];

    // Registros antigos permanecem com NULL/vazio nos campos novos até que o
    // usuário faça uma escolha explícita. Isso evita bloquear a edição de uma
    // aba antiga apenas porque Coroa/Velório/Sepultamento não existiam na época.
    if (wizardEditing && wizardOriginalLegacyRef.current) {
      const original = wizardOriginalLegacyRef.current;
      return obrigatoriosBaseForTipo.filter((id) => {
        if (id !== "coroa_flores" && id !== "realiza_velorio" && id !== "realiza_sepultamento") return true;
        const antes = String((original as any)[id] ?? "").trim();
        const agora = String((wizardData as any)?.[id] ?? "").trim();
        return !(antes === "" && agora === "");
      });
    }

    return obrigatoriosBaseForTipo;
  }, [
    obrigatoriosBaseForTipo,
    wizardEditing,
    wizardData,
    wizardIdx,
    registros,
  ]);

  /* -------------------- Trava dos itens após o Corpo Pronto -------------------- */
  const [podeAlterarItensTravados, setPodeAlterarItensTravados] = useState(false);
  useEffect(() => {
    let cancel = false;
    fetch(`${ME_API}&_nocache=${Date.now()}`, { credentials: "include", cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (!cancel) setPodeAlterarItensTravados(!!j?.pode_alterar_itens_travados);
      })
      .catch(() => {
        // Sem resposta (offline): fica travado. O servidor confere de novo ao salvar.
      });
    return () => {
      cancel = true;
    };
  }, []);

  const travaItens = useMemo<TravaItens | null>(() => {
    if (!wizardEditing) return null;
    const registroOriginal = typeof wizardIdx === "number" ? registros[wizardIdx] : null;
    if (resolveTipoFromRegistro((registroOriginal ?? wizardData) as Registro) === "terceiro") return null;
    const status = (registroOriginal as any)?.status ?? (wizardData as any)?.status ?? "";
    const fase = getNumeroFase(status);
    if (fase < FASE_TRAVA_ITENS) return null;
    return {
      campos: CAMPOS_TRAVADOS_APOS_CORPO_PRONTO,
      podeAlterar: podeAlterarItensTravados,
      // Travado = Corpo Pronto feito: a baixa no estoque já aconteceu.
      baixaFeita: true,
    };
  }, [wizardEditing, wizardIdx, registros, wizardData, podeAlterarItensTravados]);

  /* ===========================
     ✅ OFFLINE: Flush da fila
     =========================== */
  const flushingRef = useRef(false);

  const fetchRegistros = useCallback(async () => {
    let session = null as Awaited<ReturnType<typeof getCurrentOfflineSession>>;

    try {
      session = await getCurrentOfflineSession({
        refreshIfOnline: isOnlineNow(),
        allowCachedOnNetworkFailure: true,
      });
    } catch (e: any) {
      // 401/403 online não deve trocar silenciosamente de identidade.
      console.warn("[OFFLINE] Não foi possível confirmar o usuário:", e?.message || e);
    }

    const showCached = async () => {
      const cached = await loadCachedRegistros<Registro>(session?.userId);

      if (!session) {
        if (cached.length) {
          setRegistros(cached);
        }
        return;
      }

      const withLocal =
        mergeLocalAttendancesWithRecords(
          cached,
          session.userId,
        );

      const merged =
        await applyPendingActionsToRegistros(
          withLocal,
          session.userId,
        );

      setRegistros(merged);
    };

    if (!isOnlineNow()) {
      await showCached();
      return;
    }

    try {
      const r = await fetch(
        `${ENDPOINT}/informativo.php?listar=1&_nocache=${Date.now()}`,
        {
          cache: "no-store",
          credentials: "include",
        },
      );

      if (r.status === 401) {
        await showCached();
        return;
      }

      const data = await r.json().catch(() => null);
      if (data?.need_login) {
        await showCached();
        return;
      }

      const sane: Registro[] = Array.isArray(data)
        ? data.map((it: any) => ({
          ...it,
          id: it?.id != null ? String(it.id) : it.id,
          status: normalizarStatus(it?.status) ?? it?.status,

          // ✅ NOVOS DADOS DO FALECIDO / RESPONSÁVEL
          data_nascimento: String(it?.data_nascimento ?? ""),
          data_falecimento: String(it?.data_falecimento ?? ""),
          foto_falecido: String(it?.foto_falecido ?? ""),
          nome_responsavel: String(it?.nome_responsavel ?? ""),
          cpf_responsavel: String(it?.cpf_responsavel ?? ""),

          // ✅ VELÓRIO (sala + online)
          sala_velorio: String(it?.sala_velorio ?? ""),
          velorio_online: String(it?.velorio_online ?? ""),

          // ✅ URNA
          urna_deposito_nome: String(it?.urna_deposito_nome ?? ""),
          urna_produto_id: Number(it?.urna_produto_id ?? 0) || 0,
          urna_codigo_barras: String(it?.urna_codigo_barras ?? ""),

          // ✅ ROUPA
          roupa_deposito_nome: String(it?.roupa_deposito_nome ?? ""),
          roupa_produto_id: Number(it?.roupa_produto_id ?? 0) || 0,
          roupa_codigo_barras: String(it?.roupa_codigo_barras ?? ""),
          roupa_propria: Number(it?.roupa_propria ?? 0) || 0,

          // ✅ INVOL
          invol_deposito_nome: String(it?.invol_deposito_nome ?? ""),
          invol_produto_id: Number(it?.invol_produto_id ?? 0) || 0,
          invol_codigo_barras: String(it?.invol_codigo_barras ?? ""),
          invol_item: String(it?.invol_item ?? ""),

          // ✅ VÉU
          veu_deposito_nome: String(it?.veu_deposito_nome ?? ""),
          veu_produto_id: Number(it?.veu_produto_id ?? 0) || 0,
          veu_codigo_barras: String(it?.veu_codigo_barras ?? ""),
          veu_item: String(it?.veu_item ?? ""),

          // ✅ CORDÃO
          cordao_deposito_nome: String(it?.cordao_deposito_nome ?? ""),
          cordao_produto_id: Number(it?.cordao_produto_id ?? 0) || 0,
          cordao_codigo_barras: String(it?.cordao_codigo_barras ?? ""),
          cordao_item: String(it?.cordao_item ?? ""),

          // KIT LANCHE
          kit_lanche: String(it?.kit_lanche ?? "Não"),

          // ✅ COROA DE FLORES
          coroa_flores: String(it?.coroa_flores ?? ""),
          coroa_tipo: String(it?.coroa_tipo ?? ""),
          coroa_produto_id: Number(it?.coroa_produto_id ?? 0) || 0,
          coroa_modelo: String(it?.coroa_modelo ?? ""),
          coroa_codigo_barras: String(it?.coroa_codigo_barras ?? ""),
          coroa_deposito_nome: String(it?.coroa_deposito_nome ?? ""),

          // ✅ ROTEAMENTO VELÓRIO / SEPULTAMENTO
          realiza_velorio: String(it?.realiza_velorio ?? ""),
          realiza_sepultamento: String(it?.realiza_sepultamento ?? ""),

          // ✅ RESPONSABILIDADE OPERACIONAL
          responsavel_velorio_id: it?.responsavel_velorio_id ?? null,
          responsavel_velorio_nome: String(it?.responsavel_velorio_nome ?? ""),
          responsavel_velorio_desde: String(it?.responsavel_velorio_desde ?? ""),
          responsavel_sepultamento_id: it?.responsavel_sepultamento_id ?? null,
          responsavel_sepultamento_nome: String(it?.responsavel_sepultamento_nome ?? ""),
          responsavel_sepultamento_desde: String(it?.responsavel_sepultamento_desde ?? ""),

          // ✅ INSUMOS (novo formato dentro do arrumacao_json)
          arrumacao_json: String(it?.arrumacao_json ?? ""),

          // ✅ FOTOS OBRIGATÓRIAS DAS AÇÕES
          foto_fim_ornamentacao_url: String(
            it?.foto_fim_ornamentacao_url ?? "",
          ),
          foto_fim_ornamentacao_path: String(
            it?.foto_fim_ornamentacao_path ?? "",
          ),
          foto_fim_ornamentacao_em: String(
            it?.foto_fim_ornamentacao_em ?? "",
          ),
          foto_fim_ornamentacao_usuario: String(
            it?.foto_fim_ornamentacao_usuario ?? "",
          ),
          foto_entrega_corpo_url: String(it?.foto_entrega_corpo_url ?? ""),
          foto_entrega_corpo_path: String(it?.foto_entrega_corpo_path ?? ""),
          foto_entrega_corpo_em: String(it?.foto_entrega_corpo_em ?? ""),
          foto_entrega_corpo_usuario: String(
            it?.foto_entrega_corpo_usuario ?? "",
          ),
        }))
        : [];

      if (session) {
        await saveRegistrosSnapshot(
          sane,
          session.userId,
        );

        const withLocal =
          mergeLocalAttendancesWithRecords(
            sane,
            session.userId,
          );

        const merged =
          await applyPendingActionsToRegistros(
            withLocal,
            session.userId,
          );

        setRegistros(merged);
      } else {
        setRegistros(sane);
      }
    } catch (e) {
      console.warn("[OFFLINE] Falha ao atualizar atendimentos, usando snapshot local.", e);
      await showCached();
    }
  }, []);
  const fetchRegistrosSafe = useCallback(async () => {
    await fetchRegistros();
  }, [fetchRegistros]);

  const flushOfflineQueue = useCallback(async () => {
    if (typeof window === "undefined") return;
    if (!isOnlineNow()) return;
    if (flushingRef.current) return;

    const items = safeReadQueue();
    if (!items.length) return;

    flushingRef.current = true;
    try {
      let queue = [...items].sort((a, b) => a.createdAt - b.createdAt);

      for (const item of queue) {
        try {
          const json = await enviarRegistroPHP(item.payload);

          if (json?.sucesso) {
            const acao =
              String(item.payload?.acao ?? "");

            const novoId =
              json?.id ??
              json?.novo_id ??
              json?.last_id ??
              null;

            try {
              const tipoAt =
                String(
                  item.payload?.tipo_atendimento ??
                  "",
                );

              if (
                acao === "novo" &&
                tipoAt === "terceiro"
              ) {
                addTerceiroIdToSession(
                  novoId,
                );
              }
            } catch { }

            /*
             * Atendimento que nasceu offline:
             * 1. recebe o ID real;
             * 2. remapeia a telemetria;
             * 3. envia fase01, caso o usuário já tenha iniciado a remoção;
             * 4. só então remove o registro temporário.
             */
            if (
              acao === "novo" &&
              item.localRecordId &&
              novoId != null
            ) {
              const localId =
                String(
                  item.localRecordId,
                );

              setLocalAttendanceServerId(
                localId,
                String(novoId),
              );

              remapOfflineTelemetryRecordId(
                localId,
                String(novoId),
              );

              if (
                String(
                  teleRegistroIdRef.current ??
                  "",
                ) === localId
              ) {
                definirTeleRegistroId(
                  String(novoId),
                );
              }

              const localEntry =
                getLocalAttendance(
                  localId,
                );

              if (
                localEntry?.phase01 &&
                localEntry.phase01.status !==
                "synced"
              ) {
                const phase =
                  localEntry.phase01;

                const phaseJson =
                  await jsonWith401(
                    `${ENDPOINT}/informativo.php`,
                    {
                      method: "POST",
                      headers: {
                        "Content-Type":
                          "application/json",
                      },
                      credentials:
                        "include",
                      cache: "no-store",
                      body: JSON.stringify({
                        acao:
                          "atualizar_status",
                        id: String(novoId),
                        status: "fase01",
                        operation_id:
                          phase.operationId,
                        ocorreu_em:
                          phase.occurredAt,
                        device_ocorreu_em:
                          phase.deviceOccurredAt,
                        clock_offset_ms:
                          phase.clockOffsetMs,
                        device_id:
                          phase.deviceId,
                        usuario_id:
                          phase.userId,
                        origem:
                          "offline",
                        status_anterior:
                          "fase00",
                      }),
                    },
                  );

                if (
                  !phaseJson?.sucesso
                ) {
                  throw new Error(
                    phaseJson?.msg ||
                    phaseJson?.erro ||
                    "Atendimento criado, mas não foi possível sincronizar Indo Retirar o Óbito.",
                  );
                }

                markLocalAttendancePhase01Synced(
                  localId,
                );
              }

              removeLocalAttendance(
                localId,
              );
            }

            // enviado com sucesso -> remove da fila
            const after =
              safeReadQueue().filter(
                (x) =>
                  x.qid !==
                  item.qid,
              );

            safeWriteQueue(after);
          } else {
            const msg =
              typeof json?.msg === "string" && json.msg.trim()
                ? json.msg
                : typeof json?.erro === "string"
                  ? json.erro
                  : "";

            // ✅ ERROS "PERMANENTES" (validação) -> remove da fila para não ficar tentando pra sempre
            const isValidation =
              msg.includes("Selecione uma roupa da lista") ||
              msg.includes("Selecione uma urna da lista") ||
              msg.includes("Selecione um INVOL da lista") ||
              msg.includes("Depósito inválido") ||
              msg.includes("Dados inválidos") ||
              msg.includes("Campo obrigatório após Corpo na Clínica") ||
              msg.includes("Confirmação obrigatória") ||
              msg.includes("Apenas Tanatopraxista");

            if (isValidation) {
              const after = safeReadQueue().filter((x) => x.qid !== item.qid);
              safeWriteQueue(after);

              // opcional: log pra você ver o que foi descartado
              console.warn(
                "Removido da fila offline (validação):",
                item.payload,
                msg,
              );

              // ✅ segue para o próximo item da fila (não trava tudo)
              continue;
            }

            // ❗ Erro "temporário" -> mantém na fila e para (pra não martelar o servidor)
            const after = safeReadQueue().map((x) =>
              x.qid === item.qid
                ? {
                  ...x,
                  tries: (x.tries ?? 0) + 1,
                  lastError: msg || "Erro ao enviar (offline queue).",
                }
                : x,
            );
            safeWriteQueue(after);
            break;
          }
        } catch (e: any) {
          const after = safeReadQueue().map((x) =>
            x.qid === item.qid
              ? {
                ...x,
                tries: (x.tries ?? 0) + 1,
                lastError: e?.message || "Falha ao enviar (offline queue).",
              }
              : x,
          );
          safeWriteQueue(after);
          break;
        }
      }

      await fetchRegistrosSafe();
    } finally {
      flushingRef.current = false;
    }
  }, [
    fetchRegistrosSafe,
    definirTeleRegistroId,
  ]);

  /* -------------------- Avisos -------------------- */
  const fetchAvisos = useCallback(async () => {
    try {
      const r = await fetch(
        `${ENDPOINT}/avisos.php?listar=1&_nocache=${Date.now()}`,
        {
          credentials: "include",
        },
      );
      if (r.status === 401) return;
      const data = await r.json().catch(() => null);
      if (data?.need_login) return;
      setAvisos(Array.isArray(data) ? data : []);
    } catch {
      setAvisos([]);
    }
  }, []);

  const enviarAviso = useCallback(async () => {
    const val = (avisoInputRef.current?.value ?? "").trim();
    if (!val) {
      setAvisoMsg({ text: "Digite um aviso para enviar!", ok: false });
      return;
    }
    try {
      const res = await jsonWith401(`${ENDPOINT}/avisos.php`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ mensagem: val }),
      });
      if (res?.sucesso) {
        setAvisoMsg({ text: "Aviso adicionado!", ok: true });
        if (avisoInputRef.current) avisoInputRef.current.value = "";
        fetchAvisos();
      } else {
        setAvisoMsg({
          text: res?.erro || res?.msg || "Erro ao adicionar!",
          ok: false,
        });
      }
    } catch (e: any) {
      setAvisoMsg({ text: e?.message || "Erro ao adicionar!", ok: false });
    }
  }, [fetchAvisos]);

  const editarAviso = useCallback(
    async (id: number | string, mensagem: string) => {
      try {
        const res = await jsonWith401(`${ENDPOINT}/avisos.php`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ id, mensagem }),
        });
        if (res?.sucesso) {
          setAvisoMsg({ text: "Aviso atualizado!", ok: true });
          fetchAvisos();
        } else {
          setAvisoMsg({
            text: res?.erro || res?.msg || "Erro ao editar!",
            ok: false,
          });
        }
      } catch (e: any) {
        setAvisoMsg({ text: e?.message || "Erro ao editar!", ok: false });
      }
    },
    [fetchAvisos],
  );

  const excluirAviso = useCallback(
    async (id: number | string) => {
      if (!window.confirm("Tem certeza que deseja excluir este aviso?")) return;
      try {
        const res = await jsonWith401(`${ENDPOINT}/avisos.php`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ id, excluir: true }),
        });
        if (res?.sucesso) {
          setAvisoMsg({ text: "Aviso excluído!", ok: true });
          fetchAvisos();
        } else {
          setAvisoMsg({
            text: res?.erro || res?.msg || "Erro ao excluir!",
            ok: false,
          });
        }
      } catch (e: any) {
        setAvisoMsg({ text: e?.message || "Erro ao excluir!", ok: false });
      }
    },
    [fetchAvisos],
  );

  const finalizarAviso = useCallback(
    async (id: number | string) => {
      try {
        const res = await jsonWith401(`${ENDPOINT}/avisos.php`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ id, finalizar: true }),
        });
        if (res?.sucesso) {
          setAvisoMsg({ text: "Aviso finalizado!", ok: true });
          fetchAvisos();
        } else {
          setAvisoMsg({
            text: res?.erro || res?.msg || "Erro ao finalizar!",
            ok: false,
          });
        }
      } catch (e: any) {
        setAvisoMsg({ text: e?.message || "Erro ao finalizar!", ok: false });
      }
    },
    [fetchAvisos],
  );

  /* -------------------- Visita de avaliação -------------------- */
  useEffect(() => {
    let cancelled = false;

    consultarAcessoVisita(true)
      .then((me) => {
        if (!cancelled) {
          setVisitaPermitida(!!me.autorizado);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setVisitaPermitida(false);
          setVisitaStatusById({});
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const recarregarStatusVisitas = useCallback(async () => {
    if (!visitaPermitida) {
      setVisitaStatusById({});
      return;
    }

    const ids = registros
      .map((r) => r.id)
      .filter(
        (id): id is NonNullable<Registro["id"]> =>
          id !== null && id !== undefined && String(id).trim() !== "",
      );

    if (ids.length === 0) {
      setVisitaStatusById({});
      return;
    }

    const map = await consultarStatusVisitas(
      ids.map((id) => String(id)),
    );

    setVisitaStatusById(map);
  }, [registros, visitaPermitida]);

  useEffect(() => {
    void recarregarStatusVisitas().catch(() => {
      setVisitaStatusById({});
    });
  }, [recarregarStatusVisitas]);

  /* -------------------- Ciclos -------------------- */
  useEffect(() => {
    fetchRegistros();
    fetchAvisos();
    flushOfflineQueue();
  }, [fetchRegistros, fetchAvisos, flushOfflineQueue]);

  useEffect(() => {
    const intReg = setInterval(fetchRegistros, 10000);
    const intAv = setInterval(fetchAvisos, 3000);
    const intFlush = setInterval(() => flushOfflineQueue(), 20000);

    const onVis = () => {
      if (!document.hidden) {
        fetchRegistros();
        flushOfflineQueue();
      }
    };
    document.addEventListener("visibilitychange", onVis);

    const onOnline = () => flushOfflineQueue();
    window.addEventListener("online", onOnline);

    return () => {
      clearInterval(intReg);
      clearInterval(intAv);
      clearInterval(intFlush);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("online", onOnline);
    };
  }, [fetchRegistros, fetchAvisos, flushOfflineQueue]);

  useEffect(() => {
    const removeSyncListeners = installOperationalSyncListeners();

    const onSyncComplete = () => {
      void fetchRegistros();
    };
    window.addEventListener("pai-offline-sync-complete", onSyncComplete);

    if (browserSaysOnline()) {
      void syncOperationalQueue().then(() => fetchRegistros());
    }

    return () => {
      removeSyncListeners();
      window.removeEventListener("pai-offline-sync-complete", onSyncComplete);
    };
  }, [fetchRegistros]);

  useEffect(() => {
    const onEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setWizardOpen(false);
        setAcaoOpen(false);
        setInfoOpen(false);
        setShareOpen(false);
        setVisitaOpen(false);
        setMateriaisOpen(false);
        setArrumacaoOpen(false);
        setSignOpen(false);
        setTeleOpen(false);
        setMatCheckOpen(false);
        setFotoAcaoOpen(false);
      }
    };
    window.addEventListener("keydown", onEsc);
    return () => window.removeEventListener("keydown", onEsc);
  }, []);

  /* -------------------- Parsers locais -------------------- */
  const parseMateriaisFromRegistro = (r: Registro): MateriaisState => {
    if ((r as any)?.materiais_json) {
      try {
        const parsed = JSON.parse(String((r as any).materiais_json));
        return normalizeMateriaisState(parsed);
      } catch { }
    }

    const out: MateriaisState = {};
    try {
      for (const [k, v] of Object.entries(r as any)) {
        if (!k.startsWith("materiais_") || !k.endsWith("_qtd")) continue;
        const qtd = Math.max(0, Math.floor(Number(v ?? 0)));
        if (qtd <= 0) continue;

        const nomeBase = k.replace(/^materiais_/, "").replace(/_qtd$/, "");
        out[nomeBase] = {
          checked: true,
          qtd,
          nome: nomeBase.replace(/_/g, " "),
        } as any;
      }
    } catch { }

    return out;
  };

  const parseArrumacaoFromRegistro = (r: Registro): ArrumacaoState => {
    const base = defaultArrumacao();

    if ((r as any).arrumacao_json) {
      try {
        const parsed = JSON.parse(String((r as any).arrumacao_json));
        Object.assign(base, parsed);
      } catch { }
    }

    (Object.keys(base) as Array<keyof ArrumacaoState>).forEach((k) => {
      const col = (r as any)[k];
      if (col == null) return;

      if (typeof col === "boolean") base[k] = col;
      else if (typeof col === "number") base[k] = col === 1;
      else if (typeof col === "string") {
        const s = col.trim().toLowerCase();
        base[k] = s === "1" || s === "true" || s === "sim" || s === "s";
      } else base[k] = !!col;
    });

    return base;
  };

  /* -------------------- salvar conferência no backend -------------------- */
  const salvarConferenciaNoPHP = useCallback(
    async (data: {
      registro_id: string | number | null | undefined;
      falecido_nome: string;
      observacao: string;
      itens: Array<{
        key: string;
        nome: string;
        qtd: number;
        ok: 0 | 1;
        nao_conforme: 0 | 1;
      }>;
    }) => {
      const registro_id =
        data.registro_id != null ? String(data.registro_id) : "";
      if (!registro_id)
        throw new Error(
          "Não foi possível identificar o atendimento (registro_id).",
        );

      const r = await fetch(
        `${ENDPOINT}/materiais_admin.php?op=conferencia_create&_nocache=${Date.now()}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({
            registro_id,
            falecido_nome: String(data.falecido_nome || "").trim(),
            observacao: String(data.observacao || "").trim(),
            itens: Array.isArray(data.itens) ? data.itens : [],
          }),
        },
      );

      if (r.status === 401)
        throw new Error("Sessão expirada. Faça login novamente.");
      const json = await r.json().catch(() => null);
      if (!json) throw new Error("Resposta inválida do servidor.");
      if (json?.need_login)
        throw new Error("Sessão expirada. Faça login novamente.");
      if (!r.ok || json?.erro)
        throw new Error(json?.msg || "Erro ao salvar conferência.");

      return json;
    },
    [],
  );

  /* --------------------
     ✅ baixa automática dos itens (Corpo Pronto / fase12)
     -------------------- */
  const baixarItensCorpoPronto = useCallback(
    async (payload: {
      registro_id: string;
      tipo: BaixaTipo;
      deposito_nome?: string;
      itens?: Array<{ produto_id: number; qtd: number }>;
    }) => {
      const r = await fetch(`${URNA_SAIDA_API}?_nocache=${Date.now()}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(payload),
        cache: "no-store",
      });

      if (r.status === 401)
        throw new Error("Sessão expirada. Faça login novamente.");

      const j = await r.json().catch(() => null);

      if (!j) {
        throw new Error(
          `Resposta inválida do servidor (baixa ${payload.tipo || "completa"}).`,
        );
      }

      if (j?.need_login) {
        throw new Error("Sessão expirada. Faça login novamente.");
      }

      if (!r.ok || j?.ok === false) {
        const faltantesRaw = Array.isArray(j?.faltantes)
          ? j.faltantes
          : [];

        if (
          String(j?.error_code ?? "") === "ESTOQUE_INSUFICIENTE" ||
          faltantesRaw.length > 0
        ) {
          const faltantes: EstoqueInsuficienteItem[] = faltantesRaw
            .map((item: any) => ({
              produto_id: Number(item?.produto_id ?? 0) || 0,
              produto_nome:
                String(
                  item?.produto_nome ??
                  item?.nome ??
                  (item?.produto_id
                    ? `Produto ${item.produto_id}`
                    : "Produto"),
                ).trim() || "Produto",
              deposito_nome:
                String(
                  item?.deposito_nome ??
                  item?.deposito_origem ??
                  "",
                ).trim(),
              disponivel: Math.max(
                0,
                Number(
                  item?.disponivel ??
                  item?.saldo_atual ??
                  0,
                ) || 0,
              ),
              necessario: Math.max(
                1,
                Number(
                  item?.necessario ??
                  item?.quantidade_solicitada ??
                  1,
                ) || 1,
              ),
              faltante: Math.max(
                0,
                Number(
                  item?.faltante ??
                  (
                    Number(
                      item?.necessario ??
                      item?.quantidade_solicitada ??
                      1,
                    ) -
                    Number(
                      item?.disponivel ??
                      item?.saldo_atual ??
                      0,
                    )
                  ),
                ) || 0,
              ),
            }))
            .filter((item: EstoqueInsuficienteItem) => item.produto_id > 0);

          // Compatibilidade com uma resposta antiga que ainda traga apenas
          // produto_id/saldo_atual/quantidade_solicitada no nível principal.
          if (
            faltantes.length === 0 &&
            Number(j?.produto_id ?? 0) > 0
          ) {
            const necessario = Math.max(
              1,
              Number(j?.quantidade_solicitada ?? 1) || 1,
            );
            const disponivel = Math.max(
              0,
              Number(j?.saldo_atual ?? 0) || 0,
            );

            faltantes.push({
              produto_id: Number(j.produto_id),
              produto_nome:
                String(
                  j?.produto_nome ??
                  `Produto ${j.produto_id}`,
                ).trim(),
              deposito_nome: String(
                j?.deposito_origem ?? "",
              ).trim(),
              disponivel,
              necessario,
              faltante: Math.max(0, necessario - disponivel),
            });
          }

          throw new EstoqueInsuficienteError(
            String(
              j?.msg ??
              "Há item sem quantidade suficiente no estoque.",
            ),
            faltantes,
          );
        }

        throw new Error(
          j?.msg ||
          `Falha ao dar baixa automática (${payload.tipo || "completa"}) no Corpo Pronto.`,
        );
      }

      return j;
    },
    [],
  );

  /* -------------------- Aberturas -------------------- */
  const iniciarNovoRegistro = useCallback((tipo: TipoAtendimento) => {
    wizardOriginalRoupaRef.current = null;
    wizardOriginalCoroasRef.current = null;
    wizardOriginalLegacyRef.current = null;

    setTipoAtendimento(tipo);

    setWizardSubmitting(false);
    setWizardEditing(false);
    setWizardIdx(null);
    setWizardRestrictGroup(null);
    setWizardStep(0);
    setWizardMsg(null);
    setWizardTitle("Novo Registro");

    const empty: Registro = {};
    (stepsPadrao as any).forEach((s: any) => ((empty as any)[s.id] = ""));

    if (tipo === "terceiro") {
      (empty as any).assistencia = "Não";
      (empty as any).tanato = "Não";
      (empty as any).ornamentacao = "Não";
      (empty as any).tipo_atendimento = "terceiro";
    } else {
      (empty as any).tipo_atendimento = "funerario";
    }

    // ✅ defaults de meta urna
    (empty as any).urna_deposito_nome = "MEMORIAL";
    (empty as any).urna_produto_id = 0;
    (empty as any).urna_codigo_barras = "";

    // ✅ defaults de meta roupa
    (empty as any).roupa_deposito_nome = "";
    (empty as any).roupa_produto_id = 0;
    (empty as any).roupa_codigo_barras = "";
    (empty as any).roupa_propria = 0;

    // ✅ defaults de meta invol
    (empty as any).invol_deposito_nome = "";
    (empty as any).invol_produto_id = 0;
    (empty as any).invol_codigo_barras = "";

    // ✅ defaults de meta VÉU
    (empty as any).veu_deposito_nome = "";
    (empty as any).veu_produto_id = 0;
    (empty as any).veu_codigo_barras = "";
    (empty as any).veu_item = "";

    // ✅ defaults de meta CORDÃO
    (empty as any).cordao_deposito_nome = "";
    (empty as any).cordao_produto_id = 0;
    (empty as any).cordao_codigo_barras = "";
    (empty as any).cordao_item = "";

    // ✅ defaults da Coroa de Flores
    (empty as any).coroa_flores = "";
    (empty as any).coroa_tipo = "";
    (empty as any).coroa_produto_id = 0;
    (empty as any).coroa_modelo = "";
    (empty as any).coroa_codigo_barras = "";
    (empty as any).coroa_deposito_nome = "";
    (empty as any).coroas_itens = [];

    // ✅ escolha do fluxo. Campo vazio exige decisão quando a obrigatoriedade estiver ativa.
    (empty as any).realiza_velorio = "";
    (empty as any).realiza_sepultamento = "";

    // ✅ Velório (sala + online)
    (empty as any).sala_velorio = "";
    (empty as any).velorio_online = "";

    // ✅ insumos tanato (novo formato) - começa vazio
    (empty as any).arrumacao_json = "";

    // ✅ materiais de assistência (novo formato) - começa vazio
    (empty as any).materiais_json = "";

    setWizardData(empty);
    setMateriais(defaultMateriais());
    setArrumacao(defaultArrumacao());
    setAssistenciaVal(String((empty as any).assistencia || ""));
    setTanatoVal(String((empty as any).tanato || ""));
    setWizardOpen(true);
  }, []);

  const carregarCoroasAtendimento = useCallback(async (atendimentoId: string | number) => {
    const url = new URL(COROAS_API);
    url.searchParams.set("por_atendimento", "1");
    url.searchParams.set("atendimento_id", String(atendimentoId));
    url.searchParams.set("_nocache", String(Date.now()));

    const res = await fetch(url.toString(), { credentials: "include", cache: "no-store" });
    const json = await res.json().catch(() => null);
    if (!res.ok || !json?.sucesso) throw new Error(json?.msg || "Não foi possível carregar as coroas do atendimento.");
    const dado = json?.dado || null;
    return {
      pedido_id: dado?.id ? Number(dado.id) : null,
      itens: normalizarCoroasParaComparacao(dado?.itens || []),
    };
  }, []);

  const sincronizarCoroasAtendimento = useCallback(async (
    atendimentoId: string | number,
    data: any,
  ) => {
    const flag = String(data?.coroa_flores ?? "").trim();
    if (flag !== "Sim" && flag !== "Não") return null;

    const itens = flag === "Sim" ? normalizarCoroasParaComparacao(data?.coroas_itens) : [];
    const res = await fetch(COROAS_API, {
      method: "POST",
      credentials: "include",
      cache: "no-store",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        acao: "sincronizar_atendimento",
        atendimento_id: Number(atendimentoId),
        coroa_flores: flag,
        quantidade_coroas: itens.length,
        itens,
      }),
    });
    const json = await res.json().catch(() => null);
    if (!res.ok || !json?.sucesso) throw new Error(json?.msg || "Não foi possível sincronizar a Ordem de Serviço das coroas.");
    return json;
  }, []);

  const abrirWizard = useCallback(
    async (
      tipo: "novo" | "editar",
      idx: number | null = null,
      grupoStep: number | null = null,
    ) => {
      setWizardSubmitting(false);
      const editing = tipo === "editar";
      setWizardEditing(editing);
      setWizardIdx(idx);
      setWizardRestrictGroup(grupoStep);
      setWizardStep(grupoStep ?? 0);
      setWizardMsg(null);
      setWizardTitle(editing ? "Editar Registro" : "Novo Registro");

      if (editing && idx !== null && registros[idx]) {
        const r = registros[idx];
        setTipoAtendimento(resolveTipoFromRegistro(r));

        const data: Registro = {};
        (stepsPadrao as any).forEach((s: any) => {
          (data as any)[s.id] = (r as any)[s.id] ?? "";
        });
        (data as any).id = (r as any).id;
        (data as any).status = normalizeStatusCode((r as any).status ?? "");

        // ✅ Velório (sala + online) no wizardData
        (data as any).sala_velorio = String((r as any).sala_velorio ?? "");
        (data as any).velorio_online = String((r as any).velorio_online ?? "");

        // ✅ metas da urna no wizardData
        (data as any).urna_deposito_nome = String(
          (r as any).urna_deposito_nome ?? "",
        );
        (data as any).urna_produto_id =
          Number((r as any).urna_produto_id ?? 0) || 0;
        (data as any).urna_codigo_barras = String(
          (r as any).urna_codigo_barras ?? "",
        );

        // ✅ metas da ROUPA no wizardData
        (data as any).roupa_deposito_nome = String(
          (r as any).roupa_deposito_nome ?? "",
        );
        (data as any).roupa_produto_id =
          Number((r as any).roupa_produto_id ?? 0) || 0;
        (data as any).roupa_codigo_barras = String(
          (r as any).roupa_codigo_barras ?? "",
        );
        (data as any).roupa_propria =
          Number((r as any).roupa_propria ?? 0) || 0;

        // ✅ snapshot original de ROUPA (para comparar no salvar do EDITAR)
        wizardOriginalRoupaRef.current = {
          roupa: String((r as any).roupa ?? ""),
          roupa_produto_id: Number((r as any).roupa_produto_id ?? 0) || 0,
          roupa_deposito_nome: String((r as any).roupa_deposito_nome ?? ""),
          roupa_codigo_barras: String((r as any).roupa_codigo_barras ?? ""),
          roupa_propria: Number((r as any).roupa_propria ?? 0) || 0,
        };

        // ✅ metas do INVOL no wizardData
        (data as any).invol_deposito_nome = String(
          (r as any).invol_deposito_nome ?? "",
        );
        (data as any).invol_produto_id =
          Number((r as any).invol_produto_id ?? 0) || 0;
        (data as any).invol_codigo_barras = String(
          (r as any).invol_codigo_barras ?? "",
        );
        // ✅ texto do INVOL (para aparecer no combobox ao reabrir)
        (data as any).invol_item = String((r as any).invol_item ?? "");

        // ✅ metas do VÉU no wizardData
        (data as any).veu_deposito_nome = String(
          (r as any).veu_deposito_nome ?? "",
        );
        (data as any).veu_produto_id =
          Number((r as any).veu_produto_id ?? 0) || 0;
        (data as any).veu_codigo_barras = String(
          (r as any).veu_codigo_barras ?? "",
        );
        (data as any).veu_item = String((r as any).veu_item ?? "");

        // ✅ metas do CORDÃO no wizardData
        (data as any).cordao_deposito_nome = String(
          (r as any).cordao_deposito_nome ?? "",
        );
        (data as any).cordao_produto_id =
          Number((r as any).cordao_produto_id ?? 0) || 0;
        (data as any).cordao_codigo_barras = String(
          (r as any).cordao_codigo_barras ?? "",
        );
        (data as any).cordao_item = String((r as any).cordao_item ?? "");

        // ✅ Coroa de Flores
        (data as any).coroa_flores = String((r as any).coroa_flores ?? "");
        (data as any).coroa_tipo = String((r as any).coroa_tipo ?? "");
        (data as any).coroa_produto_id = Number((r as any).coroa_produto_id ?? 0) || 0;
        (data as any).coroa_modelo = String((r as any).coroa_modelo ?? "");
        (data as any).coroa_codigo_barras = String((r as any).coroa_codigo_barras ?? "");
        (data as any).coroa_deposito_nome = String((r as any).coroa_deposito_nome ?? "");
        (data as any).coroas_itens = [];
        (data as any).coroas_pedido_id = null;

        wizardOriginalLegacyRef.current = {
          coroa_flores: String((r as any).coroa_flores ?? ""),
          realiza_velorio: String((r as any).realiza_velorio ?? ""),
          realiza_sepultamento: String((r as any).realiza_sepultamento ?? ""),
        };

        if (String((r as any).coroa_flores ?? "").trim() === "Sim" && (r as any).id != null) {
          try {
            const pedido = await carregarCoroasAtendimento((r as any).id);
            (data as any).coroas_itens = pedido.itens;
            (data as any).coroas_pedido_id = pedido.pedido_id;
          } catch (e: any) {
            // Compatibilidade com registros criados antes da integração com coroas.php.
            // Mantém os metadados legados visíveis sem inventar frase ou depósito.
            const tipoLegado = String((r as any).coroa_tipo ?? "").trim();
            const pidLegado = Number((r as any).coroa_produto_id ?? 0) || 0;
            if (pidLegado > 0 && (tipoLegado === "Natural" || tipoLegado === "Artificial")) {
              (data as any).coroas_itens = [{
                ordem: 1,
                tipo_coroa: tipoLegado === "Artificial" ? "artificial" : "natural",
                produto_id: pidLegado,
                modelo_coroa: String((r as any).coroa_modelo ?? ""),
                codigo_barras: String((r as any).coroa_codigo_barras ?? ""),
                deposito_nome: String((r as any).coroa_deposito_nome ?? ""),
                frase: "",
                valor: null,
                foto_produto_url: "",
              }];
            }
            setWizardMsg({ text: e?.message || "Não foi possível carregar o pedido de coroas.", ok: false });
          }
        }

        wizardOriginalCoroasRef.current = {
          coroa_flores: String((r as any).coroa_flores ?? "").trim(),
          itens: normalizarCoroasParaComparacao((data as any).coroas_itens),
        };

        // ✅ Roteamento Velório / Sepultamento
        (data as any).realiza_velorio = String((r as any).realiza_velorio ?? "");
        (data as any).realiza_sepultamento = String((r as any).realiza_sepultamento ?? "");

        // ✅ insumos tanato (novo formato dentro do arrumacao_json)
        (data as any).arrumacao_json = String((r as any).arrumacao_json ?? "");

        const mats = parseMateriaisFromRegistro(r);
        setMateriais(mats);
        (data as any).materiais = mats;
        (data as any).materiais_json = String((r as any).materiais_json ?? "");

        const arr = parseArrumacaoFromRegistro(r);
        setArrumacao(arr);
        (data as any).arrumacao = arr;

        setWizardData(data);
        setAssistenciaVal(String((r as any).assistencia ?? ""));
        setTanatoVal(String((r as any).tanato ?? ""));
        setWizardOpen(true);
        return;
      }

      iniciarNovoRegistro(tipoAtendimento);
    },
    [registros, iniciarNovoRegistro, tipoAtendimento, carregarCoroasAtendimento],
  );

  /** Nome do campo e a aba onde ele está, para o aviso de campos obrigatórios. */
  const avisarFaltando = useCallback(
    (ids: string[]) => {
      const lista: CampoFaltando[] = ids.map((id) => {
        const idx = (stepsForTipo as unknown as any[]).findIndex((st: any) => st?.id === id);
        const aba = idx >= 0 ? wizardStepIndexesForTipo.findIndex((g) => g.includes(idx)) : -1;
        const rotulo = String((idx >= 0 ? (stepsForTipo as any)[idx]?.label : "") || id).replace(/\s*\*$/, "");
        return { id, rotulo, aba: aba >= 0 ? aba : null, abaTitulo: aba >= 0 ? String(wizardStepTitlesForTipo[aba] ?? "") : "" };
      });
      setWizardMsg({
        text: "Não foi possível salvar. Preencha: " + lista.map((c) => (c.abaTitulo ? `${c.rotulo} (aba ${c.abaTitulo})` : c.rotulo)).join(", ") + ".",
        ok: false,
        faltando: lista,
      });
    },
    [stepsForTipo, wizardStepIndexesForTipo, wizardStepTitlesForTipo],
  );

  const salvarGrupoWizard = useCallback((): Registro | null => {
    const grupo = wizardStepIndexesForTipo[wizardStep];
    const next: any = { ...wizardData };

    // ✅ Se o usuário acabou de salvar um modal interno (Materiais/Arrumação),
    // o próximo salvar do Wizard deve respeitar esse escopo menor.
    // Isso impede que a aba Itens inteira seja validada ao salvar apenas
    // materiais_json ou arrumacao_json.
    const modalRestrictIdsForSave = normalizeRestrictIds(
      (wizardData as any)?._wizard_modal_restrict_ids,
    );

    const deveValidarCampoObrigatorio = (id: string) =>
      !modalRestrictIdsForSave || modalRestrictIdsForSave.includes(id);
    const faltandoGrupo: string[] = [];

    for (const idx of grupo) {
      const s = (stepsForTipo as any)[idx] as any;

      if (s?.id === "coroas_itens") {
        next.coroas_itens = normalizarCoroasParaComparacao((wizardData as any).coroas_itens);
        continue;
      }

      // ✅ Para campos async (combobox/autocomplete), pega do state (wizardData), não do DOM
      const isAsyncField =
        s?.type === "async_urna" ||
        s?.type === "async_roupa" ||
        s?.type === "async_invol" ||
        s?.type === "async_veu" ||
        s?.type === "async_cordao" ||
        s?.type === "async_coroa";

      let v = "";

      if (isAsyncField) {
        v = String((wizardData as any)?.[s.id] ?? "").trim();
      } else {
        const el = document.getElementById("wizard-" + s.id) as
          | HTMLInputElement
          | HTMLTextAreaElement
          | HTMLSelectElement
          | null;

        v = (el?.value ?? "").trim();

        if (deveValidarCampoObrigatorio(s.id) && obrigatoriosForTipo.includes(s.id) && !v) {
          if (!faltandoGrupo.length) el?.focus?.();
          faltandoGrupo.push(s.id);
          continue;
        }
      }

      // valida obrigatórios também para async
      if (deveValidarCampoObrigatorio(s.id) && obrigatoriosForTipo.includes(s.id) && !v) {
        faltandoGrupo.push(s.id);
        continue;
      }

      next[s.id] = v;
    }

    // Todos os obrigatórios vazios da aba de uma vez (o operador vê a lista e não precisa procurar).
    if (faltandoGrupo.length) {
      avisarFaltando(faltandoGrupo);
      return null;
    }

    if ((wizardData as any).id != null) next.id = (wizardData as any).id;

    next.materiais = materiais;
    next.arrumacao = arrumacao;
    next.tipo_atendimento = tipoAtendimento;

    // ✅ garante que os materiais dinâmicos sejam enviados ao PHP.
    // O front usa `materiais`, mas o backend salva `materiais_json`.
    // Quando o MateriaisModal já gerou o JSON normalizado, preserva esse valor.
    try {
      const jsonDoModal = String(next?.materiais_json ?? "").trim();
      if (modalRestrictIdsForSave?.includes("materiais_json") && jsonDoModal) {
        next.materiais_json = jsonDoModal;
      } else {
        next.materiais_json = JSON.stringify(materiais || {});
      }
    } catch {
      next.materiais_json = "{}";
    }

    // ✅ VELÓRIO: sala selecionada e velório online
    // - Se não houver sala marcada, limpa velorio_online para não mandar informação solta.
    // - Se houver sala, mantém somente valores válidos ("Sim" ou "Não"); o Wizard também valida visualmente.
    const salaVelorio = String(next?.sala_velorio ?? "").trim();
    const velorioOnline = String(next?.velorio_online ?? "").trim();

    if (!salaVelorio) {
      next.sala_velorio = "";
      next.velorio_online = "";
    } else {
      next.sala_velorio = salaVelorio;
      next.velorio_online =
        velorioOnline === "Sim" || velorioOnline === "Não" ? velorioOnline : "";
    }

    // ✅ URNA META: não usa DOM. Mantém o que está no wizardData.
    // Urna vazia significa que o usuário marcou "Não" no Wizard.
    const urnaTxt = String(next?.urna ?? "").trim();
    const pid = Number(next?.urna_produto_id ?? 0) || 0;

    if (urnaTxt === "") {
      next.urna = "";
      next.urna_deposito_nome = "";
      next.urna_produto_id = 0;
      next.urna_codigo_barras = "";
    } else if (pid > 0) {
      const dep = String(next?.urna_deposito_nome ?? "MEMORIAL")
        .trim()
        .toUpperCase();
      next.urna_deposito_nome = dep === "FUNERARIA" ? "FUNERARIA" : "MEMORIAL";
      next.urna_codigo_barras = String(next?.urna_codigo_barras ?? "").trim();
    } else {
      // Se houver texto sem seleção real do estoque, mantém pid 0 para a validação bloquear.
      next.urna_produto_id = 0;
      next.urna_codigo_barras = String(next?.urna_codigo_barras ?? "").trim();
      next.urna_deposito_nome =
        String(next?.urna_deposito_nome ?? "MEMORIAL")
          .trim()
          .toUpperCase() === "FUNERARIA"
          ? "FUNERARIA"
          : "MEMORIAL";
    }

    // ✅ ROUPA META: mesma lógica da URNA (não depende do DOM)
    const roupaTxt = String(next?.roupa ?? "").trim();
    const roupaPropriaFlag = Number((next as any)?.roupa_propria ?? 0) ? 1 : 0;

    if (roupaTxt === "") {
      // sem roupa -> limpa metas e flag
      next.roupa_produto_id = 0;
      next.roupa_codigo_barras = "";
      next.roupa_deposito_nome = "";
      (next as any).roupa_propria = 0;
    } else if (isRoupaPropria(roupaTxt)) {
      // roupa própria não usa estoque
      next.roupa = "ROUPA PRÓPRIA";
      next.roupa_produto_id = 0;
      next.roupa_codigo_barras = "";
      next.roupa_deposito_nome = "";
      (next as any).roupa_propria = 1;
    } else {
      // roupa do estoque: zera o flag antigo de roupa própria
      (next as any).roupa_propria = 0;
      // roupa do estoque -> mantém pid/cb/dep do wizardData
      const roupaPid = Number(next?.roupa_produto_id ?? 0) || 0;

      // normaliza depósito permitido
      const depRaw = String(next?.roupa_deposito_nome ?? "")
        .trim()
        .toUpperCase();
      const depOk =
        depRaw === "ARMARIO SANDRO" ||
          depRaw === "ARMARIO ILDO" ||
          depRaw === "FUNERARIA"
          ? depRaw
          : "ARMARIO SANDRO";

      next.roupa_deposito_nome = depOk;
      next.roupa_codigo_barras = String(next?.roupa_codigo_barras ?? "").trim();

      // se digitou mas não selecionou item do estoque, mantém 0 (wizard/PHP validam)
      next.roupa_produto_id = roupaPid > 0 ? roupaPid : 0;

      // não é própria -> garante flag zerado
      (next as any).roupa_propria = 0;
    }

    // ✅ INVOL META: só vale quando invol === "Sim"
    const involFlag = String(next?.invol ?? "").trim();
    if (!isSim(involFlag)) {
      next.invol_produto_id = 0;
      next.invol_codigo_barras = "";
      next.invol_deposito_nome = "";
      // esse campo é só “UI”, mas evita sujeira:
      next.invol_item = "";
    } else {
      const involPid = Number(next?.invol_produto_id ?? 0) || 0;

      // normaliza depósito permitido
      const depRaw = String(next?.invol_deposito_nome ?? "")
        .trim()
        .toUpperCase();
      const depOk =
        depRaw === "ARMARIO ILDO" ? "ARMARIO ILDO" : "ARMARIO SANDRO";

      next.invol_deposito_nome = depOk;
      next.invol_codigo_barras = String(next?.invol_codigo_barras ?? "").trim();
      next.invol_produto_id = involPid > 0 ? involPid : 0;
    }

    // ✅ VÉU META: só vale quando veu === "Sim"
    const veuFlag = String(next?.veu ?? "").trim();
    if (!isSim(veuFlag)) {
      next.veu_produto_id = 0;
      next.veu_codigo_barras = "";
      next.veu_deposito_nome = "";
      next.veu_item = "";
    } else {
      const veuPid = Number(next?.veu_produto_id ?? 0) || 0;

      const depRaw = String(next?.veu_deposito_nome ?? "")
        .trim()
        .toUpperCase();
      const depOk =
        depRaw === "ARMARIO ILDO" || depRaw === "FUNERARIA"
          ? depRaw
          : "ARMARIO SANDRO";

      next.veu_deposito_nome = depOk;
      next.veu_codigo_barras = String(next?.veu_codigo_barras ?? "").trim();
      next.veu_produto_id = veuPid > 0 ? veuPid : 0;
    }

    // ✅ CORDÃO META: só vale quando cordao === "Sim"
    const cordaoFlag = String(next?.cordao ?? "").trim();
    if (!isSim(cordaoFlag)) {
      next.cordao_produto_id = 0;
      next.cordao_codigo_barras = "";
      next.cordao_deposito_nome = "";
      next.cordao_item = "";
    } else {
      const cordaoPid = Number(next?.cordao_produto_id ?? 0) || 0;

      const depRaw = String(next?.cordao_deposito_nome ?? "")
        .trim()
        .toUpperCase();
      const depOk =
        depRaw === "ARMARIO ILDO" || depRaw === "FUNERARIA"
          ? depRaw
          : "ARMARIO SANDRO";

      next.cordao_deposito_nome = depOk;
      next.cordao_codigo_barras = String(
        next?.cordao_codigo_barras ?? "",
      ).trim();
      next.cordao_produto_id = cordaoPid > 0 ? cordaoPid : 0;
    }

    // ✅ COROA DE FLORES - os detalhes completos ficam em coroas_itens.
    const coroaFlag = String(next?.coroa_flores ?? "").trim();
    if (!isSim(coroaFlag)) {
      next.coroa_tipo = "";
      next.coroa_produto_id = 0;
      next.coroa_modelo = "";
      next.coroa_codigo_barras = "";
      next.coroa_deposito_nome = "";
      next.coroas_itens = [];
    } else {
      const itens = normalizarCoroasParaComparacao((wizardData as any).coroas_itens);
      next.coroas_itens = itens;
      const primeiro = itens[0];
      next.coroa_tipo = primeiro?.tipo_coroa === "natural" ? "Natural" : primeiro?.tipo_coroa === "artificial" ? "Artificial" : "";
      next.coroa_produto_id = Number(primeiro?.produto_id || 0);
      next.coroa_modelo = primeiro?.modelo_coroa
        ? `${primeiro.modelo_coroa}${itens.length > 1 ? ` +${itens.length - 1}` : ""}`
        : "";
      next.coroa_codigo_barras = String(primeiro?.codigo_barras || "").trim();
      next.coroa_deposito_nome = primeiro?.tipo_coroa === "artificial" ? String(primeiro?.deposito_nome || "").trim() : "";
    }

    // ✅ ROTEAMENTO: quando Não, limpa os dados da aba para não manter informação escondida.
    if (isNao(next?.realiza_velorio)) {
      next.local_cerimonia = "";
      next.local_velorio = "";
      next.sala_velorio = "";
      next.velorio_online = "";
      next.data_inicio_velorio = "";
      next.data_fim_velorio = "";
      next.hora_inicio_velorio = "";
      next.hora_fim_velorio = "";
      next.observacao_velorio01 = "";
    }

    if (isNao(next?.realiza_sepultamento)) {
      next.local = "";
      next.observacao_velorio02 = "";
    }

    // ✅ preservar INSUMOS dentro do arrumacao_json (merge booleans + insumos)
    try {
      const prevStr = String(next.arrumacao_json ?? "");
      let prevObj: any = {};
      try {
        prevObj = prevStr ? JSON.parse(prevStr) : {};
      } catch {
        prevObj = {};
      }

      const bools =
        next.arrumacao && typeof next.arrumacao === "object"
          ? next.arrumacao
          : arrumacao;

      // mantém deposito_nome/itens e atualiza booleans
      const merged = { ...(prevObj || {}), ...(bools || {}) };

      next.arrumacao_json = JSON.stringify(merged);
    } catch {
      next.arrumacao_json = "";
    }

    setWizardData(next);
    return next as Registro;
  }, [
    wizardStepIndexesForTipo,
    wizardStep,
    wizardData,
    materiais,
    arrumacao,
    stepsForTipo,
    obrigatoriosForTipo,
    tipoAtendimento,
    avisarFaltando,
  ]);

  const concluirWizardInterno = useCallback(async (options?: {
    dataOverride?: Registro | null;
    manterWizardAberto?: boolean;
    mensagemSucesso?: string;
  }) => {
    if (wizardSubmitting) return;

    // Quando o salvamento nasce de um modal interno (ex.: Arrumação), usamos
    // exatamente o snapshot produzido por ele. Isso evita depender do próximo
    // clique em "Salvar" do Wizard para persistir arrumacao_json.
    const dataAtualizada: any = options?.dataOverride ?? salvarGrupoWizard();
    if (!dataAtualizada) return;

    /*
     * Cada criação recebe um operation_id estável durante esta tentativa.
     * Se a resposta se perder depois do INSERT, a fila reutiliza o mesmo ID
     * e o backend devolve o atendimento já criado.
     */
    const creationOperationId =
      !wizardEditing
        ? newOfflineId(
          "new-attendance-op",
        )
        : null;

    // ✅ Prioridade de escopo:
    // 1) Escopo vindo dos modais internos: Materiais/Arrumação.
    // 2) Escopo da aba editada no InfoModal.
    // 3) Edição completa.
    const modalRestrictIds = normalizeRestrictIds(
      dataAtualizada?._wizard_modal_restrict_ids,
    );

    const groupRestrictIds =
      typeof wizardRestrictGroup === "number"
        ? (wizardStepIndexesForTipo[wizardRestrictGroup] || [])
          .map((i) => (stepsForTipo as any)[i]?.id)
          .filter(Boolean)
        : null;

    const wizardRestrictIds = modalRestrictIds || groupRestrictIds;

    const escopoTemAlgum = (ids: string[]) => scopeHasAny(wizardRestrictIds, ids);

    let grupoObrigatorios: string[];
    if (wizardRestrictIds) {
      grupoObrigatorios = wizardRestrictIds.filter((id) => obrigatoriosForTipo.includes(id));
    } else {
      grupoObrigatorios = obrigatoriosForTipo;
    }

    if (wizardEditing && wizardOriginalLegacyRef.current) {
      const original = wizardOriginalLegacyRef.current;
      grupoObrigatorios = grupoObrigatorios.filter((id) => {
        if (id !== "coroa_flores" && id !== "realiza_velorio" && id !== "realiza_sepultamento") return true;
        return !(String((original as any)[id] ?? "").trim() === "" && String(dataAtualizada?.[id] ?? "").trim() === "");
      });
    }

    const faltandoTodos = grupoObrigatorios.filter((id) => !dataAtualizada[id] || String(dataAtualizada[id]).trim() === "");
    if (faltandoTodos.length) {
      avisarFaltando(faltandoTodos);
      return;
    }

    const obrigatoriedadeAtiva = obrigatoriosForTipo.length > 0;

    // ✅ validação extra (front): se escolheu sala do velório, Velório Online é obrigatório.
    const salaVelorio = String(dataAtualizada?.sala_velorio ?? "").trim();
    const velorioOnline = String(dataAtualizada?.velorio_online ?? "").trim();
    if (
      obrigatoriedadeAtiva &&
      escopoTemAlgum(["local_velorio", "sala_velorio", "velorio_online"]) &&
      salaVelorio &&
      velorioOnline !== "Sim" &&
      velorioOnline !== "Não"
    ) {
      setWizardMsg({
        text: 'Selecione "Sim" ou "Não" em Velório Online.',
        ok: false,
      });
      return;
    }

    // ✅ validação extra (front): se urna tem texto, precisa ter produto_id
    const urnaTxt = String(dataAtualizada?.urna ?? "").trim();
    // ✅ validação extra (front): ROUPA (se não for própria)
    const roupaTxt = String(dataAtualizada?.roupa ?? "").trim();
    const roupaPid = Number(dataAtualizada?.roupa_produto_id ?? 0) || 0;
    const roupaDep = String(dataAtualizada?.roupa_deposito_nome ?? "").trim();

    // ✅ no EDITAR: só valida roupa se ela mudou em relação ao original
    const origRoupa = wizardOriginalRoupaRef.current;

    const roupaMudou = wizardEditing
      ? String(roupaTxt).trim() !== String(origRoupa?.roupa ?? "").trim() ||
      (Number(roupaPid) || 0) !==
      (Number(origRoupa?.roupa_produto_id ?? 0) || 0) ||
      String(roupaDep).trim() !==
      String(origRoupa?.roupa_deposito_nome ?? "").trim() ||
      String((dataAtualizada as any)?.roupa_codigo_barras ?? "").trim() !==
      String(origRoupa?.roupa_codigo_barras ?? "").trim() ||
      (Number((dataAtualizada as any)?.roupa_propria ?? 0) ? 1 : 0) !==
      (Number(origRoupa?.roupa_propria ?? 0) ? 1 : 0)
      : true;

    if (
      obrigatoriedadeAtiva &&
      escopoTemAlgum(["roupa", "roupa_produto_id", "roupa_deposito_nome", "roupa_codigo_barras"]) &&
      roupaMudou &&
      roupaTxt !== "" &&
      !isRoupaPropria(roupaTxt)
    ) {
      if (roupaPid <= 0) {
        setWizardMsg({
          text: 'Selecione uma roupa da lista (produto do estoque) ou use "ROUPA PRÓPRIA".',
          ok: false,
        });
        return;
      }
      if (!roupaDep) {
        setWizardMsg({
          text: "Selecione o local de saída da roupa (ARMARIO SANDRO, ARMARIO ILDO ou FUNERARIA).",
          ok: false,
        });
        return;
      }
    }

    // ✅ validação extra (front):
    const involVal = dataAtualizada?.invol ?? "";
    if (
      obrigatoriedadeAtiva &&
      escopoTemAlgum(["invol", "invol_item", "invol_produto_id", "invol_deposito_nome"]) &&
      isSim(involVal)
    ) {
      const involPid = Number(dataAtualizada?.invol_produto_id ?? 0) || 0;
      const involDep = String(dataAtualizada?.invol_deposito_nome ?? "").trim();
      if (involPid <= 0) {
        setWizardMsg({
          text: "Selecione um INVOL da lista (produto do estoque).",
          ok: false,
        });
        return;
      }
      if (!involDep) {
        setWizardMsg({
          text: "Selecione o local do INVOL (ARMARIO SANDRO ou ARMARIO ILDO).",
          ok: false,
        });
        return;
      }
    }

    // ✅ validação extra (front): VÉU
    const veuVal = dataAtualizada?.veu ?? "";
    if (
      obrigatoriedadeAtiva &&
      escopoTemAlgum(["veu", "veu_item", "veu_produto_id", "veu_deposito_nome"]) &&
      isSim(veuVal)
    ) {
      const veuPid = Number(dataAtualizada?.veu_produto_id ?? 0) || 0;
      const veuDep = String(dataAtualizada?.veu_deposito_nome ?? "").trim();
      if (veuPid <= 0) {
        setWizardMsg({
          text: "Selecione um VÉU da lista (produto do estoque).",
          ok: false,
        });
        return;
      }
      if (!veuDep) {
        setWizardMsg({
          text: "Selecione o local do VÉU (ARMARIO SANDRO, ARMARIO ILDO ou FUNERARIA).",
          ok: false,
        });
        return;
      }
    }

    // ✅ validação extra (front): CORDÃO
    const cordaoVal = dataAtualizada?.cordao ?? "";
    if (
      obrigatoriedadeAtiva &&
      escopoTemAlgum(["cordao", "cordao_item", "cordao_produto_id", "cordao_deposito_nome"]) &&
      isSim(cordaoVal)
    ) {
      const cordaoPid = Number(dataAtualizada?.cordao_produto_id ?? 0) || 0;
      const cordaoDep = String(
        dataAtualizada?.cordao_deposito_nome ?? "",
      ).trim();
      if (cordaoPid <= 0) {
        setWizardMsg({
          text: "Selecione um CORDÃO da lista (produto do estoque).",
          ok: false,
        });
        return;
      }
      if (!cordaoDep) {
        setWizardMsg({
          text: "Selecione o local do CORDÃO (ARMARIO SANDRO, ARMARIO ILDO ou FUNERARIA).",
          ok: false,
        });
        return;
      }
    }

    // ✅ validação extra (front): COROAS DO ATENDIMENTO
    if (
      escopoTemAlgum(COROA_SCOPE_IDS) &&
      isSim(dataAtualizada?.coroa_flores)
    ) {
      const itens = normalizarCoroasParaComparacao(dataAtualizada?.coroas_itens);
      if (itens.length < 1 || itens.length > 20) {
        setWizardMsg({ text: "Coroa de Flores: informe de 1 a 20 coroas.", ok: false });
        return;
      }
      const agrupado = new Map<string, number>();
      for (let i = 0; i < itens.length; i += 1) {
        const item = itens[i];
        if (item.tipo_coroa !== "natural" && item.tipo_coroa !== "artificial") {
          setWizardMsg({ text: `Coroa ${i + 1}: selecione Natural ou Artificial.`, ok: false });
          return;
        }
        if (item.produto_id <= 0 || !item.modelo_coroa) {
          setWizardMsg({ text: `Coroa ${i + 1}: selecione o modelo.`, ok: false });
          return;
        }
        if (!item.frase) {
          setWizardMsg({ text: `Coroa ${i + 1}: preencha a frase.`, ok: false });
          return;
        }
        if (item.tipo_coroa === "artificial") {
          const dep = String(item.deposito_nome || "").toUpperCase();
          if (dep !== "MEMORIAL" && dep !== "FUNERARIA") {
            setWizardMsg({ text: `Coroa ${i + 1}: selecione MEMORIAL ou FUNERÁRIA.`, ok: false });
            return;
          }
          const key = `${item.produto_id}|${dep}`;
          agrupado.set(key, (agrupado.get(key) || 0) + 1);
        }
      }
    }

    // ✅ validação extra (front): INSUMOS TANATO (arrumacao_json novo)
    const ins = parseInsumosFromArrumacaoJson(dataAtualizada?.arrumacao_json);
    if (escopoTemAlgum(["arrumacao", "arrumacao_json"]) && ins && (!ins.deposito_nome || ins.itens.length === 0)) {
      setWizardMsg({
        text: "Insumos Tanatopraxia: selecione o depósito e informe itens com quantidade (>=1).",
        ok: false,
      });
      return;
    }

    const urnaPid = Number(dataAtualizada?.urna_produto_id ?? 0) || 0;
    if (
      obrigatoriedadeAtiva &&
      escopoTemAlgum(["urna", "urna_produto_id", "urna_deposito_nome"]) &&
      urnaTxt !== "" &&
      urnaPid <= 0
    ) {
      setWizardMsg({
        text: "Selecione uma urna da lista (produto do estoque).",
        ok: false,
      });
      return;
    }

    const aplicarEscopoNoPayload = (payload: any) => {
      if (payload.acao === "editar" && wizardRestrictIds) {
        let restrictIds: string[] = Array.from(new Set<string>(wizardRestrictIds.map((id) => String(id))));

        // ✅ Correção: ao editar a aba de Itens para trocar somente a URNA,
        // a mesma aba também costuma conter "roupa" no escopo.
        // Como scrubRoupaNoEditar remove roupa do payload quando ela NÃO mudou,
        // o PHP recebia _wizard_restrict_ids com "roupa" mas sem o campo "roupa",
        // e retornava: "Campo obrigatório após Corpo na Clínica: Roupa."
        // Se a roupa não foi alterada, ela também precisa sair do escopo enviado ao backend.
        if (wizardEditing && !roupaMudou) {
          restrictIds = restrictIds.filter((id) => !ROUPA_SCOPE_IDS.includes(id));
        }

        if (wizardEditing && wizardOriginalLegacyRef.current) {
          const original = wizardOriginalLegacyRef.current;
          if (!String(original.coroa_flores || "").trim() && !String(payload.coroa_flores || "").trim()) {
            restrictIds = restrictIds.filter((id) => !COROA_SCOPE_IDS.includes(id));
            for (const id of COROA_SCOPE_IDS) delete payload[id];
          }
          if (!String(original.realiza_velorio || "").trim() && !String(payload.realiza_velorio || "").trim()) {
            restrictIds = restrictIds.filter((id) => id !== "realiza_velorio");
            delete payload.realiza_velorio;
          }
          if (!String(original.realiza_sepultamento || "").trim() && !String(payload.realiza_sepultamento || "").trim()) {
            restrictIds = restrictIds.filter((id) => id !== "realiza_sepultamento");
            delete payload.realiza_sepultamento;
          }
        }

        payload._wizard_restrict_ids = restrictIds;
      }

      // Esses campos são marcadores internos do front. O PHP só precisa de _wizard_restrict_ids.
      delete payload._wizard_modal_restrict_ids;
      delete payload._wizard_modal_scope;

      return payload;
    };

    const coroaMudou = wizardEditing
      ? !coroasSnapshotIgual(wizardOriginalCoroasRef.current, dataAtualizada?.coroa_flores, dataAtualizada?.coroas_itens)
      : isSim(dataAtualizada?.coroa_flores);

    if (!isOnlineNow() && coroaMudou) {
      setWizardMsg({
        text: "Alterações de Coroa de Flores exigem internet para sincronizar a Ordem de Serviço e validar o estoque.",
        ok: false,
      });
      return;
    }

    if (!isOnlineNow()) {
      try {
        setWizardSubmitting(true);

        const payload: any = {
          ...dataAtualizada,
          acao:
            wizardEditing
              ? "editar"
              : "novo",
        };

        if (
          payload.acao === "novo" &&
          creationOperationId
        ) {
          payload.operation_id =
            creationOperationId;
          payload.origem =
            "offline";
        }

        aplicarEscopoNoPayload(
          payload,
        );

        if (
          payload.acao === "editar"
        ) {
          scrubRoupaNoEditar(
            payload,
            wizardOriginalRoupaRef.current,
          );
        }

        if (
          payload.acao === "novo"
        ) {
          const session =
            await getCurrentOfflineSession({
              refreshIfOnline:
                false,
              allowCachedOnNetworkFailure:
                true,
            });

          if (!session?.userId) {
            throw new Error(
              "Usuário offline não identificado. Abra o PAI com internet ao menos uma vez antes de criar atendimento offline.",
            );
          }

          payload.usuario_id =
            session.userId;

          const local =
            createLocalAttendance({
              payload,
              userId:
                session.userId,
              userName:
                session.userName,
              operationId:
                String(
                  payload.operation_id,
                ),
            });

          enqueueOffline(
            payload,
            "offline",
            {
              localRecordId:
                local.localId,
              userId:
                session.userId,
            },
          );

          setRegistros(
            (current) =>
              mergeLocalAttendancesWithRecords(
                current,
                session.userId,
              ) as Registro[],
          );

          setWizardMsg({
            text:
              "Sem internet: atendimento criado neste aparelho e aguardando sincronização.",
            ok: true,
          });
        } else {
          enqueueOffline(
            payload,
            "offline",
          );

          setWizardMsg({
            text:
              "Sem internet: alteração salva offline e será enviada automaticamente quando a conexão voltar.",
            ok: true,
          });
        }

        if (!options?.manterWizardAberto) {
          setTimeout(
            () =>
              setWizardOpen(false),
            950,
          );
        }
      } catch (e: any) {
        setWizardMsg({
          text:
            e?.message ||
            "Não foi possível salvar offline.",
          ok: false,
        });
      } finally {
        setWizardSubmitting(false);
      }

      return;
    }

    try {
      setWizardSubmitting(true);
      const payload: any = {
        ...dataAtualizada,
        acao:
          wizardEditing
            ? "editar"
            : "novo",
      };

      if (
        payload.acao === "novo" &&
        creationOperationId
      ) {
        payload.operation_id =
          creationOperationId;
        payload.origem =
          "online";
      }

      aplicarEscopoNoPayload(
        payload,
      );

      if (payload.acao === "editar") {
        // ✅ remove roupa do payload se não mudou
        scrubRoupaNoEditar(payload, wizardOriginalRoupaRef.current);
      }

      // ===== blindagem final da roupa antes do envio =====
      const roupaFinalTxt = String(payload.roupa ?? "").trim();

      if (isRoupaPropria(roupaFinalTxt)) {
        payload.roupa = "ROUPA PRÓPRIA";
        payload.roupa_propria = 1;
        payload.roupa_produto_id = 0;
        payload.roupa_deposito_nome = "";
        payload.roupa_codigo_barras = "";
      } else if (roupaFinalTxt !== "") {
        payload.roupa_propria = 0;
      }

      // OS: o que ela precisa para ser montada (plano, tipo de procedimento, autorização da Prefeitura, translado).
      if (
        (dataAtualizada as any).tipo_atendimento !== "terceiro" &&
        (!wizardRestrictIds || escopoTemAlgum(["tanato", "convenio"]))
      ) {
        const msgOS = validarCamposOS(
          String((dataAtualizada as any).convenio ?? ""),
          String((dataAtualizada as any).tanato ?? ""),
          osCampos,
          String((dataAtualizada as any).coroa_flores ?? ""),
        );
        if (msgOS) {
          setWizardMsg({ text: msgOS, ok: false });
          return;
        }
      }

      // Em edição, sincroniza a Ordem de Serviço ANTES de gravar o atendimento.
      // Assim, se o pedido já entrou em produção ou o estoque artificial não
      // comportar a alteração, o próprio atendimento não fica divergente.
      let coroaSincronizadaAntes = false;
      if (wizardEditing && coroaMudou) {
        const atendimentoIdEdicao = payload?.id ?? (dataAtualizada as any)?.id ?? null;
        if (atendimentoIdEdicao == null) {
          setWizardMsg({ text: "Não foi possível identificar o atendimento para sincronizar as coroas.", ok: false });
          return;
        }

        try {
          await sincronizarCoroasAtendimento(atendimentoIdEdicao, dataAtualizada);
          coroaSincronizadaAntes = true;
        } catch (syncError: any) {
          setWizardMsg({
            text: syncError?.message || "Não foi possível sincronizar a Ordem de Serviço das coroas.",
            ok: false,
          });
          return;
        }
      }

      const json = await enviarRegistroPHP(payload);

      if (json?.sucesso) {
        const atendimentoId =
          json?.id ?? json?.novo_id ?? json?.last_id ?? payload?.id ?? (dataAtualizada as any)?.id ?? null;

        if (coroaMudou && atendimentoId != null && !coroaSincronizadaAntes) {
          try {
            // Novo atendimento: primeiro precisamos do ID gerado em sepultamentos,
            // por isso a Ordem de Serviço é criada logo após o INSERT.
            await sincronizarCoroasAtendimento(atendimentoId, dataAtualizada);
          } catch (syncError: any) {
            setWizardMsg({
              text: `O atendimento foi salvo, mas a Ordem de Serviço das coroas não foi sincronizada: ${syncError?.message || "erro desconhecido"}. Corrija e salve novamente.`,
              ok: false,
            });
            await fetchRegistros();
            return;
          }
        }

        if (coroaMudou && atendimentoId != null) {
          wizardOriginalCoroasRef.current = {
            coroa_flores: String(dataAtualizada?.coroa_flores ?? "").trim(),
            itens: normalizarCoroasParaComparacao(dataAtualizada?.coroas_itens),
          };
        }

        // Local do velório: coluna nova (sepultamentos.local_cerimonia), gravada pelo os_principal.php.
        // Em edição só grava depois de ter lido o valor salvo, para não apagar o local com um campo vazio.
        let textoLocal = "";
        if (
          atendimentoId != null &&
          !String(atendimentoId).startsWith("local") &&
          localCerimoniaCarregadoRef.current &&
          (!wizardRestrictIds || escopoTemAlgum(["local_velorio", "sala_velorio", "velorio_online"]))
        ) {
          try {
            await salvarLocalCerimonia(atendimentoId, localCerimoniaEfetivo(dataAtualizada as any));
          } catch (localError: any) {
            textoLocal = ` Mas o local do velório não foi gravado: ${localError?.message || "erro desconhecido"}.`;
          }
        }

        let textoOS = "";
        if (
          atendimentoId != null &&
          (dataAtualizada as any).tipo_atendimento !== "terceiro" &&
          tipoConvenio(String((dataAtualizada as any).convenio ?? ""), osCampos.convenio_tipo) !== "outro"
        ) {
          try {
            const r = await salvarEsincronizarOS(
              atendimentoId,
              String((dataAtualizada as any).convenio ?? ""),
              String((dataAtualizada as any).tanato ?? ""),
              osCampos,
              String((dataAtualizada as any).coroa_flores ?? ""),
            );
            setOsVersao((n) => n + 1);
            textoOS = r.alteracoes.length ? " OS atualizada." : " OS em dia.";
          } catch (osError: any) {
            textoOS = ` Mas a OS não foi atualizada: ${osError?.message || "erro desconhecido"}.`;
          }
        }

        // Orçamento → atendimento (13/10/2026): o orçamento passa a "Virou atendimento" com o número deste registro.
        let textoOrc = "";
        const orcEmUso = orcamentoEmUsoRef.current;
        if (orcEmUso && !wizardEditing && atendimentoId != null && !String(atendimentoId).startsWith("local")) {
          try {
            // O servidor liga o orçamento e leva para a OS os valores tratados nele (acréscimos e descontos, 14/10/2026).
            const rc = await marcarOrcamentoConvertido(orcEmUso.id, atendimentoId);
            orcamentoEmUsoRef.current = null;
            textoOrc = ` ${rc.msg || `Orçamento ${orcEmUso.numero} ligado a este atendimento.`}`;
            setOsVersao((n) => n + 1);
          } catch (orcError: any) {
            textoOrc = ` Mas o orçamento ${orcEmUso.numero} não foi marcado como convertido: ${orcError?.message || "erro desconhecido"}.`;
          }
        }

        // Corrigir baixa (09/10/2026): a Gestão trocou item travado e o informativo.php acertou o estoque.
        const est = (json as any)?.estoque_corrigido;
        const textoEstoque =
          est && ((est.voltaram?.length ?? 0) + (est.sairam?.length ?? 0)) > 0
            ? ` Estoque acertado: ${[
              est.voltaram?.length ? `voltou ${est.voltaram.join(", ")}` : "",
              est.sairam?.length ? `saiu ${est.sairam.join(", ")}` : "",
            ].filter(Boolean).join("; ")}.`
            : "";

        setWizardMsg({
          text: (options?.mensagemSucesso || "Registro salvo!") + textoEstoque + textoOS + textoLocal + textoOrc,
          ok: !textoOS.includes("não foi atualizada") && !textoLocal && !textoOrc.includes("não foi marcado") && !textoOrc.includes("não foram"),
        });

        if ((dataAtualizada as any).tipo_atendimento === "terceiro") {
          const novoId =
            json?.id ??
            json?.novo_id ??
            json?.last_id ??
            (dataAtualizada as any).id ??
            null;
          addTerceiroIdToSession(novoId);
        }

        fetchRegistros();
        if (!options?.manterWizardAberto) {
          setTimeout(() => setWizardOpen(false), 950);
        }
      } else {
        setWizardMsg({
          text: json?.erro || json?.msg || "Erro ao salvar!",
          ok: false,
        });
      }
    } catch (e: any) {
      const msg = String(e?.message || "");

      // ✅ só enfileira offline se for falha de rede / fetch (não validação)
      const isNetwork =
        msg.includes("Failed to fetch") ||
        msg.includes("NetworkError") ||
        msg.includes("ERR_NETWORK") ||
        msg.includes("Load failed") ||
        (msg.includes("fetch") && msg.includes("failed"));

      if (isNetwork) {
        const payload: any = {
          ...dataAtualizada,
          acao:
            wizardEditing
              ? "editar"
              : "novo",
        };

        if (
          payload.acao === "novo" &&
          creationOperationId
        ) {
          payload.operation_id =
            creationOperationId;
          payload.origem =
            "offline";
        }

        aplicarEscopoNoPayload(
          payload,
        );

        if (
          payload.acao === "editar"
        ) {
          try {
            scrubRoupaNoEditar(
              payload,
              wizardOriginalRoupaRef.current,
            );
          } catch {
            // mantém o payload original
          }
        }

        if (
          payload.acao === "novo"
        ) {
          try {
            const session =
              await getCurrentOfflineSession({
                refreshIfOnline:
                  false,
                allowCachedOnNetworkFailure:
                  true,
              });

            if (!session?.userId) {
              throw new Error(
                "Usuário offline não identificado.",
              );
            }

            payload.usuario_id =
              session.userId;

            const local =
              createLocalAttendance({
                payload,
                userId:
                  session.userId,
                userName:
                  session.userName,
                operationId:
                  String(
                    payload.operation_id,
                  ),
              });

            enqueueOffline(
              payload,
              msg,
              {
                localRecordId:
                  local.localId,
                userId:
                  session.userId,
              },
            );

            setRegistros(
              (current) =>
                mergeLocalAttendancesWithRecords(
                  current,
                  session.userId,
                ) as Registro[],
            );

            setWizardMsg({
              text:
                "Falha de conexão: atendimento preservado neste aparelho e aguardando sincronização.",
              ok: true,
            });
          } catch (localError: any) {
            setWizardMsg({
              text:
                localError?.message ||
                "Falha de conexão e não foi possível preservar o atendimento localmente.",
              ok: false,
            });
            return;
          }
        } else {
          enqueueOffline(
            payload,
            msg,
          );

          setWizardMsg({
            text:
              "Falha de conexão: alteração guardada offline e será enviada automaticamente quando a conexão voltar.",
            ok: true,
          });
        }

        if (!options?.manterWizardAberto) {
          setTimeout(
            () =>
              setWizardOpen(false),
            950,
          );
        }
      } else {
        // ❗ erro real do servidor (ex.: validação 400) -> não enfileira
        setWizardMsg({
          text: msg || "Erro ao salvar!",
          ok: false,
        });
      }
    } finally {
      setWizardSubmitting(false);
      flushOfflineQueue();
    }
  }, [
    salvarGrupoWizard,
    wizardSubmitting,
    wizardRestrictGroup,
    wizardStepIndexesForTipo,
    stepsForTipo,
    obrigatoriosForTipo,
    wizardEditing,
    fetchRegistros,
    flushOfflineQueue,
    sincronizarCoroasAtendimento,
    osCampos,
  ]);

  /*
   * Trava do salvamento (08/10/2026): o estado wizardSubmitting só muda na próxima renderização, então dois toques
   * seguidos (ou o salvar da Arrumação junto com o Salvar) passavam os dois e gravavam o registro duas vezes.
   * A referência trava na hora: enquanto um salvamento estiver em andamento, o outro pedido é ignorado.
   */
  const salvandoRef = useRef(false);
  const concluirWizard = useCallback(async (options?: {
    dataOverride?: Registro | null;
    manterWizardAberto?: boolean;
    mensagemSucesso?: string;
  }) => {
    if (salvandoRef.current) return;
    salvandoRef.current = true;
    try {
      await concluirWizardInterno(options);
    } finally {
      salvandoRef.current = false;
    }
  }, [concluirWizardInterno]);

  // Salva imediatamente a Arrumação/Insumos quando estamos EDITANDO um
  // atendimento que já existe no servidor. Para atendimento novo, o modal
  // apenas atualiza o Wizard e o registro continua sendo criado no Concluir.
  const salvarArrumacaoPersistida = useCallback(
    async (data: Registro) => {
      const id = (data as any)?.id;

      if (
        !wizardEditing ||
        id == null ||
        String(id).trim() === "" ||
        isLocalAttendanceId(id)
      ) {
        return;
      }

      try {
        await concluirWizard({
          dataOverride: data,
          manterWizardAberto: true,
          mensagemSucesso: "Arrumação salva no atendimento!",
        });
      } finally {
        // O escopo especial serve somente para este salvamento imediato.
        // Limpá-lo evita que um próximo Salvar do Wizard ignore outros campos
        // que o usuário possa alterar depois.
        setWizardData((current: Registro) => {
          const next: any = { ...current };
          delete next._wizard_restrict_ids;
          delete next._wizard_modal_restrict_ids;
          delete next._wizard_modal_scope;
          return next as Registro;
        });
      }
    },
    [wizardEditing, concluirWizard],
  );

  /* -------------------- Ações (status) -------------------- */
  const abrirPopupAcaoPorId = useCallback((id: Registro["id"]) => {
    setAcaoMsg(null);
    setEstoqueInsuficiente(null);
    setAcaoId(id != null ? String(id) : null);
    setAcaoSubmitting(false);
    setAcaoOpen(true);
  }, []);

  const registrarAcao = useCallback(
    async (
      acao: string,
      opts?: {
        skipMaterialCheck?: boolean;
        skipConfirm?: boolean;
        extra?: Record<string, any>;
      },
    ): Promise<boolean> => {
      if (acaoSubmitting) return false;
      if (acaoId == null) return false;

      const statusCode = normalizeStatusCode(acao);
      const needsBackendConfirm =
        statusCode === "fase03" || statusCode === "fase04";
      const extraPayload =
        opts?.extra && typeof opts.extra === "object" ? opts.extra : {};

      // ✅ Corpo Pronto (fase12) é o checkpoint único de estoque.
      // Antes da baixa, valida os metadados de todos os itens marcados como utilizados.
      if (statusCode === "fase12") {
        const reg = registros.find(
          (x) => String(x.id) === String(acaoId),
        ) as any;

        if (resolveTipoFromRegistro(reg) === "terceiro") {
          setAcaoMsg({
            ok: false,
            text: "Corpo Pronto não faz parte do fluxo de atendimento terceiro.",
          });
          return false;
        }

        // URNA: valida apenas quando o atendimento possui urna selecionada.
        const urnaTxt = String(reg?.urna ?? "").trim();
        if (urnaTxt !== "") {
          const urnaPid = Number(reg?.urna_produto_id ?? 0) || 0;
          if (urnaPid <= 0) {
            setAcaoMsg({
              ok: false,
              text: "Urna: selecione uma urna válida na lista do estoque.",
            });
            return false;
          }
        }

        // ✅ ROUPA (se não for própria)
        const roupaTxt = String(reg?.roupa ?? "").trim();
        const roupaPropria = Number(reg?.roupa_propria ?? 0) ? 1 : 0;

        // Só valida como "roupa de estoque" quando:
        // - tem texto de roupa
        // - e NÃO é roupa própria (nem pelo texto, nem pela flag)
        const precisaValidarRoupaEstoque =
          roupaTxt !== "" && !isRoupaPropria(roupaTxt) && roupaPropria !== 1;

        if (precisaValidarRoupaEstoque) {
          const roupaPid = Number(reg?.roupa_produto_id ?? 0) || 0;
          const roupaDep = String(reg?.roupa_deposito_nome ?? "").trim();

          if (roupaPid <= 0) {
            setAcaoMsg({
              ok: false,
              text: 'Roupa: selecione uma roupa da lista (estoque) ou use "ROUPA PRÓPRIA".',
            });
            return false;
          }

          if (!roupaDep) {
            setAcaoMsg({
              ok: false,
              text: "Roupa: selecione o local (ARMARIO SANDRO, ARMARIO ILDO ou FUNERARIA).",
            });
            return false;
          }
        }

        // 3) INVOL (se invol = Sim)
        if (isSim(reg?.invol)) {
          const involPid = Number(reg?.invol_produto_id ?? 0) || 0;
          const involDep = String(reg?.invol_deposito_nome ?? "").trim();
          if (involPid <= 0) {
            setAcaoMsg({
              ok: false,
              text: "Invol: selecione um INVOL da lista (estoque).",
            });
            return false;
          }
          if (!involDep) {
            setAcaoMsg({
              ok: false,
              text: "Invol: selecione o local (ARMARIO SANDRO ou ARMARIO ILDO).",
            });
            return false;
          }
        }

        // ✅ VÉU (se veu = Sim)
        if (isSim(reg?.veu)) {
          const veuPid = Number(reg?.veu_produto_id ?? 0) || 0;
          const veuDep = String(reg?.veu_deposito_nome ?? "").trim();
          if (veuPid <= 0) {
            setAcaoMsg({
              ok: false,
              text: "Véu: selecione um VÉU da lista (estoque).",
            });
            return false;
          }
          if (!veuDep) {
            setAcaoMsg({
              ok: false,
              text: "Véu: selecione o local (ARMARIO SANDRO, ARMARIO ILDO ou FUNERARIA).",
            });
            return false;
          }
        }

        // ✅ CORDÃO (se cordao = Sim)
        if (isSim(reg?.cordao)) {
          const cordaoPid = Number(reg?.cordao_produto_id ?? 0) || 0;
          const cordaoDep = String(reg?.cordao_deposito_nome ?? "").trim();
          if (cordaoPid <= 0) {
            setAcaoMsg({
              ok: false,
              text: "Cordão: selecione um CORDÃO da lista (estoque).",
            });
            return false;
          }
          if (!cordaoDep) {
            setAcaoMsg({
              ok: false,
              text: "Cordão: selecione o local (ARMARIO SANDRO, ARMARIO ILDO ou FUNERARIA).",
            });
            return false;
          }
        }

        // Coroas artificiais são validadas no urna_saida.php a partir da Ordem de Serviço
        // vinculada ao atendimento. O navegador não decide produto, depósito ou quantidade.

        // INSUMOS TANATO (se arrumacao_json tiver itens)
        const ins = parseInsumosFromArrumacaoJson(reg?.arrumacao_json);
        if (ins && (!ins.deposito_nome || ins.itens.length === 0)) {
          setAcaoMsg({
            ok: false,
            text: "Insumos Tanatopraxia: selecione depósito e itens com quantidade (>=1).",
          });
          return false;
        }
      }

      // conferência antes do fase11
      if (statusCode === "fase11" && !opts?.skipMaterialCheck) {
        const reg = registros.find((x) => String(x.id) === String(acaoId));
        const mats = reg ? parseMateriaisFromRegistro(reg) : {};

        const itens: MatCheckItem[] = Object.entries(mats || {})
          .map(([k, it]: any) => ({
            key: String(k),
            nome: String(it?.nome || k),
            qtd: Number(it?.qtd ?? 0),
            checked: !!it?.checked,
          }))
          .filter((x) => x.checked && x.qtd > 0)
          .map((x: any) => ({ key: x.key, nome: x.nome, qtd: x.qtd }));

        setMatCheckItens(itens);
        setMatCheckRegistroId(
          reg?.id != null ? String(reg.id) : String(acaoId),
        );
        setMatCheckFalecidoNome(reg ? resolveFalecidoNome(reg) : "");

        setMatCheckReturnToAcao(true);
        setAcaoOpen(false);
        setMatCheckOpen(true);
        return false;
      }

      const registroSelecionado =
        registros.find(
          (x) =>
            String(x.id) ===
            String(acaoId),
        ) as any;

      const atendimentoLocal =
        isLocalAttendanceId(
          registroSelecionado?.id ??
          acaoId,
        ) ||
        registroSelecionado?.__localOnly ===
        true;

      /*
       * Atendimento ainda inexistente no servidor:
       * somente fase01 pode avançar.
       *
       * A fase fica no próprio registro local e não entra em IndexedDB/actions,
       * evitando que Background Sync tente enviar um ID local ao PHP.
       */
      if (atendimentoLocal) {
        if (
          statusCode !== "fase01"
        ) {
          setAcaoMsg({
            ok: false,
            text:
              "Este atendimento ainda está aguardando criação no servidor. Somente Indo Retirar o Óbito pode ser confirmado antes da sincronização.",
          });
          return false;
        }

        if (!opts?.skipConfirm) {
          const ok =
            window.confirm(
              "Deseja confirmar essa ação?",
            );

          if (!ok) {
            return false;
          }
        }

        try {
          setAcaoSubmitting(true);

          const session =
            await getCurrentOfflineSession({
              refreshIfOnline:
                false,
              allowCachedOnNetworkFailure:
                true,
            });

          if (!session?.userId) {
            throw new Error(
              "Usuário offline não identificado.",
            );
          }

          const now =
            Date.now();

          let occurredAt =
            new Date(now).toISOString();
          let deviceOccurredAt =
            occurredAt;
          let clockOffsetMs = 0;

          try {
            const stamp =
              await getOperationalTimestamp();

            occurredAt =
              stamp.occurredAt;
            deviceOccurredAt =
              stamp.deviceOccurredAt;
            clockOffsetMs =
              stamp.clockOffsetMs;
          } catch {
            // horário local acima
          }

          let deviceId =
            newOfflineId(
              "local-device",
            );

          try {
            deviceId =
              await getOfflineDeviceId();
          } catch {
            // fallback acima
          }

          const updated =
            markLocalAttendancePhase01(
              String(acaoId),
              {
                operationId:
                  String(
                    extraPayload.operationId ||
                    newOfflineId(
                      "status-op",
                    ),
                  ),
                occurredAt:
                  String(
                    extraPayload.occurredAt ||
                    occurredAt,
                  ),
                deviceOccurredAt,
                clockOffsetMs,
                deviceId,
                userId:
                  session.userId,
                userName:
                  session.userName,
              },
            );

          setRegistros(
            (current) =>
              current.map((row) =>
                String(row.id) ===
                  String(acaoId)
                  ? ({
                    ...(row as any),
                    ...(updated.record as any),
                    id:
                      updated.localId,
                    status:
                      "fase01",
                    agente:
                      session.userName,
                    __localOnly:
                      true,
                    __syncStatus:
                      "pending",
                    __pendingCount:
                      2,
                  } as Registro)
                  : row,
              ),
          );

          setAcaoMsg({
            text:
              "Indo Retirar o Óbito registrado neste aparelho. O atendimento e a fase serão sincronizados quando houver conexão.",
            ok: true,
          });

          setAcaoOpen(false);
          return true;
        } catch (e: any) {
          setAcaoMsg({
            ok: false,
            text:
              e?.message ||
              "Falha ao guardar Indo Retirar o Óbito no aparelho.",
          });
          return false;
        } finally {
          setAcaoSubmitting(false);
        }
      }

      if (!opts?.skipConfirm) {
        const ok = window.confirm("Deseja confirmar essa ação?");
        if (!ok) return false;
      }

      // Ações que assumem responsabilidade precisam ser confirmadas no servidor.
      if (!isOnlineNow() && (statusCode === "fase07" || statusCode === "fase09")) {
        setAcaoMsg({
          ok: false,
          text:
            statusCode === "fase07"
              ? "Transportando Óbito P/Velório precisa ser iniciado com internet para registrar o responsável."
              : "Transportando P/ Sepultamento precisa ser iniciado com internet para registrar o responsável.",
        });
        return false;
      }

      if (!isOnlineNow() && !isOperationalOfflineCommand(statusCode)) {
        setAcaoMsg({
          ok: false,
          text: "Esta etapa exige conexão com a internet nesta versão offline.",
        });
        return false;
      }

      if (!isOnlineNow() && isOperationalOfflineCommand(statusCode)) {
        const reg = registros.find((x) => String(x.id) === String(acaoId));
        if (!reg) {
          setAcaoMsg({ ok: false, text: "Atendimento não encontrado no armazenamento local." });
          return false;
        }

        try {
          setAcaoSubmitting(true);
          const action = await queueOperationalAction({
            registro: reg,
            command: statusCode,
            photoId: extraPayload.offlinePhotoId,
            photoAlreadyUploaded: !!extraPayload.photoAlreadyUploaded,
            materialCheckId: extraPayload.materialCheckId,
            occurredAt: extraPayload.occurredAt,
            operationId: extraPayload.operationId,
          });

          const session =
            await getCurrentOfflineSession({
              refreshIfOnline:
                false,
            });

          const cached =
            await loadCachedRegistros<Registro>(
              session?.userId,
            );

          const withLocal =
            session
              ? mergeLocalAttendancesWithRecords(
                cached,
                session.userId,
              )
              : cached;

          const merged =
            session
              ? await applyPendingActionsToRegistros(
                withLocal,
                session.userId,
              )
              : withLocal;

          if (merged.length) {
            setRegistros(merged);
          }

          setAcaoMsg({
            text: `${action.label} registrada no aparelho às ${new Date(action.occurredAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}. Aguardando sincronização.`,
            ok: true,
          });
          setAcaoOpen(false);
          return true;
        } catch (e: any) {
          setAcaoMsg({ ok: false, text: e?.message || "Falha ao guardar a ação offline." });
          return false;
        } finally {
          setAcaoSubmitting(false);
        }
      }

      // ✅ fase12 (Corpo Pronto): baixa todos os itens elegíveis em UMA ÚNICA
      // transação no backend. O urna_saida.php valida todo o estoque antes de
      // efetivar qualquer saída, permitindo informar todos os itens faltantes
      // de uma vez e evitando uma baixa parcial quando algum produto está sem saldo.
      if (statusCode === "fase12") {
        try {
          setAcaoSubmitting(true);
          setEstoqueInsuficiente(null);

          const registro_id = String(acaoId);

          await baixarItensCorpoPronto({
            registro_id,
            tipo: "",
          });
        } catch (e: any) {
          setAcaoSubmitting(false);

          if (isEstoqueInsuficienteError(e)) {
            const itens = Array.isArray((e as any)?.itens)
              ? ((e as any).itens as EstoqueInsuficienteItem[])
              : [];

            setAcaoMsg(null);
            setEstoqueInsuficiente({
              titulo: "Estoque insuficiente",
              mensagem:
                "Não é possível avançar para Corpo Pronto enquanto houver item sem quantidade suficiente no estoque.",
              itens,
            });
            return false;
          }

          setAcaoMsg({
            ok: false,
            text:
              e?.message ||
              "Falha ao processar as baixas do Corpo Pronto.",
          });
          return false;
        }
      }

      setAcaoSubmitting(true);
      let onlineOperationId = String(extraPayload.operationId || newOfflineId("status-op"));
      let onlineOccurredAt = String(extraPayload.occurredAt || "");
      let onlineDeviceId = "";
      let onlineSession: Awaited<ReturnType<typeof getCurrentOfflineSession>> = null;

      try {
        onlineSession = await getCurrentOfflineSession({
          refreshIfOnline: true,
          allowCachedOnNetworkFailure: true,
        });
        const ts = await getOperationalTimestamp();
        if (!onlineOccurredAt) onlineOccurredAt = ts.occurredAt;
        onlineDeviceId = await getOfflineDeviceId();

        const commonMeta = {
          id: acaoId,
          operation_id: onlineOperationId,
          ocorreu_em: onlineOccurredAt,
          device_id: onlineDeviceId,
          usuario_id: onlineSession?.userId || undefined,
          origem: "online",
          status_anterior: registros.find((x) => String(x.id) === String(acaoId))?.status || undefined,
        };

        const requestPayload = statusCode === "fase11"
          ? {
            acao: "material_recolhido",
            ...commonMeta,
          }
          : {
            acao: "atualizar_status",
            status: statusCode || acao,
            ...commonMeta,
            ...extraPayload,
            ...(needsBackendConfirm ? { confirmar: true } : {}),
          };

        const json = await enviarRegistroPHP(requestPayload);

        if (json?.sucesso) {
          setAcaoMsg({
            text: `Status alterado para "${capitalizeStatus(statusCode || acao)}"`,
            ok: true,
          });

          const faseAtual = statusCode || acao;
          const faseInicioTele = teleStartFaseRef.current ?? teleStartFase;
          const teleEstaAtiva = teleActiveRef.current || teleActive;

          const faseEncerraTelemetria =
            faseAtual === "fase02" ||
            faseAtual === "fase08" ||
            faseAtual === "fase10";

          const deveEncerrarPorFluxo =
            teleEstaAtiva &&
            faseInicioTele &&
            STOP_BY_START[faseInicioTele] &&
            STOP_BY_START[faseInicioTele] === faseAtual;

          if (deveEncerrarPorFluxo || faseEncerraTelemetria) {
            console.log("[TELEMETRIA] tentando encerrar", {
              faseAtual,
              faseInicioTele,
              teleEstaAtiva,
              deveEncerrarPorFluxo,
            });

            const salvo = await teleRef.current?.stopAndSave();

            console.log("[TELEMETRIA] retorno stopAndSave", salvo);

            limparTeleAtiva();
          }

          await fetchRegistros();
          setAcaoOpen(false);
          return true;
        }

        setAcaoMsg({
          text: String(json?.msg || json?.erro || "Erro ao atualizar status."),
          ok: false,
        });
        return false;
      } catch (e: any) {
        const msg = String(e?.message || "");

        const isNetwork =
          msg.includes("Failed to fetch") ||
          msg.includes("NetworkError") ||
          msg.includes("ERR_NETWORK") ||
          msg.includes("Load failed") ||
          (msg.includes("fetch") && msg.includes("failed"));

        if (isNetwork) {
          // fase07 e fase09 assumem responsabilidade e nunca são transformadas
          // em ação offline se a confirmação online não retornar.
          if (statusCode === "fase07" || statusCode === "fase09") {
            setAcaoMsg({
              text: "A conexão caiu antes da confirmação. Esta ação não foi assumida como concluída. Reconecte e tente novamente.",
              ok: false,
            });
            return false;
          }

          if (isOperationalOfflineCommand(statusCode)) {
            const reg = registros.find((x) => String(x.id) === String(acaoId));
            if (!reg) {
              setAcaoMsg({ text: "Atendimento não encontrado no cache local.", ok: false });
              return false;
            }

            try {
              const action = await queueOperationalAction({
                registro: reg,
                command: statusCode,
                operationId: onlineOperationId,
                occurredAt: onlineOccurredAt || undefined,
                photoId: extraPayload.offlinePhotoId,
                photoAlreadyUploaded:
                  statusCode === "fase08" && !!extraPayload.photoAlreadyUploaded,
                materialCheckId: extraPayload.materialCheckId,
                materialCheckAlreadyUploaded:
                  statusCode === "fase11" && !!extraPayload.materialCheckAlreadyUploaded,
              });
              setAcaoMsg({
                text: `${action.label} guardada no aparelho após falha de conexão. Aguardando sincronização.`,
                ok: true,
              });
              setAcaoOpen(false);
              return true;
            } catch (queueError: any) {
              setAcaoMsg({
                text: queueError?.message || "Não foi possível guardar a ação offline.",
                ok: false,
              });
              return false;
            }
          }

          setAcaoMsg({
            text: "A conexão caiu. Esta etapa exige internet e não foi colocada na fila offline.",
            ok: false,
          });
          return false;
        }

        setAcaoMsg({ text: msg || "Erro ao atualizar status.", ok: false });
        return false;
      } finally {
        setAcaoSubmitting(false);
        flushOfflineQueue();
      }
    },
    [
      acaoSubmitting,
      acaoId,
      registros,
      teleActive,
      teleStartFase,
      fetchRegistros,
      flushOfflineQueue,
      baixarItensCorpoPronto,
      limparTeleAtiva,
    ],
  );

  const confirmarAcaoSilenciosa = useCallback(
    async (fase: string) => {
      const id = teleRegistroIdRef.current ?? teleRegistroId ?? acaoId;
      if (id == null) return;

      const statusCode = normalizeStatusCode(fase);
      const needsBackendConfirm =
        statusCode === "fase03" || statusCode === "fase04";

      if (!isOnlineNow()) {
        // A confirmação silenciosa é usada principalmente no início dos transportes.
        // fase07/fase09 não podem ser assumidas offline porque definem o responsável.
        console.warn("[OFFLINE] Ação silenciosa não confirmada sem internet:", statusCode || fase);
        return;
      }

      try {
        const session = await getCurrentOfflineSession({
          refreshIfOnline: true,
          allowCachedOnNetworkFailure: false,
        });
        const ts = await getOperationalTimestamp();
        const deviceId = await getOfflineDeviceId();
        const atual = registros.find((x) => String(x.id) === String(id));

        await enviarRegistroPHP({
          acao: "atualizar_status",
          id,
          status: statusCode || fase,
          operation_id: newOfflineId("status-op"),
          ocorreu_em: ts.occurredAt,
          device_id: deviceId,
          usuario_id: session?.userId || undefined,
          origem: "online",
          status_anterior: atual?.status || undefined,
          ...(needsBackendConfirm ? { confirmar: true } : {}),
        });

        await fetchRegistros();
      } catch (e: any) {
        console.warn("[OFFLINE] Falha ao confirmar ação silenciosa; não enfileirada:", e?.message || e);
      } finally {
        flushOfflineQueue();
      }
    },
    [teleRegistroId, acaoId, registros, fetchRegistros, flushOfflineQueue],
  );

  /* -------------------- Info por ID -------------------- */
  const registroInfo = useMemo(
    () =>
      infoId != null
        ? (registros.find((x) => String(x.id) === String(infoId)) ?? null)
        : null,
    [registros, infoId],
  );

  // Os títulos do modal Info pertencem ao registro que está aberto.
  // Isso evita herdar o tipo do último cadastro/wizard acessado.
  const wizardStepTitlesInfo = useMemo<Array<string | null>>(() => {
    const tipoDoRegistro = resolveTipoFromRegistro(registroInfo);
    const titulos = [...getWizardConfig(tipoDoRegistro).wizardStepTitles] as Array<string | null>;

    if (tipoDoRegistro === "funerario" && registroInfo) {
      // Grupos 2 e 3 são Velório e Sepultamento. Campo vazio mantém compatibilidade com registros antigos.
      if (isNao((registroInfo as any).realiza_velorio)) titulos[2] = null;
      if (isNao((registroInfo as any).realiza_sepultamento)) titulos[3] = null;
    }

    return titulos;
  }, [registroInfo]);

  const registroCompartilhar = useMemo(
    () =>
      shareId != null
        ? (registros.find((x) => String(x.id) === String(shareId)) ?? null)
        : null,
    [registros, shareId],
  );

  const registroVisita = useMemo(
    () =>
      visitaId != null
        ? (registros.find((x) => String(x.id) === String(visitaId)) ?? null)
        : null,
    [registros, visitaId],
  );

  const infoIdxResolved = useMemo(() => {
    if (infoId == null) return null;
    const idx = registros.findIndex((x) => String(x.id) === String(infoId));
    return idx >= 0 ? idx : null;
  }, [registros, infoId]);

  const abrirInfoPorId = useCallback(
    (id: Registro["id"]) => {
      const normalizedId = id != null ? String(id) : null;

      const registro =
        normalizedId != null
          ? (registros.find((item) => String(item.id) === normalizedId) ?? null)
          : null;

      setTipoAtendimento(resolveTipoFromRegistro(registro));
      setInfoId(normalizedId);
      setInfoOpen(true);
    },
    [registros],
  );

  const abrirCompartilharPorId = useCallback((id: Registro["id"]) => {
    setShareId(id != null ? String(id) : null);
    setShareOpen(true);
  }, []);

  const abrirVisitaPorId = useCallback(
    (id: Registro["id"]) => {
      if (!visitaPermitida || id == null) return;

      setVisitaId(String(id));
      setVisitaOpen(true);
    },
    [visitaPermitida],
  );

  const abrirWizardFromInfo = useCallback(
    (
      tipo: "novo" | "editar",
      _idx: number | null = null,
      grupoStep: number | null = null,
    ) => {
      const idx = infoIdxResolved;
      if (idx != null) {
        setTipoAtendimento(resolveTipoFromRegistro(registros[idx]));
        abrirWizard(tipo, idx, grupoStep);
      }
    },
    [infoIdxResolved, abrirWizard, registros],
  );

  const editarPorId = useCallback(
    (id: Registro["id"]) => {
      const idx = registros.findIndex((r) => String(r.id) === String(id));
      if (idx < 0) return;
      setTipoAtendimento(resolveTipoFromRegistro(registros[idx]));
      abrirWizard("editar", idx, null);
    },
    [registros, abrirWizard],
  );

  /* Orçamento → "Virar atendimento" chega com ?orcamento=<id>: abre o Novo registro já preenchido (uma vez). */
  const orcamentoDaUrlRef = useRef(false);
  useEffect(() => {
    if (orcamentoDaUrlRef.current || typeof window === "undefined") return;
    orcamentoDaUrlRef.current = true;
    const url = new URL(window.location.href);
    const alvo = Number(url.searchParams.get("orcamento") || 0);
    if (!alvo) return;
    url.searchParams.delete("orcamento");
    window.history.replaceState(window.history.state, "", url.pathname + (url.search ? url.search : "") + url.hash);
    camposDoOrcamento(alvo)
      .then(({ orcamento, registro, os }) => {
        orcamentoOsRef.current = os as Partial<OsCampos>;
        orcamentoEmUsoRef.current = { id: orcamento.id, numero: orcamento.numero };
        iniciarNovoRegistro("funerario");
        setWizardData((prev: any) => ({ ...prev, ...registro }));
        setAssistenciaVal(String((registro as any).assistencia ?? ""));
        setTanatoVal(String((registro as any).tanato ?? ""));
        setWizardMsg({ text: `Preenchido com o orçamento ${orcamento.numero}. Confira os itens e complete o registro.`, ok: true });
      })
      .catch((e: any) => {
        window.alert(e?.message || "Não foi possível abrir o orçamento.");
      });
  }, [iniciarNovoRegistro]);

  // Fechou o registro sem salvar: o próximo Novo registro abre vazio.
  useEffect(() => {
    if (!wizardOpen) {
      orcamentoOsRef.current = null;
      orcamentoEmUsoRef.current = null;
    }
  }, [wizardOpen]);

  /* Quadro de atendimentos → "Editar" chega com ?editar=<id>: abre o Editar registro desse atendimento direto (uma vez). */
  const editarDaUrlRef = useRef(false);
  useEffect(() => {
    if (editarDaUrlRef.current || typeof window === "undefined" || !registros.length) return;
    const url = new URL(window.location.href);
    const alvo = url.searchParams.get("editar");
    if (!alvo) {
      editarDaUrlRef.current = true;
      return;
    }
    if (!registros.some((r) => String(r.id) === alvo)) return; // espera a lista trazer o atendimento
    editarDaUrlRef.current = true;
    url.searchParams.delete("editar");
    window.history.replaceState(window.history.state, "", url.pathname + (url.search ? url.search : "") + url.hash);
    editarPorId(alvo);
  }, [registros, editarPorId]);

  /* Editar registro (layout do mockup): documentos e Registrar ação ficam na coluna da direita. */
  const abrirDocumentoDoWizard = useCallback(
    (tipo: "recebimento" | "requisicao") => {
      if (wizardIdx == null) return;
      setSignIdx(wizardIdx);
      setSignTipo(tipo);
      setSignOpen(true);
    },
    [wizardIdx],
  );

  const registrarAcaoDoWizard = useCallback(() => {
    if (wizardIdx == null) return;
    const id = registros[wizardIdx]?.id;
    if (id != null) abrirPopupAcaoPorId(id);
  }, [wizardIdx, registros, abrirPopupAcaoPorId]);

  const abrirAssinaturaFromInfo = useCallback(
    (_idx: number, tipo: "recebimento" | "requisicao") => {
      const idx = infoIdxResolved;
      if (idx != null) {
        setSignIdx(idx);
        setSignTipo(tipo);
        setSignOpen(true);
      }
    },
    [infoIdxResolved],
  );

  /* -------------------- Foto obrigatória fase06/fase08 -------------------- */
  const handleFotoAcaoRequired = useCallback(
    (
      id: Registro["id"] | null | undefined,
      fase: string,
      tipo: FotoAcaoTipo,
    ) => {
      const normalizedId = id != null ? String(id) : null;

      setAcaoMsg(null);
      setAcaoId(normalizedId);
      setFotoAcaoId(normalizedId);
      setFotoAcaoFase(fase);
      setFotoAcaoTipo(tipo);

      // fecha o modal de ações e abre o modal da câmera
      setAcaoOpen(false);
      setFotoAcaoOpen(true);
    },
    [],
  );

  /* -------------------- Telemetria -------------------- */
  const handleVeiculoRequired = useCallback(
    (id: Registro["id"] | null | undefined, fase: string) => {
      const normalizedId = id != null ? String(id) : null;
      const tipo = mapFaseToTipo(fase);

      if (!tipo) {
        setAcaoId(normalizedId);
        registrarAcao(fase);
        return;
      }

      setAcaoId(normalizedId);
      definirTeleRegistroId(normalizedId);
      setTeleFase(fase);
      setTeleTipo(tipo);
      setTeleOpen(true);
      setAcaoOpen(false);
    },
    [registrarAcao, definirTeleRegistroId],
  );

  // Mantém o vínculo com o cadastro em dia: id, tipo (Particular/Associado/Prefeitura), plano e pacote do convênio escolhido.
  // Em registro antigo (só o nome do convênio gravado) acha o convênio pelo nome.
  const convenioTextoWizard = String((wizardData as any)?.convenio ?? "");
  useEffect(() => {
    if (!wizardOpen || !opcoesConv.convenios.length) return;
    const novo = resolverVinculo(opcoesConv.convenios, convenioTextoWizard, osCampos);
    if (novo) setOsCampos((c) => ({ ...c, ...novo }));
  }, [wizardOpen, opcoesConv.convenios, convenioTextoWizard, osCampos]);

  const wizardRegistroId = (wizardData as any)?.id ?? null;
  useEffect(() => {
    if (!wizardOpen) return;
    let vivo = true;
    // Novo registro vindo do orçamento: tanatopraxia e translado já preenchidos (o resto vem no wizardData).
    setOsCampos(!wizardEditing && orcamentoOsRef.current ? { ...OS_CAMPOS_VAZIO, ...orcamentoOsRef.current } : OS_CAMPOS_VAZIO);
    setOsColunasFaltando([]);
    localCerimoniaCarregadoRef.current = !wizardEditing;
    if (!wizardEditing || wizardRegistroId == null || String(wizardRegistroId).startsWith("local")) return;
    carregarCamposOS(wizardRegistroId)
      .then((r) => {
        if (!vivo) return;
        setOsCampos(r.campos);
        setOsColunasFaltando(r.faltando);
        localCerimoniaCarregadoRef.current = true;
        if (r.localCerimonia) {
          setWizardData((prev: any) => ({ ...prev, local_cerimonia: r.localCerimonia }));
        }
      })
      .catch(() => {
        /* sem OS disponível: a tela segue sem os campos preenchidos */
      });
    return () => {
      vivo = false;
    };
  }, [wizardOpen, wizardEditing, wizardRegistroId]);

  /* -------------------- Resumos -------------------- */
  const materiaisSelecionadosResumo = useMemo(() => {
    const matsPrefer = (wizardData as any)?.materiais;
    const mats: any =
      matsPrefer &&
        typeof matsPrefer === "object" &&
        Object.keys(matsPrefer).length > 0
        ? matsPrefer
        : materiais;

    const list = Object.values(mats || {})
      .filter((it: any) => it?.checked && Number(it?.qtd ?? 0) > 0)
      .map(
        (it: any) => `${String(it?.nome || "Item")} (${Number(it?.qtd ?? 1)})`,
      );

    return list.length ? list.join(" • ") : "Nenhum material selecionado";
  }, [wizardData, materiais]);

  const arrumacaoSelecionadaResumo = useMemo(() => {
    const mapa: { key: keyof ArrumacaoState; label: string }[] = [
      { key: "luvas", label: "Luvas" },
      { key: "palha", label: "Palha" },
      { key: "tamponamento", label: "Tamponamento" },
      { key: "maquiagem", label: "Maquiagem" },
      { key: "algodao", label: "Algodão" },
      { key: "cordao", label: "Cordão" },
      { key: "barba", label: "Barba" },
      { key: "ta32", label: "TA-32" },
      { key: "fluido_cavitario", label: "Fluído Cavitário" },
      { key: "formol", label: "Formol" },
      { key: "mascara", label: "Máscara" },
    ];
    const arr = (wizardData as any).arrumacao || arrumacao;
    return mapa
      .filter((o) => !!(arr as any)?.[o.key])
      .map((o) => o.label)
      .join(" • ");
  }, [wizardData, arrumacao]);

  const findRegistroById = useCallback(
    (id: Registro["id"] | null): Registro | undefined =>
      id == null
        ? undefined
        : registros.find((x) => String(x.id) === String(id)),
    [registros],
  );

  /* Seção da OS dividida em partes: procedimento (depois de Tanatopraxia), translado (depois de Invol) e resumo (no fim). */
  const renderOs = (parte: ParteOS) =>
    (wizardData as any)?.tipo_atendimento === "terceiro" ? null : (
      <SecaoOSAtendimento
        parte={parte}
        convenio={String((wizardData as any)?.convenio ?? "")}
        tanato={tanatoVal || String((wizardData as any)?.tanato ?? "")}
        coroaFlores={String((wizardData as any)?.coroa_flores ?? "")}
        valores={osCampos}
        onChange={(p) => setOsCampos((c) => ({ ...c, ...p }))}
        colunasFaltando={osColunasFaltando}
        atendimentoId={wizardEditing ? (wizardData as any)?.id ?? null : null}
        versao={osVersao}
        disabled={wizardSubmitting}
        atualizando={wizardSubmitting}
        // "Atualizar OS" (só na edição): mesmo salvamento do botão Salvar, mas a tela continua aberta e a OS é refeita na hora.
        onAtualizarOS={
          parte === "lateral" && wizardEditing
            ? () => concluirWizard({ manterWizardAberto: true, mensagemSucesso: "Registro salvo." })
            : undefined
        }
      />
    );

  /* -------------------- Render -------------------- */
  return (
    <div className="min-h-[100dvh] bg-[#F6F8FB] p-4 text-[#313C55] dark:bg-[#161C2A] dark:text-white sm:p-6 lg:px-10 lg:py-8">
      <header className="mb-5 flex flex-col gap-3 sm:mb-7 sm:flex-row sm:items-center sm:gap-4">
        <div className="hidden size-14 shrink-0 items-center justify-center rounded-[18px] bg-[#313C55] text-white sm:flex dark:bg-[#3D6A99] dark:text-white" aria-hidden="true">
          <svg viewBox="0 0 24 24" className="size-[26px]" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <rect x="8" y="2" width="8" height="4" rx="1" /><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /><path d="M12 11h4" /><path d="M12 16h4" />
          </svg>
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl font-extrabold leading-tight sm:text-[32px]">Atendimentos</h1>
          <p className="mt-1 text-sm text-[#5B6478] dark:text-[#AEB9CF] sm:text-[15px]">
            Registre cada etapa e mantenha as informações do atendimento em dia.
          </p>
        </div>
        {/* Cancelados (09/10/2026): consulta, só Gestão, no computador. */}
        <div className="hidden lg:flex">
          <BotaoAtendimentosCancelados />
        </div>
        <BotoesTopoAtendimentos onNovoRegistro={() => iniciarNovoRegistro("funerario")} />
      </header>

      <TabelaAtendimentos
        selecionadoId={acaoOpen ? acaoId : null}
        registros={registros}
        onAcao={(id) => abrirPopupAcaoPorId(id)}
        onEditar={editarPorId}
        onCompartilhar={(id) => abrirCompartilharPorId(id)}
        onVerOS={(id) => id != null && !isLocalAttendanceId(id) && setOsDoAtendimentoId(id)}
        visitaPermitida={visitaPermitida}
        visitaStatusById={visitaStatusById}
        onVisita={abrirVisitaPorId}
        ocultarAgente={visitaPermitida}
      />
      {osDoAtendimentoId != null && (
        <OSDoAtendimento sobreposto atendimentoId={osDoAtendimentoId} onFechar={() => setOsDoAtendimentoId(null)} />
      )}
      <AcaoModal
        open={acaoOpen}
        setOpen={setAcaoOpen}
        registros={registros}
        acaoId={acaoId}
        registrarAcao={registrarAcao}
        acaoMsg={acaoMsg}
        acaoSubmitting={acaoSubmitting}
        estoqueInsuficiente={estoqueInsuficiente}
        onCloseEstoqueInsuficiente={() => setEstoqueInsuficiente(null)}
        onVeiculoRequired={handleVeiculoRequired}
        onFotoAcaoRequired={handleFotoAcaoRequired}
        onAbrirCadastro={(id) => editarPorId(id)}
        onCorrecaoFeita={(msg) => {
          setAcaoOpen(false);
          void fetchRegistros();
        }}
      />

      <Wizard
        open={wizardOpen}
        onClose={() => setWizardOpen(false)}
        wizardTitle={wizardTitle}
        wizardStep={wizardStep}
        setWizardStep={setWizardStep}
        wizardRestrictGroup={wizardRestrictGroup}
        convenioSlot={
          <ConvenioVinculo
            valorTexto={convenioTextoWizard}
            valores={osCampos}
            onChange={(p) => setOsCampos((c) => ({ ...c, ...p }))}
            onTexto={(nome) => setWizardData((prev: any) => ({ ...prev, convenio: nome }))}
            obrigatorio={obrigatoriosForTipo.includes("convenio")}
            disabled={wizardSubmitting}
            nomesAntigos={(((stepsForTipo as unknown as any[]).find((s) => s?.id === "convenio")?.options ?? []) as string[]).filter(Boolean)}
          />
        }
        osCampos={osCampos}
        osSlot={renderOs("resumo")}
        osProcedimentoSlot={renderOs("procedimento")}
        osTransladoSlot={renderOs("translado")}
        osCoroaSlot={renderOs("coroa")}
        osLateralSlot={renderOs("lateral")}
        wizardData={wizardData}
        setWizardData={setWizardData}
        obrigatorios={obrigatoriosForTipo}
        steps={stepsForTipo as any}
        wizardStepIndexes={wizardStepIndexesForTipo}
        wizardStepTitles={wizardStepTitlesForTipo}
        assistenciaVal={assistenciaVal}
        setAssistenciaVal={setAssistenciaVal}
        tanatoVal={tanatoVal}
        setTanatoVal={setTanatoVal}
        materiaisSelecionadosResumo={materiaisSelecionadosResumo}
        arrumacaoSelecionadaResumo={arrumacaoSelecionadaResumo}
        setMateriaisOpen={setMateriaisOpen}
        setArrumacaoOpen={setArrumacaoOpen}
        salvarGrupoWizard={salvarGrupoWizard}
        concluirWizard={concluirWizard}
        wizardSubmitting={wizardSubmitting}
        registroEdicao={wizardEditing && wizardIdx != null ? (registros[wizardIdx] ?? null) : null}
        onAbrirDocumento={abrirDocumentoDoWizard}
        onRegistrarAcaoEdicao={registrarAcaoDoWizard}
        aviso={wizardMsg}
        onFecharAviso={() => setWizardMsg(null)}
        travaItens={travaItens}
      />

      <MateriaisModal
        open={materiaisOpen}
        setOpen={setMateriaisOpen}
        materiais={materiais}
        setMateriais={setMateriais}
        setWizardData={setWizardData}
      />
      <ArrumacaoModal
        open={arrumacaoOpen}
        setOpen={setArrumacaoOpen}
        arrumacao={arrumacao}
        setArrumacao={setArrumacao}
        setWizardData={setWizardData}
        wizardData={wizardData} // ✅ ESSENCIAL
        onSave={salvarArrumacaoPersistida}
      />


      <FotoAcaoModal
        open={fotoAcaoOpen}
        onClose={() => setFotoAcaoOpen(false)}
        registro={findRegistroById(fotoAcaoId)}
        registroId={fotoAcaoId}
        fase={fotoAcaoFase}
        tipo={fotoAcaoTipo}
        onSaved={async ({
          id,
          fase,
          offline,
          photoId,
          occurredAt,
        }) => {
          setAcaoId(id != null ? String(id) : null);
          setFotoAcaoOpen(false);

          // Offline: a foto já está no IndexedDB.
          // Online: a foto já foi enviada ao servidor.
          await registrarAcao(fase, {
            skipConfirm: true,
            extra: {
              offlinePhotoId: offline ? photoId : undefined,
              photoAlreadyUploaded: !offline,
              occurredAt,
            },
          });
          await fetchRegistros();
        }}
      />

      <MateriaisConferenciaModal
        open={matCheckOpen}
        itens={matCheckItens}
        onClose={() => {
          setMatCheckOpen(false);
          setMatCheckSaving(false);
          if (matCheckReturnToAcao) setAcaoOpen(true);
          setMatCheckReturnToAcao(false);
        }}
        onConfirm={async (result?: MateriaisConferenciaResult) => {
          if (!result) return;
          try {
            setMatCheckSaving(true);

            const registro_id = matCheckRegistroId ?? acaoId;
            if (!registro_id)
              throw new Error(
                "Não foi possível identificar o atendimento (registro_id).",
              );

            let nomeFinal = (matCheckFalecidoNome || "").trim();
            if (!nomeFinal) {
              const reg = registros.find(
                (x) => String(x.id) === String(registro_id),
              );
              nomeFinal = reg ? resolveFalecidoNome(reg) : "";
            }

            const itensNormalizados: Array<{
              key: string;
              nome: string;
              qtd: number;
              ok: 0 | 1;
              nao_conforme: 0 | 1;
            }> = (result.itens || []).map((it) => ({
              key: String(it.key),
              nome: String(it.nome),
              qtd: Number(it.qtd ?? 0),
              ok: it.ok ? 1 : 0,
              nao_conforme: it.naoConforme ? 1 : 0,
            }));

            if (!isOnlineNow()) {
              const localCheck = await saveOfflineMaterialCheck({
                recordId: registro_id,
                falecidoNome: nomeFinal,
                observacao: result.observacao,
                itens: itensNormalizados,
              });

              setMatCheckOpen(false);
              setMatCheckReturnToAcao(false);
              setMatCheckSaving(false);

              await registrarAcao("fase11", {
                skipMaterialCheck: true,
                skipConfirm: true,
                extra: {
                  materialCheckId: localCheck.checkId,
                  occurredAt: localCheck.occurredAt,
                },
              });
              return;
            }

            await salvarConferenciaNoPHP({
              registro_id,
              falecido_nome: nomeFinal,
              observacao: result.observacao,
              itens: itensNormalizados,
            });

            setMatCheckOpen(false);
            setMatCheckReturnToAcao(false);
            setMatCheckSaving(false);

            await registrarAcao("fase11", {
              skipMaterialCheck: true,
              skipConfirm: true,
              extra: { materialCheckAlreadyUploaded: true },
            });
          } catch (e: any) {
            setMatCheckSaving(false);
            alert(e?.message || "Erro ao salvar conferência de materiais.");
          }
        }}
      />

      <InfoModal
        open={infoOpen}
        setOpen={setInfoOpen}
        infoIdx={infoIdxResolved}
        abrirWizard={abrirWizardFromInfo}
        abrirAssinatura={(idx, tipo) => abrirAssinaturaFromInfo(idx, tipo)}
        registro={registroInfo}
        wizardStepTitles={wizardStepTitlesInfo}
      />

      <CompartilharModal
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        registro={registroCompartilhar}
      />

      {visitaPermitida && (
        <Visita
          open={visitaOpen}
          onClose={() => setVisitaOpen(false)}
          registro={registroVisita}
          onSaved={async () => {
            await recarregarStatusVisitas();
          }}
        />
      )}

      <SignatureModal
        open={signOpen}
        onClose={() => setSignOpen(false)}
        registro={signIdx != null ? registros[signIdx] : undefined}
        tipo={signTipo}
        onSaved={() => fetchRegistros()}
      />

      <TelemetriaModal
        ref={teleRef}
        open={teleOpen}
        onClose={() => {
          setTeleOpen(false);
          fetchRegistros();
        }}
        registro={findRegistroById(teleRegistroId)}
        fase={teleFase}
        tipo={teleTipo}
        onConfirmAcao={confirmarAcaoSilenciosa}
        onStarted={({ fase }) => {
          marcarTeleAtiva(fase);
        }}
        onSaved={() => {
          limparTeleAtiva();
          fetchRegistros();
        }}
      />

      {matCheckSaving ? (
        <div className="fixed inset-0 z-[60] grid place-items-center bg-[#313C55]/45 p-4">
          <div className="rounded-xl bg-[#F1F4F8] dark:bg-[#1C2334] p-4 shadow-xl border border-[#E3E8F0] dark:border-white/[0.12]">
            <div className="text-sm font-medium">Salvando conferência...</div>
            <div className="mt-1 text-xs text-[#5B6478] dark:text-[#AEB9CF]">
              Aguarde um instante.
            </div>
          </div>
        </div>
      ) : null}

      {wizardMsg ? (
        <div className="mt-4">
          <div
            className={`rounded-lg border p-3 text-sm border-[#E3E8F0] dark:border-white/[0.12] ${wizardMsg.ok
              ? "border-[#7BA11A]/50 dark:border-[#B3CE52]/40 bg-[#EEF5D6] dark:bg-[#B3CE52]/20 text-[#313C55] dark:text-white"
              : "border-[#B42318]/40 dark:border-[#FF9C92]/40 bg-[#FDECEA] dark:bg-[#FF9C92]/15 text-[#B42318] dark:text-[#FF9C92]"
              }`}
          >
            {wizardMsg.text}
          </div>
        </div>
      ) : null}
    </div>
  );
}
