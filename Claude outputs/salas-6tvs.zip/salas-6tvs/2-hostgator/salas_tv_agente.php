<?php
declare(strict_types=1);

/**
 * salas_tv_agente.php — usado SÓ pelo agente do PC do Memorial (agente_salas.pyw).
 *
 * Autenticação: cabeçalho X-Agente-Chave. O servidor guarda só o resumo SHA-256 da chave,
 * no arquivo privado /home2/pla48587/pai-tv-agente.php (gerado no PC pelo instalar_agente.bat).
 * Não usa sessão nem cookies, e não responde a navegadores (sem CORS).
 *
 * POST ?action=buscar     {versao, maquina, esperar?: 0..20, status?: [{tv, estado, volume, volume_max}]}
 *        → cada pedido vem com "tv" (uma TV) ou tv = null (sala inteira: painel + TV de dentro).
 *        → marca o agente como online, grava o estado das TVs e entrega os pedidos pendentes
 *          (já marcados como "executando", para não serem entregues duas vezes).
 * POST ?action=resultado  {id, final: bool, ok?: bool, msg}
 *        → final=false: só atualiza o andamento; final=true: conclui (concluido/falhou).
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

require __DIR__ . '/salas_tv_comum.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    tvResponder(['erro' => true, 'msg' => 'Use POST.'], 405);
}

// ---------------------------------------------------------------------------
// Chave do agente
// ---------------------------------------------------------------------------
function conferirChaveAgente(): void
{
    $chave = (string)($_SERVER['HTTP_X_AGENTE_CHAVE'] ?? '');
    if (!is_file(TV_ARQ_CHAVE_AGENTE) || !is_readable(TV_ARQ_CHAVE_AGENTE)) {
        error_log('salas_tv_agente.php: arquivo da chave do agente ausente.');
        tvResponder(['erro' => true, 'msg' => 'Chave do agente não configurada no servidor (pai-tv-agente.php).'], 500);
    }
    $cfg = require TV_ARQ_CHAVE_AGENTE;
    $esperado = is_array($cfg) ? strtolower((string)($cfg['token_sha256'] ?? '')) : '';
    if (strlen($esperado) !== 64 || strlen($chave) < 32 || !hash_equals($esperado, hash('sha256', $chave))) {
        usleep(300000); // atrapalha tentativa de adivinhar
        tvResponder(['erro' => true, 'msg' => 'Chave do agente inválida.'], 401);
    }
}

try {
    conferirChaveAgente();
    $pdo = tvConectar('salas_tv_agente.php');
    $action = (string)($_GET['action'] ?? '');
    $d = tvLerJson();
    $agora = tvAgora();

    if ($action === 'buscar') {
        $pdo->prepare(
            'INSERT INTO tv_agente (id, visto_em, versao, maquina) VALUES (1, :v, :ver, :m)
             ON DUPLICATE KEY UPDATE visto_em = VALUES(visto_em), versao = VALUES(versao), maquina = VALUES(maquina)'
        )->execute([':v' => $agora, ':ver' => tvTexto($d['versao'] ?? '', 20), ':m' => tvTexto($d['maquina'] ?? '', 80)]);

        if (isset($d['status']) && is_array($d['status'])) {
            $tvsValidas = [];
            foreach (TV_SALAS as $par) { $tvsValidas[$par['painel']] = true; $tvsValidas[$par['dentro']] = true; }
            $up = $pdo->prepare(
                'INSERT INTO tv_status (tv, estado, volume, volume_max, atualizado_em) VALUES (:tv, :e, :v, :m, :a)
                 ON DUPLICATE KEY UPDATE estado = VALUES(estado), volume = VALUES(volume),
                                         volume_max = VALUES(volume_max), atualizado_em = VALUES(atualizado_em)'
            );
            foreach ($d['status'] as $s) {
                if (!is_array($s)) continue;
                $tv = strtoupper(tvTexto($s['tv'] ?? '', 30));
                $estado = (string)($s['estado'] ?? '');
                if (!isset($tvsValidas[$tv]) || !in_array($estado, TV_ESTADOS, true)) continue;
                $up->execute([
                    ':tv' => $tv, ':e' => $estado,
                    ':v' => isset($s['volume']) && is_numeric($s['volume']) ? (int)$s['volume'] : null,
                    ':m' => isset($s['volume_max']) && is_numeric($s['volume_max']) ? (int)$s['volume_max'] : null,
                    ':a' => $agora,
                ]);
            }
        }

        tvVencerPedidos($pdo);

        // Conexão em espera (13/11/2026): se não há pedido, segura a resposta até "esperar" segundos (máx. 20),
        // conferindo a cada 0,4 s. Assim o pedido do app chega ao Memorial na hora, sem o agente perguntar toda hora.
        $esperar = max(0, min(20, (int)($d['esperar'] ?? 0)));
        if ($esperar > 0) {
            @set_time_limit($esperar + 20);
            $fim = microtime(true) + $esperar;
            $tem = $pdo->prepare("SELECT 1 FROM tv_comandos WHERE situacao = 'pendente' LIMIT 1");
            while (true) {
                $tem->execute();
                $achou = (bool)$tem->fetchColumn();
                $tem->closeCursor();
                if ($achou || microtime(true) >= $fim || connection_aborted()) break;
                usleep(400000);
            }
        }

        // Entrega os pendentes (no máximo 1 por sala) e marca como executando, numa transação.
        $pdo->beginTransaction();
        $colTv = tvTemColunaTv($pdo) ? 'tv' : 'NULL AS tv';
        $rows = $pdo->query(
            "SELECT id, sala, {$colTv}, acao, valor FROM tv_comandos
              WHERE situacao = 'pendente' ORDER BY id ASC LIMIT 12 FOR UPDATE"
        )->fetchAll();
        // Pedidos de TVs diferentes vão juntos (o agente executa em paralelo). O app não deixa criar
        // pedidos que se cruzam (sala inteira x uma TV da mesma sala), mas por garantia: um por alvo.
        $entregar = [];
        $alvos = [];
        foreach ($rows as $r) {
            $tvAlvo = $r['tv'] !== null && $r['tv'] !== '' ? strtoupper((string)$r['tv']) : '';
            $chaves = $tvAlvo !== '' ? [$tvAlvo] : array_values(TV_SALAS[$r['sala']] ?? []);
            $ocupado = false;
            foreach ($chaves as $k) { if (isset($alvos[$k])) { $ocupado = true; break; } }
            if ($ocupado) continue; // vai na próxima busca
            foreach ($chaves as $k) { $alvos[$k] = true; }
            $entregar[] = [
                'id' => (int)$r['id'], 'sala' => $r['sala'], 'tv' => $tvAlvo !== '' ? $tvAlvo : null,
                'acao' => $r['acao'], 'valor' => $r['valor'] === null ? null : (int)$r['valor'],
                'tvs' => TV_SALAS[$r['sala']] ?? null,
            ];
        }
        if ($entregar) {
            $ids = implode(',', array_map(static fn($c) => (int)$c['id'], $entregar));
            $pdo->prepare("UPDATE tv_comandos SET situacao = 'executando', pego_em = :a, resultado = 'Recebido pelo Memorial…'
                            WHERE id IN ({$ids}) AND situacao = 'pendente'")->execute([':a' => $agora]);
        }
        $pdo->commit();

        tvResponder(['erro' => false, 'comandos' => array_values(array_filter($entregar, static fn($c) => $c['tvs'] !== null)), 'agora' => $agora]);
    }

    if ($action === 'resultado') {
        $id = (int)($d['id'] ?? 0);
        $msg = tvTexto($d['msg'] ?? '', 480);
        if ($id <= 0) tvResponder(['erro' => true, 'msg' => 'Pedido inválido.'], 400);
        if (!empty($d['final'])) {
            $situacao = !empty($d['ok']) ? 'concluido' : 'falhou';
            $pdo->prepare("UPDATE tv_comandos SET situacao = :s, resultado = :r, concluido_em = :a
                            WHERE id = :id AND situacao = 'executando'")
                ->execute([':s' => $situacao, ':r' => $msg, ':a' => $agora, ':id' => $id]);
        } else {
            $pdo->prepare("UPDATE tv_comandos SET resultado = :r WHERE id = :id AND situacao = 'executando'")
                ->execute([':r' => $msg, ':id' => $id]);
        }
        $pdo->prepare('UPDATE tv_agente SET visto_em = :v WHERE id = 1')->execute([':v' => $agora]);
        tvResponder(['erro' => false]);
    }

    tvResponder(['erro' => true, 'msg' => 'Ação inválida.'], 400);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('salas_tv_agente.php: ' . $e->getMessage());
    tvResponder(['erro' => true, 'msg' => 'Erro no servidor (agente).'], 500);
}
