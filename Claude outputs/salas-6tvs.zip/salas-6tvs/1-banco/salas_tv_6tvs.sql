-- =====================================================================
-- SALAS DO MEMORIAL: pedidos por TV (6 TVs separadas) - 16/11/2026
-- Rode no phpMyAdmin, banco pla48587_mensagens. Só ACRESCENTA a coluna "tv"
-- na fila de pedidos (vazia = pedido da sala inteira, como antes).
-- Pode rodar de novo: se a coluna já existir, não faz nada.
-- =====================================================================

SET @existe := (SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = 'pla48587_mensagens' AND TABLE_NAME = 'tv_comandos' AND COLUMN_NAME = 'tv');
SET @sql := IF(@existe = 0,
  'ALTER TABLE pla48587_mensagens.tv_comandos ADD COLUMN tv VARCHAR(30) NULL AFTER sala, ADD KEY idx_tv_comandos_tv (tv, id)',
  'SELECT ''A coluna tv já existe'' AS aviso');
PREPARE st FROM @sql;
EXECUTE st;
DEALLOCATE PREPARE st;

-- Conferência: deve aparecer a linha "tv".
SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE
  FROM information_schema.COLUMNS
 WHERE TABLE_SCHEMA = 'pla48587_mensagens' AND TABLE_NAME = 'tv_comandos'
 ORDER BY ORDINAL_POSITION;
