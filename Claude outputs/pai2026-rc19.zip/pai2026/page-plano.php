<?php
/**
 * Página de cada plano: /planos-funerarios/light/, /flex/, /plus/, /max/.
 * Os dados ficam em inc/rotas.php (pai_planos_dados), conforme os Termos de Adesão.
 */
$p     = pai_plano_atual();
$todos = pai_planos_dados();
$pr    = pai_precos();
get_header();

$cores = array( 'verde' => '#B3CE52', 'sol' => '#F2CB3F', 'azul' => '#00AEEC', 'branco' => '#FFFFFF' );
$cor   = $cores[ $p['cor'] ];
$wa    = pai_wa( 'Olá! Vi o ' . $p['titulo'] . ' no site e quero saber mais.' );
?>

<section class="topo-pagina topo-plano" style="--cor-plano:<?php echo esc_attr( $cor ); ?>">
	<?php echo pai_marca_dagua( 'wm--topo' ); ?>
	<div class="wrap topo-plano__in">
		<div class="pilha pilha--p">
			<nav class="trilha" aria-label="Você está em"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Início</a> <span aria-hidden="true">›</span> <a href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>">Planos funerários</a> <span aria-hidden="true">›</span> <span><?php echo esc_html( $p['titulo'] ); ?></span></nav>
			<p class="eyebrow topo-plano__eb"><?php echo esc_html( $p['chamada'] ); ?></p>
			<h1 class="display display--m"><?php echo esc_html( $p['titulo'] ); ?></h1>
			<p class="lead"><?php echo esc_html( $p['resumo'] ); ?></p>
			<div class="botoes">
				<a class="btn btn-sol btn-g" href="<?php echo esc_url( add_query_arg( 'plano', $p['slug'], home_url( '/adesao/' ) ) ); ?>">Contratar o <?php echo esc_html( $p['nome'] ); ?></a>
				<a class="btn btn-claro btn-g" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 22 ); ?>Tirar dúvidas</a>
			</div>
		</div>
		<div class="card cartao-plano">
			<span class="cartao-plano__rot">PLANO</span>
			<span class="cartao-plano__nome"><?php echo esc_html( $p['nome'] ); ?></span>
			<span class="cartao-plano__valor"><?php if ( $p['de'] ) : ?><small class="cartao-plano__de"><?php echo esc_html( $p['de'] ); ?></small><?php endif; ?><?php echo esc_html( $p['preco'] ); ?><small>/mês</small></span>
			<span class="cartao-plano__ades">Adesão de R$ <?php echo esc_html( pai_reais( $p['adesao'] ) ); ?></span>
			<a class="link-forte" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) . '?plano=' . $p['slug'] . '#simulador' ); ?>">Simular o valor da minha família ›</a>
		</div>
	</div>
</section>

<section class="secao secao--sem-topo">
	<div class="wrap duas-colunas duas-colunas--plano">
		<div class="pilha pilha--p">
			<p class="eyebrow">Quem entra no plano</p>
			<ul class="lista-check lista-check--g">
				<?php foreach ( $p['quem'] as $q ) : ?><li><?php echo esc_html( $q ); ?></li><?php endforeach; ?>
			</ul>
			<p class="nota"><?php echo esc_html( $p['extras'] ); ?></p>
		</div>
		<div class="pilha pilha--p">
			<p class="eyebrow">O que o plano cobre</p>
			<dl class="cobertura">
				<div><dt>Assistência funerária</dt><dd>Completa, com plantão 24 horas, todos os dias</dd></div>
				<?php foreach ( $p['cobertura'] as $c ) : ?>
					<div<?php echo ( false !== stripos( $c[1], 'não disponível' ) ) ? ' class="cobertura--nao"' : ''; ?>><dt><?php echo esc_html( $c[0] ); ?></dt><dd><?php echo esc_html( $c[1] ); ?></dd></div>
				<?php endforeach; ?>
				<div><dt>Em todos os planos</dt><dd>Ornamentação do corpo, kit lanche, carro funerário, sala no Memorial Senhor do Bonfim, velório online e paramentação para velório em casa</dd></div>
			</dl>
			<p class="nota">Tanatopraxia avançada, embalsamamento e reconstituição facial não fazem parte de nenhum plano e são cobrados à parte, pela tabela.</p>
		</div>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap grade-3">
		<div class="card pilha pilha--pp">
			<span class="ico ico--sol"><?php echo pai_icone( 'relogio', 24 ); ?></span>
			<h2 class="card__tit card__tit--p">Carência</h2>
			<p class="card__txt">90 dias após a adesão para morte natural e 24 horas para acidente ou causa externa. Se precisar usar durante a carência, há desconto de 10% a 20% no atendimento.</p>
		</div>
		<div class="card pilha pilha--pp">
			<span class="ico ico--verde"><?php echo pai_icone( 'escudo', 24 ); ?></span>
			<h2 class="card__tit card__tit--p">Sucessor do contrato</h2>
			<p class="card__txt">Você indica um dependente maior de idade para assumir o plano se faltar. Assim a família continua protegida, sem nova carência.</p>
		</div>
		<div class="card pilha pilha--pp">
			<span class="ico ico--azul"><?php echo pai_icone( 'estrela', 24 ); ?></span>
			<h2 class="card__tit card__tit--p">Para quem é indicado</h2>
			<ul class="lista-check"><?php foreach ( $p['para'] as $q ) : ?><li><?php echo esc_html( $q ); ?></li><?php endforeach; ?></ul>
		</div>
	</div>
</section>

<section class="secao">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Compare</p>
			<h2 class="h2">Os outros planos do PAI</h2>
		</div>
		<div class="grade-outros-planos">
			<?php foreach ( $todos as $slug => $o ) : ?>
				<a class="card card--link outro-plano<?php echo $slug === $p['slug'] ? ' outro-plano--atual' : ''; ?>" href="<?php echo esc_url( pai_url( 'planos-funerarios/' . $slug ) ); ?>" <?php echo $slug === $p['slug'] ? 'aria-current="page"' : ''; ?> style="--cor-plano:<?php echo esc_attr( $cores[ $o['cor'] ] ); ?>">
					<span class="outro-plano__nome"><?php echo esc_html( $o['nome'] ); ?></span>
					<span class="outro-plano__valor"><?php echo $o['de'] ? esc_html( $o['de'] ) . ' ' : ''; ?><?php echo esc_html( $o['preco'] ); ?>/mês</span>
					<span class="card__txt"><?php echo esc_html( $o['chamada'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
		<p class="nota">Valores das mensalidades em vigor. Condições completas nos Termos de Adesão de cada plano.</p>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow eyebrow--verde">Pronto para contratar?</p>
			<h2 class="h2">Proteja sua família hoje</h2>
		</div>
		<div class="pilha pilha--p">
			<p class="lead">Faça o cadastro pelo site ou fale com a nossa equipe: ligação ou WhatsApp no <?php echo esc_html( pai_opt( 'whatsapp' ) ); ?>, ou na sede, <?php echo esc_html( pai_opt( 'end_sede' ) ); ?>.</p>
			<div class="botoes">
				<a class="btn btn-sol" href="<?php echo esc_url( add_query_arg( 'plano', $p['slug'], home_url( '/adesao/' ) ) ); ?>">Contratar o <?php echo esc_html( $p['nome'] ); ?></a>
				<a class="btn btn-verde" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 20 ); ?>WhatsApp</a>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
