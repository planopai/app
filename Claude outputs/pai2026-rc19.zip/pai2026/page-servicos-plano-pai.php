<?php
/**
 * Página /servicos-plano-pai/.
 */
get_header();
pai_topo( 'Serviços', 'Assistência funerária completa 24 horas', 'Serviços Plano PAI', 'Tudo o que a família precisa num só lugar, com estrutura própria em Barreiras-BA.' );

$servicos = array(
	array( 'carro', 'azul', 'Translado', 'Transporte seguro e respeitoso, com frota própria equipada. Dentro ou fora do estado, nossa equipe coordena toda a logística. A distância coberta depende do plano.', array( 'planos-funerarios', 'Ver o que cada plano cobre' ) ),
	array( 'video', 'verde', 'Velório online', 'Transmissão ao vivo para quem não pode estar presente, com acesso por senha. Discreto, respeitoso e seguro.', array( 'velorio-online', 'Acessar o velório online' ) ),
	array( 'flor', 'sol', 'Ornamentação do corpo', 'Preparamos o corpo com respeito e cuidado, com técnicas para vestir e adornar, garantindo uma apresentação digna e serena.', array() ),
	array( 'gota', 'azul', 'Tanatopraxia', 'Procedimento técnico que preserva e prepara o corpo, permitindo uma apresentação serena durante o velório. Feito por profissionais qualificados.', array() ),
	array( 'coroa', 'verde', 'Coroas de flores', 'Naturais ou artificiais, com faixa e mensagem da família. Peça pelo site e entregamos direto na sala do velório.', array( 'coroas-de-flores', 'Pedir uma coroa' ) ),
	array( 'urna', 'sol', 'Urnas funerárias', 'Modelos para todos os estilos e orçamentos, das linhas tradicionais às urnas artesanais.', array( 'urnas', 'Ver o catálogo de urnas' ) ),
	array( 'predio', 'azul', 'Memorial Senhor do Bonfim', 'Salas de velório climatizadas, aberto 24 horas, com estacionamento e estrutura para receber a família com conforto.', array( 'galeria', 'Ver fotos do Memorial' ) ),
	array( 'fone', 'verde', 'Plantão 24 horas', 'Uma pessoa da equipe atende a qualquer hora, vai até a família e cuida da parte burocrática, para associados e não associados.', array( 'atendimento-24-horas', 'O que fazer quando alguém falece' ) ),
	array( 'tele', 'sol', 'Telemedicina', 'Atendimento médico pelo celular ou computador, 24 horas. Incluída no plano MAX e disponível à parte nos planos FLEX e PLUS.', array( 'telemedicina', 'Conhecer a Telemedicina' ) ),
);
?>

<section class="secao secao--sem-topo">
	<div class="wrap">
		<ul class="grade-servicos">
			<?php foreach ( $servicos as $s ) : ?>
				<li class="card servico-c">
					<span class="servico-c__ico servico-c__ico--<?php echo esc_attr( $s[1] ); ?>"><?php echo pai_icone( $s[0], 30 ); ?></span>
					<h2 class="card__tit card__tit--m"><?php echo esc_html( $s[2] ); ?></h2>
					<p class="card__txt"><?php echo esc_html( $s[3] ); ?></p>
					<?php if ( $s[4] ) : ?>
						<a class="link-forte servico-c__link" href="<?php echo esc_url( pai_url( $s[4][0] ) ); ?>"><?php echo esc_html( $s[4][1] ); ?> ›</a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow eyebrow--urg">Precisa agora?</p>
			<h2 class="h2">Plantão 24 horas</h2>
		</div>
		<div class="pilha pilha--p">
			<p class="lead">Ligue a qualquer hora. Atendemos associados e não associados, e explicamos cada passo.</p>
			<div class="botoes">
				<a class="btn btn-sol btn-g" href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>"><?php echo pai_icone( 'fone', 22 ); ?><?php echo esc_html( pai_opt( 'tel_plantao' ) ); ?></a>
				<a class="btn btn-line btn-g" href="<?php echo esc_url( pai_url( 'atendimento-24-horas' ) ); ?>">O que fazer agora</a>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
