<?php
/**
 * Página /sobre-nos/.
 */
get_header();
pai_topo( 'Sobre nós', 'Funerária Senhor do Bonfim e Plano PAI', 'Há mais de 40 anos cuidando das famílias de Barreiras', 'Dignidade, respeito e sensibilidade em cada atendimento, nos momentos mais delicados.' );
?>

<section class="secao secao--sem-topo">
	<div class="wrap sobre">
		<figure class="sobre__foto">
			<img src="<?php echo esc_url( 'https://i0.wp.com/planoassistencialintegrado.com.br/wp-content/uploads/2024/07/Plano-Pai-Frente.jpg?w=1440&ssl=1' ); ?>" alt="Fachada do Plano PAI em Barreiras-BA" width="1440" height="1124" loading="lazy" decoding="async">
		</figure>
		<div class="texto">
			<p>A Funerária Senhor do Bonfim e o Plano PAI (Plano Assistencial Integrado) somam mais de 40 anos de serviços prestados com excelência e cuidado às famílias em seus momentos mais sensíveis. Nossa trajetória é marcada pelo compromisso com a dignidade, o respeito e a sensibilidade, valores que guiam cada detalhe do nosso trabalho.</p>
			<p>Fundada com a missão de oferecer apoio e conforto, a Funerária Senhor do Bonfim se dedica a um atendimento humanizado e personalizado. Cuidamos de cada detalhe para criar um ambiente acolhedor, em que as famílias possam se despedir de quem amam de forma serena e digna.</p>
			<p>Nossos serviços vão das urnas funerárias, ornamentação e tanatopraxia às coroas de flores e ao translado. Com o velório online, quem está longe também pode participar das homenagens, independentemente da distância.</p>
			<p>O Plano PAI oferece planos assistenciais completos, com toda a organização necessária para as homenagens finais. Nossa equipe é formada por profissionais qualificados, prontos para atender bem em todas as etapas.</p>
			<p>Ao longo dessas quatro décadas, construímos uma reputação baseada na confiança e no cuidado com as famílias que atendemos. E seguimos inovando, sempre em busca de novas formas de oferecer o melhor serviço, honrando a memória de cada pessoa com a dignidade e o respeito que ela merece.</p>
		</div>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Nossos valores</p>
			<h2 class="h2">O que guia o nosso trabalho</h2>
		</div>
		<div class="grade-3">
			<div class="card pilha pilha--pp"><h3 class="card__tit card__tit--p">Dignidade</h3><p class="card__txt">Cada despedida é preparada com o cuidado que a pessoa e a família merecem.</p></div>
			<div class="card pilha pilha--pp"><h3 class="card__tit card__tit--p">Acolhimento</h3><p class="card__txt">Atendimento humano, 24 horas, com quem explica cada passo com calma.</p></div>
			<div class="card pilha pilha--pp"><h3 class="card__tit card__tit--p">Estrutura própria</h3><p class="card__txt">Memorial Senhor do Bonfim, frota própria e equipe treinada em Barreiras.</p></div>
		</div>
		<div class="botoes">
			<a class="btn btn-sol" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>">Conhecer os planos</a>
			<a class="btn btn-line" href="<?php echo esc_url( pai_url( 'galeria' ) ); ?>">Ver fotos da estrutura</a>
		</div>
	</div>
</section>

<?php
get_template_part( 'parts/enderecos' );
get_footer();
