<?php
/**
 * Página /trabalhe-conosco/ (formulário Forminator 2085).
 */
get_header();
get_template_part( 'parts/formulario', null, array(
	'trilha'  => 'Trabalhe conosco',
	'eyebrow' => 'Faça parte da equipe',
	'titulo'  => 'Trabalhe conosco',
	'lead'    => 'Preencha o formulário e envie seu currículo. Quando surgir uma vaga no seu perfil, entramos em contato.',
	'form'    => 2085,
	'lado'    => '<h2 class="subtit">Por que trabalhar no Plano PAI</h2><ul class="lista-check"><li>Mais de 40 anos de história em Barreiras</li><li>Trabalho com propósito: cuidar de famílias em momentos importantes</li><li>Equipe treinada e estrutura própria</li></ul>',
) );
get_footer();
