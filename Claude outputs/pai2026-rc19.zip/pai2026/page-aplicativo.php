<?php
/**
 * Página /aplicativo/.
 */
get_header();
pai_topo(
	'Aplicativo',
	'Novidade',
	'Chegou o app do PAI!',
	'Ficou ainda mais fácil cuidar do seu plano: tudo na palma da mão, com praticidade, rapidez e segurança.',
	'<div class="botoes"><a class="btn btn-sol btn-g" href="' . esc_url( pai_link( 'url_play' ) ) . '" target="_blank" rel="noopener">' . pai_icone( 'celular', 22 ) . 'Baixar na Play Store</a><a class="btn btn-claro btn-g" href="' . esc_url( pai_link( 'url_associado' ) ) . '">Acessar pelo navegador</a></div>'
);

$recursos = array(
	array( 'pessoa', 'Consultar as informações do seu plano' ),
	array( 'fone', 'Solicitar serviços funerários' ),
	array( 'check', 'Pagar a mensalidade' ),
	array( 'desconto', 'Aproveitar descontos exclusivos' ),
	array( 'sol', 'Conferir os resultados dos sorteios' ),
	array( 'celular', 'Receber notícias em tempo real' ),
);
?>

<section class="secao secao--sem-topo">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Para associados</p>
			<h2 class="h2">O que você faz pelo app</h2>
		</div>
		<ul class="grade-3 lista-recursos">
			<?php foreach ( $recursos as $i => $r ) : ?>
				<li class="card card--ico">
					<span class="ico ico--<?php echo esc_attr( array( 'azul', 'verde', 'sol' )[ $i % 3 ] ); ?>"><?php echo pai_icone( $r[0], 24 ); ?></span>
					<div><p class="card__tit card__tit--p"><?php echo esc_html( $r[1] ); ?></p></div>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow eyebrow--verde">Como acessar</p>
			<h2 class="h2">É simples</h2>
		</div>
		<ol class="grade-passos grade-passos--3">
			<li class="passo"><span class="passo__num" aria-hidden="true">1</span><h3 class="passo__tit">Instale</h3><p class="passo__txt">Baixe o app do PAI na Play Store.</p></li>
			<li class="passo"><span class="passo__num" aria-hidden="true">2</span><h3 class="passo__tit">Informe o CPF</h3><p class="passo__txt">Abra o app e digite o CPF do titular.</p></li>
			<li class="passo"><span class="passo__num" aria-hidden="true">3</span><h3 class="passo__tit">Crie sua senha</h3><p class="passo__txt">Cadastre uma nova senha e pronto.</p></li>
		</ol>
	</div>
</section>

<?php
get_footer();
