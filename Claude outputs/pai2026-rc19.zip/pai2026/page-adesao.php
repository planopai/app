<?php
/**
 * Página /adesao/: adesão online ao Plano PAI (cadastro completo + pagamento da adesão no WooCommerce).
 * O cadastro é gravado pelo planos-novos.php; o pagamento, pelo checkout (Cielo). Ver inc/adesao.php.
 */
get_header();

$tabela = pai_planos_tabela();
$planos = array(
	'LIGHT' => 'O essencial, com todo o cuidado',
	'FLEX'  => 'Para a família grande',
	'PLUS'  => 'Mais conforto e cobertura',
	'MAX'   => 'O mais completo',
);
$cfg = null;
if ( $tabela ) {
	foreach ( array_keys( $planos ) as $k ) {
		$prod = pai_adesao_produto( $k );
		if ( $prod && '' !== $prod->get_price() ) {
			$tabela['planos'][ $k ]['adesao'] = (float) $prod->get_price(); // o valor cobrado é o do produto
		}
		$tabela['planos'][ $k ]['disponivel'] = (bool) $prod;
		$tabela['planos'][ $k ]['termo'] = (string) pai_opt( 'termo_' . strtolower( $k ) );
	}
	$cfg = array(
		'api'    => pai_planos_api(),
		'pagar'  => home_url( '/adesao/pagar/' ),
		'whats'  => pai_digitos( pai_opt( 'whatsapp' ) ),
		'tabela' => $tabela,
	);
}
$aviso = sanitize_key( $_GET['aviso'] ?? '' );
pai_topo( 'Adesão ao Plano PAI', 'Contratar pelo site', 'Adesão ao Plano PAI', 'Escolha o plano, cadastre a sua família e veja a mensalidade na hora. No fim, você paga só a adesão, por Pix ou cartão.' );
?>

<section class="secao secao--sem-topo">
	<div class="wrap">
		<?php if ( 'ja_pago' === $aviso ) : ?>
			<p class="adesao-aviso adesao-aviso--ok">Esta adesão já está paga. Nossa equipe vai entrar em contato pelo WhatsApp com o número do contrato.</p>
		<?php elseif ( 'indisponivel' === $aviso ) : ?>
			<p class="adesao-aviso">Não conseguimos abrir o pagamento agora. Tente de novo em alguns minutos ou fale com a gente pelo <a href="<?php echo esc_url( pai_wa( 'Olá! Fiz o cadastro de adesão no site, mas não consegui pagar.' ) ); ?>" target="_blank" rel="noopener">WhatsApp</a>.</p>
		<?php endif; ?>

		<?php if ( ! $cfg ) : ?>
			<div class="card adesao-off">
				<h2 class="h2">A adesão pelo site está indisponível agora</h2>
				<p class="lead">Fale com a nossa equipe pelo WhatsApp e fazemos a sua adesão na hora.</p>
				<a class="btn btn-verde btn-g" href="<?php echo esc_url( pai_wa( 'Olá! Quero contratar um plano.' ) ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 20 ); ?>Contratar pelo WhatsApp</a>
			</div>
		<?php else : ?>
		<div class="adesao" data-adesao="<?php echo esc_attr( wp_json_encode( $cfg ) ); ?>">
			<form class="adesao__form" novalidate>
				<ol class="adesao__passos" aria-label="Etapas">
					<li data-ir="1" class="ativo"><span>1</span>Plano</li>
					<li data-ir="2"><span>2</span>Titular</li>
					<li data-ir="3"><span>3</span>Endereço</li>
					<li data-ir="4"><span>4</span>Família</li>
					<li data-ir="5"><span>5</span>Revisão</li>
				</ol>

				<!-- 1. Plano -->
				<fieldset class="adesao__etapa" data-etapa="1">
					<legend class="h2">Qual plano?</legend>
					<div class="adesao-planos">
						<?php foreach ( $planos as $k => $frase ) : $p = $tabela['planos'][ $k ]; ?>
							<label class="adesao-plano<?php echo $p['disponivel'] ? '' : ' adesao-plano--off'; ?>">
								<input type="radio" name="plano" value="<?php echo esc_attr( $k ); ?>" <?php disabled( ! $p['disponivel'] ); ?>>
								<span class="adesao-plano__in">
									<span class="adesao-plano__nome"><?php echo esc_html( $k ); ?><?php echo 'FLEX' === $k ? ' <em>Mais contratado</em>' : ''; ?></span>
									<span class="adesao-plano__frase"><?php echo esc_html( $frase ); ?></span>
									<span class="adesao-plano__valor"><?php echo 'FLEX' === $k ? 'a partir de ' : ''; ?>R$ <?php echo esc_html( pai_reais( 'FLEX' === $k ? $p['faixas'][0][1] : $p['mensalidade'], true ) ); ?><small>/mês</small></span>
									<span class="adesao-plano__ades">Adesão R$ <?php echo esc_html( pai_reais( $p['adesao'], true ) ); ?></span>
								</span>
							</label>
						<?php endforeach; ?>
					</div>
					<p class="nota">Quer comparar coberturas? <a href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>#comparativo" target="_blank" rel="noopener">Veja o que cada plano cobre</a>.</p>
				</fieldset>

				<!-- 2. Titular -->
				<fieldset class="adesao__etapa" data-etapa="2" hidden>
					<legend class="h2">Dados do titular</legend>
					<p class="nota">O titular é quem contrata e paga o plano. Precisa ter 18 anos ou mais.</p>
					<div class="adesao-grade">
						<label class="campo campo--2">Nome completo *<input name="t_nome" autocomplete="name" maxlength="150" required></label>
						<label class="campo">CPF *<input name="t_cpf" inputmode="numeric" maxlength="14" placeholder="000.000.000-00" required data-mascara="cpf"></label>
						<label class="campo">Data de nascimento *<input name="t_nascimento" type="date" required></label>
						<label class="campo">Religião *<select name="t_religiao" required data-religiao></select></label>
						<label class="campo" data-outra="t" hidden>Qual religião? *<input name="t_religiao_outra" maxlength="50"></label>
						<label class="campo">Celular / WhatsApp *<input name="t_celular" inputmode="tel" autocomplete="tel" maxlength="15" placeholder="(77) 99999-9999" required data-mascara="tel"></label>
						<label class="campo">E-mail<input name="t_email" type="email" autocomplete="email" maxlength="150"></label>
					</div>
				</fieldset>

				<!-- 3. Endereço -->
				<fieldset class="adesao__etapa" data-etapa="3" hidden>
					<legend class="h2">Endereço do titular</legend>
					<div class="adesao-grade">
						<label class="campo">CEP<input name="cep" inputmode="numeric" maxlength="9" placeholder="47800-000" autocomplete="postal-code" data-mascara="cep"></label>
						<label class="campo campo--2">Rua / Avenida *<input name="logradouro" maxlength="150" autocomplete="address-line1" required></label>
						<label class="campo">Número *<input name="numero" maxlength="20" required></label>
						<label class="campo">Complemento<input name="complemento" maxlength="80"></label>
						<label class="campo">Bairro *<input name="bairro" maxlength="80" required></label>
						<label class="campo">Cidade *<input name="cidade" maxlength="80" autocomplete="address-level2" required></label>
						<label class="campo">UF *<input name="uf" maxlength="2" autocomplete="address-level1" required></label>
					</div>
				</fieldset>

				<!-- 4. Família -->
				<fieldset class="adesao__etapa" data-etapa="4" hidden>
					<legend class="h2">Quem mais entra no plano?</legend>
					<p class="adesao-regra" data-regra></p>
					<div class="adesao-pessoas" data-pessoas></div>
					<button type="button" class="btn btn-line" data-add-pessoa><?php echo pai_icone( 'pessoa', 18 ); ?>Adicionar pessoa</button>
					<p class="nota">Só o parentesco e a data de nascimento são obrigatórios. Nome, CPF e religião podem ser informados depois.</p>
					<label class="campo campo--sucessor">Sucessor do contrato (opcional)
						<select name="sucessor" data-sucessor><option value="">Não indicar agora</option></select>
						<small>Quem assume o plano se o titular faltar (cláusula 7.1). Precisa ser maior de idade e ter o nome informado.</small>
					</label>
				</fieldset>

				<!-- 5. Revisão -->
				<fieldset class="adesao__etapa" data-etapa="5" hidden>
					<legend class="h2">Confira e finalize</legend>
					<div class="adesao-revisao" data-revisao></div>
					<label class="opcao opcao--aceite"><input type="checkbox" name="aceite_termo"><span>Li e aceito as condições do <a href="#" data-termo target="_blank" rel="noopener">Termo de Adesão do plano</a>: carência de 90 dias (morte natural) e 24 horas (acidente), contados do pagamento da adesão, e vigência de 4 anos. Sei que vou assinar o termo completo com a equipe do PAI.</span></label>
					<label class="opcao opcao--aceite"><input type="checkbox" name="aceite_religiao"><span>Autorizo o uso da religião informada só para a organização da cerimônia de despedida.</span></label>
					<label class="adesao-armadilha" aria-hidden="true">Não preencha<input name="site" tabindex="-1" autocomplete="off"></label>
				</fieldset>

				<p class="adesao-erro" role="alert" data-erro hidden></p>
				<div class="adesao__nav">
					<button type="button" class="btn btn-line" data-voltar hidden>Voltar</button>
					<button type="button" class="btn btn-sol btn-g" data-avancar>Continuar</button>
				</div>
			</form>

			<aside class="adesao-resumo faixa-escura" aria-live="polite">
				<p class="eyebrow eyebrow--sol">Seu plano</p>
				<p class="adesao-resumo__plano">Plano <span data-r-plano>—</span></p>
				<p class="resumo__rot">Mensalidade</p>
				<p class="resumo__valor" data-r-mensal>—</p>
				<dl class="resumo__linhas" data-r-linhas></dl>
				<p class="resumo__nota">Hoje você paga só a adesão, por Pix ou cartão. A carência começa no pagamento.</p>
			</aside>
		</div>
		<?php endif; ?>
	</div>
</section>

<?php
get_footer();
