<?php
/**
 * rc19 (12/11/2026): TV de mensagens dentro da sala (/mensagens-tv/ = Sala 01, /mensagens-tv-sala-02/, /mensagens-tv-sala-03/).
 *
 * Página em tela cheia, sem cabeçalho nem rodapé do site. Os dados continuam vindo do mesmo lugar de antes
 * (legadodeluztv.php da API, com ?sala=NN): falecido, homenagens aprovadas e contadores.
 * Fundo: a mesma imagem do céu do Legado de Luz. Para trocar, campo personalizado pai_fundo_tv (endereço da imagem).
 * Nome da sala: campo personalizado pai_nome_sala na página (se vazio, usa o padrão de pai_nomes_salas()).
 * Para voltar ao Elementor numa delas: campo personalizado pai_usar_elementor = 1 na página.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sala   = pai_mensagens_tv_sala();
$pagina = get_queried_object_id();
$nome   = trim( (string) get_post_meta( $pagina, 'pai_nome_sala', true ) );
if ( '' === $nome ) {
	$nomes = pai_nomes_salas();
	$nome  = isset( $nomes[ $sala ] ) ? $nomes[ $sala ] : '';
}
$nome_mai = '' !== $nome ? mb_strtoupper( $nome, 'UTF-8' ) : '';
$fundo    = trim( (string) get_post_meta( $pagina, 'pai_fundo_tv', true ) );
if ( '' === $fundo ) {
	$fundo = content_url( '/uploads/2026/06/ChatGPT-Image-12-de-jun.-de-2026-11_14_40.png' );
}
$api    = 'https://api.planoassistencialintegrado.com.br/legadodeluztv.php';
$qr     = PAI_URI . '/assets/img/qr-sala-' . $sala . '.svg';
$fontes = PAI_URI . '/assets/fonts/';
$logo   = PAI_URI . '/assets/img/logo-pai-escuro.svg';
?><!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Mensagens · Sala <?php echo esc_html( $sala ); ?></title>
<link rel="preload" href="<?php echo esc_url( $fontes . 'nunito-900.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="<?php echo esc_url( $fundo ); ?>" as="image">
<style>
@font-face{font-family:Nunito;src:url(<?php echo esc_url( $fontes . 'nunito-700.woff2' ); ?>) format('woff2');font-weight:700;font-display:swap}
@font-face{font-family:Nunito;src:url(<?php echo esc_url( $fontes . 'nunito-800.woff2' ); ?>) format('woff2');font-weight:800;font-display:swap}
@font-face{font-family:Nunito;src:url(<?php echo esc_url( $fontes . 'nunito-900.woff2' ); ?>) format('woff2');font-weight:900;font-display:swap}
:root{--ceu:url("<?php echo esc_url( $fundo ); ?>")}
</style>
<link rel="stylesheet" href="<?php echo esc_url( PAI_URI . '/assets/css/mensagens-tv.css?ver=' . rawurlencode( PAI_VER ) ); ?>">
</head>
<body class="mt--padrao">
<div class="mt-ceu" aria-hidden="true"></div>
<div class="mt-estrelas" data-mt-estrelas aria-hidden="true"></div>

<div class="mt" data-mt data-sala="<?php echo esc_attr( $sala ); ?>" data-api="<?php echo esc_url( $api ); ?>" data-logo="<?php echo esc_url( $logo ); ?>">

	<header class="mt-topo">
		<img class="mt-logo" src="<?php echo esc_url( $logo ); ?>" alt="PAI">
		<h1 class="mt-sala">SALA <?php echo esc_html( $sala ); ?><?php if ( '' !== $nome_mai ) : ?><em><?php echo esc_html( $nome_mai ); ?></em><?php endif; ?></h1>
		<p class="mt-hora"><span data-mt-hora>--:--</span><small data-mt-data></small></p>
	</header>

	<section class="mt-cx mt-perfil">
		<p class="mt-rot" data-mt-rot>Em memória</p>
		<div class="mt-foto" data-mt-foto-box><img alt="" data-mt-foto></div>
		<h2 class="mt-nome" data-mt-nome><span></span></h2>
		<p class="mt-datas" data-mt-datas></p>
	</section>

	<section class="mt-cx mt-msgs" aria-live="polite">
		<div class="mt-cab">
			<p class="mt-k">Mensagens de carinho</p>
			<p class="mt-tot" data-mt-tot></p>
		</div>
		<div class="mt-janela"><div class="mt-lista" data-mt-lista></div></div>
	</section>

	<aside class="mt-qr">
		<p class="mt-qr__eyebrow">Homenagem</p>
		<h2>Deixe sua mensagem<br>de conforto</h2>
		<div class="mt-qr__cod"><i class="c1"></i><i class="c2"></i><i class="c3"></i><i class="c4"></i><img src="<?php echo esc_url( $qr ); ?>" alt="QR code para enviar homenagem para a Sala <?php echo esc_attr( $sala ); ?>"></div>
		<p class="mt-qr__cam">Aponte a câmera<br>do celular</p>
	</aside>
</div>

<section class="mt-padrao" data-mt-padrao>
	<div>
		<div class="mt-padrao__st" aria-hidden="true">✦</div>
		<h1>Legado de Luz</h1>
		<p>SALA <?php echo esc_html( $sala ); ?><?php if ( '' !== $nome_mai ) : ?> <em><?php echo esc_html( $nome_mai ); ?></em><?php endif; ?></p>
	</div>
</section>

<script src="<?php echo esc_url( PAI_URI . '/assets/js/mensagens-tv.js?ver=' . rawurlencode( PAI_VER ) ); ?>" defer></script>
</body>
</html>
