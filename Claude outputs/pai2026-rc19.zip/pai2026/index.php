<?php
/**
 * Listas: blog, categorias, tags e busca.
 */
get_header();

if ( is_search() ) {
	$titulo = 'Busca: ' . get_search_query();
} elseif ( is_category() || is_tag() || is_tax() ) {
	$titulo = single_term_title( '', false );
} elseif ( is_home() ) {
	$titulo = 'Guia para famílias';
} else {
	$titulo = wp_strip_all_tags( get_the_archive_title() );
}
?>
<section class="topo-pagina">
	<?php echo pai_marca_dagua( 'wm--topo' ); ?>
	<div class="wrap pilha pilha--p topo-pagina__in">
		<?php pai_trilha( $titulo ); ?>
		<h1 class="display display--m"><?php echo esc_html( $titulo ); ?></h1>
		<?php if ( is_category() || is_tag() ) : ?>
			<?php $desc = term_description(); ?>
			<?php if ( $desc ) : ?><div class="lead"><?php echo wp_kses_post( $desc ); ?></div><?php endif; ?>
		<?php endif; ?>
	</div>
</section>

<section class="secao secao--sem-topo">
	<div class="wrap pilha">
		<?php if ( have_posts() ) : ?>
			<div class="grade-artigos-g">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'parts/cartao-artigo' );
				endwhile;
				?>
			</div>
			<?php
			the_posts_pagination( array(
				'prev_text' => '‹ Anteriores',
				'next_text' => 'Próximos ›',
				'class'     => 'paginacao',
			) );
			?>
		<?php else : ?>
			<p class="aviso">Nada encontrado. <a href="<?php echo esc_url( pai_url( 'guia-para-familias' ) ); ?>">Ver todo o Guia para famílias</a>.</p>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();
