/* rc17 (12/11/2026): painel da sala na TV (page-painel-sala.php).
 * Mesma fonte de dados do painel antigo: /salaNN.php (lista com nome_completo, foto_falecido,
 * data_sepultamento, horario_sepultamento, local_sepultamento).
 * - alterna as telas a cada 15 s; o QR code fica fixo;
 * - busca os dados a cada 60 s e só redesenha quando mudam (sem piscar);
 * - se a internet cair, mantém na tela os últimos dados e tenta de novo;
 * - recarrega a página uma vez por dia de madrugada (TV ligada por dias não trava). */
(function () {
	'use strict';

	var raiz = document.querySelector('[data-painel]');
	if (!raiz) { return; }

	var FONTE = raiz.getAttribute('data-fonte');
	var UPLOADS = raiz.getAttribute('data-uploads');
	var TROCA_MS = 15000;
	var BUSCA_MS = 60000;
	var LOGO = document.querySelector('.pn-logo').getAttribute('src');

	var palco = raiz.querySelector('[data-pn-palco]');
	var vazio = raiz.querySelector('[data-pn-vazio]');
	var qr = raiz.querySelector('[data-pn-qr]');
	var pontos = raiz.querySelector('[data-pn-pontos]');
	var modeloMem = document.querySelector('[data-pn-modelo-memoria]');
	var modeloSep = document.querySelector('[data-pn-modelo-sepultamento]');

	var ultimoJson = null;
	var slides = [];
	var atual = 0;
	var timerTroca = null;
	var falhasSeguidas = 0;
	var abertoEm = Date.now();

	/* ---------- utilidades ---------- */
	function txt(v) { return String(v == null ? '' : v).trim(); }
	function campo(o, nomes) {
		for (var i = 0; i < nomes.length; i++) {
			var v = txt(o[nomes[i]]);
			if (v && v !== '0000-00-00' && v.toLowerCase() !== 'null') { return v; }
		}
		return '';
	}
	function dataDe(v) {
		var m = String(v || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
		if (m) { return new Date(+m[1], +m[2] - 1, +m[3]); }
		m = String(v || '').match(/^(\d{2})\/(\d{2})\/(\d{4})/);
		if (m) { return new Date(+m[3], +m[2] - 1, +m[1]); }
		return null;
	}
	function p2(n) { return String(n).padStart(2, '0'); }
	function dataCurta(v) {
		var d = dataDe(v);
		return d ? p2(d.getDate()) + '/' + p2(d.getMonth() + 1) + '/' + d.getFullYear() : txt(v);
	}
	var DIAS = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
	function dataSepultamento(v) {
		var d = dataDe(v);
		if (!d) { return txt(v) || 'A definir'; }
		var hoje = new Date(); hoje.setHours(0, 0, 0, 0);
		var dif = Math.round((d - hoje) / 86400000);
		var dm = p2(d.getDate()) + '/' + p2(d.getMonth() + 1);
		if (dif === 0) { return 'Hoje, ' + dm; }
		if (dif === 1) { return 'Amanhã, ' + dm; }
		return DIAS[d.getDay()] + ', ' + dm;
	}
	function hora(v) {
		var m = String(v || '').match(/(\d{1,2}):(\d{2})/);
		return m ? p2(m[1]) + ':' + m[2] : (txt(v) || 'A definir');
	}
	function urlFoto(f) {
		f = txt(f);
		if (!f) { return ''; }
		if (/^https?:\/\//i.test(f)) { return f; }
		return UPLOADS + f.replace(/^\/?(uploads\/)?/i, '');
	}

	/* ---------- relógio ---------- */
	var elHora = raiz.querySelector('[data-pn-hora]');
	var elData = raiz.querySelector('[data-pn-data]');
	function relogio() {
		var d = new Date();
		elHora.textContent = p2(d.getHours()) + ':' + p2(d.getMinutes());
		elData.textContent = DIAS[d.getDay()].toLowerCase() + ', ' + p2(d.getDate()) + '/' + p2(d.getMonth() + 1);
		// Recarrega uma vez por dia, entre 3h30 e 3h45, se a página está aberta há mais de 2 horas.
		if (d.getHours() === 3 && d.getMinutes() >= 30 && d.getMinutes() < 45 && Date.now() - abertoEm > 7200000) {
			location.reload();
		}
	}

	/* ---------- nome sempre cabendo ---------- */
	function ajustarNome(el) {
		if (!el) { return; }
		el.style.fontSize = '';
		var tam = parseFloat(getComputedStyle(el).fontSize);
		var min = window.innerHeight * 0.035;
		var guarda = 40;
		// Diminui até caber na altura, sem palavra cortada na largura e em no máximo 4 linhas.
		var txtEl = el.firstElementChild || el;
		function excede() {
			var h = txtEl.offsetHeight;
			var linhas = h / (tam * 1.06);
			return h > el.clientHeight + 1 || txtEl.scrollWidth > el.clientWidth + 1 || linhas > 4.3;
		}
		while (guarda-- > 0 && tam > min && excede()) {
			tam *= 0.93;
			el.style.fontSize = tam + 'px';
		}
	}

	/** rc18: data, horário e local do sepultamento sempre cabendo (local em até 2 linhas; data e horário em 1). */
	function ajustarSepultamento(tela) {
		if (!tela) { return; }
		var valores = tela.querySelectorAll('.pn-v');
		valores.forEach(function (v) { v.style.fontSize = ''; });
		var min = window.innerHeight * 0.03;
		valores.forEach(function (v) {
			var maxLinhas = v.getAttribute('data-c') === 'local' ? 2 : 1;
			var tam = parseFloat(getComputedStyle(v).fontSize);
			var guarda = 40;
			while (guarda-- > 0 && tam > min && (v.scrollWidth > v.clientWidth + 1 || v.offsetHeight / (tam * 1.05) > maxLinhas + 0.3)) {
				tam *= 0.93;
				v.style.fontSize = tam + 'px';
			}
		});
		// Se ainda assim a tela não comportar tudo (TV pequena), diminui o conjunto por igual.
		var guarda2 = 20;
		while (guarda2-- > 0 && tela.scrollHeight > tela.clientHeight + 1) {
			valores.forEach(function (v) { v.style.fontSize = (parseFloat(getComputedStyle(v).fontSize) * 0.94) + 'px'; });
		}
	}

	/** Deixa um texto de uma linha com a largura pedida (aumenta ou diminui a letra, entre min e max). */
	function caberNaLargura(el, largura, minPx, maxPx) {
		if (!el || !largura) { return; }
		el.style.fontSize = '';
		var tam = parseFloat(getComputedStyle(el).fontSize);
		var w = el.scrollWidth;
		if (!w) { return; }
		var novo = Math.max(minPx, Math.min(maxPx, tam * (largura / w)));
		el.style.fontSize = novo + 'px';
		// correção fina (arredondamento das letras)
		var guarda = 12;
		while (guarda-- > 0 && el.scrollWidth > largura + 1 && novo > minPx) {
			novo *= 0.98;
			el.style.fontSize = novo + 'px';
		}
	}

	function ajustarTela(tela) {
		if (!tela) { return; }
		var vh = window.innerHeight / 100;
		var foto = tela.querySelector('.pn-foto');
		var rot = tela.querySelector('.pn-rot');
		// rc18: "EM MEMÓRIA" com a largura da foto, de ponta a ponta.
		if (foto && rot) { caberNaLargura(rot, foto.offsetWidth, 3 * vh, 9 * vh); }
		var nome = tela.querySelector('.pn-nome');
		if (nome) { ajustarNome(nome); }
		// rc18: datas numa linha, o maior possível na largura ao lado da foto.
		var datas = tela.querySelector('.pn-datas');
		var lado = tela.querySelector('.pn-lado');
		if (datas && lado && datas.childElementCount) { caberNaLargura(datas, lado.clientWidth, 2.4 * vh, 4.6 * vh); }
		if (tela.classList.contains('pn-sepult')) { ajustarSepultamento(tela); }
	}

	/* ---------- montar as telas ---------- */
	function preencher(no, chave, valor) {
		var el = no.querySelector('[data-c="' + chave + '"]');
		if (el) { el.textContent = valor; }
		return el;
	}

	function telaMemoria(item) {
		var no = modeloMem.content.firstElementChild.cloneNode(true);
		var nome = campo(item, ['nome_completo', 'falecido', 'nome_falecido', 'nome']) || 'Nome a definir';
		var elNome = no.querySelector('[data-c="nome"]');
		var span = document.createElement('span');
		span.textContent = nome;
		elNome.appendChild(span);
		var img = no.querySelector('[data-c="foto"]');
		var foto = urlFoto(campo(item, ['foto_falecido', 'foto']));
		if (foto) {
			img.src = foto;
			img.onerror = function () { img.onerror = null; img.src = LOGO; img.parentNode.classList.add('pn-foto--sem'); };
		} else {
			img.src = LOGO;
			img.parentNode.classList.add('pn-foto--sem');
		}
		var nasc = campo(item, ['data_nascimento', 'nascimento', 'data_nascimento_falecido']);
		var falec = campo(item, ['data_falecimento', 'data_obito', 'falecimento', 'obito']);
		var datas = no.querySelector('[data-c="datas"]');
		datas.textContent = '';
		[['✦ ', nasc], ['✝ ', falec]].forEach(function (par) {
			if (!par[1]) { return; }
			var s = document.createElement('span');
			s.appendChild(document.createTextNode(par[0]));
			var b = document.createElement('b');
			b.textContent = dataCurta(par[1]);
			s.appendChild(b);
			datas.appendChild(s);
		});
		return no;
	}

	function telaSepultamento(item) {
		var no = modeloSep.content.firstElementChild.cloneNode(true);
		preencher(no, 'data', dataSepultamento(campo(item, ['data_sepultamento'])));
		preencher(no, 'hora', hora(campo(item, ['horario_sepultamento', 'hora_sepultamento'])));
		preencher(no, 'local', campo(item, ['local_sepultamento']) || 'A definir');
		return no;
	}

	function mostrar(i) {
		if (!slides.length) { return; }
		atual = (i + slides.length) % slides.length;
		slides.forEach(function (s, k) { s.classList.toggle('on', k === atual); });
		pontos.querySelectorAll('i').forEach(function (p, k) { p.classList.toggle('on', k === atual); });
		ajustarTela(slides[atual]);
	}

	function semVelorio(mensagem) {
		slides.forEach(function (s) { s.remove(); });
		slides = [];
		pontos.textContent = '';
		qr.hidden = true;
		raiz.classList.add('pn--vazio');
		vazio.hidden = false;
		vazio.querySelector('p').textContent = mensagem;
	}

	function desenhar(lista) {
		slides.forEach(function (s) { s.remove(); });
		slides = [];
		if (!lista.length) { semVelorio('Plano Assistencial Integrado'); return; }
		lista.forEach(function (item) {
			slides.push(telaMemoria(item));
			slides.push(telaSepultamento(item));
		});
		slides.forEach(function (s) { palco.appendChild(s); });
		// Ajusta as letras de todas as telas logo ao montar (inclusive as que ainda vão aparecer).
		slides.forEach(ajustarTela);
		vazio.hidden = true;
		qr.hidden = false;
		raiz.classList.remove('pn--vazio');
		pontos.textContent = '';
		slides.forEach(function () { pontos.appendChild(document.createElement('i')); });
		pontos.hidden = slides.length < 2;
		mostrar(0);
		reiniciarTroca();
	}

	function reiniciarTroca() {
		clearInterval(timerTroca);
		timerTroca = setInterval(function () { mostrar(atual + 1); }, TROCA_MS);
	}

	/* ---------- dados ---------- */
	function buscar() {
		var url = FONTE + (FONTE.indexOf('?') < 0 ? '?' : '&') + 'cache_bust=' + Date.now();
		fetch(url, { cache: 'no-store', credentials: 'same-origin' })
			.then(function (r) { if (!r.ok) { throw new Error('HTTP ' + r.status); } return r.text(); })
			.then(function (corpo) {
				var dados = JSON.parse(corpo);
				var lista = Array.isArray(dados) ? dados : (dados && (dados.dados || dados.data || dados.registros)) || [];
				lista = lista.filter(function (x) { return x && typeof x === 'object'; });
				falhasSeguidas = 0;
				var chave = JSON.stringify(lista);
				if (chave === ultimoJson) { return; } // nada mudou: não redesenha
				ultimoJson = chave;
				desenhar(lista);
			})
			.catch(function () {
				falhasSeguidas++;
				// Mantém na tela o que já estava. Só avisa se nunca carregou.
				if (ultimoJson === null && falhasSeguidas >= 2) { semVelorio('Sem conexão. Tentando novamente…'); }
			});
	}

	/* ---------- TV acordada ---------- */
	function manterAcordada() {
		try {
			if (navigator.wakeLock && navigator.wakeLock.request) { navigator.wakeLock.request('screen').catch(function () {}); }
		} catch (e) { /* TV sem suporte: tudo bem */ }
	}
	document.addEventListener('visibilitychange', function () {
		if (document.visibilityState === 'visible') { manterAcordada(); buscar(); }
	});
	window.addEventListener('resize', function () {
		slides.forEach(ajustarTela);
	});

	relogio();
	setInterval(relogio, 15000);
	manterAcordada();
	buscar();
	setInterval(buscar, BUSCA_MS);
})();
