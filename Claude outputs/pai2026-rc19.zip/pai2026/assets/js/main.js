/* Plano PAI 2026 · tema, menu, abas, frases e simulador. Sem dependências. */
(function () {
	'use strict';
	var raiz = document.documentElement;
	raiz.classList.add('js');

	/* Tema claro/escuro */
	function rotuloTema() {
		var claro = raiz.classList.contains('light');
		document.querySelectorAll('[data-tema]').forEach(function (b) {
			b.setAttribute('aria-label', claro ? 'Usar tema escuro' : 'Usar tema claro');
		});
		var meta = document.querySelector('meta[name="theme-color"]');
		if (meta) { meta.setAttribute('content', claro ? '#FFFFFF' : '#232B3F'); }
	}
	document.querySelectorAll('[data-tema]').forEach(function (b) {
		b.addEventListener('click', function () {
			var claro = raiz.classList.toggle('light');
			try { localStorage.setItem('pai-tema', claro ? 'claro' : 'escuro'); } catch (e) {}
			rotuloTema();
		});
	});
	rotuloTema();

	/* Menu do celular */
	var botaoMenu = document.querySelector('[data-menu]');
	if (botaoMenu) {
		botaoMenu.addEventListener('click', function () {
			var aberto = document.body.classList.toggle('menu-aberto');
			botaoMenu.setAttribute('aria-expanded', aberto ? 'true' : 'false');
			botaoMenu.setAttribute('aria-label', aberto ? 'Fechar menu' : 'Abrir menu');
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && document.body.classList.contains('menu-aberto')) { botaoMenu.click(); botaoMenu.focus(); }
		});
	}

	/* Abas (coroas naturais/artificiais) */
	document.querySelectorAll('[data-abas]').forEach(function (grupo) {
		var abas = grupo.querySelectorAll('[role="tab"]');
		function ativar(aba) {
			abas.forEach(function (a) {
				var sel = a === aba;
				a.setAttribute('aria-selected', sel ? 'true' : 'false');
				a.tabIndex = sel ? 0 : -1;
				var painel = document.getElementById(a.getAttribute('aria-controls'));
				if (painel) { if (sel) { painel.removeAttribute('data-oculto'); } else { painel.setAttribute('data-oculto', ''); } }
			});
		}
		abas.forEach(function (a, i) {
			a.tabIndex = a.getAttribute('aria-selected') === 'true' ? 0 : -1;
			a.addEventListener('click', function () { ativar(a); });
			a.addEventListener('keydown', function (e) {
				var n = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
				if (!n) { return; }
				var prox = abas[(i + n + abas.length) % abas.length];
				prox.focus(); ativar(prox);
			});
		});
	});

	/* Copiar frase da faixa (rc15: o aviso aparece perto da frase copiada: aba Frases ou seção de baixo) */
	var avisoCopia = document.querySelector('[data-copiado]');
	document.querySelectorAll('[data-copiar]').forEach(function (b) {
		b.addEventListener('click', function () {
			var texto = b.getAttribute('data-copiar');
			var grupo = b.closest('[data-frases-grupo]');
			var aviso = (grupo && grupo.querySelector('[data-copiado]')) ||
				(grupo && grupo.parentNode && grupo.parentNode.querySelector('[data-copiado]')) || avisoCopia;
			function ok() {
				document.querySelectorAll('.frase.copiada').forEach(function (x) { x.classList.remove('copiada'); });
				b.classList.add('copiada');
				document.querySelectorAll('[data-copiado]').forEach(function (x) { if (x !== aviso) { x.textContent = ''; } });
				if (aviso) { aviso.textContent = 'Frase copiada: “' + texto + '”. Cole no campo da faixa ao fazer o pedido.'; }
			}
			// rc15: copia na hora do toque. Se o navegador recusar a área de transferência moderna
			// (navegador dentro do Instagram/Facebook, iPhone antigo), usa o método antigo de cópia.
			function copiarAntigo() {
				var t = document.createElement('textarea');
				t.value = texto;
				t.setAttribute('readonly', '');
				t.style.position = 'fixed'; t.style.top = '0'; t.style.left = '0'; t.style.opacity = '0';
				document.body.appendChild(t);
				t.focus(); t.select();
				try { t.setSelectionRange(0, texto.length); } catch (e) {}
				var feito = false;
				try { feito = document.execCommand('copy'); } catch (e) { feito = false; }
				document.body.removeChild(t);
				b.focus();
				return feito;
			}
			function falhou() {
				if (copiarAntigo()) { ok(); return; }
				if (aviso) { aviso.textContent = 'Não foi possível copiar automaticamente. Segure o dedo sobre a frase para copiar: “' + texto + '”.'; }
			}
			if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext) {
				navigator.clipboard.writeText(texto).then(ok, falhou);
			} else { falhou(); }
		});
	});

	/* rc15: procurar frase na aba Frases (ignora acentos e maiúsculas) */
	function semAcento(t) { return String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
	document.querySelectorAll('[data-filtro-frases]').forEach(function (campo) {
		var painel = campo.closest('[data-frases-grupo]');
		if (!painel) { return; }
		var vazio = painel.querySelector('[data-frases-vazio]');
		campo.addEventListener('input', function () {
			var q = semAcento(campo.value.trim());
			var achou = 0;
			painel.querySelectorAll('.frases--lista li').forEach(function (li) {
				var b = li.querySelector('[data-copiar]');
				var mostra = !q || semAcento(b ? b.getAttribute('data-copiar') : '').indexOf(q) !== -1;
				li.hidden = !mostra;
				if (mostra) { achou++; }
			});
			if (vazio) { vazio.hidden = achou > 0; }
		});
	});

	/* Simulador de planos */
	var sim = document.querySelector('[data-simulador]');
	if (!sim) { return; }
	var cfg;
	try { cfg = JSON.parse(sim.getAttribute('data-simulador')); } catch (e) { return; }
	var form = sim.querySelector('form');
	var idades = ['Até 54 anos', '55 a 64 anos', '65 a 74 anos', '75 anos ou mais'];
	var extras = 0;

	function brl(v) {
		return 'R$ ' + v.toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
	}
	function val(nome) {
		var el = form.querySelector('input[name="' + nome + '"]:checked');
		return el ? el.value : null;
	}
	function mostra(seletor, sim_) {
		form.querySelectorAll('[data-so="' + seletor + '"]').forEach(function (el) { el.hidden = !sim_; });
	}
	function linha(k, v) {
		return '<div><dt>' + k + '</dt><dd>' + v + '</dd></div>';
	}

	var params = new URLSearchParams(location.search);
	var pedido = (params.get('plano') || '').toUpperCase();
	if (cfg.planos[pedido]) {
		var radio = form.querySelector('input[name="plano"][value="' + pedido + '"]');
		if (radio) { radio.checked = true; }
	}

	function calcular() {
		var plano = val('plano') || 'FLEX';
		var c = cfg.planos[plano];
		var flex = plano === 'FLEX';
		var idade = parseInt(val('idade') || '0', 10);
		var podeNac = plano === 'FLEX' || plano === 'PLUS';
		var tanato = form.querySelector('input[name="tanato"]');
		var nacional = form.querySelector('input[name="nacional"]');

		mostra('flex', flex);
		mostra('extras', !flex);
		mostra('aditivos', podeNac);
		if (!flex && tanato) { tanato.checked = false; }
		if (!podeNac && nacional) { nacional.checked = false; }
		if (!flex) { extras = Math.min(extras, c.maxExtras); }

		var mensal = flex ? cfg.flex[idade] : c.base;
		var html = linha('Taxa de adesão (uma vez)', brl(c.adesao));
		if (flex) { html += linha('Faixa de idade', idades[idade]); }
		if (!flex) {
			var pagos = Math.max(0, extras - c.free);
			var soma = Math.round(pagos * c.per * 100) / 100;
			if (extras > 0) { html += linha(extras + (extras > 1 ? ' extras' : ' extra'), soma > 0 ? '+ ' + brl(soma) : 'sem custo'); }
			mensal += soma;
			sim.querySelector('[data-extras]').textContent = extras;
			sim.querySelector('[data-extras-ajuda]').textContent = c.help || '';
			sim.querySelector('[data-limite]').textContent = extras >= c.maxExtras ? 'Limite do plano' : '';
		}
		if (flex && tanato && tanato.checked) {
			var t = Math.round(mensal * 0.2 * 100) / 100;
			html += linha('Tanatopraxia (+20%)', '+ ' + brl(t));
			mensal += t;
		}
		if (podeNac && nacional && nacional.checked) {
			html += linha('Translado Nacional', '+ ' + brl(cfg.translado));
			mensal += cfg.translado;
		}
		html += linha('Carência', '90 dias · 24 h acidental');

		sim.querySelector('[data-quem]').textContent = c.who;
		sim.querySelector('[data-r-plano]').textContent = plano;
		sim.querySelector('[data-r-mensal]').textContent = brl(mensal);
		sim.querySelector('[data-r-linhas]').innerHTML = html;
		var msg = 'Olá! Simulei no site o Plano ' + plano + (flex ? ' (' + idades[idade] + ')' : '') + ': ' + brl(mensal) + '/mês. Quero saber mais.';
		var contratar = sim.querySelector('[data-r-contratar]');
		if (contratar) { contratar.href = contratar.href.replace(/plano=[a-z]+/, 'plano=' + plano.toLowerCase()); }
		sim.querySelector('[data-r-whats]').href = 'https://wa.me/' + cfg.whats + '?text=' + encodeURIComponent(msg);
	}

	form.addEventListener('change', calcular);
	sim.querySelector('[data-mais]').addEventListener('click', function () { extras += 1; calcular(); });
	sim.querySelector('[data-menos]').addEventListener('click', function () { extras = Math.max(0, extras - 1); calcular(); });
	calcular();
})();

/* Galeria: filtro por grupo e foto ampliada */
(function () {
	var lista = document.querySelector('[data-fotos]');
	if (!lista) { return; }
	var filtro = document.querySelector('[data-filtro]');
	if (filtro) {
		filtro.addEventListener('click', function (e) {
			var b = e.target.closest('[data-grupo]');
			if (!b) { return; }
			var g = b.getAttribute('data-grupo');
			filtro.querySelectorAll('[data-grupo]').forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
			lista.querySelectorAll('li').forEach(function (li) { li.hidden = !!g && li.getAttribute('data-grupo') !== g; });
		});
	}
	var dlg = document.querySelector('[data-ampliada]');
	if (!dlg || typeof dlg.showModal !== 'function') { return; }
	var img = dlg.querySelector('img');
	var leg = dlg.querySelector('.ampliada__leg');
	lista.addEventListener('click', function (e) {
		var a = e.target.closest('[data-ampliar]');
		if (!a) { return; }
		e.preventDefault();
		var mini = a.querySelector('img');
		img.src = a.href;
		img.alt = mini ? mini.alt : '';
		leg.textContent = mini ? mini.alt : '';
		dlg.showModal();
	});
	dlg.addEventListener('click', function (e) {
		if (e.target === dlg || e.target.closest('[data-fechar]')) { dlg.close(); }
	});
	dlg.addEventListener('close', function () { img.src = ''; });
})();

/* Landing page: galeria, foto ampliada, formulário para o WhatsApp e contagem de contatos */
(function () {
	var trilho = document.querySelector('[data-lp-galeria]');
	if (trilho) {
		var passo = function (n) {
			var item = trilho.querySelector('.lp-galeria__item');
			var w = item ? item.getBoundingClientRect().width + 18 : 300;
			var fim = trilho.scrollLeft + trilho.clientWidth >= trilho.scrollWidth - 4;
			if (n > 0 && fim) { trilho.scrollTo({ left: 0 }); return; }
			if (n < 0 && trilho.scrollLeft <= 2) { trilho.scrollTo({ left: trilho.scrollWidth }); return; }
			trilho.scrollBy({ left: n * w });
		};
		var ant = document.querySelector('.lp-galeria__ant');
		var prox = document.querySelector('.lp-galeria__prox');
		if (ant) { ant.addEventListener('click', function () { passo(-1); }); }
		if (prox) { prox.addEventListener('click', function () { passo(1); }); }
		var box = document.querySelector('[data-lp-ampliada]');
		if (box) {
			var im = box.querySelector('img');
			trilho.addEventListener('click', function (e) {
				var f = e.target.closest('.lp-galeria__item');
				if (!f) { return; }
				var src = f.querySelector('img');
				im.src = src.currentSrc || src.src; im.alt = src.alt;
				box.hidden = false;
			});
			var fechar = function () { box.hidden = true; im.src = ''; };
			box.addEventListener('click', function (e) { if (e.target === box || e.target.closest('[data-lp-fechar]')) { fechar(); } });
			document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !box.hidden) { fechar(); } });
		}
	}
	if (!document.body.classList.contains('lp')) { return; }
	var lead = function (origem) {
		try { if (window.fbq) { window.fbq('track', 'Lead', { content_name: origem }); } } catch (e) {}
		try { if (window.gtag) { window.gtag('event', 'generate_lead', { method: 'whatsapp', origem: origem }); } } catch (e) {}
	};
	document.querySelectorAll('.lp-wa').forEach(function (a) {
		a.addEventListener('click', function () { lead(a.textContent.trim().slice(0, 40)); });
	});
	var form = document.querySelector('[data-lp-form]');
	if (form) {
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var nome = (form.nome.value || '').trim();
			var plano = form.plano.value;
			var texto = 'Olá, vim pelo anúncio! Sou ' + nome + '. Tenho interesse em: ' + plano + '. Gostaria de receber mais informações.';
			lead('formulario');
			window.open('https://wa.me/' + form.getAttribute('data-whats') + '?text=' + encodeURIComponent(texto), '_blank', 'noopener');
		});
	}
})();

/* Pagar mensalidade: CPF do titular + número do contrato → link de pagamento (link-de-pagamento.php). */
(function () {
	var box = document.querySelector('[data-pagar]');
	if (!box) return;
	var api = box.getAttribute('data-api');
	var whats = box.getAttribute('data-whats');
	var form = box.querySelector('[data-pagar-form]');
	var cpf = form.querySelector('[name=cpf]');
	var contrato = form.querySelector('[name=contrato]');
	var btnConsultar = form.querySelector('button[type=submit]');
	var msg = box.querySelector('[data-pagar-msg]');
	var res = box.querySelector('[data-pagar-resultado]');
	var lista = box.querySelector('[data-pagar-lista]');
	var btnGerar = box.querySelector('[data-pagar-gerar]');
	var msg2 = box.querySelector('[data-pagar-msg2]');
	var ticket = null, ocupado = false;

	function reais(v) { return Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
	function data(v) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (v || ''); }
	function soDigitos(v) { return String(v || '').replace(/\D/g, ''); }
	function cpfValido(c) {
		c = soDigitos(c);
		if (c.length !== 11 || /^(\d)\1{10}$/.test(c)) return false;
		for (var t = 9; t < 11; t++) {
			var s = 0;
			for (var i = 0; i < t; i++) s += Number(c.charAt(i)) * (t + 1 - i);
			if (((10 * s) % 11) % 10 !== Number(c.charAt(t))) return false;
		}
		return true;
	}
	function aviso(el, texto, comWhats) {
		el.textContent = texto || '';
		el.classList.remove('pagar-aviso--ok');
		if (texto && comWhats && whats) {
			var a = document.createElement('a');
			a.href = whats; a.target = '_blank'; a.rel = 'noopener'; a.textContent = 'Falar no WhatsApp ›';
			el.appendChild(document.createTextNode(' '));
			el.appendChild(a);
		}
		el.hidden = !texto;
	}
	function chamar(corpo) {
		return fetch(api, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(corpo),
			credentials: 'omit',
			cache: 'no-store'
		}).then(function (r) {
			return r.json().catch(function () { return { ok: false, mensagem: 'Resposta inesperada do servidor.' }; });
		}, function () {
			return { ok: false, mensagem: 'Sem conexão com o financeiro. Confira a internet e tente de novo.' };
		});
	}
	function carregando(btn, sim, texto) {
		ocupado = sim;
		btn.disabled = sim;
		if (sim) { btn.setAttribute('data-texto', btn.textContent); btn.textContent = texto; }
		else if (btn.getAttribute('data-texto')) btn.textContent = btn.getAttribute('data-texto');
	}

	cpf.addEventListener('input', function () {
		var d = soDigitos(cpf.value).slice(0, 11), o = d;
		if (d.length > 9) o = d.slice(0, 3) + '.' + d.slice(3, 6) + '.' + d.slice(6, 9) + '-' + d.slice(9);
		else if (d.length > 6) o = d.slice(0, 3) + '.' + d.slice(3, 6) + '.' + d.slice(6);
		else if (d.length > 3) o = d.slice(0, 3) + '.' + d.slice(3);
		cpf.value = o;
	});

	form.addEventListener('submit', function (e) {
		e.preventDefault();
		if (ocupado) return;
		aviso(msg, '');
		if (!cpfValido(cpf.value)) { aviso(msg, 'Confira o CPF: ele precisa ser o do titular do plano.'); cpf.focus(); return; }
		var num = contrato.value.trim();
		if (!/\d/.test(num)) { aviso(msg, 'Digite o número completo do contrato.'); contrato.focus(); return; }
		carregando(btnConsultar, true, 'Consultando…');
		chamar({ acao: 'consultar', cpf: soDigitos(cpf.value), contrato: num }).then(function (j) {
			carregando(btnConsultar, false);
			if (!j || !j.ok) { aviso(msg, (j && j.mensagem) || 'Não foi possível consultar agora.', true); return; }
			if (!j.disponivel) { aviso(msg, j.mensagem || 'Não há mensalidade em aberto para pagar agora.'); return; }
			ticket = j.ticket;
			box.querySelector('[data-pagar-contrato]').textContent = j.contrato || num;
			box.querySelector('[data-pagar-cpf]').textContent = 'Titular: CPF ' + (j.cpf_mascarado || '');
			lista.innerHTML = '';
			(j.mensalidades || []).forEach(function (m) {
				var li = document.createElement('li');
				var a = document.createElement('span'); a.className = 'pagar-lista__p';
				var b = document.createElement('strong'); b.textContent = m.parcela || 'Mensalidade';
				var c = document.createElement('small');
				c.textContent = 'Vence em ' + data(m.vencimento) + (m.dias_atraso > 0 ? ' · ' + m.dias_atraso + (m.dias_atraso === 1 ? ' dia' : ' dias') + ' em atraso' : '');
				if (m.dias_atraso > 0) li.className = 'pagar-lista--atraso';
				a.appendChild(b); a.appendChild(c);
				var v = document.createElement('span'); v.className = 'pagar-lista__v'; v.textContent = reais(m.valor);
				li.appendChild(a); li.appendChild(v);
				lista.appendChild(li);
			});
			box.querySelector('[data-pagar-total]').textContent = reais(j.valor_total);
			btnGerar.textContent = 'Pagar ' + reais(j.valor_total);
			btnGerar.removeAttribute('data-texto');
			aviso(msg2, '');
			form.hidden = true; res.hidden = false;
			btnGerar.focus();
		});
	});

	box.querySelector('[data-pagar-trocar]').addEventListener('click', function () {
		ticket = null; res.hidden = true; form.hidden = false; aviso(msg, ''); cpf.focus();
	});

	btnGerar.addEventListener('click', function () {
		if (ocupado || !ticket) return;
		aviso(msg2, '');
		// Abre a janela já no clique (o navegador do celular bloqueia janela aberta depois).
		var janela = null;
		try { janela = window.open('', '_blank'); } catch (e) { janela = null; }
		if (janela) { try { janela.document.write('<p style="font-family:sans-serif;padding:24px">Abrindo o pagamento…</p>'); } catch (e) {} }
		carregando(btnGerar, true, 'Gerando o link…');
		chamar({ acao: 'gerar_link', ticket: ticket }).then(function (j) {
			carregando(btnGerar, false);
			if (!j || !j.ok || !j.url) {
				if (janela) janela.close();
				var expirou = j && (j.codigo === 'TICKET_EXPIRADO' || j.codigo === 'MENSALIDADES_ALTERADAS');
				aviso(msg2, (j && j.mensagem) || 'Não foi possível gerar o link agora.', !expirou);
				if (expirou) { ticket = null; btnGerar.textContent = 'Consultar de novo'; btnGerar.onclick = function () { btnGerar.onclick = null; res.hidden = true; form.hidden = false; form.requestSubmit ? form.requestSubmit() : btnConsultar.click(); }; }
				return;
			}
			if (window.gtag) { try { gtag('event', 'pagar_mensalidade', { value: j.valor_total, currency: 'BRL' }); } catch (e) {} }
			if (janela) { janela.location.href = j.url; }
			else { window.location.href = j.url; }
			msg2.textContent = 'O pagamento abriu em outra aba. Não abriu? ';
			var a = document.createElement('a'); a.href = j.url; a.target = '_blank'; a.rel = 'noopener'; a.textContent = 'Abrir o pagamento ›';
			msg2.appendChild(a); msg2.hidden = false; msg2.classList.add('pagar-aviso--ok');
		});
	});
})();

/* Adesão online (/adesao/): etapas, família, cálculo e envio ao planos-novos.php. Mesmas regras do servidor. */
(function () {
	var raiz = document.querySelector('[data-adesao]');
	if (!raiz) return;
	var cfg;
	try { cfg = JSON.parse(raiz.getAttribute('data-adesao')); } catch (e) { return; }
	var T = cfg.tabela, PL = T.planos;
	var form = raiz.querySelector('form');
	var etapa = 1, enviando = false, seq = 0;
	var pessoasBox = raiz.querySelector('[data-pessoas]');
	var erroBox = raiz.querySelector('[data-erro]');
	var btnAv = raiz.querySelector('[data-avancar]'), btnVo = raiz.querySelector('[data-voltar]');
	var PAR = {};
	T.parentescos.forEach(function (p) { PAR[p.valor] = p; });

	function $(s, el) { return (el || form).querySelector(s); }
	function v(nome) { var el = form.elements[nome]; return el ? String(el.value || '').trim() : ''; }
	function dig(s) { return String(s || '').replace(/\D/g, ''); }
	function brl(n) { return 'R$ ' + Number(n || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
	function idade(iso) {
		var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); if (!m) return null;
		var h = new Date(), a = h.getFullYear() - +m[1];
		if (h.getMonth() + 1 < +m[2] || (h.getMonth() + 1 === +m[2] && h.getDate() < +m[3])) a--;
		return a;
	}
	function dataOk(iso) { var i = idade(iso); return i !== null && i >= 0 && i < 125; }
	function cpfOk(c) {
		c = dig(c); if (c.length !== 11 || /^(\d)\1{10}$/.test(c)) return false;
		for (var t = 9; t < 11; t++) { var s = 0; for (var i = 0; i < t; i++) s += +c[i] * (t + 1 - i); if (((10 * s) % 11) % 10 !== +c[t]) return false; }
		return true;
	}
	function plano() { var r = form.querySelector('input[name="plano"]:checked'); return r ? r.value : ''; }

	/* Religiões */
	function opcoesReligiao(sel, obrig) {
		sel.innerHTML = '<option value="">' + (obrig ? 'Escolha' : 'Não informar') + '</option>' + T.religioes.map(function (r) { return '<option>' + esc(r) + '</option>'; }).join('');
	}
	opcoesReligiao($('[name="t_religiao"]'), true);
	$('[name="t_religiao"]').addEventListener('change', function () { $('[data-outra="t"]').hidden = this.value !== 'Outra'; });

	/* Máscaras */
	form.addEventListener('input', function (e) {
		var el = e.target, m = el.getAttribute('data-mascara'); if (!m) return;
		var d = dig(el.value);
		if (m === 'cpf') { d = d.slice(0, 11); el.value = d.length > 9 ? d.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, '$1.$2.$3-$4') : d.length > 6 ? d.replace(/(\d{3})(\d{3})(\d{0,3})/, '$1.$2.$3') : d.length > 3 ? d.replace(/(\d{3})(\d{0,3})/, '$1.$2') : d; }
		if (m === 'tel') { d = d.slice(0, 11); el.value = d.length > 10 ? d.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3') : d.length > 6 ? d.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3') : d.length > 2 ? d.replace(/(\d{2})(\d{0,5})/, '($1) $2') : d; }
		if (m === 'cep') { d = d.slice(0, 8); el.value = d.length > 5 ? d.replace(/(\d{5})(\d{0,3})/, '$1-$2') : d; }
	});

	/* CEP */
	$('[name="cep"]').addEventListener('blur', function () {
		var c = dig(this.value); if (c.length !== 8) return;
		fetch('https://viacep.com.br/ws/' + c + '/json/').then(function (r) { return r.json(); }).then(function (j) {
			if (!j || j.erro) return;
			[['logradouro', j.logradouro], ['bairro', j.bairro], ['cidade', j.localidade], ['uf', j.uf]].forEach(function (p) {
				if (p[1] && !v(p[0])) form.elements[p[0]].value = p[1];
			});
			form.elements.numero.focus();
		}).catch(function () {});
	});

	/* Pessoas */
	function novaPessoa() {
		var i = ++seq;
		var div = document.createElement('div');
		div.className = 'adesao-pessoa card';
		div.setAttribute('data-pessoa', i);
		div.innerHTML =
			'<div class="adesao-pessoa__cab"><strong class="adesao-pessoa__n"></strong><span class="adesao-selo" data-tipo></span>' +
			'<button type="button" class="adesao-pessoa__rem" data-rem aria-label="Remover pessoa">Remover</button></div>' +
			'<div class="adesao-grade">' +
			'<label class="campo">Parentesco *<select data-f="parentesco"><option value="">Escolha</option>' +
			T.parentescos.map(function (p) { return '<option value="' + p.valor + '">' + esc(p.rotulo) + '</option>'; }).join('') + '</select></label>' +
			'<label class="campo">Data de nascimento *<input type="date" data-f="nascimento"></label>' +
			'<label class="campo campo--2">Nome<input data-f="nome" maxlength="150"></label>' +
			'<label class="campo">CPF<input data-f="cpf" inputmode="numeric" maxlength="14" data-mascara="cpf"></label>' +
			'<label class="campo">Religião<select data-f="religiao"></select></label>' +
			'</div>';
		opcoesReligiao(div.querySelector('[data-f="religiao"]'), false);
		pessoasBox.appendChild(div);
		atualizar();
		div.querySelector('[data-f="parentesco"]').focus();
	}
	function pessoas() {
		return Array.prototype.map.call(pessoasBox.querySelectorAll('[data-pessoa]'), function (el) {
			var g = function (f) { return String(el.querySelector('[data-f="' + f + '"]').value || '').trim(); };
			return { el: el, parentesco: g('parentesco'), nascimento: g('nascimento'), nome: g('nome'), cpf: g('cpf'), religiao: g('religiao') };
		});
	}
	raiz.querySelector('[data-add-pessoa]').addEventListener('click', novaPessoa);
	pessoasBox.addEventListener('click', function (e) {
		var b = e.target.closest('[data-rem]'); if (!b) return;
		b.closest('[data-pessoa]').remove(); atualizar();
	});
	pessoasBox.addEventListener('change', atualizar);
	pessoasBox.addEventListener('input', function (e) { if (e.target.getAttribute('data-f') === 'nome') atualizar(); });

	/* Cálculo (igual ao planos-novos.php) */
	function calcular() {
		var k = plano(), p = PL[k]; if (!p) return null;
		var lista = pessoas(), r = { plano: k, adesao: p.adesao, lista: lista, agregados: 0, pagos: 0, valorAgreg: 0, mensal: 0, maior: null, erro: '' };
		if (lista.length > p.pessoas_max) r.erro = 'O plano ' + k + ' aceita até ' + p.pessoas_max + ' pessoas além do titular.';
		if (k === 'FLEX') {
			var maior = idade(v('t_nascimento')) || 0;
			lista.forEach(function (x) { var i = idade(x.nascimento); if (i !== null) maior = Math.max(maior, i); x.tipo = 'dependente'; x.paga = false; });
			r.maior = maior;
			r.mensal = p.faixas[p.faixas.length - 1][1];
			for (var f = 0; f < p.faixas.length; f++) { if (maior <= p.faixas[f][0]) { r.mensal = p.faixas[f][1]; break; } }
			return r;
		}
		var conj = 0, ps = 0;
		lista.forEach(function (x) {
			var g = (PAR[x.parentesco] || {}).grupo || '', i = idade(x.nascimento);
			x.tipo = 'agregado';
			if (g === 'conjuge') { conj++; x.tipo = 'dependente'; if (conj > 1) r.erro = 'Informe só um cônjuge ou companheiro(a).'; }
			else if (g === 'filho') { x.tipo = (i !== null && i > T.idade_filho_max) ? 'agregado' : 'dependente'; }
			else if (g === 'pais_sogros') { ps++; x.tipo = ps <= T.pais_sogros_max ? 'dependente' : 'agregado'; }
			if (!x.parentesco) x.tipo = '';
		});
		lista.forEach(function (x) { if (x.tipo !== 'agregado') { x.paga = false; return; } r.agregados++; x.paga = r.agregados > p.agregados_sem_custo; });
		if (r.agregados > p.agregados_max) r.erro = 'O plano ' + k + ' aceita até ' + p.agregados_max + ' agregados.';
		r.pagos = Math.max(0, r.agregados - p.agregados_sem_custo);
		r.valorAgreg = Math.round(r.pagos * p.valor_agregado * 100) / 100;
		r.mensal = Math.round((p.mensalidade + r.valorAgreg) * 100) / 100;
		return r;
	}

	function regraTexto(k) {
		var p = PL[k]; if (!p) return '';
		if (k === 'FLEX') return 'No FLEX entram até 9 pessoas de qualquer parentesco, sem custo por pessoa. A mensalidade segue a idade da pessoa mais velha (titular incluído).';
		var dep = 'Dependentes, sem custo: cônjuge, filhos solteiros até ' + T.idade_filho_max + ' anos e até ' + T.pais_sogros_max + ' pessoas entre pai, mãe, sogro e sogra.';
		var ag = k === 'LIGHT'
			? ' Demais pessoas entram como agregados: até ' + p.agregados_max + ', por ' + brl(p.valor_agregado) + ' cada.'
			: ' Demais pessoas entram como agregados: até ' + p.agregados_max + ', os ' + p.agregados_sem_custo + ' primeiros sem custo e, a partir do 3º, ' + brl(p.valor_agregado) + ' cada.';
		return dep + ag;
	}

	function linha(a, b) { return '<div><dt>' + a + '</dt><dd>' + b + '</dd></div>'; }

	function atualizar() {
		var r = calcular();
		var k = plano();
		raiz.querySelector('[data-regra]').textContent = regraTexto(k);
		pessoas().forEach(function (x, i) {
			x.el.querySelector('.adesao-pessoa__n').textContent = 'Pessoa ' + (i + 1);
		});
		if (r) {
			r.lista.forEach(function (x) {
				var s = x.el.querySelector('[data-tipo]');
				if (!x.tipo) { s.textContent = ''; s.className = 'adesao-selo'; return; }
				if (k === 'FLEX') { s.textContent = 'Incluído'; s.className = 'adesao-selo adesao-selo--dep'; return; }
				s.textContent = x.tipo === 'dependente' ? 'Dependente · sem custo' : (x.paga ? 'Agregado · + ' + brl(PL[k].valor_agregado) : 'Agregado · sem custo');
				s.className = 'adesao-selo ' + (x.tipo === 'dependente' ? 'adesao-selo--dep' : x.paga ? 'adesao-selo--pago' : 'adesao-selo--dep');
			});
		}
		// Sucessor: maiores de idade com nome
		var sel = raiz.querySelector('[data-sucessor]'), atual = sel.value, ops = '<option value="">Não indicar agora</option>';
		pessoas().forEach(function (x, i) {
			var id = idade(x.nascimento);
			if (x.nome && id !== null && id >= 18) ops += '<option value="' + i + '">' + esc(x.nome) + ' (' + esc((PAR[x.parentesco] || {}).rotulo || '') + ')</option>';
		});
		sel.innerHTML = ops;
		if (sel.querySelector('option[value="' + atual + '"]')) sel.value = atual;
		// Resumo
		raiz.querySelector('[data-r-plano]').textContent = k || '—';
		raiz.querySelector('[data-r-mensal]').textContent = r ? brl(r.mensal) : '—';
		var h = '';
		if (r) {
			h += linha('Pessoas no plano', String(1 + r.lista.length));
			if (k === 'FLEX' && r.maior !== null) h += linha('Pessoa mais velha', r.maior + ' anos');
			if (k !== 'FLEX' && r.agregados) h += linha(r.agregados + (r.agregados > 1 ? ' agregados' : ' agregado'), r.valorAgreg > 0 ? '+ ' + brl(r.valorAgreg) : 'sem custo');
			h += linha('Adesão (hoje)', brl(r.adesao));
			h += linha('Carência', '90 dias · 24 h acidente');
		}
		raiz.querySelector('[data-r-linhas]').innerHTML = h;
		var termo = raiz.querySelector('[data-termo]');
		if (termo && PL[k]) { if (PL[k].termo) { termo.href = PL[k].termo; termo.removeAttribute('aria-disabled'); } else { termo.removeAttribute('href'); } }
		return r;
	}
	form.addEventListener('change', function (e) { if (e.target.name === 'plano' || e.target.name === 't_nascimento') atualizar(); });

	/* Validação por etapa */
	function erro(msg, el) {
		erroBox.textContent = msg; erroBox.hidden = !msg;
		if (el) { el.focus(); el.setAttribute('aria-invalid', 'true'); }
		return !msg;
	}
	form.addEventListener('input', function (e) { e.target.removeAttribute('aria-invalid'); });
	function validar(n) {
		erro('');
		if (n === 1 && !plano()) return erro('Escolha um plano para continuar.');
		if (n === 2) {
			var nome = v('t_nome');
			if (nome.length < 5 || nome.indexOf(' ') < 0) return erro('Informe o nome completo do titular.', form.elements.t_nome);
			if (!cpfOk(v('t_cpf'))) return erro('CPF do titular inválido.', form.elements.t_cpf);
			var i = idade(v('t_nascimento'));
			if (!dataOk(v('t_nascimento'))) return erro('Informe a data de nascimento do titular.', form.elements.t_nascimento);
			if (i < 18) return erro('O titular precisa ter 18 anos ou mais.', form.elements.t_nascimento);
			if (!v('t_religiao')) return erro('Informe a religião do titular.', form.elements.t_religiao);
			if (v('t_religiao') === 'Outra' && !v('t_religiao_outra')) return erro('Escreva qual é a religião.', form.elements.t_religiao_outra);
			var t = dig(v('t_celular')); if (t.length < 10) return erro('Informe o celular com DDD.', form.elements.t_celular);
			if (v('t_email') && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v('t_email'))) return erro('E-mail inválido.', form.elements.t_email);
		}
		if (n === 3) {
			var faltando = ['logradouro', 'numero', 'bairro', 'cidade', 'uf'].filter(function (c) { return !v(c); });
			if (faltando.length) return erro('Preencha o endereço completo.', form.elements[faltando[0]]);
			if (v('uf').length !== 2) return erro('UF com 2 letras (ex.: BA).', form.elements.uf);
		}
		if (n === 4) {
			var lista = pessoas();
			for (var j = 0; j < lista.length; j++) {
				var x = lista[j];
				if (!x.parentesco) return erro('Escolha o parentesco da pessoa ' + (j + 1) + '.', x.el.querySelector('[data-f="parentesco"]'));
				if (!dataOk(x.nascimento)) return erro('Informe a data de nascimento da pessoa ' + (j + 1) + '.', x.el.querySelector('[data-f="nascimento"]'));
				if (x.cpf && !cpfOk(x.cpf)) return erro('CPF inválido na pessoa ' + (j + 1) + ' (pode deixar em branco).', x.el.querySelector('[data-f="cpf"]'));
				if (x.cpf && dig(x.cpf) === dig(v('t_cpf'))) return erro('A pessoa ' + (j + 1) + ' está com o CPF do titular.', x.el.querySelector('[data-f="cpf"]'));
			}
			var r = calcular(); if (r && r.erro) return erro(r.erro);
		}
		if (n === 5) {
			if (!form.elements.aceite_termo.checked) return erro('Marque o aceite das condições do Termo de Adesão.', form.elements.aceite_termo);
			if (!form.elements.aceite_religiao.checked) return erro('Marque a autorização do uso da religião.', form.elements.aceite_religiao);
		}
		return true;
	}

	function revisao() {
		var r = atualizar(), k = plano();
		var rel = v('t_religiao') === 'Outra' ? v('t_religiao_outra') : v('t_religiao');
		var h = '<dl class="adesao-rev">' +
			linha('Plano', esc(k) + ' · ' + brl(r.mensal) + '/mês') +
			linha('Titular', esc(v('t_nome')) + '<br><small>CPF ' + esc(v('t_cpf')) + ' · ' + esc(rel) + ' · ' + esc(v('t_celular')) + '</small>') +
			linha('Endereço', esc(v('logradouro') + ', ' + v('numero') + (v('complemento') ? ' · ' + v('complemento') : '') + ' · ' + v('bairro') + ' · ' + v('cidade') + '-' + v('uf').toUpperCase())) + '</dl>';
		if (r.lista.length) {
			h += '<h3 class="adesao-rev__tit">Família</h3><ul class="adesao-rev__lista">' + r.lista.map(function (x) {
				var tag = k === 'FLEX' ? 'Incluído' : x.tipo === 'dependente' ? 'Dependente' : (x.paga ? 'Agregado · + ' + brl(PL[k].valor_agregado) : 'Agregado · sem custo');
				return '<li><span>' + esc(x.nome || (PAR[x.parentesco] || {}).rotulo) + ' <small>' + esc((PAR[x.parentesco] || {}).rotulo) + ' · ' + idade(x.nascimento) + ' anos</small></span><em>' + tag + '</em></li>';
			}).join('') + '</ul>';
		} else {
			h += '<p class="nota">Só o titular. Você pode incluir pessoas depois, com a equipe.</p>';
		}
		var s = raiz.querySelector('[data-sucessor]');
		if (s.value !== '') h += '<p class="nota">Sucessor indicado: <strong>' + esc(s.options[s.selectedIndex].text) + '</strong></p>';
		h += '<div class="adesao-total"><span>Adesão a pagar hoje</span><strong>' + brl(r.adesao) + '</strong></div>';
		raiz.querySelector('[data-revisao]').innerHTML = h;
		btnAv.textContent = 'Ir para o pagamento · ' + brl(r.adesao);
	}

	function ir(n) {
		etapa = n;
		form.querySelectorAll('[data-etapa]').forEach(function (f) { f.hidden = +f.getAttribute('data-etapa') !== n; });
		raiz.querySelectorAll('[data-ir]').forEach(function (li) {
			var m = +li.getAttribute('data-ir');
			li.className = m === n ? 'ativo' : (m < n ? 'feito' : '');
		});
		btnVo.hidden = n === 1;
		btnAv.textContent = 'Continuar';
		if (n === 4 && !pessoasBox.children.length && plano() !== '') { /* começa vazio de propósito */ }
		if (n === 5) revisao();
		erro('');
		var topo = raiz.getBoundingClientRect().top + window.scrollY - 90;
		if (window.scrollY > topo) window.scrollTo({ top: topo, behavior: 'smooth' });
	}
	btnVo.addEventListener('click', function () { if (etapa > 1) ir(etapa - 1); });
	raiz.querySelectorAll('[data-ir]').forEach(function (li) {
		li.addEventListener('click', function () { var m = +li.getAttribute('data-ir'); if (m < etapa) ir(m); });
	});
	btnAv.addEventListener('click', function () {
		if (!validar(etapa)) return;
		if (etapa < 5) { ir(etapa + 1); return; }
		enviar();
	});
	form.addEventListener('submit', function (e) { e.preventDefault(); });

	function enviar() {
		if (enviando) return;
		enviando = true;
		var texto = btnAv.textContent;
		btnAv.disabled = true; btnAv.textContent = 'Gravando o cadastro…';
		var qs = new URLSearchParams(location.search), origem = [];
		['utm_source', 'utm_medium', 'utm_campaign'].forEach(function (k) { if (qs.get(k)) origem.push(k.replace('utm_', '') + '=' + qs.get(k)); });
		if (document.referrer) origem.push('ref=' + document.referrer.slice(0, 120));
		var s = raiz.querySelector('[data-sucessor]').value;
		var corpo = {
			acao: 'cadastrar',
			plano: plano(),
			titular: {
				nome: v('t_nome'), cpf: dig(v('t_cpf')), nascimento: v('t_nascimento'),
				religiao: v('t_religiao') === 'Outra' ? 'Outra: ' + v('t_religiao_outra') : v('t_religiao'),
				celular: dig(v('t_celular')), email: v('t_email')
			},
			endereco: { cep: dig(v('cep')), logradouro: v('logradouro'), numero: v('numero'), complemento: v('complemento'), bairro: v('bairro'), cidade: v('cidade'), uf: v('uf').toUpperCase() },
			pessoas: pessoas().map(function (x) { return { parentesco: x.parentesco, nascimento: x.nascimento, nome: x.nome, cpf: dig(x.cpf), religiao: x.religiao }; }),
			sucessor: s === '' ? null : +s,
			aceite_termo: form.elements.aceite_termo.checked,
			aceite_religiao: form.elements.aceite_religiao.checked,
			site: v('site'),
			origem: origem.join(' · ')
		};
		fetch(cfg.api, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(corpo), credentials: 'omit' })
			.then(function (r) { return r.json().catch(function () { return { erro: true, msg: 'Resposta inesperada do servidor.' }; }); },
				function () { return { erro: true, msg: 'Sem conexão. Confira a internet e tente de novo.' }; })
			.then(function (j) {
				if (!j || j.erro || !j.codigo) {
					enviando = false; btnAv.disabled = false; btnAv.textContent = texto;
					erro((j && j.msg) || 'Não foi possível gravar o cadastro.');
					return;
				}
				if (window.fbq) { try { fbq('track', 'InitiateCheckout', { value: j.valor_adesao, currency: 'BRL', content_name: 'Plano ' + j.plano }); } catch (e) {} }
				if (window.gtag) { try { gtag('event', 'begin_checkout', { value: j.valor_adesao, currency: 'BRL', items: [{ item_name: 'Adesão ' + j.plano }] }); } catch (e) {} }
				btnAv.textContent = 'Abrindo o pagamento…';
				location.href = cfg.pagar + '?c=' + encodeURIComponent(j.codigo);
			});
	}

	/* Plano vindo da URL (?plano=flex) */
	var pedido = (new URLSearchParams(location.search).get('plano') || '').toUpperCase();
	var radio = pedido && form.querySelector('input[name="plano"][value="' + pedido + '"]:not([disabled])');
	if (radio) { radio.checked = true; }
	atualizar();
	if (radio) ir(2);
})();
