/* rc16 (11/11/2026): envio de homenagem pelas páginas /enviar-homenagem-sala-01/ a 03 (page-homenagem-sala.php).
 * Mesmo contrato de antes com o homenagens.php: GET acao=carregar_sala e POST acao=enviar_homenagem.
 * Diferenças: roda assim que o arquivo carrega (não depende do aviso de "página carregada", que podia já ter
 * passado e deixava o botão parado em "Verificando atendimento..."); foto reduzida no celular antes de enviar. */
(function () {
	'use strict';

	var raiz = document.querySelector('[data-homenagem]');
	if (!raiz) { return; }

	var API = raiz.getAttribute('data-api');
	var SALA = raiz.getAttribute('data-sala');
	var FOTO_MAX_LADO = 1600;
	var FOTO_MAX_BYTES = 15 * 1024 * 1024; // antes de reduzir
	var VIDEO_MAX_BYTES = 100 * 1024 * 1024;

	function $(sel) { return raiz.querySelector(sel); }
	var el = {
		para: $('[data-hm-para]'), periodo: $('[data-hm-periodo]'), tentar: $('[data-hm-tentar]'),
		form: $('[data-hm-form]'), nome: $('[data-hm-nome]'), fone: $('[data-hm-fone]'),
		imagens: $('[data-hm-imagens]'), escolher: $('[data-hm-escolher]'), arquivo: $('[data-hm-arquivo]'),
		previa: $('[data-hm-previa]'), msg: $('[data-hm-msg]'), cont: $('[data-hm-cont]'),
		aviso: $('[data-hm-aviso]'), enviar: $('[data-hm-enviar]'), legado: $('[data-hm-legado]')
	};

	var estado = { homenagem: null, predef: '', arquivo: null, tipoArquivo: '', urlPrevia: '', legado: '' };

	/** Link do Legado de Luz (memorial com as homenagens aprovadas), que já vem na resposta da sala. */
	function linkLegado(h) {
		var u = String((h && (h.link_publico || h.legado_luz_link)) || '');
		return /^https:\/\/(www\.)?planoassistencialintegrado\.com\.br\//i.test(u) ? u : '';
	}

	function digitos(v) { return String(v || '').replace(/\D+/g, ''); }

	function avisar(tipo, texto, link) {
		el.aviso.hidden = !texto;
		el.aviso.textContent = texto || '';
		if (texto && link) {
			var a = document.createElement('a');
			a.href = link; a.target = '_blank'; a.rel = 'noopener';
			a.className = 'homenagem__aviso-link';
			a.textContent = 'Ver no Legado de Luz →';
			el.aviso.appendChild(document.createTextNode(' '));
			el.aviso.appendChild(a);
		}
		el.aviso.className = 'homenagem__aviso' + (tipo ? ' homenagem__aviso--' + tipo : '');
		el.aviso.setAttribute('role', tipo === 'erro' ? 'alert' : 'status');
		if (texto) { el.aviso.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
	}

	function dataHora(v) {
		if (!v) { return ''; }
		var d = new Date(String(v).replace(' ', 'T'));
		if (isNaN(d.getTime())) { return String(v); }
		return d.toLocaleDateString('pt-BR') + ' às ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
	}

	function lerJson(resp) {
		return resp.json().catch(function () { return null; }).then(function (data) {
			if (!resp.ok || !data) { throw new Error((data && data.msg) || 'Não foi possível falar com o servidor. Verifique a internet e tente de novo.'); }
			if (data.erro) { throw new Error(data.msg || 'Não foi possível concluir. Tente de novo.'); }
			return data;
		});
	}

	/* ---------- 1. Atendimento ativo da sala ---------- */
	function carregarSala() {
		el.tentar.hidden = true;
		el.legado.hidden = true;
		el.para.textContent = 'Buscando o atendimento da Sala ' + SALA + '…';
		el.periodo.textContent = '';
		var url = API + '?acao=carregar_sala&sala=' + encodeURIComponent(SALA) + '&cache_bust=' + Date.now();
		fetch(url, { method: 'GET', credentials: 'include', cache: 'no-store', headers: { Accept: 'application/json' } })
			.then(lerJson)
			.then(function (data) {
				if (!data.sucesso || !data.aberto || !data.homenagem || !data.homenagem.atendimento_id) {
					estado.homenagem = null;
					el.form.hidden = true;
					el.para.textContent = 'No momento não há velório na Sala ' + SALA + '.';
					el.periodo.textContent = 'Se você está no velório agora, aguarde um instante e toque em "Tentar de novo".';
					el.tentar.hidden = false;
					return;
				}
				estado.homenagem = data.homenagem;
				estado.legado = linkLegado(data.homenagem);
				if (estado.legado) { el.legado.href = estado.legado; el.legado.hidden = false; }
				var falecido = data.homenagem.falecido || 'atendimento ativo';
				el.para.textContent = 'Homenagem para ' + falecido;
				var p = data.periodo_envio || data.homenagem || {};
				var ini = dataHora(p.inicio), fim = dataHora(p.fim);
				el.periodo.textContent = 'Sala ' + SALA + (ini && fim ? ' · velório de ' + ini + ' até ' + fim : '');
				el.form.hidden = false;
			})
			.catch(function (e) {
				estado.homenagem = null;
				el.form.hidden = true;
				el.para.textContent = 'Não foi possível carregar a Sala ' + SALA + '.';
				el.periodo.textContent = e && e.message ? e.message : '';
				el.tentar.hidden = false;
			});
	}

	/* ---------- 2. Imagem pronta, foto ou vídeo ---------- */
	function limparPrevia() {
		if (estado.urlPrevia) { try { URL.revokeObjectURL(estado.urlPrevia); } catch (e) {} }
		estado.urlPrevia = '';
		el.previa.textContent = '';
		el.previa.hidden = true;
	}

	function mostrarPrevia(src, video, legenda) {
		limparPrevia();
		var m = document.createElement(video ? 'video' : 'img');
		m.src = src;
		if (video) { m.controls = true; m.preload = 'metadata'; m.playsInline = true; } else { m.alt = ''; }
		var c = document.createElement('p');
		c.className = 'homenagem__legenda';
		c.textContent = legenda;
		el.previa.appendChild(m);
		el.previa.appendChild(c);
		el.previa.hidden = false;
	}

	function marcarPredef(btn) {
		el.imagens.querySelectorAll('[data-hm-predef]').forEach(function (b) { b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'); });
	}

	el.imagens.addEventListener('click', function (ev) {
		var btn = ev.target.closest('[data-hm-predef]');
		if (!btn) { return; }
		estado.predef = btn.getAttribute('data-hm-predef');
		estado.arquivo = null; estado.tipoArquivo = '';
		el.arquivo.value = '';
		marcarPredef(btn);
		mostrarPrevia(estado.predef, false, 'Imagem escolhida para acompanhar sua mensagem.');
		avisar('', '');
	});

	el.escolher.addEventListener('click', function () { el.arquivo.click(); });

	el.arquivo.addEventListener('change', function () {
		var f = el.arquivo.files && el.arquivo.files[0];
		if (!f) { return; }
		var tipo = /^image\//i.test(f.type) ? 'foto' : (/^video\//i.test(f.type) ? 'video' : '');
		if (!tipo) { el.arquivo.value = ''; avisar('erro', 'Envie só foto ou vídeo.'); return; }
		if (tipo === 'foto' && f.size > FOTO_MAX_BYTES) { el.arquivo.value = ''; avisar('erro', 'A foto é grande demais (máximo 15 MB).'); return; }
		if (tipo === 'video' && f.size > VIDEO_MAX_BYTES) { el.arquivo.value = ''; avisar('erro', 'O vídeo deve ter até 100 MB.'); return; }
		estado.arquivo = f; estado.tipoArquivo = tipo; estado.predef = '';
		marcarPredef(null);
		var url = URL.createObjectURL(f);
		mostrarPrevia(url, tipo === 'video', (tipo === 'video' ? 'Vídeo: ' : 'Foto: ') + f.name);
		estado.urlPrevia = url;
		avisar('', '');
	});

	el.msg.addEventListener('input', function () { el.cont.textContent = String(el.msg.value.length); });

	function lerComoDataUrl(blob) {
		return new Promise(function (ok, falha) {
			var r = new FileReader();
			r.onload = function () { ok(String(r.result || '')); };
			r.onerror = function () { falha(new Error('Não foi possível ler o arquivo.')); };
			r.readAsDataURL(blob);
		});
	}

	/** Foto reduzida para no máximo 1600 px (JPEG). Se o navegador não conseguir, manda a original. */
	function fotoReduzida(arquivo) {
		return new Promise(function (ok) {
			var url = URL.createObjectURL(arquivo);
			var img = new Image();
			img.onload = function () {
				try {
					var w = img.naturalWidth, h = img.naturalHeight;
					var esc = Math.min(1, FOTO_MAX_LADO / Math.max(w, h));
					var cv = document.createElement('canvas');
					cv.width = Math.max(1, Math.round(w * esc));
					cv.height = Math.max(1, Math.round(h * esc));
					var ctx = cv.getContext('2d');
					ctx.fillStyle = '#ffffff';
					ctx.fillRect(0, 0, cv.width, cv.height);
					ctx.drawImage(img, 0, 0, cv.width, cv.height);
					var dados = cv.toDataURL('image/jpeg', 0.85);
					URL.revokeObjectURL(url);
					if (dados.indexOf('data:image/jpeg') === 0) { ok({ dados: dados, nome: arquivo.name.replace(/\.[^.]+$/, '') + '.jpg' }); return; }
				} catch (e) { /* cai para a original */ }
				URL.revokeObjectURL(url);
				lerComoDataUrl(arquivo).then(function (d) { ok({ dados: d, nome: arquivo.name }); }, function () { ok(null); });
			};
			img.onerror = function () {
				URL.revokeObjectURL(url);
				lerComoDataUrl(arquivo).then(function (d) { ok({ dados: d, nome: arquivo.name }); }, function () { ok(null); });
			};
			img.src = url;
		});
	}

	function imagemPronta(src) {
		return fetch(src, { cache: 'force-cache' }).then(function (r) {
			if (!r.ok) { throw new Error('Não foi possível carregar a imagem escolhida.'); }
			return r.blob();
		}).then(lerComoDataUrl);
	}

	/* ---------- 3. Enviar ---------- */
	function chaveSessao() {
		var base = [SALA, estado.homenagem && estado.homenagem.atendimento_id, el.nome.value, digitos(el.fone.value),
			estado.predef || (estado.arquivo ? estado.arquivo.name + ':' + estado.arquivo.size : ''), el.msg.value].join('|');
		var h = 0;
		for (var i = 0; i < base.length; i++) { h = ((h << 5) - h + base.charCodeAt(i)) | 0; }
		return 'pai_homenagem_sala' + SALA + '_' + h;
	}
	function jaEnviada(k) { try { return !!window.sessionStorage.getItem(k); } catch (e) { return false; } }
	function marcarEnviada(k) { try { window.sessionStorage.setItem(k, '1'); } catch (e) {} }

	function validar() {
		if (!estado.homenagem) { return 'Não há velório ativo na Sala ' + SALA + ' agora.'; }
		if (!el.nome.value.trim()) { el.nome.focus(); return 'Preencha o seu nome.'; }
		if (digitos(el.fone.value).length < 8) { el.fone.focus(); return 'Preencha o telefone com DDD.'; }
		if (!estado.predef && !estado.arquivo) { return 'Escolha uma das 4 imagens ou envie uma foto ou vídeo.'; }
		if (!el.msg.value.trim()) { el.msg.focus(); return 'Escreva a sua mensagem.'; }
		return '';
	}

	function ocupado(sim) {
		el.enviar.disabled = sim;
		el.enviar.textContent = sim ? 'Enviando…' : 'Enviar homenagem';
	}

	function limparFormulario() {
		el.form.reset();
		estado.predef = ''; estado.arquivo = null; estado.tipoArquivo = '';
		marcarPredef(null);
		limparPrevia();
		el.cont.textContent = '0';
	}

	el.form.addEventListener('submit', function (ev) {
		ev.preventDefault();
		var erro = validar();
		if (erro) { avisar('erro', erro); return; }
		var chave = chaveSessao();
		if (jaEnviada(chave)) { avisar('erro', 'Essa mesma homenagem já foi enviada.'); return; }

		ocupado(true);
		avisar('info', estado.tipoArquivo === 'video' ? 'Enviando o vídeo… pode levar alguns minutos, não feche a página.' : 'Enviando homenagem…');

		var tipo = estado.arquivo ? estado.tipoArquivo : 'foto';
		var preparo;
		if (estado.arquivo && tipo === 'foto') {
			preparo = fotoReduzida(estado.arquivo).then(function (r) {
				if (!r) { throw new Error('Não foi possível ler a foto.'); }
				return r;
			});
		} else if (estado.arquivo) {
			preparo = lerComoDataUrl(estado.arquivo).then(function (d) { return { dados: d, nome: estado.arquivo.name || 'video-homenagem.mp4' }; });
		} else {
			preparo = imagemPronta(estado.predef).then(function (d) { return { dados: d, nome: estado.predef.split('/').pop() || 'imagem-homenagem.png' }; });
		}

		preparo.then(function (arq) {
			return fetch(API, {
				method: 'POST',
				credentials: 'include',
				cache: 'no-store',
				headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
				body: JSON.stringify({
					acao: 'enviar_homenagem',
					atendimento_id: estado.homenagem.atendimento_id || estado.homenagem.legado_luz_atendimento_id,
					codigo: estado.homenagem.codigo_homenagem || estado.homenagem.slug || '',
					tipo: tipo,
					nome_visitante: el.nome.value.trim(),
					telefone_visitante: digitos(el.fone.value),
					mensagem: el.msg.value.trim(),
					arquivo_base64: arq.dados,
					arquivo_nome: arq.nome
				})
			});
		}).then(function (resp) {
			if (resp.status === 413) { throw new Error('O arquivo é grande demais para enviar. Escolha um vídeo menor ou uma das imagens.'); }
			return lerJson(resp);
		}).then(function (data) {
			marcarEnviada(chave);
			limparFormulario();
			if (data.status === 'aprovado') {
				avisar('ok', 'Homenagem enviada e aprovada. Ela já aparece na tela da sala. Obrigado!', estado.legado);
			} else if (data.status === 'pendente') {
				avisar('ok', 'Homenagem enviada. Ela aparece na tela da sala e no Legado de Luz depois da aprovação. Obrigado!');
			} else {
				avisar('ok', data.msg || 'Homenagem recebida. Obrigado!');
			}
		}).catch(function (e) {
			avisar('erro', (e && e.message) || 'Não foi possível enviar. Tente de novo.');
		}).then(function () { ocupado(false); });
	});

	el.tentar.addEventListener('click', carregarSala);

	carregarSala();
})();
