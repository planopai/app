/* rc19 (12/11/2026): TV de mensagens dentro da sala (page-mensagens-tv.php).
 * Mesma fonte de dados das páginas antigas: legadodeluztv.php?sala=NN
 * (tv_ativa, atendimento, approvedMessages, recentes, contadores).
 * - busca a cada 15 s; mensagens novas entram quando a volta completa termina (a rolagem nunca "pula");
 *   troca de atendimento ou fim do velório entram na hora;
 * - os cartões sobem de um em um a cada 10 s, sem voltar ao início (o primeiro vai para o fim da lista);
 * - a mensagem aparece inteira: a letra diminui até caber no cartão;
 * - se a internet cair, mantém na tela o que já estava;
 * - recarrega a página uma vez por dia de madrugada (TV ligada por dias não trava). */
(function () {
	'use strict';

	var raiz = document.querySelector('[data-mt]');
	if (!raiz) { return; }

	var API = raiz.getAttribute('data-api');
	var SALA = raiz.getAttribute('data-sala');
	var LOGO = raiz.getAttribute('data-logo');
	var BUSCA_MS = 15000;
	var PASSO_MS = 10000;
	var ANIM_MS = 950;
	var VISIVEIS = 2;

	var el = {
		lista: raiz.querySelector('[data-mt-lista]'),
		tot: raiz.querySelector('[data-mt-tot]'),
		rot: raiz.querySelector('[data-mt-rot]'),
		fotoBox: raiz.querySelector('[data-mt-foto-box]'),
		foto: raiz.querySelector('[data-mt-foto]'),
		nome: raiz.querySelector('[data-mt-nome]'),
		datas: raiz.querySelector('[data-mt-datas]'),
		hora: raiz.querySelector('[data-mt-hora]'),
		data: raiz.querySelector('[data-mt-data]'),
		estrelas: document.querySelector('[data-mt-estrelas]')
	};

	var st = {
		assinatura: '',
		atendimentoId: null,
		ativa: false,
		pendente: null,
		buscando: false,
		timerPasso: null,
		timerFim: null,
		passo: 0,
		total: 0,
		ciclo: 0,
		animando: false,
		ceuAssinatura: '',
		fotoAtual: null
	};
	var abertoEm = Date.now();

	/* ---------- utilidades ---------- */
	function txt(v) { return String(v == null ? '' : v).trim(); }
	function p2(n) { n = String(n); return n.length < 2 ? '0' + n : n; }
	function num(v) { var n = Number(v); return isFinite(n) ? n : 0; }
	function dataBR(v) {
		var c = txt(v);
		var m = c.match(/^(\d{4})-(\d{2})-(\d{2})/);
		if (m) { return m[3] + '/' + m[2] + '/' + m[1]; }
		if (!c || c === '0000-00-00' || c.toLowerCase() === 'null') { return ''; }
		return c;
	}
	function urlSegura(u) {
		u = txt(u);
		return /^https?:\/\//i.test(u) ? u : '';
	}
	function ehImagem(u) {
		return /\.(jpe?g|png|webp|gif|bmp)$/i.test(String(u || '').split('?')[0]);
	}
	// Altura de referência: a altura da tela deitada (em TV em pé, a que teria a mesma largura deitada).
	function vh(f) { return Math.min(window.innerHeight, window.innerWidth * 9 / 16) * f; }

	/* ---------- relógio ---------- */
	var DIAS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
	function relogio() {
		var d = new Date();
		el.hora.textContent = p2(d.getHours()) + ':' + p2(d.getMinutes());
		el.data.textContent = DIAS[d.getDay()] + ', ' + p2(d.getDate()) + '/' + p2(d.getMonth() + 1);
		// Recarrega uma vez por dia, entre 3h30 e 3h45, se a página está aberta há mais de 2 horas.
		if (d.getHours() === 3 && d.getMinutes() >= 30 && d.getMinutes() < 45 && Date.now() - abertoEm > 7200000) {
			location.reload();
		}
	}

	/* ---------- estrelas que piscam (mais estrelas acesas = mais estrelas no céu) ---------- */
	function sorteio(semente) { var x = Math.sin(semente) * 10000; return x - Math.floor(x); }
	function desenharCeu(totalEstrelas, semente) {
		var t = Math.max(0, Math.min(120, num(totalEstrelas)));
		var assin = semente + '|' + t;
		if (assin === st.ceuAssinatura || !el.estrelas) { return; }
		st.ceuAssinatura = assin;
		var q = Math.round(34 + (t / 120) * 30);
		var base = num(String(semente).replace(/\D/g, '')) || 17;
		var frag = document.createDocumentFragment();
		var simbolos = ['✦', '✶', '✷', '✸'];
		for (var i = 0; i < q; i++) {
			var s = document.createElement('i');
			s.textContent = simbolos[i % 4];
			s.style.cssText = 'left:' + (3 + sorteio(base + i * 11.17) * 94).toFixed(2) + '%;top:' + (4 + sorteio(base + i * 37.41) * 90).toFixed(2) +
				'%;font-size:' + (0.6 + sorteio(base + i * 71.13) * 0.8).toFixed(2) + 'vh;animation-delay:' + (sorteio(base + i * 97.27) * 5).toFixed(2) +
				's;animation-duration:' + (4.8 + sorteio(base + i * 19.91) * 4).toFixed(2) + 's';
			frag.appendChild(s);
		}
		el.estrelas.textContent = '';
		el.estrelas.appendChild(frag);
	}

	/* ---------- ajustes de tamanho ---------- */
	function caberNaLargura(alvo, largura, min, max) {
		var t = max;
		alvo.style.fontSize = t + 'px';
		var g = 60;
		while (g-- > 0 && t > min && alvo.scrollWidth > largura + 1) {
			t *= 0.97;
			alvo.style.fontSize = t + 'px';
		}
	}
	function ajustarPerfil() {
		var largura = el.fotoBox.offsetWidth;
		el.rot.style.fontSize = '';
		el.datas.style.fontSize = '';
		// TV deitada: "EM MEMÓRIA" e as datas com a largura da foto. TV em pé: tamanho do CSS.
		if (largura && window.innerWidth > window.innerHeight) {
			caberNaLargura(el.rot, largura, vh(0.03), vh(0.09));
			el.datas.style.display = 'inline-flex';
			caberNaLargura(el.datas, largura, vh(0.02), vh(0.042));
			el.datas.style.display = '';
		}
		var span = el.nome.firstElementChild;
		el.nome.style.fontSize = '';
		var tam = parseFloat(getComputedStyle(el.nome).fontSize);
		var g = 40;
		while (g-- > 0 && tam > vh(0.03) && (span.offsetHeight > el.nome.clientHeight + 1 || span.scrollWidth > el.nome.clientWidth + 1 || span.offsetHeight / (tam * 1.06) > 3.3)) {
			tam *= 0.93;
			el.nome.style.fontSize = tam + 'px';
		}
	}
	function ajustarCartao(card) {
		var caixa = card.querySelector('.mt-txt');
		var msg = card.querySelector('.mt-msg');
		if (!caixa || !msg) { return; }
		msg.style.fontSize = '';
		var tam = parseFloat(getComputedStyle(msg).fontSize);
		var g = 40;
		while (g-- > 0 && tam > vh(0.022) && caixa.scrollHeight > caixa.clientHeight + 1) {
			tam *= 0.94;
			msg.style.fontSize = tam + 'px';
		}
	}
	function ajustarTudo() {
		ajustarPerfil();
		Array.prototype.forEach.call(el.lista.querySelectorAll('.mt-card'), ajustarCartao);
		st.passo = medirPasso();
	}

	/* ---------- dados ---------- */
	function normalizar(i) {
		i = i || {};
		return {
			id: i.id || '',
			nome: txt(i.name || i.nome_visitante) || 'Visitante',
			texto: txt(i.text || i.mensagem),
			imagem: txt(i.image || i.arquivo_url || i.foto),
			tipo: txt(i.tipo).toLowerCase(),
			rotulo: txt(i.tipo_label).toLowerCase(),
			icone: txt(i.tipo_icon),
			criado: i.criado_em || ''
		};
	}
	function ehEstrela(m) {
		return m.tipo === 'vela' || m.tipo === 'estrela' || m.rotulo.indexOf('estrela') >= 0 || m.icone.indexOf('⭐') >= 0 || m.icone.indexOf('★') >= 0;
	}
	function separar(mensagens, recentes) {
		var homenagens = [], estrelas = 0, vistos = {};
		(Array.isArray(recentes) ? recentes : []).forEach(function (r) { if (ehEstrela(normalizar(r))) { estrelas++; } });
		(Array.isArray(mensagens) ? mensagens : []).forEach(function (r) {
			var m = normalizar(r);
			if (ehEstrela(m)) { estrelas++; return; }
			var foto = m.imagem && (m.tipo === 'foto' || m.tipo === 'imagem' || ehImagem(m.imagem));
			if (!foto && !m.texto) { return; }
			var chave = m.id + '|' + m.nome + '|' + m.criado + '|' + m.texto + '|' + m.imagem;
			if (vistos[chave]) { return; }
			vistos[chave] = true;
			homenagens.push(m);
		});
		return { homenagens: homenagens, estrelas: estrelas };
	}
	function totalEstrelas(contadores, contadas) {
		contadores = contadores || {};
		if (contadores.estrelas_acendidas !== undefined) { return num(contadores.estrelas_acendidas); }
		if (contadores.vela !== undefined) { return num(contadores.vela); }
		return contadas;
	}
	function assinaturaDe(dados) {
		var a = dados.atendimento || {};
		var partes = [a.id || ''];
		(Array.isArray(dados.approvedMessages) ? dados.approvedMessages : []).forEach(function (m) {
			m = m || {};
			partes.push(m.id || '', m.tipo || '', m.name || m.nome_visitante || '', m.text || m.mensagem || '', m.image || m.arquivo_url || '');
		});
		return partes.join('|');
	}

	/* ---------- falecido ---------- */
	function desenharFalecido(a) {
		a = a || {};
		var nome = txt(a.falecido || a.nome_completo) || 'Legado de Luz';
		var span = el.nome.firstElementChild;
		if (span.textContent !== nome) { span.textContent = nome; }

		var n = dataBR(a.data_nascimento), f = dataBR(a.data_falecimento);
		el.datas.textContent = '';
		[['✦ ', n], ['✝ ', f]].forEach(function (par) {
			if (!par[1]) { return; }
			var s = document.createElement('span');
			s.appendChild(document.createTextNode(par[0]));
			var b = document.createElement('b');
			b.textContent = par[1];
			s.appendChild(b);
			el.datas.appendChild(s);
		});

		var foto = urlSegura(a.foto_falecido);
		if (foto !== st.fotoAtual) {
			st.fotoAtual = foto;
			el.fotoBox.classList.toggle('mt-foto--sem', !foto);
			el.foto.onerror = function () { el.foto.onerror = null; el.foto.src = LOGO; el.fotoBox.classList.add('mt-foto--sem'); };
			el.foto.src = foto || LOGO;
		}
	}

	function desenharTotais(qtdHomenagens, qtdEstrelas) {
		el.tot.textContent = '';
		function parte(n, um, varios) {
			var b = document.createElement('b');
			b.textContent = String(n);
			el.tot.appendChild(b);
			el.tot.appendChild(document.createTextNode(' ' + (n === 1 ? um : varios)));
		}
		parte(qtdHomenagens, 'homenagem', 'homenagens');
		if (qtdEstrelas > 0) {
			el.tot.appendChild(document.createTextNode(' · '));
			parte(qtdEstrelas, 'estrela', 'estrelas');
		}
	}

	/* ---------- cartões ---------- */
	function cartao(m) {
		var art = document.createElement('article');
		var temFoto = !!urlSegura(m.imagem) && ehImagem(m.imagem);
		art.className = 'mt-card' + (temFoto ? '' : ' mt-card--txt');
		if (temFoto) {
			var th = document.createElement('div');
			th.className = 'mt-thumb';
			var img = document.createElement('img');
			img.alt = '';
			img.decoding = 'async';
			img.src = urlSegura(m.imagem);
			img.onerror = function () { th.style.visibility = 'hidden'; };
			th.appendChild(img);
			art.appendChild(th);
		}
		// Sem foto: a faixa amarela é o ::before do cartão (ocupa a 1ª coluna da grade).
		var caixa = document.createElement('div');
		caixa.className = 'mt-txt';
		var quem = document.createElement('p');
		quem.className = 'mt-quem';
		quem.textContent = m.nome;
		var msg = document.createElement('p');
		msg.className = 'mt-msg' + (m.texto ? '' : ' mt-msg--foto');
		msg.textContent = m.texto || (temFoto ? 'Enviou uma foto em homenagem.' : 'Registrou uma homenagem.');
		caixa.appendChild(quem);
		caixa.appendChild(msg);
		art.appendChild(caixa);
		return art;
	}

	function pararRolagem() {
		clearInterval(st.timerPasso);
		clearTimeout(st.timerFim);
		st.timerPasso = null;
		st.timerFim = null;
		st.animando = false;
		st.ciclo = 0;
		el.lista.style.transition = 'none';
		el.lista.style.transform = 'translate3d(0,0,0)';
	}

	function medirPasso() {
		var primeiro = el.lista.querySelector('.mt-card');
		if (!primeiro) { return 0; }
		var cs = getComputedStyle(el.lista);
		return primeiro.getBoundingClientRect().height + (parseFloat(cs.rowGap || cs.gap) || 0);
	}

	function desenharLista(homenagens) {
		pararRolagem();
		el.lista.textContent = '';
		st.total = homenagens.length;
		if (!homenagens.length) {
			var vazio = document.createElement('div');
			vazio.className = 'mt-aguarda';
			vazio.innerHTML = '<b aria-hidden="true">✧</b><strong>Aguardando homenagens</strong><span>As fotos e mensagens aprovadas aparecem aqui automaticamente.</span>';
			el.lista.appendChild(vazio);
			return;
		}
		// Com 3 ou mais, a lista roda sem fim; com 1 ou 2, ficam paradas na tela.
		homenagens.forEach(function (m) { el.lista.appendChild(cartao(m)); });
		Array.prototype.forEach.call(el.lista.children, ajustarCartao);
		if (homenagens.length > VISIVEIS) {
			st.passo = medirPasso();
			st.timerPasso = setInterval(avancar, PASSO_MS);
		}
	}

	function avancar() {
		if (st.animando) { return; }
		st.passo = st.passo || medirPasso();
		if (!st.passo) { return; }
		st.animando = true;
		el.lista.style.transition = 'transform ' + ANIM_MS + 'ms ease-in-out';
		el.lista.style.transform = 'translate3d(0,-' + st.passo + 'px,0)';
		st.timerFim = setTimeout(function () {
			// O primeiro cartão vai para o fim e a lista volta ao ponto zero sem animação: a rolagem nunca volta.
			var primeiro = el.lista.firstElementChild;
			if (primeiro) { el.lista.appendChild(primeiro); }
			el.lista.style.transition = 'none';
			el.lista.style.transform = 'translate3d(0,0,0)';
			void el.lista.offsetHeight;
			st.animando = false;
			st.ciclo++;
			if (st.ciclo >= st.total) {
				st.ciclo = 0;
				if (st.pendente) { var d = st.pendente; st.pendente = null; aplicar(d, true); }
			}
		}, ANIM_MS + 30);
	}

	/* ---------- aplicar dados ---------- */
	function telaPadrao() {
		pararRolagem();
		el.lista.textContent = '';
		st.assinatura = '';
		st.atendimentoId = null;
		st.ativa = false;
		st.pendente = null;
		document.body.classList.add('mt--padrao');
		desenharCeu(90, 'padrao');
	}

	function aplicar(dados, forcar) {
		if (!dados || typeof dados !== 'object') { return; }
		if (!dados.tv_ativa) { telaPadrao(); return; }

		var a = dados.atendimento || {};
		var trocouAtendimento = !st.ativa || String(a.id || '') !== String(st.atendimentoId);
		var rodando = !!st.timerPasso;
		var assin = assinaturaDe(dados);
		var sep = separar(dados.approvedMessages, dados.recentes);
		var estrelas = totalEstrelas(dados.contadores, sep.estrelas);

		// Nome, foto, datas e totais atualizam na hora (não mexem na rolagem).
		desenharFalecido(a);
		desenharTotais(sep.homenagens.length, estrelas);
		desenharCeu(estrelas, a.id || 'sala' + SALA);

		if (assin === st.assinatura) { st.pendente = null; ajustarPerfil(); return; }

		// Mensagens novas esperam a volta completa terminar, para a lista não pular no meio da leitura.
		if (!forcar && rodando && !trocouAtendimento) { st.pendente = dados; return; }

		st.assinatura = assin;
		st.atendimentoId = a.id || '';
		st.ativa = true;
		st.pendente = null;
		document.body.classList.remove('mt--padrao');
		ajustarPerfil();
		desenharLista(sep.homenagens);
	}

	function buscar() {
		if (st.buscando) { return; }
		st.buscando = true;
		var url = API + (API.indexOf('?') < 0 ? '?' : '&') + 'sala=' + encodeURIComponent(SALA) + '&cache_bust=' + Date.now();
		var ctrl = window.AbortController ? new AbortController() : null;
		var limite = ctrl ? setTimeout(function () { ctrl.abort(); }, 10000) : null;
		fetch(url, { cache: 'no-store', credentials: 'include', signal: ctrl ? ctrl.signal : undefined })
			.then(function (r) { if (!r.ok) { throw new Error('HTTP ' + r.status); } return r.json(); })
			.then(function (dados) { aplicar(dados, false); })
			.catch(function (e) {
				// Mantém na tela o que já estava; só fica na tela padrão se nunca carregou.
				if (window.console && console.warn) { console.warn('[mensagens-tv]', e && e.message ? e.message : e); }
			})
			.then(function () { st.buscando = false; if (limite) { clearTimeout(limite); } });
	}

	/* ---------- TV acordada ---------- */
	function manterAcordada() {
		try {
			if (navigator.wakeLock && navigator.wakeLock.request) { navigator.wakeLock.request('screen').catch(function () {}); }
		} catch (e) { /* TV sem suporte: tudo bem */ }
	}
	document.addEventListener('visibilitychange', function () {
		if (document.visibilityState === 'visible') { manterAcordada(); buscar(); }
	});
	var timerResize = null;
	window.addEventListener('resize', function () {
		clearTimeout(timerResize);
		timerResize = setTimeout(function () {
			el.lista.style.transition = 'none';
			el.lista.style.transform = 'translate3d(0,0,0)';
			ajustarTudo();
		}, 200);
	});

	relogio();
	setInterval(relogio, 15000);
	desenharCeu(90, 'inicio');
	manterAcordada();
	var pronto = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
	pronto.then(function () { buscar(); }, function () { buscar(); });
	setInterval(buscar, BUSCA_MS);
})();
