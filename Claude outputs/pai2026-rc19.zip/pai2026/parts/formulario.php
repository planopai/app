<?php
/**
 * Página com formulário do Forminator.
 * $args: trilha, eyebrow, titulo, lead, form (ID do formulário), lado (HTML da coluna ao lado).
 */
$a = wp_parse_args( $args, array( 'trilha' => '', 'eyebrow' => '', 'titulo' => '', 'lead' => '', 'form' => 0, 'lado' => '' ) );
pai_topo( $a['trilha'], $a['eyebrow'], $a['titulo'], $a['lead'] );
?>
<section class="secao secao--sem-topo">
	<div class="wrap duas-colunas duas-colunas--form">
		<div class="pilha pilha--p"><?php echo wp_kses_post( $a['lado'] ); ?></div>
		<div class="card form-pai">
			<?php
			if ( shortcode_exists( 'forminator_form' ) ) {
				echo do_shortcode( '[forminator_form id="' . (int) $a['form'] . '"]' );
			} else {
				// Sem o plugin do formulário, mostra o conteúdo original da página.
				while ( have_posts() ) {
					the_post();
					the_content();
				}
			}
			?>
		</div>
	</div>
</section>
