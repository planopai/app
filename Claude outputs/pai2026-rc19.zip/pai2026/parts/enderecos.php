<?php
/**
 * Sede e Memorial, com mapa que só carrega quando chega na tela.
 */
$sede     = pai_opt( 'end_sede' );
$memorial = pai_opt( 'end_memorial' );
$mapa     = 'https://www.google.com/maps?q=' . rawurlencode( 'Memorial Senhor do Bonfim, ' . $memorial ) . '&output=embed';
?>
<section class="secao secao--alt">
	<div class="wrap grade-enderecos">
		<div class="card pilha pilha--pp">
			<p class="eyebrow">Sede Plano PAI</p>
			<p class="card__tit card__tit--p"><?php echo esc_html( $sede ); ?></p>
			<a class="link-forte" href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( 'Plano PAI, ' . $sede ) ); ?>" target="_blank" rel="noopener">Como chegar ›</a>
		</div>
		<div class="card pilha pilha--pp">
			<p class="eyebrow">Memorial Senhor do Bonfim</p>
			<p class="card__tit card__tit--p"><?php echo esc_html( $memorial ); ?></p>
			<p class="card__txt">Aberto 24 horas</p>
			<a class="link-forte" href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( 'Memorial Senhor do Bonfim, ' . $memorial ) ); ?>" target="_blank" rel="noopener">Como chegar ›</a>
		</div>
		<div class="mapa">
			<iframe title="Mapa do Memorial Senhor do Bonfim" src="<?php echo esc_url( $mapa ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</div>
	</div>
</section>
