<?php
/**
 * Cartão compacto de artigo (Guia, categorias, busca e "Leia também"):
 * foto quadrada pequena, categoria e tempo de leitura, título e resumo curtos.
 * O cartão inteiro leva ao artigo.
 */
?>
<article class="artigo-c">
	<span class="artigo-c__foto" aria-hidden="true">
		<?php
		if ( has_post_thumbnail() ) {
			the_post_thumbnail( 'medium', array( 'loading' => 'lazy', 'decoding' => 'async', 'alt' => '' ) );
		} else {
			echo '<img class="artigo-c__marca" src="' . pai_img( 'icone-branco.svg' ) . '" alt="" loading="lazy">';
		}
		?>
	</span>
	<div class="artigo-c__txt">
		<?php echo pai_meta_artigo(); // phpcs:ignore ?>
		<h2 class="artigo-c__tit"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<p class="artigo-c__resumo"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
	</div>
</article>
