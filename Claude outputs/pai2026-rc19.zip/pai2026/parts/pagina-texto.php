<?php
/**
 * Páginas de texto (Termos, Política de Privacidade). Se a página foi feita no
 * Elementor, o tema pega só os textos; senão, mostra o conteúdo normal.
 */
while ( have_posts() ) :
	the_post();
	pai_topo( get_the_title(), 'Plano PAI', get_the_title() );
	$texto = pai_feito_no_elementor( get_the_ID() ) ? pai_el_texto( get_the_ID() ) : '';
	?>
	<section class="secao secao--sem-topo">
		<div class="wrap wrap--texto texto">
			<?php
			if ( '' !== trim( wp_strip_all_tags( $texto ) ) ) {
				echo $texto; // phpcs:ignore -- já passou por wp_kses_post
			} else {
				the_content();
			}
			?>
			<p class="nota">Última atualização: <?php echo esc_html( get_the_modified_date( 'd/m/Y' ) ); ?></p>
		</div>
	</section>
	<?php
endwhile;
