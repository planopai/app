<?php
/**
 * Topo do Guia: o artigo mais recente em destaque e os próximos em lista ao lado.
 * $args['posts']: lista de WP_Post (o primeiro vira o destaque).
 */
$lista = isset( $args['posts'] ) ? (array) $args['posts'] : array();
if ( ! $lista ) {
	return;
}
global $post;
$primeiro = array_shift( $lista );
?>
<div class="guia-destaque">
	<?php
	$post = $primeiro; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	setup_postdata( $post );
	?>
	<article class="artigo-d">
		<?php if ( has_post_thumbnail() ) : ?>
			<span class="artigo-d__foto" aria-hidden="true"><?php the_post_thumbnail( 'large', array( 'decoding' => 'async', 'alt' => '' ) ); ?></span>
		<?php endif; ?>
		<div class="artigo-d__txt">
			<?php echo pai_meta_artigo(); // phpcs:ignore ?>
			<h2 class="artigo-d__tit"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<p class="artigo-c__resumo"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
			<span class="link-forte" aria-hidden="true">Ler artigo ›</span>
		</div>
	</article>
	<?php if ( $lista ) : ?>
		<ul class="guia-lista">
			<?php
			foreach ( $lista as $p ) :
				$post = $p; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
				setup_postdata( $post );
				?>
				<li>
					<?php echo pai_meta_artigo( true ); // phpcs:ignore ?>
					<h3 class="guia-lista__tit"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
<?php
wp_reset_postdata();
