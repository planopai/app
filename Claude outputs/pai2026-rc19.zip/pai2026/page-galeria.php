<?php
/**
 * Página /galeria/: fotos do Memorial, salas, frota...
 * As fotos e os grupos continuam no Elementor da página (Image Grid).
 */
get_header();
pai_topo( 'Galeria', 'Nossa estrutura', 'Galeria de fotos', 'Conheça o Memorial Senhor do Bonfim, as salas de velório, a frota e a sede do Plano PAI.' );

$g = pai_el_galeria( get_queried_object_id() );
?>

<section class="secao secao--sem-topo">
	<div class="wrap pilha">
		<?php if ( $g['fotos'] ) : ?>
			<?php if ( count( $g['grupos'] ) > 1 ) : ?>
				<div class="abas" role="group" aria-label="Filtrar fotos" data-filtro>
					<button type="button" class="aba" aria-pressed="true" data-grupo="">Todas</button>
					<?php foreach ( $g['grupos'] as $nome ) : ?>
						<button type="button" class="aba" aria-pressed="false" data-grupo="<?php echo esc_attr( sanitize_title( $nome ) ); ?>"><?php echo esc_html( $nome ); ?></button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<ul class="grade-fotos" data-fotos>
				<?php foreach ( $g['fotos'] as $i => $f ) : ?>
					<li data-grupo="<?php echo esc_attr( sanitize_title( $f['grupo'] ) ); ?>">
						<a href="<?php echo esc_url( $f['cheia'] ? $f['cheia'] : $f['url'] ); ?>" data-ampliar>
							<img src="<?php echo esc_url( $f['url'] ); ?>" alt="<?php echo esc_attr( $f['alt'] ? $f['alt'] : $f['grupo'] ); ?>" loading="<?php echo $i < 6 ? 'eager' : 'lazy'; ?>" decoding="async">
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
			<dialog class="ampliada" data-ampliada aria-label="Foto ampliada">
				<button type="button" class="ampliada__fechar" data-fechar aria-label="Fechar"><?php echo pai_icone( 'fechar', 26 ); ?></button>
				<img src="" alt="">
				<p class="ampliada__leg"></p>
			</dialog>
		<?php else : ?>
			<div class="conteudo-elementor"><?php the_content(); ?></div>
		<?php endif; ?>
		<div class="botoes">
			<a class="btn btn-verde" href="<?php echo esc_url( pai_wa( 'Olá, vi a galeria no site e gostaria de mais informações.' ) ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 20 ); ?>Falar com a gente</a>
			<a class="btn btn-line" href="<?php echo esc_url( pai_url( 'sobre-nos' ) ); ?>">Sobre nós</a>
		</div>
	</div>
</section>

<?php
get_template_part( 'parts/enderecos' );
get_footer();
