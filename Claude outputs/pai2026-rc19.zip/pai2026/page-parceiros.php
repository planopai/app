<?php
/**
 * Página /parceiros/ e as páginas de cada especialidade (/cardiologista/, /pediatra/...).
 * Os parceiros continuam sendo cadastrados no Elementor de cada especialidade
 * (uma imagem + um botão "Entre em Contato" por parceiro). O tema lê e mostra no visual novo.
 */
get_header();

$esp    = pai_especialidades();
$atual  = get_post_field( 'post_name', get_queried_object_id() );
$e_lista = ! isset( $esp[ $atual ] );

/** Parceiros de uma especialidade (lidos da página dela). */
$parceiros_de = function ( $slug ) {
	$p = get_page_by_path( $slug );
	return $p ? pai_el_itens( $p->ID ) : array();
};

$cartoes = function ( $itens, $nome ) {
	if ( ! $itens ) {
		echo '<p class="nota">Em breve, novos parceiros nesta especialidade.</p>';
		return;
	}
	echo '<ul class="grade-parceiros">';
	foreach ( $itens as $it ) {
		$alt = $it['alt'] ? $it['alt'] : 'Parceiro ' . $nome;
		echo '<li class="card parceiro">';
		echo '<span class="parceiro__foto"><img src="' . esc_url( $it['img'] ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async"></span>';
		if ( $it['link'] ) {
			list( $rot, $ico ) = pai_tipo_contato( $it['link'] );
			$externo = 0 === strpos( $it['link'], 'http' );
			echo '<a class="btn btn-verde parceiro__btn" href="' . esc_url( $it['link'] ) . '"' . ( $externo ? ' target="_blank" rel="noopener"' : '' ) . '>' . pai_icone( $ico, 18 ) . esc_html( $rot ) . '</a>';
		}
		echo '</li>';
	}
	echo '</ul>';
};

if ( $e_lista ) {
	pai_topo( 'Parceiros', 'Clube de benefícios', 'Parceiros Plano PAI', 'Profissionais e clínicas de Barreiras com condições especiais para associados. Apresente sua carteirinha ou o app do PAI no atendimento.' );
} else {
	echo '<section class="topo-pagina">' . pai_marca_dagua( 'wm--topo' ) . '<div class="wrap pilha pilha--p topo-pagina__in">';
	echo '<nav class="trilha" aria-label="Você está em"><a href="' . esc_url( home_url( '/' ) ) . '">Início</a> <span aria-hidden="true">›</span> <a href="' . esc_url( pai_url( 'parceiros' ) ) . '">Parceiros</a> <span aria-hidden="true">›</span> <span>' . esc_html( $esp[ $atual ] ) . '</span></nav>';
	echo '<p class="eyebrow">Parceiros Plano PAI</p><h1 class="display display--m">' . esc_html( $esp[ $atual ] ) . '</h1>';
	echo '<p class="lead">Condições especiais para associados. Apresente sua carteirinha ou o app do PAI no atendimento.</p></div></section>';
}
?>

<section class="secao secao--sem-topo">
	<div class="wrap pilha">
		<nav class="abas abas--rolagem" aria-label="Especialidades">
			<a class="aba" href="<?php echo esc_url( pai_url( 'parceiros' ) ); ?>" <?php echo $e_lista ? 'aria-current="page"' : ''; ?>>Todas</a>
			<?php foreach ( $esp as $slug => $nome ) : ?>
				<a class="aba" href="<?php echo esc_url( pai_url( $slug ) ); ?>" <?php echo $slug === $atual ? 'aria-current="page"' : ''; ?>><?php echo esc_html( $nome ); ?></a>
			<?php endforeach; ?>
		</nav>

		<?php
		if ( $e_lista ) {
			foreach ( $esp as $slug => $nome ) {
				$itens = $parceiros_de( $slug );
				if ( ! $itens ) {
					continue;
				}
				echo '<div class="pilha pilha--p" id="' . esc_attr( $slug ) . '"><h2 class="subtit"><a class="link-titulo" href="' . esc_url( pai_url( $slug ) ) . '">' . esc_html( $nome ) . '</a></h2>';
				$cartoes( $itens, $nome );
				echo '</div>';
			}
		} else {
			$cartoes( pai_el_itens( get_queried_object_id() ), $esp[ $atual ] );
		}
		?>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow eyebrow--verde">Tem um negócio em Barreiras?</p>
			<h2 class="h2">Seja nosso parceiro</h2>
		</div>
		<div class="pilha pilha--p">
			<p class="lead">Ofereça condições especiais aos associados do Plano PAI e apresente seu trabalho às famílias associadas da região.</p>
			<a class="btn btn-sol alinha-ini" href="<?php echo esc_url( pai_url( 'seja-nosso-parceiro' ) ); ?>">Quero ser parceiro</a>
		</div>
	</div>
</section>

<?php
get_footer();
