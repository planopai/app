<?php
/**
 * Página /seja-nosso-parceiro/ (formulário Forminator 2190).
 */
get_header();
get_template_part( 'parts/formulario', null, array(
	'trilha'  => 'Seja nosso parceiro',
	'eyebrow' => 'Clube de benefícios',
	'titulo'  => 'Seja nosso parceiro',
	'lead'    => 'Ofereça condições especiais aos associados do Plano PAI e apresente seu negócio às famílias associadas de Barreiras e região.',
	'form'    => 2190,
	'lado'    => '<h2 class="subtit">Como funciona</h2><ul class="lista-check"><li>Você define o desconto ou a condição especial</li><li>Sua empresa aparece na página de parceiros do site</li><li>O associado apresenta a carteirinha ou o app no atendimento</li></ul><p class="nota"><a href="' . esc_url( pai_url( 'parceiros' ) ) . '">Ver os parceiros atuais ›</a></p>',
) );
get_footer();
