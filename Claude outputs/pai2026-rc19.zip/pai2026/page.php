<?php
/**
 * Páginas comuns. Se a página foi montada no Elementor, mostra o conteúdo dela
 * na largura toda (até ser refeita no visual novo). Se não, usa o layout de texto.
 */
get_header();

while ( have_posts() ) :
	the_post();
	if ( pai_feito_no_elementor( get_the_ID() ) && class_exists( '\Elementor\Plugin' ) ) :
		?>
		<div class="conteudo-elementor"><?php the_content(); ?></div>
		<?php
	elseif ( pai_feito_no_elementor( get_the_ID() ) && pai_migracao_tem_exportacao( get_post_field( 'post_name', get_the_ID() ) ) ) :
		pai_migracao_render( get_post_field( 'post_name', get_the_ID() ) );
	else :
		?>
		<section class="topo-pagina">
			<?php echo pai_marca_dagua( 'wm--topo' ); ?>
			<div class="wrap pilha pilha--p topo-pagina__in">
				<?php pai_trilha( get_the_title() ); ?>
				<h1 class="display display--m"><?php the_title(); ?></h1>
			</div>
		</section>
		<section class="secao secao--sem-topo">
			<div class="wrap <?php echo ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) ? 'loja' : 'wrap--texto texto'; ?>">
				<?php the_content(); ?>
			</div>
		</section>
		<?php
	endif;
endwhile;

get_footer();
