<?php
/**
 * Página /planos-funerarios/: simulador e comparativo.
 */
get_header();
$pr = pai_precos();

$cfg = array(
	'flex'      => $pr['flex'],
	'translado' => $pr['translado'],
	'whats'     => pai_digitos( pai_opt( 'whatsapp' ) ),
	'planos'    => array(
		'LIGHT' => array( 'base' => $pr['light'], 'adesao' => $pr['ad_lf'], 'maxExtras' => 2, 'free' => 0, 'per' => $pr['ex_light'], 'who' => 'Cônjuge, filhos solteiros e pais ou sogros já estão incluídos.', 'help' => 'Outras pessoas podem entrar como dependentes extras: até 2, por R$ ' . pai_reais( $pr['ex_light'], true ) . ' cada.' ),
		'FLEX'  => array( 'base' => 0, 'adesao' => $pr['ad_lf'], 'who' => 'Titular + até 9 dependentes de qualquer parentesco.' ),
		'PLUS'  => array( 'base' => $pr['plus'], 'adesao' => $pr['ad_pm'], 'maxExtras' => 9, 'free' => 2, 'per' => $pr['ex_plus'], 'who' => 'Cônjuge, filhos solteiros, pais ou sogros já estão incluídos, e mais 2 pessoas à sua escolha, sem custo.', 'help' => 'Outras pessoas entram como dependentes extras: as 2 primeiras sem custo; a partir da 3ª, R$ ' . pai_reais( $pr['ex_plus'], true ) . ' cada.' ),
		'MAX'   => array( 'base' => $pr['max'], 'adesao' => $pr['ad_pm'], 'maxExtras' => 9, 'free' => 2, 'per' => $pr['ex_max'], 'who' => 'Os mesmos dependentes do PLUS, com translado pelo Brasil e telemedicina incluída.', 'help' => 'Outras pessoas entram como dependentes extras: as 2 primeiras sem custo; a partir da 3ª, R$ ' . pai_reais( $pr['ex_max'], true ) . ' cada.' ),
	),
);
$idades = array( 'Até 54 anos', '55 a 64', '65 a 74', '75 ou mais' );
?>

<section class="topo-pagina">
	<?php echo pai_marca_dagua( 'wm--topo' ); ?>
	<a class="capsula capsula--lateral esconde-md" href="<?php echo esc_url( pai_wa( 'Olá! Tenho dúvidas sobre os planos.' ) ); ?>" aria-label="Tirar dúvidas no WhatsApp, <?php echo esc_attr( pai_opt( 'whatsapp' ) ); ?>">
		<span class="capsula__contorno" aria-hidden="true"></span>
		<span class="capsula__ico capsula__ico--verde"><?php echo pai_icone( 'whats', 24 ); ?></span>
		<span class="capsula__txt">
			<span class="capsula__rot">DÚVIDAS? FALE COM A GENTE</span>
			<span class="capsula__num capsula__num--m"><?php echo esc_html( pai_opt( 'whatsapp' ) ); ?></span>
			<span class="capsula__sub">WhatsApp</span>
		</span>
	</a>
	<div class="wrap pilha pilha--p topo-pagina__in">
		<?php pai_trilha( 'Planos funerários' ); ?>
		<h1 class="eyebrow">Planos funerários em Barreiras&#8209;BA</h1>
		<p class="display display--m">Escolha o plano certo em 1 minuto</p>
		<p class="lead">Selecione o plano, informe a família e veja na hora o valor da mensalidade.</p>
	</div>
</section>

<section class="secao secao--sem-topo" id="simulador">
	<div class="wrap simulador" data-simulador="<?php echo esc_attr( wp_json_encode( $cfg ) ); ?>">
		<form class="simulador__form" onsubmit="return false">
			<fieldset class="sim-passo">
				<legend class="sim-passo__tit">1. Qual plano?</legend>
				<div class="pilulas">
					<?php foreach ( array( 'LIGHT', 'FLEX', 'PLUS', 'MAX' ) as $nome ) : ?>
						<label class="pilula"><input type="radio" name="plano" value="<?php echo esc_attr( $nome ); ?>" <?php checked( 'FLEX', $nome ); ?>><span><?php echo esc_html( $nome ); ?></span></label>
					<?php endforeach; ?>
				</div>
				<p class="sim-ajuda" data-quem><?php echo esc_html( $cfg['planos']['FLEX']['who'] ); ?></p>
			</fieldset>

			<fieldset class="sim-passo" data-so="flex">
				<legend class="sim-passo__tit">2. Idade da pessoa mais velha do plano</legend>
				<div class="pilulas">
					<?php foreach ( $idades as $i => $rot ) : ?>
						<label class="pilula"><input type="radio" name="idade" value="<?php echo (int) $i; ?>" <?php checked( 0, $i ); ?>><span><?php echo esc_html( $rot ); ?> · R$ <?php echo esc_html( pai_reais( $pr['flex'][ $i ] ) ); ?></span></label>
					<?php endforeach; ?>
				</div>
				<p class="sim-ajuda">No FLEX entram o titular e até 9 dependentes de qualquer parentesco com vínculo familiar, sem custo por pessoa.</p>
			</fieldset>

			<fieldset class="sim-passo" data-so="extras" hidden>
				<legend class="sim-passo__tit">2. Dependentes extras</legend>
				<p class="sim-ajuda" data-extras-ajuda></p>
				<div class="contador">
					<button type="button" class="contador__btn" data-menos aria-label="Remover dependente extra">−</button>
					<output class="contador__num" data-extras aria-live="polite">0</output>
					<button type="button" class="contador__btn" data-mais aria-label="Adicionar dependente extra">+</button>
					<span class="sim-ajuda" data-limite></span>
				</div>
			</fieldset>

			<fieldset class="sim-passo" data-so="aditivos">
				<legend class="sim-passo__tit">3. Quer acrescentar?</legend>
				<label class="opcao" data-so="flex"><input type="checkbox" name="tanato"><span><strong>Tanatopraxia</strong> · +20% na mensalidade<br><span class="sim-ajuda">Conservação do corpo para velórios mais longos. Carência própria de 90 dias.</span></span></label>
				<label class="opcao"><input type="checkbox" name="nacional"><span><strong>Translado Nacional “De Volta pra Casa”</strong> · +R$ <?php echo esc_html( pai_reais( $pr['translado'] ) ); ?>/mês<br><span class="sim-ajuda">Translado terrestre de qualquer cidade do Brasil até a cidade de residência ou natal.</span></span></label>
			</fieldset>
		</form>

		<aside class="resumo faixa-escura" aria-live="polite">
			<?php echo pai_marca_dagua( 'wm--card' ); ?>
			<p class="eyebrow eyebrow--sol">Seu plano</p>
			<p class="resumo__plano">Plano <span data-r-plano>FLEX</span></p>
			<div>
				<p class="resumo__rot">Mensalidade</p>
				<p class="resumo__valor" data-r-mensal>R$ <?php echo esc_html( pai_reais( $pr['flex'][0], true ) ); ?></p>
			</div>
			<dl class="resumo__linhas" data-r-linhas>
				<div><dt>Taxa de adesão (uma vez)</dt><dd>R$ <?php echo esc_html( pai_reais( $pr['ad_lf'], true ) ); ?></dd></div>
				<div><dt>Faixa de idade</dt><dd>Até 54 anos</dd></div>
				<div><dt>Carência</dt><dd>90 dias · 24 h acidental</dd></div>
			</dl>
			<a class="btn btn-sol" data-r-contratar href="<?php echo esc_url( add_query_arg( 'plano', 'flex', home_url( '/adesao/' ) ) ); ?>">Contratar agora</a>
			<a class="btn btn-claro" data-r-whats href="<?php echo esc_url( pai_wa( 'Olá! Quero saber mais sobre o Plano FLEX, simulado no site.' ) ); ?>">Enviar simulação no WhatsApp</a>
			<p class="resumo__nota">Telemedicina: incluída no MAX; no FLEX e no PLUS, contratada à parte.</p>
		</aside>
	</div>
</section>

<section class="secao secao--alt" id="comparativo">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Comparativo</p>
			<h2 class="h2">Tudo o que cada plano cobre</h2>
		</div>
		<div class="tabela-rolagem">
			<table class="comparativo">
				<thead>
					<tr><th scope="col"><span class="sr">Item</span></th><th scope="col">LIGHT</th><th scope="col" class="col-flex">FLEX</th><th scope="col">PLUS</th><th scope="col" class="col-max">MAX</th></tr>
				</thead>
				<tbody>
					<tr><th scope="row">Mensalidade</th><td><strong>R$ <?php echo esc_html( pai_reais( $pr['light'] ) ); ?></strong></td><td class="col-flex"><strong>R$ <?php echo esc_html( pai_reais( $pr['flex'][0] ) ); ?> a R$ <?php echo esc_html( pai_reais( $pr['flex'][3] ) ); ?></strong><br>pela idade do mais velho</td><td><strong>R$ <?php echo esc_html( pai_reais( $pr['plus'] ) ); ?></strong></td><td class="col-max"><strong>R$ <?php echo esc_html( pai_reais( $pr['max'] ) ); ?></strong></td></tr>
					<tr><th scope="row">Adesão</th><td>R$ <?php echo esc_html( pai_reais( $pr['ad_lf'] ) ); ?></td><td class="col-flex">R$ <?php echo esc_html( pai_reais( $pr['ad_lf'] ) ); ?></td><td>R$ <?php echo esc_html( pai_reais( $pr['ad_pm'] ) ); ?></td><td class="col-max">R$ <?php echo esc_html( pai_reais( $pr['ad_pm'] ) ); ?></td></tr>
					<tr><th scope="row">Quem entra</th><td>Cônjuge, filhos solteiros, pais ou sogros; outras pessoas: até 2, por R$ <?php echo esc_html( pai_reais( $pr['ex_light'], true ) ); ?> cada</td><td class="col-flex">Titular + até 9, qualquer parentesco</td><td>Cônjuge, filhos solteiros, pais ou sogros e mais 2 pessoas à sua escolha, sem custo; a partir da 3ª, R$ <?php echo esc_html( pai_reais( $pr['ex_plus'], true ) ); ?> cada</td><td class="col-max">Os mesmos do PLUS; a partir da 3ª pessoa extra, R$ <?php echo esc_html( pai_reais( $pr['ex_max'], true ) ); ?> cada</td></tr>
					<tr><th scope="row">Urna e roupa</th><td>Semiluxo</td><td class="col-flex">Semiluxo</td><td>Luxo</td><td class="col-max">Luxo</td></tr>
					<tr><th scope="row">Coroa e véu</th><td>Coroa artificial de 60 cm, tule ou véu</td><td class="col-flex">Coroa natural ou artificial, tule ou véu</td><td>Coroa natural de 1,10 m, véu de luxo</td><td class="col-max">Coroa natural de 1,10 m, véu de luxo</td></tr>
					<tr><th scope="row">Translado</th><td>Até 200 km</td><td class="col-flex">Até 500 km</td><td>Até 1.000 km</td><td class="col-max">Brasil todo, terrestre, sem limite de km</td></tr>
					<tr><th scope="row">Tanatopraxia</th><td>Não disponível</td><td class="col-flex">Por aditivo (+20%)</td><td>Incluída</td><td class="col-max">Incluída</td></tr>
					<tr><th scope="row">Translado Nacional</th><td>Não disponível</td><td class="col-flex">Por aditivo (+R$ <?php echo esc_html( pai_reais( $pr['translado'] ) ); ?>)</td><td>Por aditivo (+R$ <?php echo esc_html( pai_reais( $pr['translado'] ) ); ?>)</td><td class="col-max">Incluído</td></tr>
					<tr><th scope="row">Telemedicina</th><td>Não disponível</td><td class="col-flex">À parte</td><td>À parte</td><td class="col-max">Incluída, sem carência</td></tr>
					<tr><th scope="row">Urna pet</th><td>—</td><td class="col-flex">Incluída</td><td>—</td><td class="col-max">—</td></tr>
					<tr class="comparativo__links"><th scope="row"><span class="sr">Detalhes</span></th><?php foreach ( array( 'light' => '', 'flex' => 'col-flex', 'plus' => '', 'max' => 'col-max' ) as $k => $cl ) : ?><td class="<?php echo esc_attr( $cl ); ?>"><a class="link-forte" href="<?php echo esc_url( pai_url( 'planos-funerarios/' . $k ) ); ?>">Ver o <?php echo esc_html( strtoupper( $k ) ); ?> ›</a></td><?php endforeach; ?></tr>
					<tr><th scope="row">Em todos</th><td colspan="4">Ornamentação do corpo, kit lanche, carro funerário, sala no Memorial Senhor do Bonfim, assistência funerária e paramentação para velório em casa.</td></tr>
				</tbody>
			</table>
		</div>
		<p class="nota">Carência de 90 dias para morte natural e de 24 horas para causa acidental. Valores conforme os Termos de Adesão.</p>
	</div>
</section>

<?php
// Texto extra escrito no editor da página (opcional), mostrado abaixo do comparativo.
while ( have_posts() ) :
	the_post();
	if ( trim( get_post_field( 'post_content', get_the_ID() ) ) && ! pai_feito_no_elementor( get_the_ID() ) ) :
		?>
		<section class="secao"><div class="wrap texto"><?php the_content(); ?></div></section>
		<?php
	endif;
endwhile;

get_footer();
