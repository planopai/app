<?php
/**
 * rc17 (12/11/2026): painéis das salas na TV (/painel-01/, /painel-02/ e /painel-03/).
 *
 * Página em tela cheia, sem cabeçalho nem rodapé do site. Os dados continuam vindo do mesmo lugar de antes
 * (/sala01.php, /sala02.php, /sala03.php no domínio principal), então o painel mostra exatamente o que já mostrava.
 * O QR code fica sempre na tela e leva ao endereço curto /h1, /h2 ou /h3 (redireciona para /enviar-homenagem-sala-0N/).
 * Para voltar ao Elementor numa delas: campo personalizado pai_usar_elementor = 1 na página.
 * Nome da sala: campo personalizado pai_nome_sala na página (se vazio, usa o padrão de pai_nomes_salas()).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sala    = pai_painel_sala();
$nome    = trim( (string) get_post_meta( get_queried_object_id(), 'pai_nome_sala', true ) );
if ( '' === $nome ) {
	$nomes = pai_nomes_salas();
	$nome  = isset( $nomes[ $sala ] ) ? $nomes[ $sala ] : '';
}
$dados   = home_url( '/sala' . $sala . '.php' );
$qr      = PAI_URI . '/assets/img/qr-sala-' . $sala . '.svg';
$fontes  = PAI_URI . '/assets/fonts/';
?><!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Painel · Sala <?php echo esc_html( $sala ); ?></title>
<link rel="preload" href="<?php echo esc_url( $fontes . 'nunito-900.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
<style>
@font-face{font-family:Nunito;src:url(<?php echo esc_url( $fontes . 'nunito-800.woff2' ); ?>) format('woff2');font-weight:800;font-display:swap}
@font-face{font-family:Nunito;src:url(<?php echo esc_url( $fontes . 'nunito-900.woff2' ); ?>) format('woff2');font-weight:900;font-display:swap}
</style>
<link rel="stylesheet" href="<?php echo esc_url( PAI_URI . '/assets/css/painel-sala.css?ver=' . rawurlencode( PAI_VER ) ); ?>">
</head>
<body>
<div class="pn" data-painel data-sala="<?php echo esc_attr( $sala ); ?>" data-fonte="<?php echo esc_url( $dados ); ?>" data-uploads="<?php echo esc_url( home_url( '/uploads/' ) ); ?>">

	<header class="pn-topo">
		<img class="pn-logo" src="<?php echo esc_url( PAI_URI . '/assets/img/logo-pai-escuro.svg' ); ?>" alt="PAI">
		<h1 class="pn-sala">SALA <?php echo esc_html( $sala ); ?><?php if ( '' !== $nome ) : ?> <em><?php echo esc_html( mb_strtoupper( $nome, 'UTF-8' ) ); ?></em><?php endif; ?></h1>
		<p class="pn-hora"><span data-pn-hora>--:--</span><small data-pn-data></small></p>
	</header>

	<main class="pn-palco" data-pn-palco aria-live="polite">
		<div class="pn-vazio" data-pn-vazio>
			<img src="<?php echo esc_url( PAI_URI . '/assets/img/logo-pai-escuro.svg' ); ?>" alt="">
			<p>Carregando…</p>
		</div>
	</main>

	<aside class="pn-qr" data-pn-qr hidden>
		<p class="pn-qr__eyebrow">Homenagem</p>
		<h2>Deixe sua mensagem<br>de conforto</h2>
		<div class="pn-qr__cod"><i class="c1"></i><i class="c2"></i><i class="c3"></i><i class="c4"></i><img src="<?php echo esc_url( $qr ); ?>" alt="QR code para enviar homenagem para a Sala <?php echo esc_attr( $sala ); ?>"></div>
		<p class="pn-qr__cam">Aponte a câmera do celular</p>
		<div class="pn-pontos" data-pn-pontos></div>
	</aside>
</div>

<template data-pn-modelo-memoria>
	<section class="pn-slide pn-memoria">
		<p class="pn-rot">Em memória</p>
		<div class="pn-foto"><img alt="" data-c="foto"></div>
		<div class="pn-lado">
			<p class="pn-nome" data-c="nome"></p>
			<p class="pn-datas" data-c="datas"></p>
		</div>
	</section>
</template>

<template data-pn-modelo-sepultamento>
	<section class="pn-slide pn-sepult">
		<div class="pn-linha"><span class="pn-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/></svg></span><div><p class="pn-k">Sepultamento</p><p class="pn-v" data-c="data"></p></div></div>
		<div class="pn-linha"><span class="pn-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></span><div><p class="pn-k">Horário</p><p class="pn-v" data-c="hora"></p></div></div>
		<div class="pn-linha"><span class="pn-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/></svg></span><div><p class="pn-k">Local</p><p class="pn-v" data-c="local"></p></div></div>
	</section>
</template>

<script src="<?php echo esc_url( PAI_URI . '/assets/js/painel-sala.js?ver=' . rawurlencode( PAI_VER ) ); ?>" defer></script>
</body>
</html>
