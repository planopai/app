<?php
/**
 * Página /tutoriais/.
 * Para incluir um tutorial, acrescente uma linha em $tutoriais (título, descrição, link).
 */
get_header();
pai_topo( 'Tutoriais', 'Instruções de uso', 'Tutoriais', 'Passo a passo para aproveitar os benefícios do seu plano.' );

$tutoriais = array(
	array( 'Primeiro cadastro no Clube de Benefícios', 'Como criar seu acesso e começar a usar os descontos.', 'https://drive.google.com/file/d/1nn-pH-jaIrP_VSPPnWc6GD3kwXtQAEWI/view?usp=drive_link' ),
	array( 'Ativação dos descontos em farmácias', 'Como ativar o desconto nas farmácias parceiras.', '' ),
);
?>

<section class="secao secao--sem-topo">
	<div class="wrap grade-3">
		<?php foreach ( $tutoriais as $t ) : ?>
			<?php if ( $t[2] ) : ?>
				<a class="card card--link pilha pilha--pp" href="<?php echo esc_url( $t[2] ); ?>" target="_blank" rel="noopener">
					<h2 class="card__tit card__tit--p"><?php echo esc_html( $t[0] ); ?></h2>
					<p class="card__txt"><?php echo esc_html( $t[1] ); ?></p>
					<span class="link-forte">Abrir o tutorial ›</span>
				</a>
			<?php else : ?>
				<div class="card pilha pilha--pp">
					<h2 class="card__tit card__tit--p"><?php echo esc_html( $t[0] ); ?></h2>
					<p class="card__txt"><?php echo esc_html( $t[1] ); ?></p>
					<span class="nota">Em breve</span>
				</div>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>
	<div class="wrap">
		<p class="nota nota--espaco">Ficou com dúvida? <a href="<?php echo esc_url( pai_wa( 'Olá, preciso de ajuda com um tutorial do site.' ) ); ?>" target="_blank" rel="noopener">Fale com o atendimento no WhatsApp</a>.</p>
	</div>
</section>

<?php
get_footer();
