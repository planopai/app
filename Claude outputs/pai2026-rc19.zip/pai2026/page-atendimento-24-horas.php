<?php
/**
 * Página /atendimento-24-horas/: o que fazer quando alguém falece.
 */
get_header();

$passos = array(
	array( 'Você liga', 'Informe o nome, onde a pessoa está e um telefone de contato. Se for associado, diga o nome do titular.' ),
	array( 'Vamos até você', 'Nossa equipe faz a remoção com carro funerário próprio, em casa, no hospital ou onde for preciso.' ),
	array( 'Organizamos o velório', 'Urna, roupa, coroa, ornamentação e sala no Memorial Senhor do Bonfim, com velório online para quem está longe.' ),
	array( 'Acompanhamos a família', 'Pelo Portal da Família você autoriza mensagens e acessa o velório online.' ),
);

$documentos = array(
	'Documento de identidade e CPF da pessoa que faleceu',
	'Declaração de Óbito emitida pelo médico, hospital ou IML',
	'Documento com foto de quem vai fazer o registro',
	'Certidão de nascimento ou de casamento da pessoa que faleceu',
	'Se for associado: nome do titular ou número do contrato',
);

$etapas = array(
	array(
		'Declaração de Óbito (DO)',
		'Emitida pelo médico, hospital ou IML',
		'<p>É o primeiro documento e é emitido por um médico. Sem ele não há registro nem sepultamento.</p><ul><li>Morte em hospital ou com acompanhamento médico: o médico que atendeu emite a DO.</li><li>Morte natural em casa, sem médico: a DO é emitida pelo serviço indicado pela rede de saúde do município. Nossa equipe orienta a família.</li><li>Morte violenta ou suspeita (acidente, por exemplo): o corpo passa pelo IML, que emite a DO.</li></ul>',
	),
	array(
		'Registro do óbito e certidão',
		'Cartório de Registro Civil · prazo de 24 h',
		'<p>Com a DO em mãos, um familiar (ou a funerária, como representante) registra o óbito no Cartório de Registro Civil do lugar do falecimento ou da residência da pessoa. O cartório emite a <strong>certidão de óbito</strong>.</p><ul><li>Prazo: até 24 horas após o falecimento; se não for possível por distância ou outro motivo relevante, pode ser feito depois, dentro dos prazos da lei.</li><li>Leve: DO, documento com foto e CPF da pessoa falecida, documento de quem declara e, se possível, certidão de nascimento ou casamento.</li><li>Podem declarar: cônjuge, filhos, parentes, pessoas presentes no falecimento, entre outros previstos em lei.</li></ul>',
	),
	array(
		'Autorização para o sepultamento',
		'Certidão de óbito + regras do cemitério',
		'<p>Nenhum sepultamento pode ser feito sem a certidão de óbito do cartório. Com ela, o cemitério libera o sepultamento.</p><p>No Plano PAI, a equipe cuida desses trâmites junto com a família.</p>',
	),
	array(
		'Cremação: o que a lei exige',
		'Vontade do falecido + atestado de 2 médicos',
		'<ul><li>A pessoa precisa ter manifestado em vida a vontade de ser cremada (ou haver interesse de saúde pública).</li><li>O atestado de óbito deve ser assinado por dois médicos ou por um médico legista.</li><li>Em caso de morte violenta, a cremação só acontece com autorização judicial.</li></ul>',
	),
);
?>

<section class="faixa-escura topo-urgente">
	<?php echo pai_marca_dagua( 'wm--topo' ); ?>
	<div class="wrap pilha topo-pagina__in">
		<?php pai_trilha( 'Atendimento 24 horas' ); ?>
		<p class="eyebrow eyebrow--sol">Plantão 24 horas, todos os dias</p>
		<h1 class="display display--m">Sentimos muito pela sua perda. Estamos aqui para cuidar de tudo.</h1>
		<p class="lead">Ligue agora. Uma pessoa da nossa equipe atende, explica cada passo e vai até você, seja associado ou não.</p>
		<div class="botoes">
			<a class="btn btn-sol btn-g" href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>"><?php echo pai_icone( 'fone', 22 ); ?><?php echo esc_html( pai_opt( 'tel_plantao' ) ); ?></a>
			<a class="btn btn-claro btn-g" href="<?php echo esc_url( pai_tel( 'tel_fixo' ) ); ?>">Fixo: <?php echo esc_html( pai_opt( 'tel_fixo' ) ); ?></a>
		</div>
	</div>
</section>

<section class="secao">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Passo a passo</p>
			<h2 class="h2">O que acontece depois da ligação</h2>
		</div>
		<ol class="grade-passos">
			<?php foreach ( $passos as $i => $p ) : ?>
				<li class="passo">
					<span class="passo__num" aria-hidden="true"><?php echo (int) $i + 1; ?></span>
					<h3 class="passo__tit"><?php echo esc_html( $p[0] ); ?></h3>
					<p class="passo__txt"><?php echo esc_html( $p[1] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow eyebrow--verde">Separe se puder</p>
			<h2 class="h2">Documentos</h2>
			<p class="lead">Não se preocupe se faltar algo: nossa equipe orienta e ajuda no registro em cartório.</p>
		</div>
		<ul class="lista-docs">
			<?php foreach ( $documentos as $d ) : ?><li><?php echo esc_html( $d ); ?></li><?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="secao">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Entenda o processo</p>
			<h2 class="h2">Do óbito ao sepultamento: o que a lei pede</h2>
			<p class="lead">Um resumo para a família entender cada etapa. Nossa equipe orienta e cuida da parte burocrática junto com você.</p>
		</div>
		<div class="etapas">
			<?php foreach ( $etapas as $i => $e ) : ?>
				<details class="etapa" <?php echo 0 === $i ? 'open' : ''; ?>>
					<summary>
						<span class="etapa__num" aria-hidden="true"><?php echo (int) $i + 1; ?></span>
						<span class="etapa__cab"><span class="etapa__tit"><?php echo esc_html( $e[0] ); ?></span><span class="etapa__sub"><?php echo esc_html( $e[1] ); ?></span></span>
						<span class="faq__mais" aria-hidden="true">+</span>
					</summary>
					<div class="etapa__corpo texto"><?php echo wp_kses_post( $e[2] ); ?></div>
				</details>
			<?php endforeach; ?>
		</div>
		<p class="nota">Base legal: Lei nº 6.015/1973 (Lei de Registros Públicos), arts. 77 a 80. Conteúdo informativo; cada caso pode ter exigências próprias.</p>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap grade-3">
		<div class="card pilha pilha--pp">
			<h2 class="card__tit card__tit--p">Não é associado?</h2>
			<p class="card__txt">Atendemos todas as famílias. A equipe apresenta as opções de urna e serviços com os valores antes de começar.</p>
		</div>
		<div class="card pilha pilha--pp">
			<h2 class="card__tit card__tit--p">Quer enviar uma coroa?</h2>
			<p class="card__txt">Escolha o modelo e a frase; entregamos direto na sala do velório.</p>
			<a class="link-forte" href="<?php echo esc_url( pai_url( 'coroas-de-flores' ) ); ?>">Ver coroas ›</a>
		</div>
		<div class="card pilha pilha--pp">
			<h2 class="card__tit card__tit--p">Memorial Senhor do Bonfim</h2>
			<p class="card__txt"><?php echo esc_html( pai_opt( 'end_memorial' ) ); ?></p>
			<a class="link-forte" href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( 'Memorial Senhor do Bonfim, ' . pai_opt( 'end_memorial' ) ) ); ?>" target="_blank" rel="noopener">Como chegar ›</a>
		</div>
	</div>
</section>

<?php
get_footer();
