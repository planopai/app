<?php
/**
 * Página não encontrada.
 */
get_header();
?>
<section class="topo-pagina">
	<?php echo pai_marca_dagua( 'wm--topo' ); ?>
	<div class="wrap pilha topo-pagina__in">
		<p class="eyebrow">Erro 404</p>
		<h1 class="display display--m">Não encontramos esta página</h1>
		<p class="lead">O endereço pode ter mudado. Veja os caminhos mais procurados:</p>
		<div class="botoes">
			<a class="btn btn-sol" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>">Planos</a>
			<a class="btn btn-line" href="<?php echo esc_url( pai_url( 'coroas-de-flores' ) ); ?>">Coroas de flores</a>
			<a class="btn btn-line" href="<?php echo esc_url( pai_url( 'atendimento-24-horas' ) ); ?>">Atendimento 24 horas</a>
			<a class="btn btn-line" href="<?php echo esc_url( home_url( '/' ) ); ?>">Página inicial</a>
		</div>
	</div>
</section>
<?php
get_footer();
