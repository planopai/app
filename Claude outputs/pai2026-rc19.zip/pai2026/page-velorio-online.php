<?php
/**
 * Página /velorio-online/: acesso às salas (com senha).
 * As salas continuam nas páginas /velorio-online-sala-01/ a 03, protegidas por senha.
 */
get_header();
pai_topo( 'Velório online', 'Para quem está longe', 'Velório online', 'Familiares e amigos podem acompanhar a cerimônia de despedida ao vivo, de qualquer lugar do mundo.' );

$salas = array(
	'01' => 'https://planoassistencialintegrado.com.br/velorio-online-sala-01/',
	'02' => 'https://planoassistencialintegrado.com.br/velorio-online-sala-02/',
	'03' => 'https://planoassistencialintegrado.com.br/velorio-online-sala-03/',
);
$plantao = pai_digitos( pai_opt( 'tel_plantao' ) );
?>

<section class="secao secao--sem-topo">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Área restrita</p>
			<h2 class="h2">Acessar uma sala</h2>
			<p class="lead">Para acompanhar um velório online é preciso a senha de acesso, que a família recebe da nossa equipe. Se já tem a senha, clique em <strong>Acessar sala</strong>. Se não tem, clique em <strong>Pedir senha</strong>.</p>
		</div>
		<ul class="grade-salas">
			<?php foreach ( $salas as $n => $url_sala ) : ?>
				<li class="card sala pilha pilha--p">
					<span class="ico ico--azul"><?php echo pai_icone( 'video', 26 ); ?></span>
					<h3 class="card__tit card__tit--m">Sala <?php echo esc_html( $n ); ?></h3>
					<div class="botoes">
						<a class="btn btn-sol" href="<?php echo esc_url( $url_sala ); ?>">Acessar sala</a>
						<a class="btn btn-line" href="<?php echo esc_url( 'https://wa.me/' . $plantao . '?text=' . rawurlencode( 'Olá, gostaria da senha de acesso para acompanhar o Velório Online da Sala ' . $n . '.' ) ); ?>" target="_blank" rel="noopener">Pedir senha</a>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
		<p class="nota">A senha é enviada somente com autorização da família, para preservar a privacidade da cerimônia.</p>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap grade-3">
		<div class="card pilha pilha--pp">
			<h2 class="card__tit card__tit--p">Ao vivo e com segurança</h2>
			<p class="card__txt">Transmissão discreta e respeitosa, só para quem tem a senha.</p>
		</div>
		<a class="card card--link pilha pilha--pp" href="<?php echo esc_url( pai_url( 'coroas-de-flores' ) ); ?>">
			<h2 class="card__tit card__tit--p">Enviar uma coroa de flores</h2>
			<p class="card__txt">Mesmo de longe, sua homenagem chega à sala do velório.</p>
		</a>
		<a class="card card--link pilha pilha--pp" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>">
			<h2 class="card__tit card__tit--p">Incluído nos planos</h2>
			<p class="card__txt">O velório online faz parte dos planos do Plano PAI.</p>
		</a>
	</div>
</section>

<?php
get_footer();
