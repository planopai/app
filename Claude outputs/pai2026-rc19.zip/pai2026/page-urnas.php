<?php
/**
 * Página /urnas/: catálogo de urnas.
 * As urnas continuam cadastradas no Elementor da página (carrossel + blocos de detalhes).
 */
get_header();

$id       = get_queried_object_id();
$urnas    = pai_el_urnas( $id );
$catalogo = pai_el_botao( $id, 'atálogo' );
$wa_padrao = 'https://wa.me/' . pai_digitos( pai_opt( 'whats_urnas' ) ) . '?text=' . rawurlencode( 'Olá, vim pelo catálogo digital. Gostaria de informações sobre uma urna.' );

$extra = '<div class="botoes"><a class="btn btn-verde btn-g" href="' . esc_url( $wa_padrao ) . '" target="_blank" rel="noopener">' . pai_icone( 'whats', 22 ) . 'Falar com um consultor</a>';
if ( $catalogo ) {
	$extra .= '<a class="btn btn-claro btn-g" href="' . esc_url( $catalogo ) . '" target="_blank" rel="noopener">Baixar catálogo (PDF)</a>';
}
$extra .= '</div>';

pai_topo( 'Urnas', 'Catálogo digital', 'Confira nossas urnas', 'Modelos para todos os estilos, das linhas tradicionais às urnas artesanais. Toque em um modelo para ver os detalhes.', $extra );
?>

<section class="secao secao--sem-topo">
	<div class="wrap pilha">
		<?php if ( $urnas ) : ?>
			<ul class="grade-urnas">
				<?php foreach ( $urnas as $u ) : ?>
					<?php
					$nome = $u['nome'];
					$link = $u['link'] ? $u['link'] : $wa_padrao;
					if ( false !== strpos( $link, 'wa.me' ) || false !== strpos( $link, 'whatsapp' ) ) {
						$link = preg_replace( '/([?&])text=[^&]*/', '$1text=' . rawurlencode( 'Olá, vim pelo catálogo digital. Gostaria de informações sobre a urna ' . $nome . '.' ), $link );
					}
					?>
					<li class="card urna">
						<span class="urna__foto"><img src="<?php echo esc_url( $u['img'] ); ?>" alt="<?php echo esc_attr( 'Urna ' . $nome ); ?>" loading="lazy" decoding="async"></span>
						<div class="urna__cab">
							<h2 class="urna__nome"><?php echo esc_html( $nome ); ?></h2>
							<?php if ( $u['fabricante'] ) : ?><span class="urna__marca"><?php echo esc_html( $u['fabricante'] ); ?></span><?php endif; ?>
						</div>
						<?php if ( $u['texto'] ) : ?>
							<details class="urna__det">
								<summary>Ver detalhes</summary>
								<div class="texto texto--p"><?php echo wp_kses_post( wpautop( preg_replace( '/(INSPIRAÇÃO:|CONCEITO:|ESPECIFICAÇÕES TÉCNICAS:?)/u', '<strong>$1</strong> ', $u['texto'] ) ) ); ?></div>
							</details>
						<?php endif; ?>
						<a class="btn btn-verde urna__btn" href="<?php echo esc_url( $link ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 18 ); ?>Quero esta urna</a>
					</li>
				<?php endforeach; ?>
			</ul>
			<p class="nota">Imagens ilustrativas. Disponibilidade, cores e acabamentos podem variar; consulte nossa equipe.</p>
		<?php else : ?>
			<div class="conteudo-elementor"><?php the_content(); ?></div>
		<?php endif; ?>
	</div>
</section>

<?php
get_footer();
