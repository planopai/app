<?php
/**
 * Cabeçalho: faixa do plantão, logo, menu, tema claro/escuro e Contratar agora.
 */
$menu_padrao = array(
	array( '/planos-funerarios/', 'Planos' ),
	array( '/coroas-de-flores/', 'Coroas de flores' ),
	array( '/velorio-online/', 'Velório online' ),
	array( '/guia-para-familias/', 'Guia para famílias' ),
	array( '/sobre-nos/', 'Sobre nós' ),
	array( '/contato-plano-pai/', 'Contato' ),
);
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>

<div class="topo-faixa">
	<div class="wrap topo-faixa__in">
		<div class="topo-faixa__plantao">
			<span class="ponto" aria-hidden="true"></span>
			<strong>Plantão 24 horas:</strong>
			<a class="sol" href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>"><?php echo esc_html( pai_opt( 'tel_plantao' ) ); ?></a>
			<span class="esconde-sm" aria-hidden="true">·</span>
			<a class="esconde-sm" href="<?php echo esc_url( pai_tel( 'tel_fixo' ) ); ?>"><?php echo esc_html( pai_opt( 'tel_fixo' ) ); ?></a>
		</div>
		<div class="topo-faixa__links">
			<a class="pilula-associado" href="<?php echo esc_url( pai_link( 'url_associado' ) ); ?>"><?php echo pai_icone( 'pessoa', 18 ); ?>SOU ASSOCIADO</a>
			<a class="esconde-sm topo-faixa__pagar" href="<?php echo esc_url( pai_url( 'pagar-mensalidade' ) ); ?>"><?php echo pai_icone( 'cartao', 16 ); ?>Pagar mensalidade</a>
			<a class="esconde-sm" href="<?php echo esc_url( pai_link( 'url_telemedicina' ) ); ?>">Telemedicina</a>
		</div>
	</div>
</div>

<header class="cabecalho">
	<div class="wrap cabecalho__in">
		<?php echo pai_logo( 50 ); ?>
		<nav class="nav" id="menu-principal" aria-label="Menu principal">
			<?php pai_menu( 'principal', $menu_padrao, 'nav__lista' ); ?>
			<div class="nav__extra">
				<a class="btn btn-line" href="<?php echo esc_url( pai_link( 'url_associado' ) ); ?>"><?php echo pai_icone( 'pessoa', 18 ); ?>Área do associado</a>
				<a class="btn btn-line" href="<?php echo esc_url( pai_url( 'pagar-mensalidade' ) ); ?>"><?php echo pai_icone( 'cartao', 18 ); ?>Pagar mensalidade</a>
			</div>
		</nav>
		<div class="cabecalho__acoes">
			<button type="button" class="tema-btn" data-tema aria-label="Usar tema claro" title="Mudar tema">
				<span class="ic-sol"><?php echo pai_icone( 'sol', 20 ); ?></span><span class="ic-lua"><?php echo pai_icone( 'lua', 20 ); ?></span>
			</button>
			<a class="btn btn-sol btn-cab" href="<?php echo esc_url( pai_link( 'url_contratar' ) ); ?>">Contratar agora</a>
			<button type="button" class="menu-btn" data-menu aria-controls="menu-principal" aria-expanded="false" aria-label="Abrir menu">
				<span class="ic-abrir"><?php echo pai_icone( 'menu', 24 ); ?></span><span class="ic-fechar"><?php echo pai_icone( 'fechar', 24 ); ?></span>
			</button>
		</div>
	</div>
</header>

<main id="conteudo">
