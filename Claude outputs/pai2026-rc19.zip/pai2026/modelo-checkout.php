<?php
/**
 * Checkout (Finalizar compra, Pedido recebido e Pagar pedido) no layout do tema.
 * O formulário é o padrão do WooCommerce, desenhado pelo Fluid Checkout. Ver inc/checkout.php.
 */
get_header();
$t = pai_checkout_textos();
pai_topo( $t['trilha'], $t['eyebrow'], $t['titulo'], $t['lead'] );
?>
<section class="secao secao--checkout">
	<div class="wrap pai-checkout-area">
		<?php do_action( 'fc_checkout_before_main_section_wrapper' ); ?>
		<div class="fc-content <?php echo esc_attr( apply_filters( 'fc_content_section_class', '' ) ); ?>">
			<?php
			do_action( 'fc_checkout_before_main_section' );
			pai_checkout_barra_resumo();
			echo do_shortcode( '[woocommerce_checkout]' ); // phpcs:ignore WordPress.Security.EscapeOutput
			do_action( 'fc_checkout_after_main_section' );
			?>
		</div>
		<?php do_action( 'fc_checkout_after_main_section_wrapper' ); ?>
	</div>
</section>
<?php
get_footer();
