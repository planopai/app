<?php
/**
 * Landing page dos anúncios: /landing-page/.
 * Página enxuta (só logo, plantão e WhatsApp no topo) para quem chega pelo anúncio.
 * Preços vêm de Aparência > Personalizar > Plano PAI > Preços dos planos.
 * As imagens (topo e galeria) são as mesmas da landing anterior.
 */
$pr  = pai_precos();
$msg = 'Olá, vim pelo anúncio! Quero falar sobre os planos funerários.';
$wa  = pai_wa( $msg );

$planos = array(
	array(
		'nome'  => 'LIGHT',
		'cor'   => '#B3CE52',
		'itens' => array( 'Urna semiluxo', 'Roupa fúnebre', 'Kit lanche', 'Coroa artificial de 60 cm', 'Translado do corpo (até 200 km)', 'Ornamentação do corpo', 'Assistência funerária', 'Carro funerário', 'Sala de velório' ),
		'de'    => '',
		'preco' => $pr['light'],
		'nota'  => 'Adesão: R$ ' . pai_reais( $pr['ad_lf'], true ) . '. Dependente extra: R$ ' . pai_reais( $pr['ex_light'], true ) . ' (até 2).',
		'selo'  => '',
	),
	array(
		'nome'  => 'FLEX',
		'cor'   => '#F2CB3F',
		'itens' => array( 'Urna semiluxo', 'Roupa fúnebre semiluxo', 'Kit lanche', 'Coroa de flores', 'Translado do corpo (até 500 km)', 'Ornamentação do corpo', 'Assistência funerária', 'Carro funerário', 'Sala de velório', 'Urna pet' ),
		'de'    => 'a partir de',
		'preco' => $pr['flex'][0],
		'nota'  => 'Titular + até 9 dependentes, valor pela idade do mais velho. Adesão: R$ ' . pai_reais( $pr['ad_lf'], true ) . '.',
		'selo'  => 'MAIS CONTRATADO',
	),
	array(
		'nome'  => 'PLUS',
		'cor'   => '#00AEEC',
		'itens' => array( 'Urna luxo', 'Roupa fúnebre luxo', 'Kit lanche', 'Coroa natural de 1,10 m', 'Translado do corpo (até 1.000 km)', 'Ornamentação do corpo', 'Assistência funerária', 'Carro funerário', 'Sala de velório', 'Tanatopraxia' ),
		'de'    => '',
		'preco' => $pr['plus'],
		'nota'  => 'Adesão: R$ ' . pai_reais( $pr['ad_pm'], true ) . '. Mais 2 pessoas sem custo; a partir da 3ª, R$ ' . pai_reais( $pr['ex_plus'], true ) . '.',
		'selo'  => '',
	),
	array(
		'nome'  => 'MAX',
		'cor'   => '#FFFFFF',
		'itens' => array( 'Urna luxo', 'Roupa fúnebre luxo', 'Kit lanche', 'Coroa natural de 1,10 m', 'Translado para todo o Brasil, sem limite de km', 'Ornamentação do corpo', 'Assistência funerária', 'Carro funerário', 'Sala de velório', 'Tanatopraxia', 'Telemedicina incluída' ),
		'de'    => '',
		'preco' => $pr['max'],
		'nota'  => 'Adesão: R$ ' . pai_reais( $pr['ad_pm'], true ) . '. Mais 2 pessoas sem custo; a partir da 3ª, R$ ' . pai_reais( $pr['ex_max'], true ) . '.',
		'selo'  => '',
	),
);

$campanha = trim( (string) pai_opt( 'tele_campanha' ) );
$beneficios = array(
	array( 'tele', 'azul', 'Telemedicina 24h', 'Médico pelo celular, a qualquer hora. Incluída no plano MAX; contratada à parte no FLEX e no PLUS.' . ( $campanha ? ' ' . $campanha : '' ) ),
	array( 'desconto', 'verde', 'Descontos em consultas', 'Rede de parceiros com descontos de até 50% em consultas médicas presenciais com profissionais especializados.' ),
	array( 'celular', 'sol', 'Aplicativo do associado', 'Veja as informações do plano, solicite serviços, pague mensalidades, acesse descontos e acompanhe os sorteios.' ),
	array( 'cadeira', 'azul', 'Material ortopédico', 'Empréstimo de cadeira de rodas, cadeira de banho, muletas e andador por até 6 meses, mediante solicitação médica.' ),
	array( 'escudo', 'verde', 'Assistência funerária completa', 'Em caso de falecimento, o PAI cuida de todas as providências para as homenagens, com plantão 24 horas.' ),
	array( 'estrela', 'sol', 'Sorteios mensais', 'A cada mês, os associados têm novas oportunidades de participar de sorteios e ganhar prêmios.' ),
);

$diferenciais = array(
	array( 'relogio', 'Atendimento 24 horas', 'Sempre ao seu lado nos momentos difíceis, com suporte a qualquer hora.' ),
	array( 'pessoa', 'Equipe qualificada', 'Profissionais preparados para atender familiares e amigos com carinho e profissionalismo.' ),
	array( 'predio', 'Qualidade e respeito', 'Serviços conduzidos com dignidade, responsabilidade e atenção aos detalhes.' ),
	array( 'carro', 'Frota própria', 'Veículos funerários preparados para oferecer um serviço digno e profissional.' ),
);

$galeria = array(
	'2026/04/ChatGPT-Image-23-de-abr.-de-2026-09_49_44.png',
	'2026/04/ChatGPT-Image-23-de-abr.-de-2026-10_03_53.png',
	'2024/11/DSC_5759-scaled.jpg',
	'2024/11/DSC_5751-scaled.jpg',
	'2026/04/ChatGPT-Image-23-de-abr.-de-2026-09_33_11.png',
	'2024/11/DSC_6025-scaled.jpg',
	'2024/11/DSC_6026-scaled.jpg',
	'2024/11/DSC_6029-scaled.jpg',
	'2024/11/DSC_6034-scaled.jpg',
	'2026/04/ChatGPT-Image-23-de-abr.-de-2026-09_58_26.png',
	'2024/11/DSC_5987-scaled.jpg',
	'2024/11/DSC_5986-scaled.jpg',
	'2024/11/DSC_5763-scaled.jpg',
	'2024/11/DSC_5764-scaled.jpg',
	'2024/11/DSC_5767-scaled.jpg',
	'2024/11/DSC_5766-scaled.jpg',
	'2024/09/WhatsApp-Image-2024-09-13-at-08.45.49.jpeg',
	'2024/09/WhatsApp-Image-2024-09-13-at-08.45.47-2.jpeg',
	'2024/09/WhatsApp-Image-2024-09-13-at-08.45.46-1.jpeg',
);

$depoimentos = array(
	array( 'Fomos atendidos com muita atenção e respeito. A equipe explicou tudo com calma e cuidou de cada detalhe.', 'Mariana S. · Barreiras' ),
	array( 'O plano trouxe segurança para nossa família. O atendimento foi rápido, humano e muito organizado.', 'Carlos A. · Luís Eduardo Magalhães' ),
	array( 'Recomendo para quem deseja se prevenir e proteger a família com tranquilidade.', 'Neide R. · Barreiras' ),
);

$faq = array(
	array( 'Qual é a carência dos planos?', '90 dias após a adesão para morte natural e 24 horas para morte por acidente ou causa externa. Se precisar usar durante a carência, há desconto de 10% a 20% no atendimento.' ),
	array( 'O atendimento funciona 24 horas?', 'Sim. O plantão atende 24 horas, todos os dias, para orientar a família, iniciar os procedimentos e dar suporte em momentos de urgência, para associados e não associados.' ),
	array( 'O que o aplicativo do associado permite fazer?', 'Consultar as informações do plano, solicitar serviços, pagar mensalidades, acessar os descontos e acompanhar os resultados dos sorteios.' ),
	array( 'Quais benefícios de saúde estão disponíveis?', 'Rede de parceiros com descontos em consultas presenciais para todos os associados. A Telemedicina 24h vem incluída no plano MAX e pode ser contratada à parte no FLEX e no PLUS.' ),
	array( 'É possível incluir dependentes?', 'Sim. No LIGHT, PLUS e MAX entram cônjuge, filhos solteiros e pais ou sogros; o PLUS e o MAX incluem mais 2 pessoas à sua escolha sem custo. No FLEX, entram até 9 dependentes de qualquer parentesco.' ),
	array( 'O que está incluído na assistência funerária?', 'Urna, roupa fúnebre, kit lanche, coroa de flores, translado, ornamentação do corpo, carro funerário, sala de velório e suporte completo à família, conforme o plano escolhido.' ),
);

$wa_plano = function ( $nome ) {
	return pai_wa( 'Olá, vim pelo anúncio! Quero contratar o Plano ' . $nome . '.' );
};
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'lp' ); ?>>
<?php wp_body_open(); ?>

<header class="lp-topo">
	<div class="wrap lp-topo__in">
		<?php echo pai_logo( 44, false ); ?>
		<div class="lp-topo__acoes">
			<a class="lp-topo__plantao esconde-sm" href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>"><?php echo pai_icone( 'fone', 18 ); ?>Plantão 24h <strong><?php echo esc_html( pai_opt( 'tel_plantao' ) ); ?></strong></a>
			<a class="btn btn-verde lp-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 20 ); ?>WhatsApp</a>
		</div>
	</div>
</header>

<main id="conteudo">

<section class="lp-hero" style="--foto-topo:url('<?php echo esc_url( pai_opt( 'url_foto_topo' ) ); ?>')">
	<div class="wrap lp-hero__in">
		<div class="pilha pilha--p lp-hero__texto">
			<p class="eyebrow eyebrow--sol">Atendimento 24h em Barreiras-BA</p>
			<h1 class="display">Há mais de 40 anos cuidando de você e da sua família</h1>
			<p class="lead">Planos funerários completos, acessíveis e humanizados para proteger sua família com tranquilidade, respeito, acolhimento e suporte em cada detalhe.</p>
			<div class="botoes">
				<a class="btn btn-verde btn-g lp-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 22 ); ?>Falar no WhatsApp</a>
				<a class="btn btn-claro btn-g" href="#planos">Ver os planos</a>
			</div>
			<dl class="lp-numeros">
				<div><dt>+40</dt><dd>anos de cuidado</dd></div>
				<div><dt>24h</dt><dd>plantão ativo</dd></div>
				<div><dt>4</dt><dd>planos familiares</dd></div>
				<div><dt>a partir de R$ <?php echo esc_html( pai_reais( $pr['light'] ) ); ?></dt><dd>por mês</dd></div>
			</dl>
		</div>
		<aside class="card lp-hero__card pilha pilha--p">
			<p class="eyebrow">Proteção completa</p>
			<h2 class="card__tit card__tit--m">Assistência com estrutura, respeito e empatia</h2>
			<ul class="lista-check lista-check--g">
				<li>Organização de cada detalhe do velório</li>
				<li>Memorial Senhor do Bonfim e salas de velório</li>
				<li>Frota própria, atendimento 24h e apoio integral</li>
			</ul>
			<a class="btn btn-sol" href="#planos">Conhecer os planos</a>
		</aside>
	</div>
</section>

<section class="secao" id="sobre">
	<div class="wrap duas-colunas lp-sobre">
		<div class="pilha pilha--p">
			<p class="eyebrow">Sobre o Plano PAI</p>
			<h2 class="h2">Cuidado profissional para uma homenagem digna e serena</h2>
			<p class="lead">No PAI, assumimos com responsabilidade e sensibilidade a missão de organizar cada detalhe do velório, proporcionando tranquilidade em um momento delicado.</p>
			<p class="lead">Nossa equipe cuida da preparação do ambiente, do suporte à família e de toda a estrutura necessária para que você possa se concentrar no que realmente importa: oferecer uma última homenagem com amor, dignidade e serenidade.</p>
		</div>
		<div class="card pilha pilha--p">
			<h3 class="card__tit card__tit--m">Diferenciais que tornam o cuidado mais seguro</h3>
			<dl class="lp-stats">
				<div><dt>24h</dt><dd>Atendimento todos os dias</dd></div>
				<div><dt>1.000 km</dt><dd>Translado no PLUS</dd></div>
				<div><dt>Brasil</dt><dd>Translado sem limite no MAX</dd></div>
				<div><dt>até 50%</dt><dd>Descontos em consultas</dd></div>
			</dl>
		</div>
	</div>
</section>

<section class="secao secao--alt" id="beneficios">
	<div class="wrap pilha">
		<div class="secao__cab lp-centro">
			<p class="eyebrow eyebrow--verde">Benefícios do associado</p>
			<h2 class="h2">Mais tranquilidade, saúde e praticidade no dia a dia</h2>
			<p class="lead">O Plano PAI une assistência funerária, suporte familiar, saúde, tecnologia e benefícios para os associados.</p>
		</div>
		<ul class="grade-servicos">
			<?php foreach ( $beneficios as $b ) : ?>
				<li class="card servico-c">
					<span class="servico-c__ico servico-c__ico--<?php echo esc_attr( $b[1] ); ?>"><?php echo pai_icone( $b[0], 28 ); ?></span>
					<h3 class="card__tit card__tit--m"><?php echo esc_html( $b[2] ); ?></h3>
					<p class="card__txt"><?php echo esc_html( $b[3] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="secao">
	<div class="wrap">
		<div class="lp-app duas-colunas">
			<div class="pilha pilha--p">
				<p class="eyebrow eyebrow--sol">Aplicativo do associado</p>
				<h2 class="h2">Tudo do seu plano na palma da mão</h2>
				<p class="lead">Com o aplicativo, você acompanha seu plano, consulta informações importantes, solicita serviços e mantém as mensalidades em dia.</p>
			</div>
			<ul class="lista-check lista-check--g">
				<li>Verificar todas as informações do plano</li>
				<li>Solicitar serviços de forma prática</li>
				<li>Pagar mensalidades pelo aplicativo</li>
				<li>Acessar os descontos disponíveis</li>
				<li>Conferir os resultados dos sorteios</li>
			</ul>
		</div>
	</div>
</section>

<section class="secao secao--alt" id="planos">
	<div class="wrap pilha">
		<div class="secao__cab lp-centro">
			<p class="eyebrow">Planos disponíveis</p>
			<h2 class="h2">Escolha o plano ideal para sua família</h2>
			<p class="lead">Quatro planos completos para atender às suas necessidades e condições.</p>
		</div>
		<div class="lp-planos">
			<?php foreach ( $planos as $p ) : ?>
				<article class="card lp-plano<?php echo $p['selo'] ? ' lp-plano--destaque' : ''; ?>" style="--cor-plano:<?php echo esc_attr( $p['cor'] ); ?>">
					<?php if ( $p['selo'] ) : ?><span class="lp-plano__selo"><?php echo esc_html( $p['selo'] ); ?></span><?php endif; ?>
					<h3 class="lp-plano__nome">Plano <?php echo esc_html( $p['nome'] ); ?></h3>
					<ul class="lista-check">
						<?php foreach ( $p['itens'] as $i ) : ?><li><?php echo esc_html( $i ); ?></li><?php endforeach; ?>
					</ul>
					<div class="lp-plano__preco">
						<?php if ( $p['de'] ) : ?><small><?php echo esc_html( $p['de'] ); ?></small><?php endif; ?>
						<strong>R$ <?php echo esc_html( pai_reais( $p['preco'], true ) ); ?></strong><span>/mês</span>
					</div>
					<p class="lp-plano__nota"><?php echo esc_html( $p['nota'] ); ?></p>
					<a class="btn btn-sol lp-contratar" href="<?php echo esc_url( add_query_arg( 'plano', strtolower( $p['nome'] ), home_url( '/adesao/' ) ) ); ?>" data-plano="<?php echo esc_attr( $p['nome'] ); ?>">Contratar online</a>
					<a class="lp-plano__wa lp-wa" href="<?php echo esc_url( $wa_plano( $p['nome'] ) ); ?>" target="_blank" rel="noopener">ou tire dúvidas no WhatsApp</a>
					<a class="link-forte lp-plano__mais" href="<?php echo esc_url( pai_url( 'planos-funerarios/' . strtolower( $p['nome'] ) ) ); ?>">Ver detalhes ›</a>
				</article>
			<?php endforeach; ?>
		</div>
		<p class="nota lp-centro">Carência de 90 dias para morte natural e 24 horas para acidente. Condições completas nos Termos de Adesão.</p>
	</div>
</section>

<section class="secao">
	<div class="wrap pilha">
		<div class="secao__cab lp-centro">
			<p class="eyebrow">Nossos diferenciais</p>
			<h2 class="h2">Estrutura, acolhimento e qualidade em todos os detalhes</h2>
		</div>
		<ul class="lp-diferenciais">
			<?php foreach ( $diferenciais as $d ) : ?>
				<li class="card pilha pilha--pp">
					<span class="ico ico--azul"><?php echo pai_icone( $d[0], 24 ); ?></span>
					<h3 class="card__tit card__tit--p"><?php echo esc_html( $d[1] ); ?></h3>
					<p class="card__txt"><?php echo esc_html( $d[2] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="secao secao--alt" id="galeria">
	<div class="wrap">
		<div class="lp-galeria">
			<button class="lp-galeria__nav lp-galeria__ant" type="button" aria-label="Foto anterior">‹</button>
			<div class="lp-galeria__trilho" data-lp-galeria>
				<?php foreach ( $galeria as $g ) : ?>
					<figure class="lp-galeria__item"><img src="<?php echo pai_upload( $g ); ?>" alt="Estrutura Plano PAI" loading="lazy" decoding="async"></figure>
				<?php endforeach; ?>
			</div>
			<button class="lp-galeria__nav lp-galeria__prox" type="button" aria-label="Próxima foto">›</button>
		</div>
	</div>
</section>

<section class="secao">
	<div class="wrap">
		<div class="card lp-velorio duas-colunas">
			<div class="pilha pilha--p">
				<p class="eyebrow eyebrow--verde">Velório online</p>
				<h2 class="h2">Presença de qualquer lugar do mundo</h2>
			</div>
			<div class="pilha pilha--p">
				<p class="lead">O PAI oferece a opção de velório online, permitindo que familiares e amigos participem da cerimônia de despedida à distância, por meio de transmissões ao vivo, mensagens e homenagens.</p>
				<a class="btn btn-sol alinha-ini lp-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener">Contratar plano funerário</a>
			</div>
		</div>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap pilha">
		<div class="secao__cab lp-centro">
			<p class="eyebrow eyebrow--sol">Depoimentos</p>
			<h2 class="h2">Famílias que sentiram acolhimento quando mais precisaram</h2>
		</div>
		<ul class="lp-depoimentos">
			<?php foreach ( $depoimentos as $d ) : ?>
				<li class="card pilha pilha--p">
					<span class="lp-estrelas" aria-label="5 estrelas">★★★★★</span>
					<p class="card__txt">“<?php echo esc_html( $d[0] ); ?>”</p>
					<span class="lp-pessoa"><?php echo esc_html( $d[1] ); ?></span>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="secao" id="faq">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow">Perguntas frequentes</p>
			<h2 class="h2">Dúvidas importantes sobre o Plano PAI</h2>
			<p class="lead">As principais explicações para contratar com mais segurança.</p>
		</div>
		<div class="faq">
			<?php foreach ( $faq as $i => $q ) : ?>
				<details <?php echo 0 === $i ? 'open' : ''; ?>>
					<summary><?php echo esc_html( $q[0] ); ?><span class="faq__mais" aria-hidden="true">+</span></summary>
					<p><?php echo esc_html( $q[1] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="secao secao--alt" id="contato">
	<div class="wrap">
		<div class="lp-final duas-colunas">
			<div class="pilha pilha--p">
				<p class="eyebrow eyebrow--sol">Contato imediato</p>
				<h2 class="h2">Não deixe para depois o cuidado com quem você ama</h2>
				<p class="lead">Fale com um consultor do Plano PAI e receba uma orientação acolhedora para escolher o melhor plano para sua família.</p>
			</div>
			<form class="card lp-form pilha pilha--p" data-lp-form data-whats="<?php echo esc_attr( pai_digitos( pai_opt( 'whatsapp' ) ) ); ?>">
				<label for="lp-nome">Seu nome</label>
				<input id="lp-nome" name="nome" type="text" autocomplete="name" required>
				<label for="lp-plano">Plano de interesse</label>
				<select id="lp-plano" name="plano">
					<option>Ainda não sei, quero ajuda para escolher</option>
					<?php foreach ( $planos as $p ) : ?><option>Plano <?php echo esc_html( $p['nome'] ); ?></option><?php endforeach; ?>
				</select>
				<button class="btn btn-verde btn-g" type="submit"><?php echo pai_icone( 'whats', 22 ); ?>Continuar no WhatsApp</button>
				<p class="nota">Abrimos o WhatsApp com a sua mensagem pronta. Nada é gravado neste site.</p>
			</form>
		</div>
	</div>
</section>

</main>

<footer class="rodape lp-rodape">
	<div class="wrap lp-rodape__in">
		<div class="rodape__marca lp-rodape__marca">
			<?php echo pai_logo( 60, false ); ?>
			<div class="rodape__lema">COM VOCÊ TODOS OS DIAS</div>
		</div>
		<div>
			<h2 class="rodape__tit">Contatos</h2>
			<ul class="rodape__lista">
				<li><a href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>">Plantão 24h: <?php echo esc_html( pai_opt( 'tel_plantao' ) ); ?></a></li>
				<li><a class="lp-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener">Plano PAI (WhatsApp): <?php echo esc_html( pai_opt( 'whatsapp' ) ); ?></a></li>
			</ul>
		</div>
		<div>
			<h2 class="rodape__tit">Endereços</h2>
			<ul class="rodape__lista">
				<li>Sede: <?php echo esc_html( pai_opt( 'end_sede' ) ); ?></li>
				<li>Memorial Senhor do Bonfim: <?php echo esc_html( pai_opt( 'end_memorial' ) ); ?></li>
			</ul>
		</div>
	</div>
	<div class="wrap">
		<div class="rodape__base">
			<span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Plano PAI · CNPJ <?php echo esc_html( pai_opt( 'cnpj' ) ); ?></span>
			<span><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Site do Plano PAI</a> · <a href="<?php echo esc_url( pai_url( 'politica-de-privacidade' ) ); ?>">Política de privacidade</a></span>
		</div>
	</div>
</footer>

<nav class="barra-cel" aria-label="Atalhos">
	<a class="btn btn-sol" href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>"><?php echo pai_icone( 'fone', 18 ); ?>Plantão 24h</a>
	<a class="btn btn-verde lp-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 18 ); ?>WhatsApp</a>
</nav>
<a class="whats-flutuante lp-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener" aria-label="Falar no WhatsApp"><?php echo pai_icone( 'whats', 30 ); ?></a>

<div class="ampliada lp-ampliada" data-lp-ampliada hidden>
	<button type="button" class="ampliada__fechar" data-lp-fechar aria-label="Fechar"><?php echo pai_icone( 'fechar', 26 ); ?></button>
	<img src="" alt="">
</div>

<?php wp_footer(); ?>
</body>
</html>
