<?php
/**
 * Página /contato-plano-pai/.
 */
get_header();
pai_topo( 'Contato', 'Fale com a gente', 'Contato Plano PAI', 'Para assistência funerária e atendimento imediato, estamos à disposição 24 horas por dia, todos os dias, em Barreiras-BA e região.' );
$insta = (string) pai_opt( 'instagram' );
?>

<section class="secao secao--sem-topo">
	<div class="wrap grade-contatos">
		<div class="card card--borda-sol pilha pilha--p">
			<p class="eyebrow eyebrow--urg">Falecimento · Plantão 24 horas</p>
			<p class="card__tit card__tit--m">Atendimento funerário</p>
			<p class="card__txt">Para associados e não associados, a qualquer hora.</p>
			<div class="botoes">
				<a class="btn btn-sol" href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>"><?php echo pai_icone( 'fone', 20 ); ?><?php echo esc_html( pai_opt( 'tel_plantao' ) ); ?></a>
				<a class="btn btn-line" href="<?php echo esc_url( pai_tel( 'tel_fixo' ) ); ?>">Fixo: <?php echo esc_html( pai_opt( 'tel_fixo' ) ); ?></a>
			</div>
		</div>
		<div class="card card--borda-verde pilha pilha--p">
			<p class="eyebrow eyebrow--verde">Atendimento Plano PAI</p>
			<p class="card__tit card__tit--m">Planos, dúvidas e associados</p>
			<p class="card__txt">Ligação ou WhatsApp: contrate seu plano, tire dúvidas, atualize dados ou fale sobre a mensalidade.</p>
			<div class="botoes">
				<a class="btn btn-verde" href="<?php echo esc_url( pai_wa( 'Olá! Vim pelo site e gostaria de falar com o atendimento do Plano PAI.' ) ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 20 ); ?>WhatsApp</a>
				<a class="btn btn-line" href="<?php echo esc_url( pai_tel( 'whatsapp' ) ); ?>"><?php echo esc_html( pai_opt( 'whatsapp' ) ); ?></a>
			</div>
		</div>
		<div class="card pilha pilha--p">
			<p class="eyebrow">E-mail e redes</p>
			<p class="card__tit card__tit--p"><a href="mailto:<?php echo esc_attr( antispambot( pai_opt( 'email' ) ) ); ?>"><?php echo esc_html( antispambot( pai_opt( 'email' ) ) ); ?></a></p>
			<?php if ( $insta ) : ?>
				<a class="link-forte" href="<?php echo esc_url( $insta ); ?>" target="_blank" rel="noopener">Instagram @planopai_ ›</a>
			<?php endif; ?>
			<a class="link-forte" href="<?php echo esc_url( pai_link( 'url_associado' ) ); ?>">Área do associado ›</a>
		</div>
	</div>
</section>

<?php get_template_part( 'parts/enderecos' ); ?>

<section class="secao">
	<div class="wrap grade-3">
		<a class="card card--link pilha pilha--pp" href="<?php echo esc_url( pai_url( 'trabalhe-conosco' ) ); ?>">
			<h2 class="card__tit card__tit--p">Trabalhe conosco</h2>
			<p class="card__txt">Envie seu currículo para fazer parte da equipe.</p>
		</a>
		<a class="card card--link pilha pilha--pp" href="<?php echo esc_url( pai_url( 'seja-nosso-parceiro' ) ); ?>">
			<h2 class="card__tit card__tit--p">Seja nosso parceiro</h2>
			<p class="card__txt">Ofereça descontos aos associados do Plano PAI.</p>
		</a>
		<a class="card card--link pilha pilha--pp" href="<?php echo esc_url( pai_url( 'atendimento-24-horas' ) ); ?>">
			<h2 class="card__tit card__tit--p">O que fazer quando alguém falece</h2>
			<p class="card__txt">Passo a passo, documentos e o que a lei pede.</p>
		</a>
	</div>
</section>

<?php
get_footer();
