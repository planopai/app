<?php
/**
 * Página /coroas-de-flores/: modelos do WooCommerce. O pedido continua pela
 * página de cada produto (carrinho e finalização do WooCommerce).
 */
get_header();

$grupos = array(
	'coroas-de-flores-naturais'    => array( 'Naturais', 'Feitas com flores frescas, para uma homenagem delicada e tradicional.' ),
	'coroas-de-flores-artificiais' => array( 'Artificiais', 'Alta durabilidade e ótimo acabamento, opção mais econômica.' ),
);
$entrega = (float) pai_opt( 'coroa_entrega' );

$frases = array(
	'Com amor e eterna saudade',
	'Nossas sinceras condolências',
	'Uma homenagem de familiares e amigos',
	'Descanse em paz',
	'Com amor de seus pais e irmãos',
	'Estaremos lembrando de ti sempre com muito amor',
	'Descanse à sombra do Altíssimo',
	'Aquele que crê no Salvador jamais morrerá',
	'Com pesar da família',
	'Homenagem dos amigos e companheiros de trabalho',
	'Não deixei nenhum bem material, mas deixei o bem maior: o exemplo de vida',
);

// rc15 (11/11/2026): lista completa de frases para a faixa, a mesma do app do PAI (venda direta de coroas).
// Aparece na aba "Frases", ao lado de Naturais e Artificiais.
$frases_completas = array(
	'A saudade e o pesar dos seus colegas da (nome da empresa).',
	'A Ti, Senhor, elevo e entrego a minha alma.',
	'Aquele que crê no Salvador jamais morrerá.',
	'Com amor de seus pais e irmãos.',
	'Com pesar da família (nome da família).',
	'Com pesar do(a) (nome da empresa, nome da família, nome dos amigos).',
	'Com pesar dos amigos (nome da empresa, nome da família).',
	'Com pesar dos colegas (nome da empresa).',
	'Condolências de toda a equipe da (nome da empresa).',
	'Condolências do(a) (nome da empresa, família ou amigos).',
	'Condolências dos amigos (nome da empresa, nome da família).',
	'Condolências dos colegas (nome da empresa).',
	'Condolências dos funcionários da (nome da empresa).',
	'Descanse à sombra do Altíssimo.',
	'Estaremos lembrando de ti sempre com muito amor.',
	'Eterna saudade de seus familiares e sentidos pêsames dos colegas e amigos.',
	'Homenagem da direção e funcionários da (nome da empresa).',
	'Homenagem de seus amigos...',
	'Homenagem do(a) (nome da empresa, nome da família, nome dos amigos).',
	'Homenagem dos amigos e companheiros da (nome da empresa).',
	'Homenagem dos colegas (nome do colega ou empresa).',
	'Homenagem dos diretores e funcionários da (nome da empresa).',
	'Homenagem dos diretores, funcionários e amigos da (nome da empresa).',
	'Jesus, meu Rei, na Tua mão segurarei.',
	'Não deixei nenhum bem material, mas deixei o bem maior: o exemplo de vida.',
	'Ninguém morre enquanto permanecer vivo no coração de alguém.',
	'Nossa eterna gratidão e saudade de (nome dos parentes).',
	'Nunca esqueceremos os seus exemplos...',
	'O amor não conhece a barreira da separação, te amaremos sempre.',
	'O Senhor é a minha luz e a minha eterna salvação.',
	'O Senhor é meu pastor e nada me faltará.',
	'Pêsames do(a) (nome da empresa, nome da família, nome dos amigos).',
	'Pêsames dos colegas da (nome da empresa).',
	'Pêsames dos amigos da (nome da empresa, nome da família).',
	'Que Deus o tenha...',
	'Que Deus o(a) tenha em paz.',
	'Saudade de seu(sua) esposo(a), filhos(as), genros, noras e netos.',
	'Saudades de seus amigos (nome) e familiares.',
	'Saudades de seus familiares e amigos.',
	'Sentimentos da família.',
	'Sentimentos de...',
	'Sentimentos do(a) (nome da empresa, nome da família, nome dos amigos).',
	'Sentimentos dos amigos (nome da empresa, nome da família).',
	'Sentimentos dos colegas (nome da empresa).',
	'Sentiremos sua falta.',
	'Será eterno(a) em nossos corações.',
	'Sua passagem foi breve, sua obra eterna.',
	'Um anjo do Senhor me tocou e eu adormeci em paz...',
	'Você é mais uma estrela a brilhar em paz...',
	'Você foi um exemplo de vida...',
);

$faq = array(
	array( 'Em quanto tempo a coroa é entregue?', 'Pedidos feitos até as 20h são montados e entregues no mesmo dia em Barreiras. Depois das 20h, a confecção e a entrega acontecem no dia seguinte, a partir das 8h.' ),
	array( 'Qual a diferença entre natural e artificial?', 'A natural é feita com flores frescas, com visual mais delicado e tradicional. A artificial tem alta durabilidade, ótimo acabamento e costuma ser mais econômica.' ),
	array( 'Quanto custa a entrega?', 'R$ ' . pai_reais( $entrega, true ) . ' para entregas em Barreiras. Para outras cidades da região, consulte pelo WhatsApp.' ),
	array( 'Quais as formas de pagamento?', 'Pix, cartão de crédito e cartão de débito.' ),
);
?>

<section class="topo-pagina">
	<?php echo pai_marca_dagua( 'wm--topo' ); ?>
	<a class="capsula capsula--lateral esconde-md" href="<?php echo esc_url( pai_wa( 'Olá! Preciso de uma coroa de flores com urgência.' ) ); ?>" aria-label="Pedido urgente de coroa pelo WhatsApp">
		<span class="capsula__contorno" aria-hidden="true"></span>
		<span class="capsula__ico capsula__ico--verde"><?php echo pai_icone( 'whats', 24 ); ?></span>
		<span class="capsula__txt">
			<span class="capsula__rot">PEDIDO URGENTE</span>
			<span class="capsula__num capsula__num--m"><?php echo esc_html( pai_opt( 'whatsapp' ) ); ?></span>
			<span class="capsula__sub">Montamos e entregamos no velório</span>
		</span>
	</a>
	<div class="wrap pilha pilha--p topo-pagina__in">
		<?php pai_trilha( 'Coroas de flores' ); ?>
		<h1 class="display display--m">Coroas de flores em Barreiras&#8209;BA</h1>
		<p class="lead">Naturais e artificiais, com faixa personalizada e entrega direto no velório em Barreiras e região. Atendimento 24 horas.</p>
		<ul class="chips">
			<li>Entrega em Barreiras: R$ <?php echo esc_html( pai_reais( $entrega ) ); ?></li>
			<li>Pedidos após 20h: entrega no dia seguinte, a partir das 8h</li>
			<li>Pix, crédito ou débito</li>
		</ul>
	</div>
</section>

<section class="secao secao--sem-topo">
	<div class="wrap pilha">
		<?php if ( ! function_exists( 'wc_get_products' ) ) : ?>
			<p class="aviso">Ative o WooCommerce para mostrar os modelos de coroa.</p>
		<?php else : ?>
			<div class="abas" role="tablist" aria-label="Tipo de coroa" data-abas>
				<?php $n = 0; foreach ( $grupos as $slug => $g ) : ?>
					<button type="button" class="aba" role="tab" id="aba-<?php echo esc_attr( $slug ); ?>" aria-controls="painel-<?php echo esc_attr( $slug ); ?>" aria-selected="<?php echo 0 === $n ? 'true' : 'false'; ?>"><?php echo esc_html( $g[0] ); ?></button>
				<?php $n++; endforeach; ?>
				<button type="button" class="aba" role="tab" id="aba-frases" aria-controls="painel-frases" aria-selected="false">Frases</button>
			</div>
			<?php
			$n = 0;
			foreach ( $grupos as $slug => $g ) :
				$produtos = wc_get_products( array(
					'status'   => 'publish',
					'limit'    => -1,
					'category' => array( $slug ),
					'orderby'  => 'menu_order',
					'order'    => 'ASC',
				) );
				?>
				<div class="painel-aba" role="tabpanel" id="painel-<?php echo esc_attr( $slug ); ?>" aria-labelledby="aba-<?php echo esc_attr( $slug ); ?>" <?php echo 0 === $n ? '' : 'data-oculto'; ?>>
					<h2 class="subtit">Coroas <?php echo esc_html( strtolower( $g[0] ) ); ?></h2>
					<p class="sim-ajuda"><?php echo esc_html( $g[1] ); ?></p>
					<?php if ( $produtos ) : ?>
						<ul class="grade-coroas">
							<?php foreach ( $produtos as $prod ) : ?>
								<li class="card coroa">
									<a class="coroa__foto" href="<?php echo esc_url( $prod->get_permalink() ); ?>" tabindex="-1" aria-hidden="true">
										<?php echo $prod->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
									</a>
									<h3 class="coroa__nome"><a href="<?php echo esc_url( $prod->get_permalink() ); ?>"><?php echo esc_html( $prod->get_name() ); ?></a></h3>
									<p class="coroa__preco"><?php echo wp_kses_post( $prod->get_price_html() ); ?></p>
									<a class="btn btn-line coroa__btn" href="<?php echo esc_url( $prod->get_permalink() ); ?>">Escolher esta</a>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php else : ?>
						<p class="aviso">Nenhum modelo publicado nesta categoria.</p>
					<?php endif; ?>
				</div>
				<?php
				$n++;
			endforeach;
			?>
			<div class="painel-aba" role="tabpanel" id="painel-frases" aria-labelledby="aba-frases" data-oculto data-frases-grupo>
				<h2 class="subtit">Frases para a faixa</h2>
				<p class="sim-ajuda">Toque em uma frase para copiar e cole no campo da faixa ao fazer o pedido. Troque o que estiver entre parênteses pelo nome certo.</p>
				<label class="frases-busca">
					<span class="screen-reader-text">Procurar frase</span>
					<input type="search" class="frases-busca__campo" placeholder="Procurar frase (ex.: saudade, amigos, Senhor)" autocomplete="off" data-filtro-frases>
				</label>
				<p class="sim-ajuda" data-copiado role="status"></p>
				<ol class="frases frases--lista">
					<?php foreach ( $frases_completas as $i => $f ) : ?>
						<li><button type="button" class="frase" data-copiar="<?php echo esc_attr( $f ); ?>"><span class="frase__n"><?php echo (int) $i + 1; ?></span><?php echo esc_html( $f ); ?></button></li>
					<?php endforeach; ?>
				</ol>
				<p class="aviso" data-frases-vazio hidden>Nenhuma frase encontrada. Você também pode escrever a sua.</p>
			</div>
		<?php endif; ?>
		<p class="nota">Associado do PAI? A coroa do plano já está incluída no atendimento.</p>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Sugestões de frases</p>
			<h2 class="h2">Não sabe o que escrever na faixa?</h2>
			<p class="lead">Toque em uma frase para copiar e colar no seu pedido.</p>
		</div>
		<ul class="frases" data-frases-grupo>
			<?php foreach ( $frases as $f ) : ?>
				<li><button type="button" class="frase" data-copiar="<?php echo esc_attr( $f ); ?>"><?php echo esc_html( $f ); ?></button></li>
			<?php endforeach; ?>
		</ul>
		<p class="sim-ajuda" data-copiado role="status"></p>
	</div>
</section>

<section class="secao">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow">Dúvidas frequentes</p>
			<h2 class="h2">Sobre as coroas</h2>
		</div>
		<div class="faq">
			<?php foreach ( $faq as $i => $q ) : ?>
				<details <?php echo 0 === $i ? 'open' : ''; ?>>
					<summary><?php echo esc_html( $q[0] ); ?><span class="faq__mais" aria-hidden="true">+</span></summary>
					<p><?php echo esc_html( $q[1] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php
get_footer();
