<?php
/**
 * Leitura do conteúdo salvo no Elementor.
 *
 * Algumas páginas (urnas, galeria, parceiros, termos) continuam sendo editadas
 * no Elementor, como antes. O tema lê o que está salvo lá (fotos, nomes, textos,
 * links) e mostra no visual novo. Assim a equipe não precisa mexer em código
 * para trocar uma urna, uma foto ou um parceiro.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Lista de widgets da página, na ordem em que aparecem. */
function pai_el_widgets( $post_id ) {
	static $cache = array();
	$post_id = (int) $post_id;
	if ( isset( $cache[ $post_id ] ) ) {
		return $cache[ $post_id ];
	}
	$bruto = get_post_meta( $post_id, '_elementor_data', true );
	if ( is_string( $bruto ) ) {
		$dados = json_decode( $bruto, true );
	} else {
		$dados = $bruto;
	}
	// Preserva os dados de urnas, parceiros e galerias mesmo quando o plugin
	// Elementor não estiver disponível ou quando seu metadado estiver ausente.
	if ( ! is_array( $dados ) || ! $dados ) {
		$slug = get_post_field( 'post_name', $post_id );
		if ( function_exists( 'pai_migracao_carregar' ) ) {
			$exportados = pai_migracao_carregar( $slug );
			if ( $exportados ) {
				$dados = array();
				$converter = function ( $elementos ) use ( &$converter ) {
					$saida = array();
					foreach ( (array) $elementos as $el ) {
						if ( ! is_array( $el ) ) { continue; }
						$saida[] = array(
							'elType'     => isset( $el['type'] ) ? $el['type'] : '',
							'widgetType' => isset( $el['widget'] ) ? $el['widget'] : '',
							'settings'   => isset( $el['settings'] ) ? $el['settings'] : array(),
							'elements'   => $converter( isset( $el['elements'] ) ? $el['elements'] : array() ),
						);
					}
					return $saida;
				};
				$dados = $converter( $exportados );
			}
		}
	}
	$lista = array();
	$andar = function ( $elementos ) use ( &$andar, &$lista ) {
		foreach ( (array) $elementos as $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			if ( isset( $el['elType'] ) && 'widget' === $el['elType'] ) {
				$lista[] = array(
					'tipo' => isset( $el['widgetType'] ) ? (string) $el['widgetType'] : '',
					's'    => isset( $el['settings'] ) && is_array( $el['settings'] ) ? $el['settings'] : array(),
				);
			}
			if ( ! empty( $el['elements'] ) ) {
				$andar( $el['elements'] );
			}
		}
	};
	if ( is_array( $dados ) ) {
		$andar( $dados );
	}
	$cache[ $post_id ] = $lista;
	return $lista;
}

/** Endereço de uma imagem salva no Elementor ({id, url}). */
function pai_el_img( $img, $tamanho = 'large' ) {
	if ( ! is_array( $img ) ) {
		return '';
	}
	if ( ! empty( $img['id'] ) ) {
		$u = wp_get_attachment_image_url( (int) $img['id'], $tamanho );
		if ( $u ) {
			return $u;
		}
	}
	return isset( $img['url'] ) ? (string) $img['url'] : '';
}

/** Texto alternativo de uma imagem do Elementor. */
function pai_el_alt( $img, $padrao = '' ) {
	if ( is_array( $img ) && ! empty( $img['id'] ) ) {
		$alt = get_post_meta( (int) $img['id'], '_wp_attachment_image_alt', true );
		if ( $alt ) {
			return $alt;
		}
	}
	if ( is_array( $img ) && ! empty( $img['alt'] ) ) {
		return $img['alt'];
	}
	return $padrao;
}

/** Link de um controle de link do Elementor. */
function pai_el_link( $s, $chave = 'link' ) {
	if ( isset( $s[ $chave ]['url'] ) ) {
		return trim( (string) $s[ $chave ]['url'] );
	}
	return '';
}

/**
 * Itens no formato "foto, título, texto, botão" (urnas, parceiros).
 * Cada widget de imagem começa um item novo.
 */
function pai_el_itens( $post_id ) {
	$itens = array();
	$atual = null;
	foreach ( pai_el_widgets( $post_id ) as $w ) {
		$s = $w['s'];
		switch ( $w['tipo'] ) {
			case 'image':
				if ( $atual ) {
					$itens[] = $atual;
				}
				$atual = array(
					'img'    => pai_el_img( isset( $s['image'] ) ? $s['image'] : array() ),
					'alt'    => pai_el_alt( isset( $s['image'] ) ? $s['image'] : array() ),
					'titulo' => '',
					'texto'  => '',
					'link'   => '',
					'rotulo' => '',
				);
				$l = pai_el_link( $s );
				if ( $l ) {
					$atual['link'] = $l;
				}
				break;
			case 'heading':
				if ( $atual && '' === $atual['titulo'] && ! empty( $s['title'] ) ) {
					$atual['titulo'] = wp_strip_all_tags( $s['title'] );
				}
				break;
			case 'text-editor':
				if ( $atual && ! empty( $s['editor'] ) ) {
					$atual['texto'] .= $s['editor'];
				}
				break;
			case 'button':
				if ( $atual ) {
					$l = pai_el_link( $s );
					if ( $l ) {
						$atual['link']   = $l;
						$atual['rotulo'] = isset( $s['text'] ) ? wp_strip_all_tags( $s['text'] ) : '';
					}
				}
				break;
		}
	}
	if ( $atual ) {
		$itens[] = $atual;
	}
	return array_values( array_filter( $itens, function ( $i ) {
		return '' !== $i['img'];
	} ) );
}

/** Primeiro botão da página com um texto que contenha $trecho (ex.: "Catálogo"). */
function pai_el_botao( $post_id, $trecho ) {
	foreach ( pai_el_widgets( $post_id ) as $w ) {
		if ( 'button' === $w['tipo'] && isset( $w['s']['text'] ) && false !== stripos( $w['s']['text'], $trecho ) ) {
			return pai_el_link( $w['s'] );
		}
	}
	return '';
}

/** Uma lista de imagens do Elementor ([{id,url}, ...])? */
function pai_el_e_lista_de_imagens( $v ) {
	if ( ! is_array( $v ) || empty( $v ) || ! isset( $v[0] ) || ! is_array( $v[0] ) ) {
		return false;
	}
	return isset( $v[0]['url'] ) || isset( $v[0]['id'] );
}

/**
 * Fotos de uma galeria do Elementor, com o grupo (filtro) de cada uma.
 * Funciona com a "Image Grid" do Happy Addons (grupos com filtro) e com a galeria comum.
 *
 * @return array{grupos: string[], fotos: array}
 */
function pai_el_galeria( $post_id ) {
	$grupos = array();
	$fotos  = array();
	$vistos = array();
	$add    = function ( $img, $grupo ) use ( &$fotos, &$grupos, &$vistos ) {
		$chave = ! empty( $img['id'] ) ? 'i' . $img['id'] : 'u' . ( isset( $img['url'] ) ? $img['url'] : '' );
		if ( isset( $vistos[ $chave . '|' . $grupo ] ) ) {
			return;
		}
		$vistos[ $chave . '|' . $grupo ] = 1;
		if ( '' !== $grupo && ! in_array( $grupo, $grupos, true ) ) {
			$grupos[] = $grupo;
		}
		$fotos[] = array(
			'id'    => ! empty( $img['id'] ) ? (int) $img['id'] : 0,
			'url'   => pai_el_img( $img, 'large' ),
			'cheia' => pai_el_img( $img, 'full' ),
			'alt'   => pai_el_alt( $img ),
			'grupo' => $grupo,
		);
	};

	foreach ( pai_el_widgets( $post_id ) as $w ) {
		if ( false === strpos( $w['tipo'], 'gallery' ) && false === strpos( $w['tipo'], 'image-grid' ) ) {
			continue;
		}
		foreach ( $w['s'] as $valor ) {
			if ( pai_el_e_lista_de_imagens( $valor ) ) {
				// Galeria simples.
				foreach ( $valor as $img ) {
					$add( $img, '' );
				}
				continue;
			}
			if ( ! is_array( $valor ) || ! isset( $valor[0] ) || ! is_array( $valor[0] ) ) {
				continue;
			}
			// Repetidor: cada linha é um grupo com nome e fotos.
			foreach ( $valor as $linha ) {
				if ( ! is_array( $linha ) ) {
					continue;
				}
				$nome    = '';
				$imagens = array();
				foreach ( $linha as $k => $v ) {
					if ( pai_el_e_lista_de_imagens( $v ) ) {
						$imagens = array_merge( $imagens, $v );
					} elseif ( is_array( $v ) && ( isset( $v['url'] ) || isset( $v['id'] ) ) && in_array( $k, array( 'image', 'imagem', 'photo' ), true ) ) {
						$imagens[] = $v;
					} elseif ( '' === $nome && is_string( $v ) && '' !== trim( $v ) && in_array( $k, array( 'filter', 'title', 'name', 'label', 'gallery_title', 'filter_name' ), true ) ) {
						$nome = trim( wp_strip_all_tags( $v ) );
					}
				}
				if ( '' === $nome ) {
					// Nome do grupo em outro campo de texto curto da linha.
					foreach ( $linha as $k => $v ) {
						if ( '_id' !== $k && is_string( $v ) && '' !== trim( $v ) && strlen( $v ) <= 60 && ! preg_match( '/^(yes|no|#|https?:)/', $v ) ) {
							$nome = trim( wp_strip_all_tags( $v ) );
							break;
						}
					}
				}
				foreach ( $imagens as $img ) {
					if ( is_array( $img ) ) {
						$add( $img, $nome );
					}
				}
			}
		}
	}
	return array( 'grupos' => $grupos, 'fotos' => $fotos );
}

/**
 * Só os textos da página (títulos, parágrafos, listas), para páginas de texto
 * como Termos e Política de Privacidade.
 *
 * @param bool $pular_primeiro_titulo O primeiro título vira o H1 do tema.
 */
function pai_el_texto( $post_id, $pular_primeiro_titulo = true ) {
	$html   = '';
	$pulou  = ! $pular_primeiro_titulo;
	foreach ( pai_el_widgets( $post_id ) as $w ) {
		$s = $w['s'];
		switch ( $w['tipo'] ) {
			case 'heading':
				if ( ! $pulou ) {
					$pulou = true;
					break;
				}
				if ( ! empty( $s['title'] ) ) {
					$html .= '<h2>' . esc_html( wp_strip_all_tags( $s['title'] ) ) . '</h2>';
				}
				break;
			case 'text-editor':
				if ( ! empty( $s['editor'] ) ) {
					$html .= wpautop( $s['editor'] );
				}
				break;
			case 'icon-list':
				if ( ! empty( $s['icon_list'] ) && is_array( $s['icon_list'] ) ) {
					$html .= '<ul>';
					foreach ( $s['icon_list'] as $li ) {
						$t = isset( $li['text'] ) ? wp_strip_all_tags( $li['text'] ) : '';
						$l = isset( $li['link']['url'] ) ? $li['link']['url'] : '';
						$html .= '<li>' . ( $l ? '<a href="' . esc_url( $l ) . '">' . esc_html( $t ) . '</a>' : esc_html( $t ) ) . '</li>';
					}
					$html .= '</ul>';
				}
				break;
		}
	}
	return wp_kses_post( $html );
}

/** Rótulo e ícone do botão de contato conforme o tipo de link. */
function pai_tipo_contato( $link ) {
	if ( 0 === strpos( $link, 'tel:' ) ) {
		$num = trim( substr( $link, 4 ) );
		return array( 'Ligar ' . $num, 'fone' );
	}
	if ( false !== strpos( $link, 'wa.me' ) || false !== strpos( $link, 'whatsapp' ) ) {
		return array( 'Chamar no WhatsApp', 'whats' );
	}
	if ( false !== strpos( $link, 'instagram.com' ) ) {
		return array( 'Ver no Instagram', 'pessoa' );
	}
	return array( 'Visitar o site', 'busca' );
}

/** Nome comparável: sem acento, sem marca, minúsculo. */
function pai_el_chave_nome( $nome ) {
	$n = remove_accents( strtolower( wp_strip_all_tags( (string) $nome ) ) );
	$n = preg_replace( '/\s*-\s*(rigon|cas industrial)\s*$/', '', $n );
	$n = preg_replace( '/[^a-z0-9]+/', ' ', $n );
	return trim( $n );
}

/** Nome do arquivo da imagem, sem tamanho, sem "-1" e sem extensão. */
function pai_el_chave_img( $url ) {
	$b = strtolower( pathinfo( wp_parse_url( (string) $url, PHP_URL_PATH ), PATHINFO_FILENAME ) );
	return preg_replace( '/-(\d+x\d+|scaled)$/', '', $b );
}

/**
 * Catálogo de urnas: junta o carrossel (lista completa) com os blocos de detalhes
 * (foto, nome, descrição e botão Comprar) cadastrados no Elementor.
 */
function pai_el_urnas( $post_id ) {
	$detalhes = pai_el_itens( $post_id );
	$lista    = array();

	// 1) Itens do carrossel, na ordem.
	foreach ( pai_el_widgets( $post_id ) as $w ) {
		if ( false === strpos( $w['tipo'], 'carousel' ) && false === strpos( $w['tipo'], 'slider' ) ) {
			continue;
		}
		foreach ( $w['s'] as $valor ) {
			if ( ! is_array( $valor ) || ! isset( $valor[0]['image'] ) ) {
				continue;
			}
			foreach ( $valor as $sl ) {
				$img = isset( $sl['image'] ) ? $sl['image'] : array();
				$url = pai_el_img( $img );
				if ( ! $url ) {
					continue;
				}
				$lista[] = array(
					'img'    => $url,
					'alt'    => pai_el_alt( $img ),
					'titulo' => isset( $sl['title'] ) ? trim( wp_strip_all_tags( $sl['title'] ) ) : pai_el_alt( $img ),
					'texto'  => '',
					'link'   => isset( $sl['link']['url'] ) ? (string) $sl['link']['url'] : '',
				);
			}
		}
	}

	// 2) Liga cada bloco de detalhes ao item do carrossel: primeiro pelo nome, depois pela foto.
	$usados = array();
	$achar  = function ( $d ) use ( &$lista, &$usados ) {
		foreach ( array( 'nome', 'foto' ) as $modo ) {
			foreach ( $lista as $i => $it ) {
				if ( isset( $usados[ $i ] ) ) {
					continue;
				}
				$ok = 'nome' === $modo
					? pai_el_chave_nome( $it['titulo'] ) === pai_el_chave_nome( $d['titulo'] )
					: pai_el_chave_img( $it['img'] ) === pai_el_chave_img( $d['img'] );
				if ( $ok ) {
					return $i;
				}
			}
		}
		return -1;
	};
	foreach ( $detalhes as $d ) {
		$i = $achar( $d );
		if ( $i >= 0 ) {
			$lista[ $i ]['texto'] = $d['texto'];
			$lista[ $i ]['marca'] = $d['titulo'];
			if ( $d['link'] ) {
				$lista[ $i ]['link'] = $d['link'];
			}
			$usados[ $i ] = 1;
		} elseif ( $d['titulo'] ) {
			$d['marca'] = $d['titulo'];
			$lista[]    = $d;
		}
	}

	foreach ( $lista as &$it ) {
		$completo     = isset( $it['marca'] ) ? $it['marca'] : $it['titulo'];
		$partes       = preg_split( '/\s+-\s+/', $completo, 2 );
		$it['nome']   = trim( $partes[0] ) ? trim( $partes[0] ) : $it['titulo'];
		$it['fabricante'] = isset( $partes[1] ) ? trim( $partes[1] ) : '';
		$it['infantil'] = false !== stripos( $completo, 'infantil' );
	}
	unset( $it );
	return $lista;
}
