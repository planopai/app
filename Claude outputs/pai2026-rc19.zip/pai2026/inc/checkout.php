<?php
/**
 * Checkout (Finalizar compra) no visual do tema · rc12.
 *
 * Antes: a página do checkout era montada no Elementor (modelo Canvas, widget de checkout)
 * e o Fluid Checkout desenhava um topo próprio, fora do visual do site. O widget do Elementor
 * também quebrava o resumo do pedido do Fluid Checkout (não aparecia no computador e,
 * no celular, o botão "Finalizar pedido" ficava escondido).
 *
 * Agora: o tema desenha a página (topo, rodapé, cores e fonte do site) e coloca o formulário
 * padrão do WooCommerce ([woocommerce_checkout]), que continua sendo o do Fluid Checkout.
 * O conteúdo do Elementor da página não é usado. O título muda conforme o pedido:
 * adesão de plano ou coroa de flores.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Página do checkout (inclui "pedido recebido" e "pagar pedido"). */
function pai_eh_checkout() {
	return function_exists( 'is_checkout' ) && is_checkout() && ! is_admin();
}

/** Tipo do pedido na tela: 'planos' (adesão) ou 'coroas'. */
function pai_checkout_tipo() {
	static $tipo = null;
	if ( null !== $tipo ) {
		return $tipo;
	}
	$tipo = 'coroas';
	if ( ! function_exists( 'WC' ) ) {
		return $tipo;
	}
	$pedido_id = function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-received' ) ? absint( get_query_var( 'order-received' ) ) : 0;
	if ( $pedido_id ) {
		$pedido = wc_get_order( $pedido_id );
		if ( $pedido ) {
			$meta = (string) $pedido->get_meta( 'pai_tipo_pedido' );
			if ( '' !== $meta ) {
				$tipo = 'planos' === $meta ? 'planos' : 'coroas';
				return $tipo;
			}
			foreach ( $pedido->get_items() as $item ) {
				$produto = $item->get_product();
				if ( $produto && pai_adesao_eh_produto( $produto ) ) {
					$tipo = 'planos';
					break;
				}
			}
		}
		return $tipo;
	}
	if ( WC()->cart ) {
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['data'] ) && pai_adesao_eh_produto( $item['data'] ) ) {
				$tipo = 'planos';
				break;
			}
		}
	}
	return $tipo;
}

/** Textos do topo da página. */
function pai_checkout_textos() {
	$planos   = 'planos' === pai_checkout_tipo();
	$recebido = function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-received' );
	if ( $recebido ) {
		return $planos
			? array( 'trilha' => 'Adesão ao Plano PAI', 'eyebrow' => 'Contratar pelo site', 'titulo' => 'Adesão recebida', 'lead' => '' )
			: array( 'trilha' => 'Coroas de flores', 'eyebrow' => 'Coroas de flores', 'titulo' => 'Pedido recebido', 'lead' => '' );
	}
	return $planos
		? array( 'trilha' => 'Adesão ao Plano PAI', 'eyebrow' => 'Contratar pelo site', 'titulo' => 'Falta só um passo para ativar o seu plano', 'aba' => 'Pagamento da adesão', 'lead' => 'Seu cadastro já está pronto. Pague a adesão por Pix ou cartão e a carência começa a contar no mesmo dia.' )
		: array( 'trilha' => 'Coroas de flores', 'eyebrow' => 'Coroas de flores', 'titulo' => 'Finalizar pedido', 'lead' => 'Confira os dados da entrega e escolha como pagar.' );
}

/* O Fluid Checkout usa o topo e o rodapé do site (e não o topo próprio dele). Só no site, não no painel. */
add_filter( 'pre_option_fc_hide_site_header_footer_at_checkout', function ( $valor ) {
	return is_admin() ? $valor : 'no';
} );

/* Modelo do tema no checkout (no lugar do Canvas do Elementor e do modelo do Fluid Checkout). */
add_filter( 'template_include', function ( $modelo ) {
	if ( ! pai_eh_checkout() ) {
		return $modelo;
	}
	$p = locate_template( 'modelo-checkout.php' );
	return $p ? $p : $modelo;
}, 10000 );

/* Classe no <body> para o CSS do checkout. */
add_filter( 'body_class', function ( $classes ) {
	if ( pai_eh_checkout() ) {
		$classes[] = 'pai-checkout';
		$classes[] = 'pai-checkout--' . pai_checkout_tipo();
	}
	return $classes;
} );

/* Título da aba do navegador. */
$pai_checkout_titulo_aba = function ( $titulo ) {
	if ( ! pai_eh_checkout() ) {
		return $titulo;
	}
	$t = pai_checkout_textos();
	return ( $t['aba'] ?? $t['titulo'] ) . ' - ' . get_bloginfo( 'name' );
};
add_filter( 'rank_math/frontend/title', $pai_checkout_titulo_aba, 99 );
add_filter( 'pre_get_document_title', $pai_checkout_titulo_aba, 99 );

/*
 * Resumo do pedido no celular: o Fluid Checkout só mostra o botão do resumo no topo próprio dele.
 * Com o topo do site, o tema mostra esse botão acima do formulário (o total se atualiza sozinho).
 */
add_filter( 'woocommerce_update_order_review_fragments', function ( $fragments ) {
	if ( isset( $fragments['.fc-checkout__cart-link'] ) || ! class_exists( 'FluidCheckout_Steps' ) || ! method_exists( 'FluidCheckout_Steps', 'get_checkout_header_cart_link' ) ) {
		return $fragments;
	}
	$fragments['.fc-checkout__cart-link'] = FluidCheckout_Steps::instance()->get_checkout_header_cart_link();
	return $fragments;
}, 20 );

/** Barra "Resumo do pedido" do celular (só aparece em telas menores que 1000px, pelo CSS). */
function pai_checkout_barra_resumo() {
	if ( ! class_exists( 'FluidCheckout_Steps' ) || ! method_exists( 'FluidCheckout_Steps', 'output_checkout_header_cart_link' ) || ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}
	if ( function_exists( 'is_wc_endpoint_url' ) && ( is_wc_endpoint_url( 'order-received' ) || is_wc_endpoint_url( 'order-pay' ) ) ) {
		return;
	}
	echo '<div class="pai-checkout-resumo"><span class="pai-checkout-resumo__rot">Resumo do pedido</span>';
	FluidCheckout_Steps::instance()->output_checkout_header_cart_link();
	echo '</div>';
}

/*
 * rc13: cupom embaixo do resumo do pedido (no computador, dentro do cartão do resumo; no celular, dentro do resumo que abre).
 * O aviso padrão "Tem um cupom?" do WooCommerce ficava acima do formulário. O cupom é aplicado pelo mesmo
 * endereço do WooCommerce (apply_coupon), sem formulário separado.
 */
add_action( 'wp', function () {
	if ( ! pai_eh_checkout() ) {
		return;
	}
	remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
	if ( function_exists( 'wc_coupons_enabled' ) && wc_coupons_enabled() ) {
		add_action( 'fc_checkout_after_order_review_inside', 'pai_checkout_cupom', 20 );
		add_action( 'wp_footer', 'pai_checkout_cupom_js', 30 );
	}
}, 200 );

function pai_checkout_cupom() {
	if ( function_exists( 'is_wc_endpoint_url' ) && ( is_wc_endpoint_url( 'order-received' ) || is_wc_endpoint_url( 'order-pay' ) ) ) {
		return;
	}
	?>
	<details class="pai-cupom">
		<summary>Tem um cupom de desconto?</summary>
		<div class="pai-cupom__campo">
			<label class="sr" for="pai-cupom-codigo">Código do cupom</label>
			<input type="text" id="pai-cupom-codigo" placeholder="Código do cupom" autocomplete="off" autocapitalize="characters">
			<button type="button" class="pai-cupom__aplicar">Aplicar</button>
		</div>
		<div class="pai-cupom__msg" role="status" aria-live="polite"></div>
	</details>
	<?php
}

function pai_checkout_cupom_js() {
	?>
	<script>
	(function () {
		if (typeof jQuery === 'undefined' || typeof wc_checkout_params === 'undefined') { return; }
		var $ = jQuery;
		function aplicar(caixa) {
			var campo = caixa.find('input'), codigo = $.trim(campo.val());
			if (!codigo || caixa.hasClass('carregando')) { return; }
			caixa.addClass('carregando');
			$.post(wc_checkout_params.wc_ajax_url.toString().replace('%%endpoint%%', 'apply_coupon'), {
				security: wc_checkout_params.apply_coupon_nonce,
				coupon_code: codigo,
				billing_email: $('#billing_email').val() || ''
			}).done(function (html) {
				caixa.find('.pai-cupom__msg').html(html);
				if (html && html.indexOf('woocommerce-error') === -1) { campo.val(''); }
				$(document.body).trigger('applied_coupon_in_checkout', [codigo]);
				$(document.body).trigger('update_checkout', { update_shipping_method: false });
			}).always(function () { caixa.removeClass('carregando'); });
		}
		$(document.body).on('click', '.pai-cupom__aplicar', function (e) {
			e.preventDefault();
			aplicar($(this).closest('.pai-cupom'));
		}).on('keydown', '#pai-cupom-codigo', function (e) {
			if (e.key === 'Enter') { e.preventDefault(); aplicar($(this).closest('.pai-cupom')); }
		});
	})();
	</script>
	<?php
}
