<?php
/**
 * Reprodução independente do Elementor, baseada no kit de exportação fornecido
 * pelo proprietário. O conteúdo embutido em widgets HTML não foi reescrito:
 * deve ser testado em homologação antes de desligar plugins no site público.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Somente slugs e arquivos gerados localmente, nunca caminhos vindos do usuário. */
function pai_migracao_tem_exportacao( $slug ) {
	return is_string( $slug ) && preg_match( '/^[a-z0-9.-]+$/D', $slug ) && is_file( PAI_DIR . '/inc/conteudo-importado/' . $slug . '.php' );
}

function pai_migracao_carregar( $slug ) {
	if ( ! pai_migracao_tem_exportacao( $slug ) ) {
		return array();
	}
	$dados = include PAI_DIR . '/inc/conteudo-importado/' . $slug . '.php';
	return is_array( $dados ) ? $dados : array();
}

function pai_migracao_css_num( $num, $min = 0, $max = 1600 ) {
	if ( ! is_numeric( $num ) ) {
		return '';
	}
	return (string) max( $min, min( $max, (float) $num ) );
}

function pai_migracao_dim( $entry, $max = 1400 ) {
	if ( ! is_array( $entry ) || ! isset( $entry['size'] ) ) {
		return '';
	}
	$unit = isset( $entry['unit'] ) ? (string) $entry['unit'] : 'px';
	if ( ! in_array( $unit, array( 'px', '%', 'em', 'rem', 'vw', 'vh' ), true ) ) {
		return '';
	}
	$v = pai_migracao_css_num( $entry['size'], -$max, $max );
	return '' === $v ? '' : $v . $unit;
}

/** Converte apenas propriedades CSS conhecidas. */
function pai_migracao_estilo( $s, $tipo = 'container' ) {
	if ( ! is_array( $s ) ) {
		return '';
	}
	$props = array();
	if ( 'container' === $tipo || 'section' === $tipo || 'column' === $tipo ) {
		$direcao = isset( $s['flex_direction'] ) ? $s['flex_direction'] : 'column';
		$props['display'] = 'flex';
		$props['flex-direction'] = 'row' === $direcao || 'row-reverse' === $direcao ? $direcao : 'column';
		$props['flex-wrap'] = ( isset( $s['flex_wrap'] ) && 'wrap' === $s['flex_wrap'] ) ? 'wrap' : 'nowrap';
		$alinhar = array( 'center', 'flex-start', 'flex-end', 'stretch', 'space-between', 'space-around', 'space-evenly' );
		foreach ( array( 'justify-content' => 'flex_justify_content', 'align-items' => 'flex_align_items' ) as $css => $control ) {
			if ( isset( $s[ $control ] ) && in_array( $s[ $control ], $alinhar, true ) ) {
				$props[ $css ] = $s[ $control ];
			}
		}
		if ( isset( $s['flex_gap'] ) && is_array( $s['flex_gap'] ) ) {
			$gap = pai_migracao_dim( array( 'size' => isset( $s['flex_gap']['column'] ) ? $s['flex_gap']['column'] : ( isset( $s['flex_gap']['size'] ) ? $s['flex_gap']['size'] : '' ), 'unit' => isset( $s['flex_gap']['unit'] ) ? $s['flex_gap']['unit'] : 'px' ), 120 );
			if ( $gap ) {
				$props['gap'] = $gap;
			}
		}
	}
	if ( isset( $s['width'] ) ) {
		$w = pai_migracao_dim( $s['width'] );
		if ( $w ) { $props['width'] = $w; }
	}
	if ( isset( $s['min_height'] ) ) {
		$h = pai_migracao_dim( $s['min_height'] );
		if ( $h ) { $props['min-height'] = $h; }
	}
	foreach ( array( 'padding', 'margin', 'border_radius' ) as $control ) {
		if ( ! empty( $s[ $control ] ) && is_array( $s[ $control ] ) ) {
			$vals = array();
			foreach ( array( 'top', 'right', 'bottom', 'left' ) as $side ) {
				$vals[] = pai_migracao_dim( array( 'size' => isset( $s[ $control ][ $side ] ) ? $s[ $control ][ $side ] : 0, 'unit' => isset( $s[ $control ]['unit'] ) ? $s[ $control ]['unit'] : 'px' ), 250 );
			}
			$props[ str_replace( '_', '-', $control ) ] = implode( ' ', $vals );
		}
	}
	foreach ( array( 'background_color' => 'background-color', 'color' => 'color', 'title_color' => 'color', 'text_color' => 'color' ) as $k => $css ) {
		if ( ! empty( $s[ $k ] ) && is_string( $s[ $k ] ) && preg_match( '/^#[0-9a-f]{3,8}$/iD', $s[ $k ] ) ) {
			$props[ $css ] = $s[ $k ];
		}
	}
	if ( isset( $s['background_image']['url'] ) && is_string( $s['background_image']['url'] ) && 0 === strpos( $s['background_image']['url'], 'https://' ) ) {
		$props['background-image'] = 'url("' . esc_url( $s['background_image']['url'] ) . '")';
		$props['background-size'] = 'cover';
	}
	foreach ( array( 'typography_font_size' => 'font-size', 'typography_font_weight' => 'font-weight' ) as $k => $css ) {
		if ( ! isset( $s[ $k ] ) ) { continue; }
		if ( is_array( $s[ $k ] ) ) {
			$d = pai_migracao_dim( $s[ $k ], 180 );
			if ( $d ) { $props[ $css ] = $d; }
		} elseif ( 'font-weight' === $css && preg_match( '/^[1-9]00$/D', (string) $s[ $k ] ) ) {
			$props[ $css ] = $s[ $k ];
		}
	}
	$pairs = array();
	foreach ( $props as $k => $v ) {
		if ( '' !== $v ) { $pairs[] = $k . ':' . $v; }
	}
	return implode( ';', $pairs );
}

function pai_migracao_link( $s ) {
	return isset( $s['link']['url'] ) && is_string( $s['link']['url'] ) ? esc_url( $s['link']['url'] ) : '';
}

function pai_migracao_img( $s ) {
	$img = isset( $s['image'] ) && is_array( $s['image'] ) ? $s['image'] : array();
	$src = ! empty( $img['url'] ) ? $img['url'] : ( isset( $s['url'] ) ? $s['url'] : '' );
	if ( ! $src ) { return ''; }
	$alt = ! empty( $s['caption'] ) ? wp_strip_all_tags( $s['caption'] ) : '';
	return '<img src="' . esc_url( $src ) . '" loading="lazy" decoding="async" alt="' . esc_attr( $alt ) . '">';
}

function pai_migracao_elementos( $elements, $depth = 0 ) {
	if ( $depth > 25 || ! is_array( $elements ) ) { return; }
	foreach ( $elements as $e ) {
		if ( ! is_array( $e ) ) { continue; }
		$s = isset( $e['settings'] ) && is_array( $e['settings'] ) ? $e['settings'] : array();
		$tipo = isset( $e['type'] ) ? $e['type'] : '';
		if ( in_array( $tipo, array( 'container', 'section', 'column' ), true ) ) {
			$style = pai_migracao_estilo( $s, 'container' );
			echo '<div class="pai-migrado__container"' . ( $style ? ' style="' . esc_attr( $style ) . '"' : '' ) . '>';
			pai_migracao_elementos( isset( $e['elements'] ) ? $e['elements'] : array(), $depth + 1 );
			echo '</div>';
			continue;
		}
		if ( 'widget' !== $tipo ) { continue; }
		$widget = isset( $e['widget'] ) ? $e['widget'] : '';
		$css = pai_migracao_estilo( $s, 'widget' );
		// HTML includes scripts written by the site owner. Do not silently remove business functionality.
		if ( 'html' === $widget ) {
			if ( isset( $s['html'] ) && is_string( $s['html'] ) ) {
				echo '<div class="pai-migrado__html">' . $s['html'] . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			continue;
		}
		echo '<div class="pai-migrado__widget pai-migrado__' . esc_attr( sanitize_html_class( $widget ) ) . '"' . ( $css ? ' style="' . esc_attr( $css ) . '"' : '' ) . '>';
		switch ( $widget ) {
			case 'heading':
				$tag = isset( $s['header_size'] ) && in_array( $s['header_size'], array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ? $s['header_size'] : 'h2';
				echo '<' . $tag . '>' . wp_kses_post( isset( $s['title'] ) ? $s['title'] : '' ) . '</' . $tag . '>';
				break;
			case 'text-editor':
				echo wp_kses_post( isset( $s['editor'] ) ? $s['editor'] : '' );
				break;
			case 'image':
				$img = pai_migracao_img( $s );
				$url = pai_migracao_link( $s );
				echo $url ? '<a href="' . $url . '">' . $img . '</a>' : $img;
				break;
			case 'button':
				$url = pai_migracao_link( $s );
				$label = isset( $s['text'] ) ? $s['text'] : __( 'Saiba mais', 'pai2026' );
				if ( $url ) { echo '<a class="pai-migrado__botao" href="' . $url . '">' . esc_html( $label ) . '</a>'; }
				break;
			case 'image-box':
			case 'icon-box':
				if ( 'image-box' === $widget ) { echo pai_migracao_img( $s ); }
				if ( isset( $s['title_text'] ) ) { echo '<h3>' . esc_html( $s['title_text'] ) . '</h3>'; }
				if ( isset( $s['description_text'] ) ) { echo wp_kses_post( wpautop( $s['description_text'] ) ); }
				break;
			case 'divider':
				echo '<hr aria-hidden="true">';
				break;
			case 'spacer':
				$h = isset( $s['space'] ) ? pai_migracao_dim( $s['space'], 180 ) : '';
				echo '<div class="pai-migrado__espaco" aria-hidden="true"' . ( $h ? ' style="height:' . esc_attr( $h ) . '"' : '' ) . '></div>';
				break;
			case 'icon-list':
				$itens = isset( $s['icon_list'] ) ? $s['icon_list'] : array();
				echo '<ul class="pai-migrado__lista">';
				foreach ( (array) $itens as $it ) {
					$label = esc_html( isset( $it['text'] ) ? $it['text'] : '' );
					$link = isset( $it['link']['url'] ) ? esc_url( $it['link']['url'] ) : '';
					echo '<li>' . ( $link ? '<a href="' . $link . '">' . $label . '</a>' : $label ) . '</li>';
				}
				echo '</ul>';
				break;
			case 'shortcode':
				if ( isset( $s['shortcode'] ) && is_string( $s['shortcode'] ) ) {
					echo do_shortcode( $s['shortcode'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				break;
			case 'wpforms':
				$id = isset( $s['form_id'] ) ? absint( $s['form_id'] ) : 0;
				if ( $id ) { echo do_shortcode( '[wpforms id="' . $id . '"]' ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;
			case 'woocommerce-my-account':
				echo do_shortcode( '[woocommerce_my_account]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;
			case 'woocommerce-checkout-page':
				echo do_shortcode( '[woocommerce_checkout]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;
			case 'woocommerce-purchase-summary':
				echo do_shortcode( '[woocommerce_checkout]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;
			case 'ha-link-hover':
				if ( isset( $s['title'] ) ) { echo '<p>' . esc_html( $s['title'] ) . '</p>'; }
				break;
			case 'shopengine-product-list':
				if ( class_exists( 'WooCommerce' ) ) { echo do_shortcode( '[products limit="8" columns="4"]' ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;
		}
		echo '</div>';
	}
}

function pai_migracao_render( $slug ) {
	$elementos = pai_migracao_carregar( $slug );
	if ( ! $elementos ) { return false; }
	echo '<div class="pai-migrado" data-pai-migrado="' . esc_attr( $slug ) . '">';
	pai_migracao_elementos( $elementos );
	echo '</div>';
	return true;
}

// No site de produção, impedir acesso não autorizado às páginas de gestão do velório
// caso o Elementor seja removido antes de concluída a revisão dos controles de acesso.
add_action( 'template_redirect', function () {
	if ( class_exists( '\\Elementor\\Plugin' ) || ! is_page() ) { return; }
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	if ( 0 === strpos( $slug, 'admin-velorio-online' ) && ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Área restrita. Entre em contato com a administração.', 'pai2026' ), esc_html__( 'Acesso restrito', 'pai2026' ), array( 'response' => 403 ) );
	}
}, 0 );
