<?php
/**
 * Adesão online (tela /adesao/ + WooCommerce + planos-novos.php).
 *
 * Fluxo:
 * 1. /adesao/?plano=flex — o visitante preenche titular, endereço, família, sucessor e aceite.
 *    O navegador grava o cadastro direto no planos-novos.php (acao=cadastrar) e recebe um código.
 * 2. /adesao/pagar/?c=CODIGO — o site confere o código no planos-novos.php (com a chave),
 *    põe no carrinho o produto de adesão do plano (SKU adesao-light, adesao-flex, adesao-plus, adesao-max)
 *    e leva ao checkout do WooCommerce (Cielo: Pix e cartão).
 * 3. Pedido criado → planos-novos.php (acao=pedido). Pedido pago → acao=pagamento (pago), que marca o
 *    início da carência e envia a notificação. Cancelado/estornado → acao=pagamento (cancelado).
 *
 * Configuração:
 * - wp-config.php: define( 'PAI_PLANOS_CHAVE', '<a mesma planos_novos_chave do pai-chaves.php>' );
 * - Personalizar > Plano PAI > links: endereço do planos-novos.php e PDFs dos Termos (opcional).
 * - WooCommerce: 4 produtos simples e virtuais, com os SKUs acima, preço = adesão, visibilidade "Oculto".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const PAI_ADESAO_SKU = 'adesao-';
const PAI_ADESAO_META = '_pai_adesao_codigo';

/** Endereço do planos-novos.php. */
function pai_planos_api() {
	return (string) pai_opt( 'url_api_planos' );
}

/** Chamada do servidor do site ao planos-novos.php, com a chave. */
function pai_planos_post( array $dados ) {
	$chave = defined( 'PAI_PLANOS_CHAVE' ) ? (string) PAI_PLANOS_CHAVE : '';
	if ( strlen( $chave ) < 32 ) {
		return new WP_Error( 'sem_chave', 'PAI_PLANOS_CHAVE não configurada no wp-config.php.' );
	}
	$r = wp_remote_post( pai_planos_api(), array(
		'timeout' => 20,
		'headers' => array( 'Content-Type' => 'application/json', 'X-PAI-Planos-Key' => $chave ),
		'body'    => wp_json_encode( $dados ),
	) );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	$j = json_decode( (string) wp_remote_retrieve_body( $r ), true );
	if ( ! is_array( $j ) ) {
		return new WP_Error( 'resposta', 'Resposta inválida do planos-novos.php (HTTP ' . wp_remote_retrieve_response_code( $r ) . ').' );
	}
	if ( ! empty( $j['erro'] ) ) {
		return new WP_Error( 'recusado', (string) ( $j['msg'] ?? 'Recusado.' ), array( 'status' => wp_remote_retrieve_response_code( $r ) ) );
	}
	return $j;
}

/** Tabela de valores e regras (do planos-novos.php, guardada por 1 hora; reserva com os valores do painel). */
function pai_planos_tabela() {
	$t = get_transient( 'pai_planos_tabela' );
	if ( is_array( $t ) ) {
		return $t;
	}
	$r = wp_remote_get( add_query_arg( 'acao', 'tabela', pai_planos_api() ), array( 'timeout' => 8 ) );
	$j = is_wp_error( $r ) ? null : json_decode( (string) wp_remote_retrieve_body( $r ), true );
	if ( is_array( $j ) && empty( $j['erro'] ) && ! empty( $j['planos'] ) ) {
		set_transient( 'pai_planos_tabela', $j, HOUR_IN_SECONDS );
		return $j;
	}
	return null;
}

/** Produto de adesão do plano (pelo SKU). */
function pai_adesao_produto( $plano ) {
	if ( ! function_exists( 'wc_get_product_id_by_sku' ) ) {
		return null;
	}
	$id = wc_get_product_id_by_sku( PAI_ADESAO_SKU . strtolower( $plano ) );
	$p  = $id ? wc_get_product( $id ) : null;
	return ( $p && $p->is_purchasable() ) ? $p : null;
}

/** É produto de adesão? */
function pai_adesao_eh_produto( $produto ) {
	if ( is_numeric( $produto ) ) {
		$produto = wc_get_product( $produto );
	}
	return $produto && 0 === strpos( (string) $produto->get_sku(), PAI_ADESAO_SKU );
}

/* ---------- 2. /adesao/pagar/?c=CODIGO: monta o carrinho e vai ao checkout ---------- */
add_action( 'template_redirect', function () {
	if ( 'adesao_pagar' !== pai_rota() ) {
		return;
	}
	$volta = home_url( '/adesao/' );
	$codigo = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) ( $_GET['c'] ?? '' ) ) );
	if ( strlen( $codigo ) !== 12 || ! function_exists( 'WC' ) ) {
		wp_safe_redirect( $volta );
		exit;
	}
	$r = pai_planos_post( array( 'acao' => 'consultar_codigo', 'codigo' => $codigo ) );
	if ( is_wp_error( $r ) ) {
		error_log( '[adesao] consultar_codigo: ' . $r->get_error_message() );
		wp_safe_redirect( add_query_arg( 'aviso', 'indisponivel', $volta ) );
		exit;
	}
	$cad = $r['cadastro'];
	if ( in_array( $cad['status'], array( 'pago', 'contrato_criado' ), true ) ) {
		wp_safe_redirect( add_query_arg( 'aviso', 'ja_pago', $volta ) );
		exit;
	}
	$produto = pai_adesao_produto( $cad['plano'] );
	if ( ! $produto ) {
		error_log( '[adesao] produto ' . PAI_ADESAO_SKU . strtolower( $cad['plano'] ) . ' não encontrado ou sem preço.' );
		wp_safe_redirect( add_query_arg( 'aviso', 'indisponivel', $volta ) );
		exit;
	}

	if ( WC()->cart === null && function_exists( 'wc_load_cart' ) ) {
		wc_load_cart();
	}
	WC()->cart->empty_cart();
	$GLOBALS['pai_adesao_adicionando'] = true;
	WC()->cart->add_to_cart( $produto->get_id(), 1, 0, array(), array( 'pai_adesao' => array( 'codigo' => $codigo, 'plano' => $cad['plano'] ) ) );
	$GLOBALS['pai_adesao_adicionando'] = false;

	// Dados para preencher o checkout.
	WC()->session->set( 'pai_adesao_cliente', array(
		// Nome completo no primeiro campo (o formulário "Adesão de planos" do plugin PAI · Formulários do Checkout usa só ele).
		'billing_first_name' => (string) $cad['titular_nome'],
		'billing_email'      => (string) $cad['titular_email'],
		'billing_phone'      => (string) $cad['titular_celular'],
		'billing_postcode'   => (string) $cad['cep'],
		'billing_address_1'  => trim( $cad['logradouro'] . ', ' . $cad['numero'], ', ' ),
		'billing_address_2'  => (string) $cad['complemento'],
		'billing_city'       => (string) $cad['cidade'],
		'billing_state'      => (string) $cad['uf'],
		'billing_country'    => 'BR',
		'billing_cpf'        => (string) $cad['titular_cpf'],
		'billing_neighborhood' => (string) $cad['bairro'],
	) );
	wp_safe_redirect( wc_get_checkout_url() );
	exit;
} );

/* Produto de adesão só entra no carrinho pelo caminho acima (com o código do cadastro). */
add_filter( 'woocommerce_add_to_cart_validation', function ( $ok, $produto_id ) {
	if ( $ok && pai_adesao_eh_produto( $produto_id ) && empty( $GLOBALS['pai_adesao_adicionando'] ) ) {
		wc_add_notice( 'Para contratar um plano, faça a adesão pela página de adesão.', 'error' );
		return false;
	}
	return $ok;
}, 10, 2 );

/* Uma adesão por pedido e sem misturar com outros produtos. */
add_filter( 'woocommerce_add_to_cart_validation', function ( $ok, $produto_id ) {
	if ( ! $ok || ! WC()->cart ) {
		return $ok;
	}
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( ! empty( $item['pai_adesao'] ) && ! pai_adesao_eh_produto( $produto_id ) ) {
			wc_add_notice( 'Finalize primeiro o pagamento da adesão do plano. Depois faça o outro pedido.', 'error' );
			return false;
		}
	}
	return $ok;
}, 11, 2 );

/* Quantidade fixa em 1 e item sem link para a página do produto. */
add_filter( 'woocommerce_cart_item_quantity', function ( $html, $chave, $item ) {
	return ! empty( $item['pai_adesao'] ) ? '1' : $html;
}, 10, 3 );
add_filter( 'woocommerce_cart_item_permalink', function ( $link, $item ) {
	return ! empty( $item['pai_adesao'] ) ? '' : $link;
}, 10, 2 );
add_filter( 'woocommerce_get_item_data', function ( $dados, $item ) {
	if ( ! empty( $item['pai_adesao']['codigo'] ) ) {
		$dados[] = array( 'name' => 'Cadastro', 'value' => $item['pai_adesao']['codigo'] );
	}
	return $dados;
}, 10, 2 );

/* Checkout já preenchido com os dados do cadastro. */
add_filter( 'woocommerce_checkout_get_value', function ( $valor, $campo ) {
	if ( null !== $valor && '' !== $valor ) {
		return $valor;
	}
	$d = function_exists( 'WC' ) && WC()->session ? WC()->session->get( 'pai_adesao_cliente' ) : null;
	return ( is_array( $d ) && isset( $d[ $campo ] ) && '' !== $d[ $campo ] ) ? $d[ $campo ] : $valor;
}, 10, 2 );

/* Código do cadastro no item e no pedido. */
add_action( 'woocommerce_checkout_create_order_line_item', function ( $item, $chave, $valores ) {
	if ( ! empty( $valores['pai_adesao']['codigo'] ) ) {
		$item->add_meta_data( 'Cadastro', $valores['pai_adesao']['codigo'], true );
		$item->add_meta_data( PAI_ADESAO_META, $valores['pai_adesao']['codigo'], true );
	}
}, 10, 3 );

function pai_adesao_codigo_do_pedido( $pedido ) {
	if ( ! $pedido instanceof WC_Order ) {
		return '';
	}
	$c = (string) $pedido->get_meta( PAI_ADESAO_META );
	if ( '' !== $c ) {
		return $c;
	}
	foreach ( $pedido->get_items() as $item ) {
		$c = (string) $item->get_meta( PAI_ADESAO_META );
		if ( '' !== $c ) {
			$pedido->update_meta_data( PAI_ADESAO_META, $c );
			$pedido->save();
			return $c;
		}
	}
	return '';
}

/** Avisa o planos-novos.php; se falhar, tenta de novo em 5 minutos (até 6 vezes). */
function pai_adesao_avisar( $pedido_id, $acao, $tentativa = 0 ) {
	$pedido = wc_get_order( $pedido_id );
	$codigo = pai_adesao_codigo_do_pedido( $pedido );
	if ( '' === $codigo ) {
		return;
	}
	if ( 'pago' === $acao && $pedido->get_meta( '_pai_adesao_pago_ok' ) ) {
		return;
	}
	$dados = array( 'acao' => 'pedido', 'codigo' => $codigo, 'pedido' => (int) $pedido_id );
	if ( 'pago' === $acao ) {
		$pago = $pedido->get_date_paid() ? $pedido->get_date_paid() : $pedido->get_date_created();
		$dados = array(
			'acao'     => 'pagamento',
			'codigo'   => $codigo,
			'pedido'   => (int) $pedido_id,
			'situacao' => 'pago',
			'valor'    => (float) $pedido->get_total(),
			'metodo'   => $pedido->get_payment_method_title(),
			'pago_em'  => $pago ? $pago->date_i18n( 'Y-m-d H:i:s' ) : current_time( 'mysql' ),
		);
	} elseif ( 'cancelado' === $acao ) {
		$dados = array( 'acao' => 'pagamento', 'codigo' => $codigo, 'pedido' => (int) $pedido_id, 'situacao' => 'cancelado', 'motivo' => 'Pedido ' . $pedido->get_status() );
	}
	$r = pai_planos_post( $dados );
	if ( is_wp_error( $r ) ) {
		$pedido->add_order_note( 'Adesão: não foi possível avisar o sistema (' . $acao . '): ' . $r->get_error_message() );
		$status = (int) ( $r->get_error_data()['status'] ?? 0 );
		if ( $tentativa < 6 && ( $status === 0 || $status >= 500 ) ) {
			wp_schedule_single_event( time() + 300, 'pai_adesao_avisar_de_novo', array( (int) $pedido_id, $acao, $tentativa + 1 ) );
		}
		return;
	}
	if ( 'pago' === $acao ) {
		$pedido->update_meta_data( '_pai_adesao_pago_ok', current_time( 'mysql' ) );
		$pedido->save();
		if ( empty( $r['repetido'] ) ) {
			$pedido->add_order_note( 'Adesão ' . $codigo . ': pagamento informado ao sistema. A carência começa na data do pagamento.' );
		}
	}
}
add_action( 'pai_adesao_avisar_de_novo', 'pai_adesao_avisar', 10, 3 );

/* Pedido criado (checkout clássico e em blocos). */
add_action( 'woocommerce_checkout_order_processed', function ( $pedido_id ) {
	pai_adesao_avisar( $pedido_id, 'pedido' );
}, 20 );
add_action( 'woocommerce_store_api_checkout_order_processed', function ( $pedido ) {
	pai_adesao_avisar( $pedido->get_id(), 'pedido' );
}, 20 );

/* Pago. */
add_action( 'woocommerce_payment_complete', function ( $pedido_id ) {
	pai_adesao_avisar( $pedido_id, 'pago' );
} );
add_action( 'woocommerce_order_status_processing', function ( $pedido_id ) {
	pai_adesao_avisar( $pedido_id, 'pago' );
} );
add_action( 'woocommerce_order_status_completed', function ( $pedido_id ) {
	pai_adesao_avisar( $pedido_id, 'pago' );
} );

/* Cancelado ou estornado. */
add_action( 'woocommerce_order_status_cancelled', function ( $pedido_id ) {
	pai_adesao_avisar( $pedido_id, 'cancelado' );
} );
add_action( 'woocommerce_order_status_refunded', function ( $pedido_id ) {
	pai_adesao_avisar( $pedido_id, 'cancelado' );
} );

/* Adesão é serviço: pedido pago vai direto para "Concluído". */
add_filter( 'woocommerce_payment_complete_order_status', function ( $status, $pedido_id, $pedido ) {
	return pai_adesao_codigo_do_pedido( $pedido ) !== '' ? 'completed' : $status;
}, 10, 3 );

/* Página de obrigado. */
add_action( 'woocommerce_thankyou', function ( $pedido_id ) {
	$pedido = wc_get_order( $pedido_id );
	if ( '' === pai_adesao_codigo_do_pedido( $pedido ) ) {
		return;
	}
	if ( WC()->session ) {
		WC()->session->__unset( 'pai_adesao_cliente' );
	}
	echo '<div class="adesao-obrigado card"><h2 class="h2">Bem-vindo ao Plano PAI!</h2>';
	if ( $pedido->is_paid() ) {
		echo '<p>Recebemos o pagamento da adesão. <strong>A carência começa hoje.</strong></p>';
	} else {
		echo '<p>Assim que o pagamento for confirmado, a sua adesão é liberada e a carência começa a contar.</p>';
	}
	echo '<ol><li>Nossa equipe cadastra o seu contrato e envia o número pelo WhatsApp.</li>';
	echo '<li>Combinamos com você a assinatura do Termo de Adesão.</li>';
	echo '<li>A primeira mensalidade vem depois, pelo app, boleto ou link de pagamento.</li></ol>';
	echo '<p>Dúvidas? Fale com a gente pelo <a href="' . esc_url( pai_wa( 'Olá! Acabei de fazer a adesão ao Plano PAI pelo site.' ) ) . '">WhatsApp ' . esc_html( pai_opt( 'whatsapp' ) ) . '</a>.</p></div>';
}, 5 );
