<?php
/**
 * Aparência > Personalizar > Plano PAI: contatos, links, preços e fotos.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'customize_register', function ( $wp ) {
	$p = pai_padroes();

	$wp->add_panel( 'pai', array(
		'title'    => 'Plano PAI',
		'priority' => 25,
	) );

	$secoes = array(
		'pai_contatos' => 'Contatos e endereços',
		'pai_links'    => 'Botões e links',
		'pai_precos'   => 'Preços dos planos',
		'pai_coroas'   => 'Coroas de flores',
		'pai_fotos'    => 'Fotos',
		'pai_paginas'  => 'Textos das páginas',
	);
	foreach ( $secoes as $id => $titulo ) {
		$wp->add_section( $id, array( 'title' => $titulo, 'panel' => 'pai' ) );
	}

	$texto = function ( $chave, $rotulo, $secao, $tipo = 'text', $ajuda = '' ) use ( $wp, $p ) {
		$sanitiza = 'sanitize_text_field';
		if ( 'url' === $tipo ) {
			$sanitiza = function ( $v ) {
				$v = trim( (string) $v );
				return 0 === strpos( $v, '/' ) ? sanitize_text_field( $v ) : esc_url_raw( $v );
			};
			$tipo = 'text';
		} elseif ( 'number' === $tipo ) {
			$sanitiza = function ( $v ) {
				return (float) str_replace( ',', '.', (string) $v );
			};
		} elseif ( 'email' === $tipo ) {
			$sanitiza = 'sanitize_email';
		}
		$wp->add_setting( 'pai_' . $chave, array(
			'default'           => $p[ $chave ],
			'sanitize_callback' => $sanitiza,
		) );
		$wp->add_control( 'pai_' . $chave, array(
			'label'       => $rotulo,
			'section'     => $secao,
			'type'        => $tipo,
			'description' => $ajuda,
			'input_attrs' => 'number' === $tipo ? array( 'step' => '0.01', 'min' => '0' ) : array(),
		) );
	};

	// Contatos
	$texto( 'tel_plantao', 'Plantão 24 horas (celular)', 'pai_contatos' );
	$texto( 'tel_fixo', 'Plantão fixo', 'pai_contatos' );
	$texto( 'whatsapp', 'WhatsApp de atendimento', 'pai_contatos', 'text', 'Usado no botão verde, no simulador e nas dúvidas.' );
	$texto( 'email', 'E-mail', 'pai_contatos', 'email' );
	$texto( 'instagram', 'Instagram (link)', 'pai_contatos', 'url' );
	$texto( 'end_sede', 'Endereço da sede', 'pai_contatos' );
	$texto( 'end_memorial', 'Endereço do Memorial', 'pai_contatos' );
	$texto( 'cnpj', 'CNPJ', 'pai_contatos' );

	// Links
	$texto( 'url_contratar', 'Botão "Contratar agora"', 'pai_links', 'url', 'Landing page de cadastro. Pode ser um endereço do site (ex.: /landing-page/) ou um link completo.' );
	$texto( 'url_associado', 'Botão "Sou associado"', 'pai_links', 'url', 'Área do associado e Clube de benefícios.' );
	$texto( 'url_telemedicina', 'Plataforma de Telemedicina', 'pai_links', 'url', 'Abre no topo do site, no rodapé e dentro da página Telemedicina.' );
	$texto( 'url_app', 'Página do aplicativo', 'pai_links', 'url' );
	$wp->add_setting( 'pai_whats_flutuante', array( 'default' => 1, 'sanitize_callback' => 'absint' ) );
	$wp->add_control( 'pai_whats_flutuante', array(
		'label'       => 'Mostrar o botão flutuante do WhatsApp',
		'description' => 'Desmarque se outro plugin já mostra esse botão.',
		'section'     => 'pai_links',
		'type'        => 'checkbox',
	) );

	// Preços
	$texto( 'p_light', 'LIGHT (R$/mês)', 'pai_precos', 'number' );
	$texto( 'p_flex_1', 'FLEX até 54 anos', 'pai_precos', 'number' );
	$texto( 'p_flex_2', 'FLEX 55 a 64 anos', 'pai_precos', 'number' );
	$texto( 'p_flex_3', 'FLEX 65 a 74 anos', 'pai_precos', 'number' );
	$texto( 'p_flex_4', 'FLEX 75 anos ou mais', 'pai_precos', 'number' );
	$texto( 'p_plus', 'PLUS (R$/mês)', 'pai_precos', 'number' );
	$texto( 'p_max', 'MAX (R$/mês)', 'pai_precos', 'number', 'O dependente extra é calculado sozinho: 20% da mensalidade.' );
	$texto( 'ad_light_flex', 'Adesão LIGHT e FLEX', 'pai_precos', 'number' );
	$texto( 'ad_plus_max', 'Adesão PLUS e MAX', 'pai_precos', 'number' );
	$texto( 'p_translado', 'Translado Nacional (R$/mês)', 'pai_precos', 'number' );

	// Coroas
	$texto( 'url_foto_topo', 'Foto do topo (endereço da imagem)', 'pai_fotos', 'url', 'Usada no fundo do topo da página inicial e da landing page, e no quadro do topo quando nenhuma foto for escolhida acima.' );
	$texto( 'url_play', 'Aplicativo na Play Store (link)', 'pai_links', 'url' );
	$texto( 'url_api_planos', 'Adesão online: endereço do planos-novos.php', 'pai_links', 'url' );
	foreach ( array( 'light' => 'LIGHT', 'flex' => 'FLEX', 'plus' => 'PLUS', 'max' => 'MAX' ) as $k => $n ) {
		$texto( 'termo_' . $k, 'Termo de Adesão ' . $n . ' (link do PDF, opcional)', 'pai_links', 'url' );
	}
	$texto( 'url_api_pagamento', 'Link de pagamento da mensalidade (endereço da API)', 'pai_links', 'url' );
	$texto( 'whats_urnas', 'WhatsApp das urnas', 'pai_contatos', 'text', 'Usado no botão "Quero esta urna" quando a urna não tem link próprio no Elementor.' );
	$texto( 'avaliacoes_shortcode', 'Avaliações do Google (shortcode)', 'pai_paginas', 'text', 'Cole o shortcode do plugin de avaliações do Google (ex.: [trustindex no-registration=google]). Vazio, a seção não aparece.' );
	$texto( 'tele_campanha', 'Telemedicina: campanha promocional', 'pai_paginas', 'textarea', 'Aparece em destaque na página Telemedicina. Quando a campanha acabar, apague o texto e o destaque some.' );
	$texto( 'tele_quem', 'Telemedicina: quem tem direito', 'pai_paginas', 'textarea', 'Aparece na página Telemedicina.' );
	$texto( 'coroa_entrega', 'Taxa de entrega em Barreiras (R$)', 'pai_coroas', 'number' );

	// Fotos
	$fotos = array(
		'img_hero'  => 'Foto do topo da página inicial',
		'img_mem_1' => 'Memorial: foto grande (fachada)',
		'img_mem_2' => 'Memorial: foto 2',
		'img_mem_3' => 'Memorial: foto 3',
		'img_mem_4' => 'Memorial: foto 4',
		'img_mem_5' => 'Memorial: foto 5',
	);
	foreach ( $fotos as $chave => $rotulo ) {
		$wp->add_setting( 'pai_' . $chave, array( 'default' => '', 'sanitize_callback' => 'absint' ) );
		$wp->add_control( new WP_Customize_Media_Control( $wp, 'pai_' . $chave, array(
			'label'     => $rotulo,
			'section'   => 'pai_fotos',
			'mime_type' => 'image',
		) ) );
	}
} );
