<?php
/**
 * Páginas montadas pelo tema sem precisar criar a página no WordPress:
 * - /planos-funerarios/light/, /flex/, /plus/, /max/ (uma página por plano)
 * - /pagar-mensalidade/
 * Também cuida do título, da descrição e do endereço oficial (canonical) delas.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Dados de cada plano, conforme os Termos de Adesão aprovados em 02/10/2026. */
function pai_planos_dados() {
	$pr = pai_precos();
	return array(
		'light' => array(
			'nome'      => 'LIGHT',
			'cor'       => 'verde',
			'titulo'    => 'Plano LIGHT',
			'chamada'   => 'O essencial, com todo o cuidado',
			'resumo'    => 'O plano de entrada do PAI: assistência funerária completa para a família básica, com mensalidade que cabe no orçamento.',
			'preco'     => 'R$ ' . pai_reais( $pr['light'] ),
			'de'        => '',
			'adesao'    => $pr['ad_lf'],
			'quem'      => array( 'Titular e cônjuge', 'Filhos solteiros', 'Pais ou sogros' ),
			'extras'    => 'Outras pessoas: até 2 dependentes extras, por R$ ' . pai_reais( $pr['ex_light'], true ) . ' por mês cada.',
			'cobertura' => array(
				array( 'Urna e roupa', 'Semiluxo' ),
				array( 'Coroa e véu', 'Coroa artificial de 60 cm e tule ou véu' ),
				array( 'Translado', 'Até 200 km' ),
				array( 'Tanatopraxia', 'Não disponível' ),
				array( 'Telemedicina', 'Não disponível' ),
			),
			'para'      => array( 'Quem quer começar a proteger a família gastando pouco', 'Famílias que moram em Barreiras e região' ),
			'checkout'  => 'checkout-plano-light',
			'seo'       => 'Plano LIGHT em Barreiras-BA: plano funerário a partir de R$ ' . pai_reais( $pr['light'] ) . ' por mês, para cônjuge, filhos e pais ou sogros, com plantão 24 horas.',
		),
		'flex'  => array(
			'nome'      => 'FLEX',
			'cor'       => 'sol',
			'titulo'    => 'Plano FLEX',
			'chamada'   => 'Para a família grande',
			'resumo'    => 'Titular e até 9 dependentes de qualquer parentesco. A mensalidade segue a idade da pessoa mais velha do contrato.',
			'preco'     => 'R$ ' . pai_reais( $pr['flex'][0] ),
			'de'        => 'a partir de',
			'adesao'    => $pr['ad_lf'],
			'quem'      => array( 'Titular e até 9 dependentes', 'Qualquer parentesco com vínculo familiar', 'Urna pet incluída' ),
			'extras'    => 'Mensalidade pela idade da pessoa mais velha: R$ ' . pai_reais( $pr['flex'][0] ) . ' (até 54 anos), R$ ' . pai_reais( $pr['flex'][1] ) . ' (55 a 64), R$ ' . pai_reais( $pr['flex'][2] ) . ' (65 a 74) e R$ ' . pai_reais( $pr['flex'][3] ) . ' (75 ou mais).',
			'cobertura' => array(
				array( 'Urna e roupa', 'Semiluxo' ),
				array( 'Coroa e véu', 'Coroa natural ou artificial (conforme a disponibilidade) e tule ou véu' ),
				array( 'Translado', 'Até 500 km, ou pelo Brasil todo com o aditivo de Translado Nacional (R$ ' . pai_reais( $pr['translado'] ) . ' por mês)' ),
				array( 'Tanatopraxia', 'Simples, por aditivo (+20% na mensalidade)' ),
				array( 'Telemedicina', 'Disponível à parte' ),
			),
			'para'      => array( 'Famílias grandes ou com parentes que não entram nos outros planos', 'Quem quer incluir o animal de estimação' ),
			'checkout'  => 'checkout-plano-flex',
			'seo'       => 'Plano FLEX em Barreiras-BA: titular e até 9 dependentes de qualquer parentesco, mensalidade a partir de R$ ' . pai_reais( $pr['flex'][0] ) . ' pela idade do mais velho.',
		),
		'plus'  => array(
			'nome'      => 'PLUS',
			'cor'       => 'azul',
			'titulo'    => 'Plano PLUS',
			'chamada'   => 'Mais gente protegida, com urna de luxo',
			'resumo'    => 'A família básica e mais 2 pessoas à sua escolha, sem custo, com urna de luxo, tanatopraxia e translado até 1.000 km.',
			'preco'     => 'R$ ' . pai_reais( $pr['plus'] ),
			'de'        => '',
			'adesao'    => $pr['ad_pm'],
			'quem'      => array( 'Titular e cônjuge', 'Filhos solteiros', 'Pais ou sogros', 'Mais 2 pessoas à sua escolha, sem custo' ),
			'extras'    => 'A partir da 3ª pessoa extra: R$ ' . pai_reais( $pr['ex_plus'], true ) . ' por mês cada.',
			'cobertura' => array(
				array( 'Urna e roupa', 'Luxo' ),
				array( 'Coroa e véu', 'Coroa natural de 1,10 m e véu de luxo' ),
				array( 'Translado', 'Até 1.000 km, ou pelo Brasil todo com o aditivo de Translado Nacional (R$ ' . pai_reais( $pr['translado'] ) . ' por mês)' ),
				array( 'Tanatopraxia', 'Simples, incluída' ),
				array( 'Telemedicina', 'Disponível à parte' ),
			),
			'para'      => array( 'Quem quer incluir pessoas fora da família básica', 'Quem quer urna de luxo e tanatopraxia sem custo extra' ),
			'checkout'  => 'checkout-plano-plus',
			'seo'       => 'Plano PLUS em Barreiras-BA: família básica e mais 2 pessoas sem custo, urna de luxo, tanatopraxia e translado até 1.000 km.',
		),
		'max'   => array(
			'nome'      => 'MAX',
			'cor'       => 'branco',
			'titulo'    => 'Plano MAX',
			'chamada'   => 'O plano mais completo do PAI',
			'resumo'    => 'Tudo o que o PLUS oferece, com translado terrestre para todo o Brasil, sem limite de km, e Telemedicina incluída.',
			'preco'     => 'R$ ' . pai_reais( $pr['max'] ),
			'de'        => '',
			'adesao'    => $pr['ad_pm'],
			'quem'      => array( 'Titular e cônjuge', 'Filhos solteiros', 'Pais ou sogros', 'Mais 2 pessoas à sua escolha, sem custo' ),
			'extras'    => 'A partir da 3ª pessoa extra: R$ ' . pai_reais( $pr['ex_max'], true ) . ' por mês cada.',
			'cobertura' => array(
				array( 'Urna e roupa', 'Luxo' ),
				array( 'Coroa e véu', 'Coroa natural de 1,10 m e véu de luxo' ),
				array( 'Translado', 'Terrestre, para todo o Brasil, sem limite de km (até a cidade de residência ou a cidade natal)' ),
				array( 'Tanatopraxia', 'Simples, incluída' ),
				array( 'Telemedicina', 'Incluída, sem carência' ),
			),
			'para'      => array( 'Famílias com pessoas em outros estados', 'Quem nasceu em outra cidade e quer ser levado para casa', 'Quem quer médico pelo celular no dia a dia' ),
			'checkout'  => '',
			'seo'       => 'Plano MAX em Barreiras-BA: translado terrestre para todo o Brasil sem limite de km, Telemedicina incluída, urna de luxo e tanatopraxia.',
		),
	);
}

/* Endereços novos */
add_action( 'init', function () {
	add_rewrite_rule( '^planos-funerarios/(light|flex|plus|max)/?$', 'index.php?pai_rota=plano&pai_plano=$matches[1]', 'top' );
	add_rewrite_rule( '^pagar-mensalidade/?$', 'index.php?pai_rota=pagar', 'top' );
	add_rewrite_rule( '^adesao/pagar/?$', 'index.php?pai_rota=adesao_pagar', 'top' );
	add_rewrite_rule( '^adesao/?$', 'index.php?pai_rota=adesao', 'top' );
	// Grava os endereços novos uma vez por versão do tema.
	if ( get_option( 'pai_rotas_ver' ) !== PAI_VER ) {
		flush_rewrite_rules( false );
		update_option( 'pai_rotas_ver', PAI_VER );
	}
} );
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'pai_rota';
	$v[] = 'pai_plano';
	return $v;
} );

/** Rota atual do tema: 'plano', 'pagar' ou ''. */
function pai_rota() {
	return (string) get_query_var( 'pai_rota' );
}

/** Plano da rota atual (dados) ou null. */
function pai_plano_atual() {
	if ( 'plano' !== pai_rota() ) {
		return null;
	}
	$d = pai_planos_dados();
	$k = (string) get_query_var( 'pai_plano' );
	return isset( $d[ $k ] ) ? array_merge( $d[ $k ], array( 'slug' => $k ) ) : null;
}

/** Endereço, título e descrição da rota atual. */
function pai_rota_meta() {
	$r = pai_rota();
	if ( 'plano' === $r ) {
		$p = pai_plano_atual();
		if ( ! $p ) {
			return null;
		}
		return array(
			'url'   => home_url( '/planos-funerarios/' . $p['slug'] . '/' ),
			'title' => $p['titulo'] . ' em Barreiras-BA: cobertura, valores e quem entra | Plano PAI',
			'desc'  => $p['seo'],
			'h1'    => $p['titulo'],
		);
	}
	if ( 'adesao' === $r || 'adesao_pagar' === $r ) {
		return array(
			'url'   => home_url( '/adesao/' ),
			'title' => 'Contratar o Plano PAI pelo site: adesão online | Plano PAI',
			'desc'  => 'Faça a adesão ao Plano PAI pelo site: escolha o plano, cadastre a família, veja a mensalidade e pague a adesão por Pix ou cartão.',
			'h1'    => 'Adesão ao Plano PAI',
		);
	}
	if ( 'pagar' === $r ) {
		return array(
			'url'   => home_url( '/pagar-mensalidade/' ),
			'title' => 'Pagar a mensalidade do Plano PAI: canais oficiais | Plano PAI',
			'desc'  => 'Pague a mensalidade do Plano PAI pelo app, pela área do associado, pelo atendimento no WhatsApp ou na sede em Barreiras-BA. Só valem os canais oficiais.',
			'h1'    => 'Pagar mensalidade',
		);
	}
	return null;
}

/* Modelo da página */
add_filter( 'template_include', function ( $modelo ) {
	$r = pai_rota();
	if ( 'plano' === $r ) {
		if ( ! pai_plano_atual() ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			return get_404_template();
		}
		$p = locate_template( 'page-plano.php' );
		return $p ? $p : $modelo;
	}
	if ( 'adesao' === $r ) {
		$p = locate_template( 'page-adesao.php' );
		return $p ? $p : $modelo;
	}
	if ( 'pagar' === $r ) {
		$p = locate_template( 'page-pagar-mensalidade.php' );
		return $p ? $p : $modelo;
	}
	return $modelo;
}, 10000 );

/* Não deixa o WordPress tratar a rota como página inicial ou lista do blog. */
add_action( 'parse_query', function ( $q ) {
	if ( $q->is_main_query() && $q->get( 'pai_rota' ) ) {
		$q->is_home       = false;
		$q->is_front_page = false;
		$q->is_page       = false;
		$q->is_singular   = false;
		$q->is_archive    = false;
		$q->is_404        = false;
	}
} );
add_filter( 'posts_pre_query', function ( $posts, $q ) {
	if ( $q->is_main_query() && $q->get( 'pai_rota' ) ) {
		$q->found_posts   = 0;
		$q->max_num_pages = 0;
		return array();
	}
	return $posts;
}, 10, 2 );
add_filter( 'redirect_canonical', function ( $url ) {
	return pai_rota() ? false : $url;
} );

/* Título, descrição e canonical (WordPress e Rank Math). */
add_filter( 'pre_get_document_title', function ( $t ) {
	$m = pai_rota_meta();
	return $m ? $m['title'] : $t;
}, 99 );
add_filter( 'rank_math/frontend/title', function ( $t ) {
	$m = pai_rota_meta();
	return $m ? $m['title'] : $t;
}, 99 );
add_filter( 'rank_math/frontend/description', function ( $d ) {
	$m = pai_rota_meta();
	return $m ? $m['desc'] : $d;
}, 99 );
add_filter( 'rank_math/frontend/canonical', function ( $c ) {
	$m = pai_rota_meta();
	return $m ? $m['url'] : $c;
}, 99 );
add_filter( 'rank_math/opengraph/url', function ( $c ) {
	$m = pai_rota_meta();
	return $m ? $m['url'] : $c;
}, 99 );
add_filter( 'rank_math/frontend/robots', function ( $robots ) {
	if ( pai_rota_meta() ) {
		$robots['index']  = 'index';
		$robots['follow'] = 'follow';
	}
	return $robots;
}, 99 );
/* Sem o Rank Math: imprime a descrição e o canonical. */
add_action( 'wp_head', function () {
	$m = pai_rota_meta();
	if ( ! $m || defined( 'RANK_MATH_VERSION' ) ) {
		return;
	}
	echo '<meta name="description" content="' . esc_attr( $m['desc'] ) . '">' . "\n";
	echo '<link rel="canonical" href="' . esc_url( $m['url'] ) . '">' . "\n";
}, 1 );

/* A rota não tem post no banco: impede o WordPress de responder 404. */
add_filter( 'pre_handle_404', function ( $preempt, $q ) {
	if ( $q->get( 'pai_rota' ) && ( in_array( $q->get( 'pai_rota' ), array( 'pagar', 'adesao', 'adesao_pagar' ), true ) || isset( pai_planos_dados()[ (string) $q->get( 'pai_plano' ) ] ) ) ) {
		status_header( 200 );
		return true;
	}
	return $preempt;
}, 10, 2 );
