<?php
/**
 * Funções de apoio do tema: opções do painel, preços, links e ícones.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Valores padrão de todas as opções editáveis em Aparência > Personalizar > Plano PAI.
 */
function pai_padroes() {
	return array(
		// Contatos
		'tel_plantao'     => '(77) 98853-4512',
		'tel_fixo'        => '(77) 3611-2440',
		'whatsapp'        => '(77) 98858-8166',
		'email'           => 'contato@planoassistencialintegrado.com.br',
		'instagram'       => 'https://www.instagram.com/planopai_/',
		'end_sede'        => 'Av. Dr. Clériston Andrade, 135, Centro, Barreiras-BA',
		'end_memorial'    => 'Av. Antônio Carlos Magalhães, 3348, Flamengo, Barreiras-BA',
		'cnpj'            => '03.726.651/0001-51',
		// Links
		'url_contratar'   => '/landing-page/',
		'url_api_planos' => 'https://api.planoassistencialintegrado.com.br/planos-novos.php',
		'termo_light' => '',
		'termo_flex' => '',
		'termo_plus' => '',
		'termo_max' => '',
		'url_api_pagamento' => 'https://api.planoassistencialintegrado.com.br/link-de-pagamento.php',
		'url_associado'   => 'https://club.planoassistencialintegrado.com.br/',
		'url_telemedicina' => 'https://telemedicina.planoassistencialintegrado.com.br/',
		'url_app'         => '/aplicativo/',
		'whats_flutuante' => 1,
		'url_play'        => 'https://play.google.com/store/apps/details?id=com.associado.pai',
		'whats_urnas'     => '(77) 99955-8866',
		// Textos
		'avaliacoes_shortcode' => '',
		'tele_campanha'   => 'O titular do plano tem acesso gratuito à Telemedicina como cortesia, por tempo limitado.',
		'tele_quem'       => 'A Telemedicina já vem incluída no plano MAX. Nos planos FLEX e PLUS, pode ser contratada à parte. Fale com a gente para saber como usar ou incluir no seu plano.',
		// Preços (mensalidades)
		'p_light'         => 46,
		'p_flex_1'        => 48,
		'p_flex_2'        => 57,
		'p_flex_3'        => 69,
		'p_flex_4'        => 82,
		'p_plus'          => 110,
		'p_max'           => 150,
		// Adesão e aditivos (não reajustados)
		'ad_light_flex'   => 50,
		'ad_plus_max'     => 100,
		'p_translado'     => 30,
		// Coroas
		'coroa_entrega'   => 20,
		// Imagens
		'img_hero'        => '',
		'url_foto_topo'   => 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=1800&q=80',
		'img_mem_1'       => '',
		'img_mem_2'       => '',
		'img_mem_3'       => '',
		'img_mem_4'       => '',
		'img_mem_5'       => '',
	);
}

/** Lê uma opção do painel (ou o valor padrão). */
function pai_opt( $chave ) {
	$p = pai_padroes();
	$v = get_theme_mod( 'pai_' . $chave, isset( $p[ $chave ] ) ? $p[ $chave ] : '' );
	return $v;
}

/** Valor em reais: 46 → "46"; 9.2 → "9,20". */
function pai_reais( $v, $sempre_centavos = false ) {
	$v = (float) $v;
	if ( ! $sempre_centavos && abs( $v - round( $v ) ) < 0.001 ) {
		return number_format( $v, 0, ',', '.' );
	}
	return number_format( $v, 2, ',', '.' );
}

/** Tabela de preços usada nas páginas e no simulador. Extra = 20% da mensalidade (cláusula 9.4). */
function pai_precos() {
	$flex = array( (float) pai_opt( 'p_flex_1' ), (float) pai_opt( 'p_flex_2' ), (float) pai_opt( 'p_flex_3' ), (float) pai_opt( 'p_flex_4' ) );
	$light = (float) pai_opt( 'p_light' );
	$plus  = (float) pai_opt( 'p_plus' );
	$max   = (float) pai_opt( 'p_max' );
	return array(
		'light'     => $light,
		'flex'      => $flex,
		'plus'      => $plus,
		'max'       => $max,
		'ad_lf'     => (float) pai_opt( 'ad_light_flex' ),
		'ad_pm'     => (float) pai_opt( 'ad_plus_max' ),
		'translado' => (float) pai_opt( 'p_translado' ),
		'ex_light'  => round( $light * 0.2, 2 ),
		'ex_plus'   => round( $plus * 0.2, 2 ),
		'ex_max'    => round( $max * 0.2, 2 ),
	);
}

/** Só os números do telefone, com 55 na frente. */
function pai_digitos( $tel ) {
	$d = preg_replace( '/\D+/', '', (string) $tel );
	if ( strlen( $d ) <= 11 ) {
		$d = '55' . $d;
	}
	return $d;
}

function pai_tel( $chave = 'tel_plantao' ) {
	return 'tel:+' . pai_digitos( pai_opt( $chave ) );
}

function pai_wa( $mensagem = '' ) {
	$url = 'https://wa.me/' . pai_digitos( pai_opt( 'whatsapp' ) );
	if ( $mensagem ) {
		$url .= '?text=' . rawurlencode( $mensagem );
	}
	return $url;
}

/** Link interno ou externo vindo do painel. */
function pai_link( $chave ) {
	$v = (string) pai_opt( $chave );
	if ( '' === $v ) {
		return home_url( '/' );
	}
	if ( 0 === strpos( $v, '/' ) ) {
		return home_url( $v );
	}
	return $v;
}

/** URL de uma página pelo endereço (slug). */
function pai_url( $caminho ) {
	return home_url( '/' . trim( $caminho, '/' ) . '/' );
}

function pai_img( $arquivo ) {
	return esc_url( PAI_URI . '/assets/img/' . $arquivo );
}

/** Logo com versão para o tema escuro e para o claro. */
function pai_logo( $altura = 50, $link = true ) {
	$alt  = esc_attr__( 'PAI Plano Assistencial Integrado', 'pai2026' );
	$html = sprintf(
		'<img class="logo-d" src="%1$s" alt="%3$s" width="%4$d" height="%5$d"><img class="logo-l" src="%2$s" alt="%3$s" width="%4$d" height="%5$d" loading="lazy">',
		pai_img( 'logo-escuro.svg' ),
		pai_img( 'logo-claro.svg' ),
		$alt,
		(int) round( $altura * 796 / 214 ),
		(int) $altura
	);
	if ( $link ) {
		$html = '<a class="logo" href="' . esc_url( home_url( '/' ) ) . '" aria-label="' . esc_attr__( 'Página inicial', 'pai2026' ) . '">' . $html . '</a>';
	}
	return $html;
}

/** Marca d'água do símbolo, sempre do lado esquerdo. */
function pai_marca_dagua( $classe = '' ) {
	return '<span class="wm ' . esc_attr( $classe ) . '" aria-hidden="true"><img class="wm-d" src="' . pai_img( 'icone-branco.svg' ) . '" alt="" loading="lazy"><img class="wm-l" src="' . pai_img( 'icone-escuro.svg' ) . '" alt="" loading="lazy"></span>';
}

/** Ícones em linha (SVG), sem biblioteca externa. */
function pai_icone( $nome, $tam = 22 ) {
	$p = array(
		'fone'     => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
		'whats'    => '<path d="M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 21l2.1-5.4A8.4 8.4 0 1 1 21 11.5z"/>',
		'pessoa'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
		'sol'      => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
		'lua'      => '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
		'menu'     => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'fechar'   => '<path d="M6 6l12 12M18 6 6 18"/>',
		'tele'     => '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4M12 8v5M9.5 10.5h5"/>',
		'desconto' => '<path d="M19 5 5 19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
		'cadeira'  => '<circle cx="9" cy="17" r="4"/><path d="M9 13V5h4l3 6h3M5 5h4"/>',
		'celular'  => '<rect x="6" y="2" width="12" height="20" rx="2.5"/><path d="M11 18h2"/>',
		'video'    => '<path d="m22 8-6 4 6 4V8z"/><rect x="2" y="6" width="14" height="12" rx="2"/>',
		'flor'     => '<circle cx="12" cy="12" r="3"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4M5 5l3 3M16 16l3 3M5 19l3-3M16 8l3-3"/>',
		'check'    => '<path d="M20 6 9 17l-5-5"/>',
		'busca'    => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
		'carro'    => '<path d="M3 16V9.5L6 6h9l4 4h2v6"/><path d="M3 16h18"/><circle cx="7.5" cy="16.5" r="2"/><circle cx="16.5" cy="16.5" r="2"/><path d="M6.5 6v4h12"/>',
		'coroa'    => '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2M6.3 6.3l1.4 1.4M16.3 16.3l1.4 1.4M6.3 17.7l1.4-1.4M16.3 7.7l1.4-1.4"/>',
		'urna'     => '<path d="M8 3h8l3 5-2 13H7L5 8z"/><path d="M12 9v6M9.5 11.5h5"/>',
		'predio'   => '<path d="M3 21h18"/><path d="M5 21V9l7-5 7 5v12"/><path d="M9 21v-6h6v6"/><path d="M9 11h.01M15 11h.01"/>',
		'gota'     => '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/><path d="M9.5 14.5a2.5 2.5 0 0 0 2.5 2.5"/>',
		'maos'     => '<path d="M12 21s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.6-7 10-7 10z"/>',
		'cartao'   => '<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 10h19M6.5 15h4"/>',
		'estrela'  => '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/>',
		'relogio'  => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		'escudo'   => '<path d="M12 3 4 6v6c0 5 3.5 8.3 8 9 4.5-.7 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
	);
	if ( ! isset( $p[ $nome ] ) ) {
		return '';
	}
	return '<svg width="' . (int) $tam . '" height="' . (int) $tam . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $p[ $nome ] . '</svg>';
}

/** Imagem escolhida no painel (ID do anexo) ou vazio. */
function pai_imagem_painel( $chave, $tamanho = 'large', $attrs = array() ) {
	$id = (int) pai_opt( $chave );
	if ( ! $id ) {
		return '';
	}
	return wp_get_attachment_image( $id, $tamanho, false, array_merge( array( 'loading' => 'lazy', 'decoding' => 'async' ), $attrs ) );
}

/** Menu do painel; se não existir, usa a lista padrão. */
function pai_menu( $local, $padrao, $classe = '' ) {
	if ( has_nav_menu( $local ) ) {
		wp_nav_menu( array(
			'theme_location' => $local,
			'container'      => false,
			'menu_class'     => $classe,
			'depth'          => 1,
			'fallback_cb'    => false,
		) );
		return;
	}
	echo '<ul class="' . esc_attr( $classe ) . '">';
	foreach ( $padrao as $item ) {
		$atual = '';
		if ( 0 === strpos( $item[0], '/' ) && is_page( trim( $item[0], '/' ) ) ) {
			$atual = ' class="current-menu-item"';
		}
		$href = 0 === strpos( $item[0], '/' ) ? home_url( $item[0] ) : $item[0];
		echo '<li' . $atual . '><a href="' . esc_url( $href ) . '">' . esc_html( $item[1] ) . '</a></li>';
	}
	echo '</ul>';
}

/** A página foi montada no Elementor? */
function pai_feito_no_elementor( $id ) {
	return 'builder' === get_post_meta( $id, '_elementor_edit_mode', true );
}

/** Trilha "Início › Página". */
function pai_trilha( $atual ) {
	echo '<nav class="trilha" aria-label="Você está em"><a href="' . esc_url( home_url( '/' ) ) . '">Início</a> <span aria-hidden="true">›</span> <span>' . esc_html( $atual ) . '</span></nav>';
}

/** Topo padrão das páginas internas. $extra = HTML (botões etc.) já escapado. */
function pai_topo( $trilha, $eyebrow, $titulo, $lead = '', $extra = '' ) {
	echo '<section class="topo-pagina">' . pai_marca_dagua( 'wm--topo' ) . '<div class="wrap pilha pilha--p topo-pagina__in">';
	pai_trilha( $trilha );
	if ( $eyebrow ) {
		echo '<p class="eyebrow">' . esc_html( $eyebrow ) . '</p>';
	}
	echo '<h1 class="display display--m">' . esc_html( $titulo ) . '</h1>';
	if ( $lead ) {
		echo '<p class="lead">' . esc_html( $lead ) . '</p>';
	}
	echo $extra; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</div></section>';
}

/** Endereço de um arquivo da pasta de uploads do site (fotos que já estão na biblioteca). */
function pai_upload( $caminho ) {
	$up = wp_get_upload_dir();
	return esc_url( trailingslashit( $up['baseurl'] ) . ltrim( $caminho, '/' ) );
}

/** Especialidades da página Parceiros (endereço => nome). */
function pai_especialidades() {
	return array(
		'cardiologista'  => 'Cardiologista',
		'fisioterapeuta' => 'Fisioterapeuta',
		'ginecologista'  => 'Ginecologista',
		'nutricionista'  => 'Nutricionista',
		'odontologista'  => 'Odontologista',
		'otorrino'       => 'Otorrino',
		'pediatra'       => 'Pediatra',
		'psicologo'      => 'Psicólogo',
		'psicopedagogo'  => 'Psicopedagogo',
		'psiquiatra'     => 'Psiquiatra',
		'clinicas'       => 'Clínicas',
		'laboratorios'   => 'Laboratórios',
	);
}

/** Tempo de leitura do artigo, em minutos (mínimo 2). */
function pai_tempo_leitura( $post_id = 0 ) {
	$texto    = wp_strip_all_tags( (string) get_post_field( 'post_content', $post_id ? $post_id : get_the_ID() ) );
	$palavras = count( preg_split( '/\s+/u', trim( $texto ), -1, PREG_SPLIT_NO_EMPTY ) );
	return max( 2, (int) ceil( $palavras / 200 ) );
}

/** Linha "Categoria · 4 min de leitura" (ou com a data) dos cartões de artigo. */
function pai_meta_artigo( $com_data = false ) {
	$cat = get_the_category();
	$nome = $cat ? $cat[0]->name : 'Guia';
	$extra = $com_data ? get_the_date( 'j \d\e M \d\e Y' ) : pai_tempo_leitura() . ' min de leitura';
	return '<span class="meta-artigo">' . esc_html( $nome ) . ' <span>· ' . esc_html( $extra ) . '</span></span>';
}

/**
 * Fotos da página Galeria (Elementor), para usar quando o painel não tem foto escolhida.
 * $grupos: nomes dos grupos preferidos, na ordem (ex.: Memorial, Salas de Velório).
 */
function pai_fotos_da_galeria( $quantas, $grupos = array() ) {
	static $todas = null;
	if ( null === $todas ) {
		$todas = array();
		$p     = get_page_by_path( 'galeria' );
		if ( $p && function_exists( 'pai_el_galeria' ) ) {
			$g     = pai_el_galeria( $p->ID );
			$todas = $g['fotos'];
		}
	}
	$escolhidas = array();
	foreach ( $grupos as $grupo ) {
		foreach ( $todas as $f ) {
			if ( count( $escolhidas ) >= $quantas ) {
				break 2;
			}
			if ( 0 === strcasecmp( $f['grupo'], $grupo ) && ! in_array( $f, $escolhidas, true ) ) {
				$escolhidas[] = $f;
			}
		}
	}
	foreach ( $todas as $f ) {
		if ( count( $escolhidas ) >= $quantas ) {
			break;
		}
		if ( ! in_array( $f, $escolhidas, true ) ) {
			$escolhidas[] = $f;
		}
	}
	return $escolhidas;
}

/** <img> de uma foto da galeria. */
function pai_img_galeria( $f, $attrs = array() ) {
	if ( ! empty( $f['id'] ) ) {
		$html = wp_get_attachment_image( (int) $f['id'], isset( $attrs['size'] ) ? $attrs['size'] : 'large', false, array_merge( array( 'loading' => 'lazy', 'decoding' => 'async', 'alt' => $f['alt'] ), array_diff_key( $attrs, array( 'size' => 1 ) ) ) );
		if ( $html ) {
			return $html;
		}
	}
	$extra = '';
	foreach ( array_diff_key( $attrs, array( 'size' => 1 ) ) as $k => $v ) {
		$extra .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
	}
	if ( false === strpos( $extra, 'loading=' ) ) {
		$extra .= ' loading="lazy"';
	}
	return '<img src="' . esc_url( $f['url'] ) . '" alt="' . esc_attr( $f['alt'] ) . '" decoding="async"' . $extra . '>';
}
