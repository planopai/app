<?php
/**
 * Ajustes de busca e compartilhamento:
 * - descrição padrão nas páginas que ficaram sem descrição no Rank Math;
 * - imagem padrão quando o link é compartilhado (WhatsApp, Facebook);
 * - páginas internas fora do Google e do mapa do site.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Descrições padrão (só entram quando a página não tem descrição própria no Rank Math). */
function pai_descricoes_padrao() {
	return array(
		'sobre-nos'               => 'Há mais de 40 anos a Funerária Senhor do Bonfim e o Plano PAI cuidam das famílias de Barreiras-BA com dignidade, respeito e atendimento humanizado.',
		'guia-para-familias'      => 'Orientações claras sobre despedida, documentos, luto, pensão, inventário e planejamento, escritas pela equipe do Plano PAI em Barreiras-BA.',
		'atendimento-24-horas'    => 'Perdeu alguém? Ligue para o plantão 24 horas do Plano PAI. Veja o passo a passo, os documentos e o que a lei pede para o sepultamento e a cremação.',
		'telemedicina'            => 'Telemedicina do Plano PAI: médico 24 horas pelo celular ou computador, com clínico geral e especialistas. Acesse a plataforma direto pelo site.',
		'aplicativo'              => 'App do Plano PAI: consulte seu plano, pague a mensalidade, solicite serviços e aproveite descontos. Baixe na Play Store e entre com o CPF.',
		'parceiros'               => 'Parceiros do Plano PAI em Barreiras-BA: médicos, clínicas e laboratórios com condições especiais para associados.',
		'galeria'                 => 'Fotos do Memorial Senhor do Bonfim, das salas de velório climatizadas, do estacionamento, da frota e da sede do Plano PAI em Barreiras-BA.',
		'velorio-online'          => 'Velório online do Plano PAI: acompanhe a cerimônia de despedida ao vivo, de qualquer lugar, com acesso por senha.',
		'trabalhe-conosco'        => 'Trabalhe no Plano PAI e na Funerária Senhor do Bonfim, em Barreiras-BA. Envie seu currículo pelo formulário.',
		'seja-nosso-parceiro'     => 'Seja parceiro do Plano PAI: ofereça condições especiais aos associados e apresente seu negócio às famílias de Barreiras e região.',
		'termos-e-condicoes'      => 'Termos e condições de uso do site do Plano PAI - Plano Assistencial Integrado.',
		'politica-de-privacidade' => 'Como o Plano PAI trata os dados pessoais de quem usa o site, conforme a LGPD.',
		'tutoriais'               => 'Tutoriais do Plano PAI: passo a passo para usar os benefícios do seu plano.',
		'servicos-plano-pai'      => 'Serviços do Plano PAI em Barreiras-BA: translado, velório online, ornamentação, tanatopraxia, coroas de flores, urnas e Memorial 24 horas.',
	);
}

add_filter( 'rank_math/frontend/description', function ( $d ) {
	if ( '' !== trim( (string) $d ) || ! is_page() ) {
		return $d;
	}
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	if ( isset( pai_especialidades()[ $slug ] ) ) {
		return 'Parceiros do Plano PAI em ' . pai_especialidades()[ $slug ] . ' em Barreiras-BA, com condições especiais para associados.';
	}
	$p = pai_descricoes_padrao();
	return isset( $p[ $slug ] ) ? $p[ $slug ] : $d;
}, 20 );

/** Imagem padrão de compartilhamento. */
function pai_imagem_compartilhar() {
	return PAI_URI . '/assets/img/compartilhar.jpg';
}
add_filter( 'rank_math/opengraph/facebook/image', function ( $img ) {
	return $img ? $img : pai_imagem_compartilhar();
} );
add_filter( 'rank_math/opengraph/twitter/image', function ( $img ) {
	return $img ? $img : pai_imagem_compartilhar();
} );

/** Páginas internas (painéis, checkouts, telas de TV, confirmações): fora do Google. */
function pai_pagina_interna( $slug ) {
	$exatas   = array( 'contrato-online', 'velorio-online-login', 'user', 'obrigado', 'minha-conta', 'carrinho', 'finalizar-compra', 'app-plano-pai', 'painel-administracao' );
	$prefixos = array( 'admin-velorio-online', 'painel-', 'mensagens-tv', 'enviar-homenagem-sala-', 'checkout-', 'wi-fi', 'feedback', 'velorio-online-sala-' );
	if ( in_array( $slug, $exatas, true ) ) {
		return true;
	}
	foreach ( $prefixos as $p ) {
		if ( 0 === strpos( $slug, $p ) ) {
			return true;
		}
	}
	return false;
}

/* Landing dos anúncios: fora do Google (repete a página de planos), mas segue os links. */
add_filter( 'rank_math/frontend/robots', function ( $robots ) {
	if ( is_page( 'landing-page' ) ) {
		$robots['index']  = 'noindex';
		$robots['follow'] = 'follow';
	}
	return $robots;
}, 21 );
add_filter( 'wp_robots', function ( $robots ) {
	if ( is_page( 'landing-page' ) ) {
		$robots['noindex'] = true;
	}
	return $robots;
} );

add_filter( 'rank_math/frontend/robots', function ( $robots ) {
	if ( is_page() && pai_pagina_interna( get_post_field( 'post_name', get_queried_object_id() ) ) ) {
		$robots['index']  = 'noindex';
		$robots['follow'] = 'nofollow';
	}
	return $robots;
}, 20 );
add_filter( 'wp_robots', function ( $robots ) {
	if ( is_page() && pai_pagina_interna( get_post_field( 'post_name', get_queried_object_id() ) ) ) {
		$robots['noindex']  = true;
		$robots['nofollow'] = true;
	}
	return $robots;
} );
/* Tira essas páginas do mapa do site do Rank Math. */
add_filter( 'rank_math/sitemap/entry', function ( $url, $type, $obj ) {
	if ( 'post' === $type && $obj instanceof WP_Post && 'page' === $obj->post_type && ( pai_pagina_interna( $obj->post_name ) || 'landing-page' === $obj->post_name ) ) {
		return false;
	}
	return $url;
}, 10, 3 );
