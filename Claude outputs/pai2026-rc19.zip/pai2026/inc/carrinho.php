<?php
/**
 * rc14 · Carrinho no visual do tema, endereços antigos redirecionados e título da aba sem o nome do site repetido.
 *
 * Carrinho: antes era montado no Elementor/ShopEngine (tabela branca, sem foto e nome do produto).
 * Agora o tema desenha a página (topo, rodapé, cores) e coloca o carrinho padrão do WooCommerce ([woocommerce_cart]).
 * O conteúdo do Elementor da página não é usado.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Página do carrinho. */
function pai_eh_carrinho() {
	return function_exists( 'is_cart' ) && is_cart() && ! is_admin();
}

/* Modelo do tema no carrinho. */
add_filter( 'template_include', function ( $modelo ) {
	if ( ! pai_eh_carrinho() ) {
		return $modelo;
	}
	$p = locate_template( 'modelo-carrinho.php' );
	return $p ? $p : $modelo;
}, 10000 );

add_filter( 'body_class', function ( $classes ) {
	if ( pai_eh_carrinho() ) {
		$classes[] = 'pai-carrinho';
	}
	return $classes;
} );

/** Textos do topo do carrinho (adesão ou coroa). */
function pai_carrinho_textos() {
	$planos = false;
	if ( function_exists( 'WC' ) && WC()->cart ) {
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['data'] ) && pai_adesao_eh_produto( $item['data'] ) ) {
				$planos = true;
				break;
			}
		}
	}
	return $planos
		? array( 'trilha' => 'Adesão ao Plano PAI', 'eyebrow' => 'Contratar pelo site', 'titulo' => 'Seu carrinho', 'lead' => 'Confira a adesão e siga para o pagamento.' )
		: array( 'trilha' => 'Coroas de flores', 'eyebrow' => 'Coroas de flores', 'titulo' => 'Seu carrinho', 'lead' => 'Confira os itens e siga para finalizar o pedido.' );
}

/*
 * Endereços antigos → atuais (301).
 * - /checkout-coroa-de-flores/: o checkout passou a ser /checkout/.
 * - /checkout-plano-* e /contrato-online/: páginas antigas dos planos; a contratação agora é pela /adesao/.
 */
add_action( 'template_redirect', function () {
	$caminho = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore
	$mapa = array(
		'checkout-coroa-de-flores' => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : home_url( '/checkout/' ),
		'checkout-plano-light'     => home_url( '/adesao/?plano=light' ),
		'checkout-plano-flex'      => home_url( '/adesao/?plano=flex' ),
		'checkout-plano-plus'      => home_url( '/adesao/?plano=plus' ),
		'checkout-plano-max'       => home_url( '/adesao/?plano=max' ),
		'contrato-online'          => home_url( '/adesao/' ), // página antiga, fora de uso
	);
	if ( isset( $mapa[ $caminho ] ) ) {
		wp_safe_redirect( $mapa[ $caminho ], 301 );
		exit;
	}
}, 1 );

/*
 * Título da aba: algumas páginas têm no título SEO o nome do site, e o Rank Math junta o nome de novo
 * ("Plano PAI - Plano Assistencial Integrado - PAI - Plano Assistencial Integrado"). Tira a repetição.
 */
function pai_titulo_sem_repeticao( $titulo ) {
	$site = (string) get_bloginfo( 'name' ); // "PAI - Plano Assistencial Integrado"
	if ( '' === $site || ! is_string( $titulo ) ) {
		return $titulo;
	}
	$fim = ' - ' . $site;
	if ( substr( $titulo, -strlen( $fim ) ) !== $fim ) {
		return $titulo;
	}
	$antes = substr( $titulo, 0, -strlen( $fim ) );
	// Se o começo já tem o nome por extenso, o final é repetição.
	if ( false !== stripos( $antes, 'Plano Assistencial Integrado' ) ) {
		return $antes;
	}
	return $titulo;
}
add_filter( 'rank_math/frontend/title', 'pai_titulo_sem_repeticao', 100 );
add_filter( 'rank_math/opengraph/facebook/og_title', 'pai_titulo_sem_repeticao', 100 );
add_filter( 'rank_math/opengraph/twitter/title', 'pai_titulo_sem_repeticao', 100 );
