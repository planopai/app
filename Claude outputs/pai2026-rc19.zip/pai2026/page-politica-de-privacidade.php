<?php
/**
 * Página /politica-de-privacidade/.
 */
get_header();
get_template_part( 'parts/pagina-texto' );
get_footer();
