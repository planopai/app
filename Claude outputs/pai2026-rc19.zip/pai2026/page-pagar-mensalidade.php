<?php
/**
 * Página /pagar-mensalidade/: link de pagamento pelo CPF + contrato e os canais oficiais.
 * O formulário chama a API link-de-pagamento.php (Personalizar > Plano PAI > links).
 */
get_header();
pai_topo( 'Pagar mensalidade', 'Para associados', 'Pagar mensalidade', 'Gere o link da sua mensalidade aqui mesmo, com o CPF do titular e o número do contrato. Mantendo as mensalidades em dia, a sua família continua protegida.' );

$canais = array(
	array( 'celular', 'sol', 'Pelo app do PAI', 'Abra o app, entre com o CPF do titular e pague a mensalidade pelo pagamento digital do próprio app.', pai_link( 'url_play' ), 'Baixar o app', true ),
	array( 'pessoa', 'azul', 'Na área do associado', 'Pelo navegador do celular ou do computador, com o seu CPF e senha.', pai_link( 'url_associado' ), 'Acessar a área do associado', true ),
	array( 'whats', 'verde', 'Pelo WhatsApp', 'Prefere ajuda? Peça à nossa equipe o boleto ou o link de pagamento da sua mensalidade.', pai_wa( 'Olá! Sou associado do Plano PAI e quero pagar a minha mensalidade. Pode me enviar o link ou o boleto?' ), 'Pedir pelo WhatsApp', true ),
	array( 'predio', 'sol', 'Na sede', 'Pagamento presencial na sede do Plano PAI. O pagamento do contrato inteiro de uma só vez é feito somente na sede.', 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( 'Plano PAI, ' . pai_opt( 'end_sede' ) ), 'Como chegar', true ),
);
?>

<section class="secao secao--sem-topo" id="gerar-link">
	<div class="wrap duas-colunas duas-colunas--pagar">
		<div class="pilha pilha--p">
			<p class="eyebrow eyebrow--verde">Pague agora pelo site</p>
			<h2 class="h2">Gerar o link da mensalidade</h2>
			<ol class="passos-pagar">
				<li><span>1</span>Digite o CPF do titular do plano e o número do contrato.</li>
				<li><span>2</span>Confira as mensalidades em aberto e o valor total.</li>
				<li><span>3</span>Toque em pagar: o pagamento abre no ambiente seguro do nosso banco.</li>
			</ol>
			<p class="nota">O número do contrato está na sua carteirinha, no app do PAI e no contrato. Não sabe? Peça pelo <a href="<?php echo esc_url( pai_wa( 'Olá! Sou associado do Plano PAI e preciso do número do meu contrato para pagar a mensalidade.' ) ); ?>" target="_blank" rel="noopener">WhatsApp</a>.</p>
		</div>
		<div class="card pagar-card" data-pagar data-api="<?php echo esc_url( pai_opt( 'url_api_pagamento' ) ); ?>" data-whats="<?php echo esc_url( pai_wa( 'Olá! Sou associado do Plano PAI e não consegui gerar o link da mensalidade pelo site.' ) ); ?>">
			<form class="pagar-form" data-pagar-form novalidate>
				<label for="pagar-cpf">CPF do titular</label>
				<input id="pagar-cpf" name="cpf" inputmode="numeric" autocomplete="off" placeholder="000.000.000-00" maxlength="14" required>
				<label for="pagar-contrato">Número do contrato</label>
				<input id="pagar-contrato" name="contrato" autocomplete="off" placeholder="Ex.: 012345" maxlength="32" required>
				<button class="btn btn-sol btn-g" type="submit">Consultar mensalidades</button>
				<p class="pagar-aviso" data-pagar-msg role="alert" hidden></p>
			</form>
			<div class="pagar-resultado" data-pagar-resultado hidden>
				<div class="pagar-resultado__cab">
					<div>
						<p class="eyebrow">Contrato <span data-pagar-contrato></span></p>
						<p class="nota" data-pagar-cpf></p>
					</div>
					<button class="link-forte pagar-trocar" type="button" data-pagar-trocar>Trocar dados</button>
				</div>
				<ul class="pagar-lista" data-pagar-lista></ul>
				<div class="pagar-total"><span>Total</span><strong data-pagar-total></strong></div>
				<button class="btn btn-verde btn-g pagar-botao" type="button" data-pagar-gerar></button>
				<p class="pagar-aviso" data-pagar-msg2 role="alert" hidden></p>
				<p class="nota pagar-seguro"><?php echo pai_icone( 'escudo', 18 ); ?> O valor vem direto do nosso financeiro. O pagamento é feito no ambiente do banco, não no site.</p>
			</div>
		</div>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Outras formas de pagar</p>
			<h2 class="h2">Canais oficiais</h2>
		</div>
			<ul class="grade-servicos">
			<?php foreach ( $canais as $c ) : ?>
				<li class="card servico-c">
					<span class="servico-c__ico servico-c__ico--<?php echo esc_attr( $c[1] ); ?>"><?php echo pai_icone( $c[0], 30 ); ?></span>
					<h2 class="card__tit card__tit--m"><?php echo esc_html( $c[2] ); ?></h2>
					<p class="card__txt"><?php echo esc_html( $c[3] ); ?></p>
					<a class="link-forte servico-c__link" href="<?php echo esc_url( $c[4] ); ?>"<?php echo $c[6] ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo esc_html( $c[5] ); ?> ›</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="secao">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow eyebrow--urg">Cuidado com golpes</p>
			<h2 class="h2">Só valem os canais oficiais</h2>
		</div>
		<div class="pilha pilha--p">
			<p class="lead">O pagamento só é válido pelos canais desta página. O Plano PAI não se responsabiliza por pagamentos feitos a terceiros. Recebeu uma cobrança diferente? Confirme antes de pagar pelo <?php echo esc_html( pai_opt( 'whatsapp' ) ); ?>.</p>
			<ul class="lista-check">
				<li>Com mais de 10 dias de atraso, os direitos do plano ficam suspensos até a quitação.</li>
				<li>Depois de quitar, há uma nova carência de 15 dias.</li>
			</ul>
		</div>
	</div>
</section>

<?php
get_footer();
