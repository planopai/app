<?php
/**
 * Carrinho no layout do tema. O conteúdo é o carrinho padrão do WooCommerce. Ver inc/carrinho.php.
 */
get_header();
$t = pai_carrinho_textos();
pai_topo( $t['trilha'], $t['eyebrow'], $t['titulo'], $t['lead'] );
?>
<section class="secao secao--checkout">
	<div class="wrap loja pai-carrinho-area">
		<?php echo do_shortcode( '[woocommerce_cart]' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</div>
</section>
<?php
get_footer();
