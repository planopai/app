<?php
/**
 * rc16 (11/11/2026): páginas /enviar-homenagem-sala-01/, -02/ e -03/ (QR code das salas do velório).
 *
 * Um único modelo para as três salas: a sala vem do endereço da página (pai_homenagem_sala()).
 * Antes eram três cópias de HTML dentro do Elementor; o envio continua igual, para o homenagens.php
 * da API (carregar_sala e enviar_homenagem), com moderação da Aurora e painel /mensagens.
 * O conteúdo do Elementor fica salvo na página e não aparece (para voltar a usá-lo, ver inc em functions.php).
 */
get_header();

$sala      = pai_homenagem_sala();
$api       = 'https://api.planoassistencialintegrado.com.br/homenagens.php';
$imagens   = array( 1, 2, 3, 4 );
$base_img  = home_url( '/uploads/' ); // imagens prontas que já existiam no domínio principal (/uploads/1.png a 4.png)

pai_topo(
	'Homenagem · Sala ' . $sala,
	'Sala ' . $sala,
	'Enviar homenagem',
	'Deixe uma mensagem de carinho, com uma imagem ou uma foto. Ela aparece na tela da sala depois da aprovação.'
);
?>

<section class="secao secao--sem-topo">
	<div class="wrap"><div class="homenagem" data-homenagem data-sala="<?php echo esc_attr( $sala ); ?>" data-api="<?php echo esc_url( $api ); ?>">

		<div class="card homenagem__status" data-hm-status role="status" aria-live="polite">
			<span class="ico ico--azul" aria-hidden="true"><?php echo pai_icone( 'estrela', 24 ); ?></span>
			<div class="homenagem__status-txt">
				<p class="homenagem__para" data-hm-para>Buscando o atendimento da Sala <?php echo esc_html( $sala ); ?>…</p>
				<p class="homenagem__periodo" data-hm-periodo></p>
			</div>
			<button type="button" class="btn btn-line homenagem__tentar" data-hm-tentar hidden>Tentar de novo</button>
			<a class="btn btn-line homenagem__legado" data-hm-legado href="#" target="_blank" rel="noopener" hidden>Ver o Legado de Luz</a>
		</div>

		<form class="card homenagem__form" data-hm-form autocomplete="on" novalidate hidden>
			<div class="homenagem__grade">
				<label class="campo">
					Seu nome
					<input type="text" name="nome" maxlength="120" autocomplete="name" required data-hm-nome>
				</label>
				<label class="campo">
					Telefone
					<input type="tel" name="telefone" maxlength="20" inputmode="tel" autocomplete="tel" placeholder="(77) 99999-9999" required data-hm-fone>
				</label>

				<div class="campo campo--2">
					<span>Escolha uma imagem ou envie uma foto ou vídeo</span>
					<div class="homenagem__imagens" data-hm-imagens>
						<?php foreach ( $imagens as $n ) : ?>
							<button type="button" class="homenagem__img" data-hm-predef="<?php echo esc_url( $base_img . $n . '.png' ); ?>" aria-pressed="false" aria-label="Escolher a imagem <?php echo (int) $n; ?>">
								<img src="<?php echo esc_url( $base_img . $n . '.png' ); ?>" alt="" loading="lazy" decoding="async">
							</button>
						<?php endforeach; ?>
					</div>
					<button type="button" class="btn btn-line homenagem__arquivo" data-hm-escolher>
						<?php echo pai_icone( 'video', 20 ); ?> Enviar foto ou vídeo do celular
					</button>
					<input type="file" class="sr" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" data-hm-arquivo tabindex="-1" aria-hidden="true">
					<div class="homenagem__previa" data-hm-previa hidden></div>
					<small>Escolha uma das 4 imagens ou envie uma foto (a foto é reduzida no celular antes de enviar) ou um vídeo de até 100 MB.</small>
				</div>

				<label class="campo campo--2">
					Mensagem
					<textarea name="mensagem" maxlength="500" rows="5" required data-hm-msg placeholder="Escreva sua homenagem"></textarea>
					<small><span data-hm-cont>0</span>/500 caracteres</small>
				</label>
			</div>

			<p class="homenagem__aviso" data-hm-aviso role="alert" hidden></p>

			<div class="botoes homenagem__acoes">
				<button type="submit" class="btn btn-sol btn-g" data-hm-enviar>Enviar homenagem</button>
			</div>
			<p class="nota">A homenagem passa por aprovação antes de aparecer na tela da sala.</p>
		</form>

		<a class="card card--link homenagem__coroa" href="<?php echo esc_url( pai_url( 'coroas-de-flores' ) ); ?>">
			<span class="ico ico--verde" aria-hidden="true"><?php echo pai_icone( 'coroa', 24 ); ?></span>
			<span class="pilha pilha--pp">
				<span class="card__tit card__tit--p">Enviar uma coroa de flores</span>
				<span class="card__txt">Compre online e entregamos na sala, com a frase que você escolher na faixa.</span>
			</span>
		</a>
	</div></div>
</section>


<?php
get_footer();
