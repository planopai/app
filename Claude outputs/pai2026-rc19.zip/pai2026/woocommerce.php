<?php
/**
 * Loja (páginas de produto e categorias do WooCommerce) no layout do tema.
 */
get_header();
?>
<section class="secao secao--loja">
	<div class="wrap loja">
		<?php
		if ( is_product() ) {
			echo '<nav class="trilha" aria-label="Você está em"><a href="' . esc_url( home_url( '/' ) ) . '">Início</a> <span aria-hidden="true">›</span> <a href="' . esc_url( pai_url( 'coroas-de-flores' ) ) . '">Coroas de flores</a> <span aria-hidden="true">›</span> <span>' . esc_html( get_the_title() ) . '</span></nav>';
		}
		woocommerce_content();
		?>
	</div>
</section>
<?php
get_footer();
