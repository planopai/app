<?php
/**
 * Página inicial.
 */
get_header();
$pr = pai_precos();

$planos = array(
	array(
		'nome'   => 'LIGHT',
		'preco'  => $pr['light'],
		'de'     => '',
		'quem'   => 'Casal, filhos solteiros e pais ou sogros · adesão R$ ' . pai_reais( $pr['ad_lf'] ),
		'itens'  => array( 'Urna e roupa semiluxo', 'Translado até 200 km', 'Coroa artificial de 60 cm' ),
		'selo'   => '',
		'classe' => '',
		'btn'    => array( 'btn-line', 'Ver o LIGHT' ),
	),
	array(
		'nome'   => 'FLEX',
		'preco'  => $pr['flex'][0],
		'de'     => 'a partir de',
		'quem'   => 'Titular + até 9 dependentes, qualquer parentesco · valor pela idade do mais velho',
		'itens'  => array( 'Urna e roupa semiluxo', 'Translado até 500 km', 'Urna pet inclusa' ),
		'selo'   => 'FAMÍLIA GRANDE',
		'classe' => 'card--verde',
		'btn'    => array( 'btn-verde', 'Ver o FLEX' ),
	),
	array(
		'nome'   => 'PLUS',
		'preco'  => $pr['plus'],
		'de'     => '',
		'quem'   => 'Cônjuge, filhos solteiros, pais ou sogros e mais 2 pessoas à sua escolha, sem custo · adesão R$ ' . pai_reais( $pr['ad_pm'] ),
		'itens'  => array( 'Urna e roupa luxo', 'Translado até 1.000 km', 'Tanatopraxia incluída' ),
		'selo'   => '',
		'classe' => '',
		'btn'    => array( 'btn-line', 'Ver o PLUS' ),
	),
	array(
		'nome'   => 'MAX',
		'preco'  => $pr['max'],
		'de'     => '',
		'quem'   => 'Os mesmos dependentes do PLUS · adesão R$ ' . pai_reais( $pr['ad_pm'] ),
		'itens'  => array( 'Translado pelo Brasil, sem limite de km', 'Telemedicina incluída', 'Coroa natural de 1,10 m' ),
		'selo'   => 'MAIS COMPLETO',
		'classe' => 'card--sol',
		'btn'    => array( 'btn-sol', 'Ver o MAX' ),
	),
);

$beneficios = array(
	array( 'tele', 'azul', 'Telemedicina 24h', 'Consulta pelo celular a qualquer hora. Incluída no MAX; contratada à parte no FLEX e no PLUS.', '/telemedicina/' ),
	array( 'desconto', 'verde', 'Até 50% em consultas', 'Rede de parceiros em Barreiras: cardiologia, pediatria, odontologia, clínicas e laboratórios.', '/descontos-em-consultas-medicas/' ),
	array( 'cadeira', 'sol', 'Material ortopédico', 'Cadeira de rodas, de banho, muletas e andador emprestados por até 6 meses, conforme o plano.', '' ),
	array( 'celular', 'azul', 'App do associado', 'Mensalidades, serviços, descontos e resultado dos sorteios mensais no celular.', pai_opt( 'url_app' ) ),
);

$faq = array(
	array( 'Quanto tempo de carência?', '90 dias a partir da adesão para morte natural e 24 horas para causa externa, acidental ou violenta. Se precisar usar durante a carência, você tem desconto de 10% a 20% no atendimento.' ),
	array( 'Quem posso incluir como dependente?', 'No LIGHT, PLUS e MAX: cônjuge, filhos solteiros e pais ou sogros. No FLEX: até 9 pessoas de qualquer parentesco com vínculo familiar, e o valor segue a idade do mais velho.' ),
	array( 'Posso cancelar quando quiser?', 'Sim, com mensalidades em dia e aviso de 20 dias. Se o plano já tiver sido usado, pode haver ressarcimento conforme a cláusula 8.5 do Termo de Adesão.' ),
	array( 'E se eu atrasar a mensalidade?', 'Com mais de 10 dias de atraso os direitos ficam suspensos até a quitação. Depois de quitar, há nova carência de 15 dias.' ),
	array( 'Como pago as mensalidades?', 'Na sede, por boleto ou pelo pagamento digital do app. Só valem os canais oficiais do PAI.' ),
);
?>

<section class="hero hero--foto" style="--foto-topo:url('<?php echo esc_url( pai_opt( 'url_foto_topo' ) ); ?>')">
	<?php echo pai_marca_dagua( 'wm--hero' ); ?>
	<span class="hero__sol esconde-md" aria-hidden="true"></span>
	<div class="wrap hero__in">
		<div class="hero__texto">
			<h1 class="eyebrow">Plano funerário em Barreiras&#8209;BA · há mais de 40 anos</h1>
			<p class="display">Cuidamos de tudo, para você cuidar de quem ama.</p>
			<p class="lead">Planos para toda a família a partir de <strong class="destaque">R$ <?php echo esc_html( pai_reais( $pr['light'] ) ); ?> por mês</strong>, com plantão 24 horas, Memorial próprio e benefícios de saúde no dia a dia.</p>
			<div class="botoes">
				<a class="btn btn-sol" href="<?php echo esc_url( pai_link( 'url_contratar' ) ); ?>">Contratar agora</a>
				<a class="btn btn-line" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>">Conhecer os planos</a>
			</div>
			<a class="hero__associado" href="<?php echo esc_url( pai_url( 'pagar-mensalidade' ) ); ?>"><?php echo pai_icone( 'cartao', 18 ); ?>Já é associado? <strong>Pague sua mensalidade ›</strong></a>
			<dl class="numeros">
				<div><dt>+40 anos</dt><dd>cuidando de famílias</dd></div>
				<div><dt>24 h</dt><dd>plantão todos os dias</dd></div>
				<div><dt>3 salas</dt><dd>no Memorial Senhor do Bonfim</dd></div>
			</dl>
		</div>
		<div class="hero__lado">
			<div class="hero__foto">
				<?php
				$foto = pai_imagem_painel( 'img_hero', 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) );
				if ( ! $foto && pai_opt( 'url_foto_topo' ) ) {
					// Sem foto escolhida no painel: a mesma foto do topo da landing page.
					$foto = '<img src="' . esc_url( pai_opt( 'url_foto_topo' ) ) . '" alt="Família reunida ao pôr do sol" width="1800" height="1200" loading="eager" fetchpriority="high" decoding="async">';
				}
				echo $foto ? $foto : '<img class="hero__simbolo logo-d" src="' . pai_img( 'icone-branco.svg' ) . '" alt="" width="220" height="220"><img class="hero__simbolo logo-l" src="' . pai_img( 'icone-escuro.svg' ) . '" alt="" width="220" height="220">';
				?>
			</div>
			<a class="capsula" href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>" aria-label="Ligar para o plantão 24 horas, <?php echo esc_attr( pai_opt( 'tel_plantao' ) ); ?>">
				<span class="capsula__contorno" aria-hidden="true"></span>
				<span class="capsula__ico"><?php echo pai_icone( 'fone', 26 ); ?></span>
				<span class="capsula__txt">
					<span class="capsula__rot">PLANTÃO 24 HORAS</span>
					<span class="capsula__num"><?php echo esc_html( pai_opt( 'tel_plantao' ) ); ?></span>
					<span class="capsula__sub">Toque para ligar · associados ou não</span>
				</span>
			</a>
			<a class="link-forte" href="<?php echo esc_url( pai_url( 'atendimento-24-horas' ) ); ?>">Perdeu alguém agora? Veja o que fazer passo a passo ›</a>
		</div>
	</div>
</section>

<section class="secao secao--alt secao--curta">
	<div class="wrap grade-2">
		<a class="card card--link card--borda-sol" href="<?php echo esc_url( pai_url( 'atendimento-24-horas' ) ); ?>">
			<span class="eyebrow eyebrow--urg">Urgência</span>
			<span class="card__tit">Preciso de atendimento agora</span>
			<span class="card__txt">Nossa equipe vai até você a qualquer hora, organiza o velório, o sepultamento e ajuda com os documentos.</span>
			<span class="btn btn-sol">Ver o que fazer agora</span>
		</a>
		<a class="card card--link" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>">
			<span class="eyebrow eyebrow--verde">Planejamento</span>
			<span class="card__tit">Quero proteger minha família</span>
			<span class="card__txt">Compare os 4 planos e simule o valor pela idade em poucos minutos.</span>
			<span class="btn btn-verde">Simular meu plano</span>
		</a>
	</div>
</section>

<section class="secao">
	<div class="wrap pilha">
		<div class="secao__topo">
			<div class="secao__cab">
				<p class="eyebrow">Planos funerários</p>
				<h2 class="h2">Um plano para cada família</h2>
				<p class="lead">Todos incluem urna, roupa, ornamentação, coroa, carro funerário, sala no Memorial e kit lanche.</p>
			</div>
			<a class="link-forte" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>#comparativo">Comparar todos os itens ›</a>
		</div>
		<div class="grade-planos">
			<?php foreach ( $planos as $pl ) : ?>
				<article class="card plano <?php echo esc_attr( $pl['classe'] ); ?>">
					<?php if ( $pl['selo'] ) : ?><span class="selo"><?php echo esc_html( $pl['selo'] ); ?></span><?php endif; ?>
					<h3 class="plano__nome"><?php echo esc_html( $pl['nome'] ); ?></h3>
					<p class="plano__preco">
						<?php if ( $pl['de'] ) : ?><span class="plano__de"><?php echo esc_html( $pl['de'] ); ?></span><br><?php endif; ?>
						<span class="plano__rs">R$</span> <span class="plano__valor"><?php echo esc_html( pai_reais( $pl['preco'] ) ); ?></span><span class="plano__mes">/mês</span>
					</p>
					<p class="plano__quem"><?php echo esc_html( $pl['quem'] ); ?></p>
					<ul class="lista-check">
						<?php foreach ( $pl['itens'] as $it ) : ?><li><?php echo esc_html( $it ); ?></li><?php endforeach; ?>
					</ul>
					<a class="btn <?php echo esc_attr( $pl['btn'][0] ); ?> plano__btn" href="<?php echo esc_url( pai_url( 'planos-funerarios/' . strtolower( $pl['nome'] ) ) ); ?>"><?php echo esc_html( $pl['btn'][1] ); ?></a>
				</article>
			<?php endforeach; ?>
		</div>
		<p class="nota">Carência de 90 dias para morte natural e de 24 horas para causa acidental. Valores conforme os Termos de Adesão.</p>
	</div>
</section>

<section class="secao faixa-escura">
	<?php echo pai_marca_dagua( 'wm--faixa' ); ?>
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow eyebrow--sol">Com você todos os dias</p>
			<h2 class="h2">Benefícios para usar em vida, não só no momento da despedida</h2>
		</div>
		<div class="grade-auto">
			<?php foreach ( $beneficios as $b ) : ?>
				<div class="beneficio">
					<span class="ico ico--<?php echo esc_attr( $b[1] ); ?>"><?php echo pai_icone( $b[0], 26 ); ?></span>
					<h3 class="beneficio__tit"><?php echo esc_html( $b[2] ); ?></h3>
					<p class="beneficio__txt"><?php echo esc_html( $b[3] ); ?></p>
					<?php if ( $b[4] ) : ?><a class="link-forte" href="<?php echo esc_url( 0 === strpos( $b[4], '/' ) ? home_url( $b[4] ) : $b[4] ); ?>">Saiba mais ›</a><?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="secao">
	<div class="wrap pilha">
		<div class="secao__cab">
			<p class="eyebrow">Nossa estrutura</p>
			<h2 class="h2">Memorial Senhor do Bonfim</h2>
			<p class="lead">Salas de velório climatizadas, estacionamento e frota própria, no bairro Flamengo.</p>
		</div>
		<?php
		$fotos = array();
		for ( $i = 1; $i <= 5; $i++ ) {
			$f = pai_imagem_painel( 'img_mem_' . $i, 1 === $i ? 'large' : 'medium_large' );
			if ( $f ) {
				$fotos[] = $f;
			}
		}
		if ( ! $fotos ) {
			// Sem fotos no painel: todas as fotos da página Galeria (Memorial primeiro).
			foreach ( pai_fotos_da_galeria( 60, array( 'Memorial', 'Salas de Velório', 'Ambiente Climatizado', 'Estacionamento', 'Frota', 'Plano PAI' ) ) as $g ) {
				$fotos[] = pai_img_galeria( $g, array( 'size' => 'large' ) );
			}
		}
		if ( $fotos ) :
			?>
			<div class="lp-galeria">
				<button class="lp-galeria__nav lp-galeria__ant" type="button" aria-label="Foto anterior">‹</button>
				<div class="lp-galeria__trilho" data-lp-galeria>
					<?php foreach ( $fotos as $f ) : ?><figure class="lp-galeria__item"><?php echo $f; ?></figure><?php endforeach; ?>
				</div>
				<button class="lp-galeria__nav lp-galeria__prox" type="button" aria-label="Próxima foto">›</button>
			</div>
			<div class="ampliada lp-ampliada" data-lp-ampliada hidden>
				<button type="button" class="ampliada__fechar" data-lp-fechar aria-label="Fechar"><?php echo pai_icone( 'fechar', 26 ); ?></button>
				<img src="" alt="">
			</div>
			<p class="nota"><a href="<?php echo esc_url( pai_url( 'galeria' ) ); ?>">Ver a galeria completa ›</a></p>
		<?php endif; ?>
		<div class="grade-2">
			<div class="card card--ico card--borda-azul">
				<span class="ico ico--azul"><?php echo pai_icone( 'video', 26 ); ?></span>
				<div>
					<h3 class="card__tit card__tit--m">Velório online</h3>
					<p class="card__txt">Transmissão ao vivo das 3 salas, com senha para a família, mensagens e homenagens na TV da sala.</p>
					<a class="link-forte" href="<?php echo esc_url( pai_url( 'velorio-online' ) ); ?>">Acessar uma sala ›</a>
				</div>
			</div>
			<div class="card card--ico card--borda-verde">
				<span class="ico ico--verde"><?php echo pai_icone( 'flor', 26 ); ?></span>
				<div>
					<h3 class="card__tit card__tit--m">Coroas de flores</h3>
					<p class="card__txt">Naturais e artificiais, com faixa personalizada e entrega direto no velório em Barreiras.</p>
					<a class="link-forte" href="<?php echo esc_url( pai_url( 'coroas-de-flores' ) ); ?>">Escolher uma coroa ›</a>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
$artigos = new WP_Query( array(
	'post_type'           => 'post',
	'posts_per_page'      => 5,
	'ignore_sticky_posts' => true,
	'no_found_rows'       => true,
) );
?>
<section class="secao secao--alt">
	<div class="wrap pilha">
		<div class="secao__topo">
			<div class="secao__cab">
				<p class="eyebrow">Guia para famílias</p>
				<h2 class="h2">Informação que acolhe, em cada momento</h2>
				<p class="lead">Respostas simples para o que as famílias de Barreiras mais perguntam, antes, durante e depois da despedida.</p>
			</div>
			<a class="btn btn-line" href="<?php echo esc_url( pai_url( 'guia-para-familias' ) ); ?>">Ver todo o guia</a>
		</div>
		<div class="grade-temas">
			<a class="card card--link tema tema--sol" href="<?php echo esc_url( pai_url( 'atendimento-24-horas' ) ); ?>">
				<span class="card__tit card__tit--p">Quando alguém falece</span>
				<span class="card__txt">O que fazer nas primeiras horas, como registrar o óbito e o que a lei exige para a cremação.</span>
			</a>
			<a class="card card--link tema tema--azul" href="<?php echo esc_url( pai_url( 'guia-para-familias' ) . '?tema=depois-do-sepultamento' ); ?>">
				<span class="card__tit card__tit--p">Depois do sepultamento</span>
				<span class="card__txt">Pensão por morte, contas e documentos, inventário.</span>
			</a>
			<a class="card card--link tema tema--verde" href="<?php echo esc_url( pai_url( 'guia-para-familias' ) . '?tema=luto-e-acolhimento' ); ?>">
				<span class="card__tit card__tit--p">Luto e acolhimento</span>
				<span class="card__txt">Como lidar com a perda e onde buscar apoio em Barreiras.</span>
			</a>
			<a class="card card--link tema tema--sol" href="<?php echo esc_url( pai_url( 'guia-para-familias' ) . '?tema=planejar-em-vida' ); ?>">
				<span class="card__tit card__tit--p">Planejar em vida</span>
				<span class="card__txt">Por que ter um plano funerário e quem é o sucessor do contrato.</span>
			</a>
		</div>
		<?php if ( $artigos->have_posts() ) : ?>
			<div class="pilha pilha--p">
				<h3 class="subtit">Artigos recentes</h3>
				<div class="grade-artigos">
					<?php
					while ( $artigos->have_posts() ) :
						$artigos->the_post();
						$cat = get_the_category();
						?>
						<a class="artigo-mini" href="<?php the_permalink(); ?>">
							<?php if ( $cat ) : ?><span class="artigo-mini__cat"><?php echo esc_html( $cat[0]->name ); ?></span><?php endif; ?>
							<span class="artigo-mini__tit"><?php the_title(); ?></span>
						</a>
					<?php endwhile; ?>
				</div>
			</div>
			<?php
			wp_reset_postdata();
		endif;
		?>
	</div>
</section>

<section class="secao">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow">Dúvidas frequentes</p>
			<h2 class="h2">Antes de contratar</h2>
			<p class="lead">Não achou sua dúvida? Fale com a gente no WhatsApp.</p>
			<a class="btn btn-verde alinha-ini" href="<?php echo esc_url( pai_wa( 'Olá, vim pelo site e tenho uma dúvida sobre os planos.' ) ); ?>"><?php echo pai_icone( 'whats', 20 ); ?><?php echo esc_html( pai_opt( 'whatsapp' ) ); ?></a>
		</div>
		<div class="faq">
			<?php foreach ( $faq as $i => $q ) : ?>
				<details <?php echo 0 === $i ? 'open' : ''; ?>>
					<summary><?php echo esc_html( $q[0] ); ?><span class="faq__mais" aria-hidden="true">+</span></summary>
					<p><?php echo esc_html( $q[1] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php
$aval = trim( (string) pai_opt( 'avaliacoes_shortcode' ) );
if ( $aval && false !== strpos( $aval, '[' ) ) :
	?>
	<section class="secao">
		<div class="wrap pilha">
			<div class="secao__cab">
				<p class="eyebrow">Avaliações no Google</p>
				<h2 class="h2">O que as famílias dizem</h2>
			</div>
			<div class="avaliacoes"><?php echo do_shortcode( $aval ); // phpcs:ignore ?></div>
		</div>
	</section>
<?php endif; ?>

<script type="application/ld+json"><?php
echo wp_json_encode( array(
	'@context'   => 'https://schema.org',
	'@type'      => 'FAQPage',
	'mainEntity' => array_map( function ( $q ) {
		return array( '@type' => 'Question', 'name' => $q[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $q[1] ) );
	}, $faq ),
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
?></script>

<?php get_template_part( 'parts/enderecos' ); ?>

<?php
get_footer();
