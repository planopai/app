<?php
/**
 * Página /termos-e-condicoes/.
 */
get_header();
get_template_part( 'parts/pagina-texto' );
get_footer();
