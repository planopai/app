<?php
/**
 * Página /telemedicina/.
 */
get_header();
pai_topo(
	'Telemedicina',
	'Telemedicina do PAI',
	'Médico 24 horas na palma da sua mão',
	'Atendimento médico pelo celular ou computador, com mais praticidade, segurança e agilidade.',
	'<div class="botoes"><a class="btn btn-sol btn-g" href="#acessar-telemedicina">' . pai_icone( 'tele', 22 ) . 'Acessar a Telemedicina</a><a class="btn btn-claro btn-g" href="' . esc_url( pai_wa( 'Olá, vim pelo site e gostaria de saber mais sobre a Telemedicina do PAI (atendimento médico 24h).' ) ) . '" target="_blank" rel="noopener">' . pai_icone( 'whats', 22 ) . 'Tirar dúvidas no WhatsApp</a></div>'
);

$sem = array( 'Filas de espera', 'Deslocamentos desnecessários', 'Longas esperas por orientação médica' );
$com = array( 'Atendimento médico 24 horas', 'Clínico geral e especialistas', 'Orientações médicas com segurança', 'Receitas e pedidos de exames, quando necessário', 'Mais comodidade para cuidar da saúde da família' );
?>

<?php $campanha = trim( (string) pai_opt( 'tele_campanha' ) ); ?>
<?php if ( $campanha ) : ?>
	<section class="secao secao--curta secao--sem-topo">
		<div class="wrap">
			<p class="campanha"><span class="campanha__selo">Promoção</span><?php echo esc_html( $campanha ); ?></p>
		</div>
	</section>
<?php endif; ?>

<section class="secao secao--sem-topo">
	<div class="wrap grade-2">
		<div class="card pilha pilha--p">
			<p class="eyebrow eyebrow--urg">Cuide da saúde sem</p>
			<ul class="lista-x">
				<?php foreach ( $sem as $t ) : ?><li><?php echo esc_html( $t ); ?></li><?php endforeach; ?>
			</ul>
		</div>
		<div class="card card--borda-verde pilha pilha--p">
			<p class="eyebrow eyebrow--verde">O associado PAI conta com</p>
			<ul class="lista-check">
				<?php foreach ( $com as $t ) : ?><li><?php echo esc_html( $t ); ?></li><?php endforeach; ?>
			</ul>
		</div>
	</div>
</section>


<?php $url_tele = pai_link( 'url_telemedicina' ); ?>
<section class="secao secao--alt" id="acessar-telemedicina">
	<div class="wrap pilha">
		<div class="secao__cab tele-acesso__cab">
			<div class="pilha pilha--pp">
				<p class="eyebrow">Acesse aqui mesmo</p>
				<h2 class="h2">Entre na Telemedicina</h2>
				<p class="lead">Use o e-mail ou o CPF e a sua senha. Primeiro acesso? Clique em “Crie seu cadastro”. Para a consulta por vídeo, permita o uso da câmera e do microfone quando o navegador pedir.</p>
			</div>
			<a class="btn btn-line" href="<?php echo esc_url( $url_tele ); ?>" target="_blank" rel="noopener">Abrir em tela cheia ›</a>
		</div>
		<div class="tele-acesso">
			<iframe src="<?php echo esc_url( $url_tele ); ?>" title="Telemedicina do Plano PAI" loading="lazy" allow="camera; microphone; fullscreen; display-capture; autoplay; clipboard-write" referrerpolicy="strict-origin-when-cross-origin"></iframe>
		</div>
		<p class="nota">Se a tela não carregar, use o botão “Abrir em tela cheia”. No celular, a consulta funciona melhor em tela cheia.</p>
	</div>
</section>

<section class="secao">
	<div class="wrap duas-colunas">
		<div class="pilha pilha--p">
			<p class="eyebrow">Quem tem direito</p>
			<h2 class="h2">Telemedicina nos planos</h2>
		</div>
		<div class="pilha pilha--p">
			<p class="lead"><?php echo esc_html( pai_opt( 'tele_quem' ) ); ?></p>
			<div class="botoes">
				<a class="btn btn-verde" href="<?php echo esc_url( pai_wa( 'Olá, vim pelo site e gostaria de saber como usar ou contratar a Telemedicina do PAI.' ) ); ?>" target="_blank" rel="noopener"><?php echo pai_icone( 'whats', 20 ); ?>Falar no WhatsApp</a>
				<a class="btn btn-line" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>">Comparar os planos</a>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
