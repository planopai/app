<?php
/**
 * Rodapé completo, barra de atalhos do celular e botão do WhatsApp.
 */
?>
</main>

<footer class="rodape">
	<div class="wrap">
		<div class="rodape__grade">
			<div class="rodape__marca">
				<?php echo pai_logo( 46, false ); ?>
				<div class="rodape__lema">COM VOCÊ TODOS OS DIAS</div>
			</div>
			<div>
				<h2 class="rodape__tit">Institucional</h2>
				<?php
				pai_menu( 'rodape-inst', array(
					array( '/sobre-nos/', 'Sobre nós' ),
					array( '/servicos-plano-pai/', 'Serviços' ),
					array( '/trabalhe-conosco/', 'Trabalhe conosco' ),
					array( '/seja-nosso-parceiro/', 'Seja nosso parceiro' ),
					array( '/guia-para-familias/', 'Guia para famílias' ),
				), 'rodape__lista' );
				?>
			</div>
			<div>
				<h2 class="rodape__tit">Atendimento</h2>
				<ul class="rodape__lista">
					<li><a href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>">Plantão 24h: <?php echo esc_html( pai_opt( 'tel_plantao' ) ); ?></a></li>
					<li><a href="<?php echo esc_url( pai_wa() ); ?>">WhatsApp: <?php echo esc_html( pai_opt( 'whatsapp' ) ); ?></a></li>
					<li><a href="mailto:<?php echo esc_attr( pai_opt( 'email' ) ); ?>"><?php echo esc_html( pai_opt( 'email' ) ); ?></a></li>
				</ul>
			</div>
			<div>
				<h2 class="rodape__tit">Associado</h2>
				<?php
				pai_menu( 'rodape-asso', array(
					array( pai_link( 'url_associado' ), 'Área do associado' ),
					array( '/aplicativo/', 'Aplicativo' ),
					array( pai_link( 'url_telemedicina' ), 'Telemedicina' ),
					array( '/pagar-mensalidade/', 'Pagar mensalidade' ),
					array( '/tutoriais/', 'Tutoriais' ),
					array( '/parceiros/', 'Parceiros' ),
					array( pai_opt( 'instagram' ), 'Instagram' ),
				), 'rodape__lista' );
				?>
			</div>
			<div>
				<h2 class="rodape__tit">Transparência</h2>
				<?php
				pai_menu( 'rodape-tran', array(
					array( '/termos-e-condicoes/', 'Termos de uso' ),
					array( '/politica-de-privacidade/', 'Política de privacidade (LGPD)' ),
					array( '/contato-plano-pai/', 'Reclamações e elogios' ),
				), 'rodape__lista' );
				?>
			</div>
		</div>
		<div class="rodape__base">
			<span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> PAI Plano Assistencial Integrado · CNPJ <?php echo esc_html( pai_opt( 'cnpj' ) ); ?></span>
			<span><a href="<?php echo esc_url( pai_url( 'politica-de-privacidade' ) ); ?>">Política de privacidade</a> · <a href="<?php echo esc_url( pai_url( 'termos-e-condicoes' ) ); ?>">Termos de uso</a></span>
		</div>
	</div>
</footer>

<nav class="barra-cel" aria-label="Atalhos">
	<a class="btn btn-sol" href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>"><?php echo pai_icone( 'fone', 18 ); ?>Plantão 24h</a>
	<a class="btn btn-verde" href="<?php echo esc_url( pai_wa( 'Olá, vim pelo site!' ) ); ?>"><?php echo pai_icone( 'whats', 18 ); ?>WhatsApp</a>
</nav>

<?php if ( pai_opt( 'whats_flutuante' ) ) : ?>
<a class="whats-flutuante" href="<?php echo esc_url( pai_wa( 'Olá, vim pelo site!' ) ); ?>" aria-label="Falar no WhatsApp"><?php echo pai_icone( 'whats', 30 ); ?></a>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
