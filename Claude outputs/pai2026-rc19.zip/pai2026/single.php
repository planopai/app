<?php
/**
 * Artigo do Guia para famílias.
 */
get_header();

while ( have_posts() ) :
	the_post();
	$cat       = get_the_category();
	$elementor = pai_feito_no_elementor( get_the_ID() );
	?>
	<article <?php post_class( 'artigo-pagina' ); ?>>
		<header class="topo-pagina">
			<?php echo pai_marca_dagua( 'wm--topo' ); ?>
			<div class="wrap wrap--texto pilha pilha--p topo-pagina__in">
				<nav class="trilha" aria-label="Você está em"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Início</a> <span aria-hidden="true">›</span> <a href="<?php echo esc_url( pai_url( 'guia-para-familias' ) ); ?>">Guia para famílias</a><?php if ( $cat ) : ?> <span aria-hidden="true">›</span> <a href="<?php echo esc_url( add_query_arg( 'tema', $cat[0]->slug, pai_url( 'guia-para-familias' ) ) ); ?>"><?php echo esc_html( $cat[0]->name ); ?></a><?php endif; ?></nav>
				<h1 class="display display--m"><?php the_title(); ?></h1>
				<p class="nota">Atualizado em <time datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>"><?php echo esc_html( get_the_modified_date( 'd/m/Y' ) ); ?></time> · Equipe Plano PAI</p>
			</div>
		</header>
		<?php if ( has_post_thumbnail() && ! $elementor ) : ?>
			<div class="wrap wrap--texto artigo-pagina__foto"><?php the_post_thumbnail( 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?></div>
		<?php endif; ?>
		<div class="<?php echo $elementor ? 'conteudo-elementor' : 'wrap wrap--texto texto artigo-pagina__corpo'; ?>">
			<?php the_content(); ?>
		</div>
		<aside class="wrap wrap--texto">
			<div class="card card--borda-sol cta-artigo">
				<p class="card__tit card__tit--p">Precisa de ajuda agora?</p>
				<p class="card__txt">Plantão 24 horas, todos os dias, para associados ou não.</p>
				<div class="botoes">
					<a class="btn btn-sol" href="<?php echo esc_url( pai_tel( 'tel_plantao' ) ); ?>"><?php echo pai_icone( 'fone', 20 ); ?><?php echo esc_html( pai_opt( 'tel_plantao' ) ); ?></a>
					<a class="btn btn-line" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>">Conhecer os planos</a>
				</div>
			</div>
		</aside>
	</article>
	<?php
	$rel = new WP_Query( array(
		'post_type'           => 'post',
		'posts_per_page'      => 3,
		'post__not_in'        => array( get_the_ID() ),
		'category__in'        => $cat ? array( $cat[0]->term_id ) : array(),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	) );
	if ( $rel->have_posts() ) :
		?>
		<section class="secao secao--alt">
			<div class="wrap pilha">
				<h2 class="h2">Leia também</h2>
				<div class="grade-artigos-g">
					<?php
					while ( $rel->have_posts() ) :
						$rel->the_post();
						get_template_part( 'parts/cartao-artigo' );
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
		<?php
	endif;
endwhile;

get_footer();
