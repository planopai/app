<?php
/**
 * Página /guia-para-familias/: lista os artigos do blog, com filtro por categoria.
 */
get_header();

$tema   = isset( $_GET['tema'] ) ? sanitize_title( wp_unslash( $_GET['tema'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$pagina = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
$cats   = get_categories( array( 'hide_empty' => true ) );

$args = array(
	'post_type'           => 'post',
	'posts_per_page'      => 12,
	'paged'               => $pagina,
	'ignore_sticky_posts' => true,
);
if ( $tema ) {
	$args['category_name'] = $tema;
}
$artigos = new WP_Query( $args );
$base    = get_permalink();
?>

<section class="topo-pagina">
	<?php echo pai_marca_dagua( 'wm--topo' ); ?>
	<div class="wrap pilha pilha--p topo-pagina__in">
		<?php pai_trilha( 'Guia para famílias' ); ?>
		<h1 class="display display--m">Guia para famílias</h1>
		<p class="lead">Orientações claras sobre despedida, documentos, luto e planejamento, escritas pela equipe do Plano PAI, há mais de 40 anos em Barreiras.</p>
		<form class="busca" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="sr" for="busca-guia">Buscar no guia</label>
			<input id="busca-guia" class="busca__campo" type="search" name="s" placeholder="Buscar: certidão de óbito, pensão, cremação...">
			<input type="hidden" name="post_type" value="post">
			<button class="busca__btn" type="submit" aria-label="Buscar"><?php echo pai_icone( 'busca', 22 ); ?></button>
		</form>
	</div>
</section>

<section class="secao secao--sem-topo">
	<div class="wrap pilha">
		<?php if ( $cats ) : ?>
			<nav class="abas" aria-label="Filtrar por tema">
				<a class="aba" href="<?php echo esc_url( $base ); ?>" <?php echo $tema ? '' : 'aria-current="page"'; ?>>Todos</a>
				<?php foreach ( $cats as $c ) : ?>
					<a class="aba" href="<?php echo esc_url( add_query_arg( 'tema', $c->slug, $base ) ); ?>" <?php echo $tema === $c->slug ? 'aria-current="page"' : ''; ?>><?php echo esc_html( $c->name ); ?></a>
				<?php endforeach; ?>
			</nav>
		<?php endif; ?>

		<?php if ( $artigos->have_posts() ) : ?>
			<?php
			// Primeira página sem filtro: destaque + lista ao lado com os 6 mais recentes.
			$resto = $artigos->posts;
			if ( 1 === $pagina && ! $tema && count( $resto ) >= 3 ) {
				get_template_part( 'parts/artigo-destaque', null, array( 'posts' => array_slice( $resto, 0, 6 ) ) );
				$resto = array_slice( $resto, 6 );
			}
			if ( $resto ) :
				?>
				<div class="grade-artigos-g">
					<?php
					global $post;
					foreach ( $resto as $p ) {
						$post = $p; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
						setup_postdata( $post );
						get_template_part( 'parts/cartao-artigo' );
					}
					wp_reset_postdata();
					?>
				</div>
			<?php endif; ?>
			<?php
			$links = paginate_links( array(
				'base'      => trailingslashit( $base ) . '%_%',
				'format'    => 'page/%#%/',
				'current'   => $pagina,
				'total'     => $artigos->max_num_pages,
				'add_args'  => $tema ? array( 'tema' => $tema ) : false,
				'prev_text' => '‹ Anteriores',
				'next_text' => 'Próximos ›',
			) );
			if ( $links ) {
				echo '<nav class="paginacao" aria-label="Páginas">' . wp_kses_post( $links ) . '</nav>';
			}
			wp_reset_postdata();
			?>
		<?php else : ?>
			<p class="aviso">Ainda não há artigos neste tema.</p>
		<?php endif; ?>
	</div>
</section>

<section class="secao secao--alt">
	<div class="wrap grade-2">
		<a class="card card--link card--borda-sol" href="<?php echo esc_url( pai_url( 'atendimento-24-horas' ) ); ?>">
			<span class="eyebrow eyebrow--urg">Perdeu alguém agora?</span>
			<span class="card__tit">Veja o que fazer passo a passo</span>
			<span class="card__txt">Plantão 24 horas, documentos, registro do óbito e o que a lei pede para o sepultamento e a cremação.</span>
		</a>
		<a class="card card--link" href="<?php echo esc_url( pai_url( 'planos-funerarios' ) ); ?>">
			<span class="eyebrow eyebrow--verde">Planejar em vida</span>
			<span class="card__tit">Conheça os planos</span>
			<span class="card__txt">Compare os 4 planos e simule o valor da mensalidade.</span>
		</a>
	</div>
</section>

<?php
get_footer();
