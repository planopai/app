<?php
/**
 * Páginas de texto (Termos, Política de Privacidade). Se a página foi feita no
 * Elementor, o tema pega só os textos; senão, mostra o conteúdo normal.
 */
while ( have_posts() ) :
	the_post();
	pai_topo( get_the_title(), 'Plano PAI', get_the_title() );
	$texto = pai_feito_no_elementor( get_the_ID() ) ? pai_el_texto( get_the_ID() ) : '';
	?>
	<section class="secao secao--sem-topo">
		<div class="wrap wrap--texto texto">
			<?php
			if ( '' !== trim( wp_strip_all_tags( $texto ) ) ) {
				echo $texto; // phpcs:ignore -- já passou por wp_kses_post
			} else {
				the_content();
			}

			// Exclusão de dados (LGPD). Vem do tema, porque a página não é mais editada no Elementor.
			// O id "exclusao-de-dados" é o link informado à Meta (URL de instruções de exclusão de dados).
			if ( is_page( 'politica-de-privacidade' ) ) :
				$assunto = 'Excluir meus dados';
				?>
				<h2 id="exclusao-de-dados">Exclusão de dados</h2>
				<p>Para pedir a exclusão dos seus dados de conversas pelo site, Facebook, Instagram ou WhatsApp, envie um e-mail para <a href="<?php echo esc_url( 'mailto:suporte@planoassistencialintegrado.com.br?subject=' . rawurlencode( $assunto ) ); ?>">suporte@planoassistencialintegrado.com.br</a> ou uma mensagem pelo <a href="<?php echo esc_url( pai_wa( $assunto ) ); ?>" target="_blank" rel="noopener">WhatsApp do Plano PAI</a> com o assunto “<?php echo esc_html( $assunto ); ?>”. Respondemos em até 15 dias. Dados que a lei obriga a guardar (contratos e documentos do atendimento) são mantidos pelo prazo legal.</p>
				<?php
			endif;
			?>
			<p class="nota">Última atualização: <?php echo esc_html( get_the_modified_date( 'd/m/Y' ) ); ?></p>
		</div>
	</section>
	<?php
endwhile;
