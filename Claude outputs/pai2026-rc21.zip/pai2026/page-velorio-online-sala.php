<?php
/**
 * rc20 (12/11/2026): velório online das salas (/velorio-online-sala-01/, -02/ e -03/). Um modelo para as três salas.
 *
 * Mantém tudo o que já funcionava (mesmos endereços do servidor):
 * - dados do velório: /salaNN.php?modo=online (a cada 30 s);
 * - senha: POST /salaNN.php?action=verificar_senha (sala=sala-NN, senha);
 * - cadastro do visitante: POST /gravar_leads.php (nome, pais, estado, cidade, telefone);
 * - cookie de acesso: acessoSalaNN = id do registro (quem já entrou continua entrando);
 * - mensagens: POST /saveMessage.php (name, selectedImage, imageUpload, messageText);
 * - transmissão: https://live.planoassistencialintegrado.com.br:4040/live/salaNN/.m3u8
 *   (pode ser trocada pelo campo personalizado pai_stream_url na página).
 * Nome da sala: campo personalizado pai_nome_sala (se vazio, usa pai_nomes_salas()).
 * Para voltar ao Elementor numa delas: campo personalizado pai_usar_elementor = 1.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sala   = pai_velorio_online_sala();
$pagina = get_queried_object_id();
$nome   = trim( (string) get_post_meta( $pagina, 'pai_nome_sala', true ) );
if ( '' === $nome ) {
	$nomes = pai_nomes_salas();
	$nome  = isset( $nomes[ $sala ] ) ? $nomes[ $sala ] : '';
}
$stream = trim( (string) get_post_meta( $pagina, 'pai_stream_url', true ) );
if ( '' === $stream ) {
	$stream = 'https://live.planoassistencialintegrado.com.br:4040/live/sala' . $sala . '/.m3u8';
}
$logo   = PAI_URI . '/assets/img/logo-pai-escuro.svg';
$imgs   = array( 1, 2, 3, 4 );

$icone = array(
	'data'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/></svg>',
	'hora'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
	'local'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>',
	'msg'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
	'flor'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="9" r="2.2"/><circle cx="12" cy="4.6" r="2.4"/><circle cx="16.2" cy="7.6" r="2.4"/><circle cx="14.6" cy="12.4" r="2.4"/><circle cx="9.4" cy="12.4" r="2.4"/><circle cx="7.8" cy="7.6" r="2.4"/><path d="M12 15v7M12 19c-2 0-3.5-1-4-3M12 18c2 0 3.5-1 4-3"/></svg>',
	'estrela'=> '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2l2.9 6.9L22 9.3l-5.4 4.7L18.2 21 12 17.3 5.8 21l1.6-7L2 9.3l7.1-.4z"/></svg>',
	'som'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/></svg>',
);
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'vo-pagina' ); ?>>
<?php wp_body_open(); ?>

<div class="vo" data-vo
	data-sala="<?php echo esc_attr( $sala ); ?>"
	data-stream="<?php echo esc_url( $stream ); ?>"
	data-dados="<?php echo esc_url( home_url( '/sala' . $sala . '.php' ) ); ?>"
	data-leads="<?php echo esc_url( home_url( '/gravar_leads.php' ) ); ?>"
	data-mensagem="<?php echo esc_url( home_url( '/saveMessage.php' ) ); ?>"
	data-homenagens="https://api.planoassistencialintegrado.com.br/homenagens.php"
	data-legado="<?php echo esc_url( home_url( '/legado-de-luz/' ) ); ?>"
	data-cidades="<?php echo esc_url( PAI_URI . '/assets/data/cidades/' ); ?>">

	<header class="vo-topo">
		<img src="<?php echo esc_url( $logo ); ?>" alt="Plano PAI" width="110" height="47">
		<p class="vo-sala"><small>VELÓRIO ONLINE</small>SALA <?php echo esc_html( $sala ); ?><?php if ( '' !== $nome ) : ?><em><?php echo esc_html( mb_strtoupper( $nome, 'UTF-8' ) ); ?></em><?php endif; ?></p>
	</header>

	<div class="vo-grade">
		<div class="vo-esq">
			<div class="vo-video" data-vo-video-box>
				<video data-vo-video controls playsinline muted autoplay preload="none"></video>
				<span class="vo-aovivo" data-vo-aovivo hidden><i></i>AO VIVO</span>
				<button type="button" class="vo-som" data-vo-som hidden><?php echo $icone['som']; // phpcs:ignore ?>Ativar som</button>
				<div class="vo-aviso" data-vo-aviso>
					<div><div class="vo-gira" aria-hidden="true"></div><b data-vo-aviso-tit>Carregando…</b><span data-vo-aviso-txt></span></div>
				</div>
			</div>
		</div>

		<section class="vo-cx vo-info" aria-live="polite">
			<p class="vo-rot">EM MEMÓRIA</p>
			<h1 class="vo-nome" data-vo-nome>Carregando…</h1>
			<p class="vo-datas" data-vo-datas hidden></p>
			<p class="vo-velorio" data-vo-velorio hidden></p>
			<div class="vo-linhas">
				<div class="vo-linha"><span class="vo-ic"><?php echo $icone['data']; // phpcs:ignore ?></span><div><p class="vo-k">Sepultamento</p><p class="vo-v" data-vo-data>—</p></div></div>
				<div class="vo-linha"><span class="vo-ic"><?php echo $icone['hora']; // phpcs:ignore ?></span><div><p class="vo-k">Horário</p><p class="vo-v" data-vo-hora>—</p></div></div>
				<div class="vo-linha"><span class="vo-ic"><?php echo $icone['local']; // phpcs:ignore ?></span><div><p class="vo-k">Local</p><p class="vo-v" data-vo-local>—</p></div></div>
			</div>
		</section>

		<div class="vo-acoes" data-vo-acoes>
			<button type="button" class="vo-bt vo-bt--sol" data-vo-abrir-msg><?php echo $icone['msg']; // phpcs:ignore ?><span>Enviar mensagem<small>Uma palavra de conforto à família</small></span></button>
			<a class="vo-bt" href="<?php echo esc_url( pai_url( 'coroas-de-flores' ) ); ?>" target="_blank" rel="noopener"><?php echo $icone['flor']; // phpcs:ignore ?><span>Coroa de flores<small>Entregue na sala, com faixa</small></span></a>
			<a class="vo-bt" href="<?php echo esc_url( home_url( '/legado-de-luz/' ) ); ?>" target="_blank" rel="noopener" data-vo-legado><?php echo $icone['estrela']; // phpcs:ignore ?><span>Legado de Luz<small data-vo-legado-txt>Memorial de homenagens</small></span></a>
		</div>
	</div>

	<footer class="vo-rodape"><img src="<?php echo esc_url( $logo ); ?>" alt="" width="70" height="30">Tecnologia Plano PAI</footer>
</div>

<!-- Acesso (senha) -->
<div class="vo-fundo" data-vo-acesso hidden>
	<form class="vo-janela" data-vo-form-acesso novalidate autocomplete="on">
		<div class="vo-jtopo"><div><h2>Acesso à transmissão</h2><p>Preencha seus dados e a senha que a família recebeu do Plano PAI.</p></div></div>
		<div class="vo-campos">
			<label class="vo-campo vo-campo--2">Nome completo<input type="text" name="nome" maxlength="120" autocomplete="name" required data-vo-a-nome></label>
			<label class="vo-campo vo-campo--2">Telefone (WhatsApp)<input type="tel" name="telefone" maxlength="20" inputmode="tel" autocomplete="tel" placeholder="(77) 99999-9999" required data-vo-a-fone></label>
			<div class="vo-campo vo-campo--2"><span id="vo-l-pais">País</span><div class="vo-combo" data-vo-combo="pais"><input type="text" role="combobox" aria-labelledby="vo-l-pais" aria-autocomplete="list" aria-expanded="false" autocomplete="off" placeholder="Digite para buscar"><ul role="listbox" hidden></ul></div></div>
			<div class="vo-campo"><span id="vo-l-estado" data-vo-l-estado>Estado</span><div class="vo-combo" data-vo-combo="estado"><input type="text" role="combobox" aria-labelledby="vo-l-estado" aria-autocomplete="list" aria-expanded="false" autocomplete="off" placeholder="Digite para buscar"><ul role="listbox" hidden></ul></div></div>
			<div class="vo-campo"><span id="vo-l-cidade">Cidade</span><div class="vo-combo" data-vo-combo="cidade"><input type="text" role="combobox" aria-labelledby="vo-l-cidade" aria-autocomplete="list" aria-expanded="false" autocomplete="off" placeholder="Escolha o estado"><ul role="listbox" hidden></ul></div></div>
			<p class="vo-dica vo-campo--2" data-vo-dica-cidade hidden>Não achou? Escolha o município ao qual sua localidade pertence.</p>
			<label class="vo-campo vo-campo--2">Senha<span class="vo-senha"><input type="password" name="senha" autocomplete="off" required data-vo-a-senha><button type="button" data-vo-mostrar>Mostrar</button></span></label>
		</div>
		<p class="vo-erro" data-vo-a-erro role="alert" hidden></p>
		<button type="submit" class="vo-enviar" data-vo-a-enviar disabled>Assistir à transmissão</button>
	</form>
</div>

<!-- Mensagem -->
<div class="vo-fundo" data-vo-msg hidden>
	<form class="vo-janela" data-vo-form-msg novalidate>
		<div class="vo-jtopo"><div><h2>Mensagem de conforto</h2><p data-vo-msg-para>Escreva uma palavra de carinho para a família.</p></div><button type="button" class="vo-fechar" data-vo-fechar-msg aria-label="Fechar">×</button></div>
		<div class="vo-campos">
			<label class="vo-campo vo-campo--2">Seu nome<input type="text" name="name" maxlength="120" autocomplete="name" required data-vo-m-nome></label>
			<div class="vo-campo vo-campo--2">Escolha uma imagem ou envie uma foto
				<div class="vo-imgs" data-vo-imgs>
					<?php foreach ( $imgs as $n ) : ?>
						<button type="button" data-vo-img="<?php echo esc_attr( 'uploads/' . $n . '.png' ); ?>" aria-pressed="false" aria-label="Escolher a imagem <?php echo (int) $n; ?>"><img src="<?php echo esc_url( home_url( '/uploads/' . $n . '.png' ) ); ?>" alt="" loading="lazy"></button>
					<?php endforeach; ?>
				</div>
				<button type="button" class="vo-foto" data-vo-escolher>+ Enviar foto do celular</button>
				<input type="file" accept="image/*" data-vo-arquivo hidden>
				<img class="vo-previa" data-vo-previa alt="" hidden>
			</div>
			<label class="vo-campo vo-campo--2">Mensagem<textarea name="messageText" maxlength="350" required data-vo-m-texto></textarea><small><span data-vo-m-cont>0</span>/350</small></label>
		</div>
		<p class="vo-erro" data-vo-m-erro role="alert" hidden></p>
		<button type="submit" class="vo-enviar" data-vo-m-enviar>Enviar mensagem</button>
		<p class="vo-ok" data-vo-m-ok role="status" hidden>Mensagem enviada. Obrigado pelo carinho.</p>
	</form>
</div>

<!-- Encerrado -->
<div class="vo-fundo vo-fundo--meio" data-vo-encerrado hidden>
	<div class="vo-janela vo-janela--meio">
		<p class="vo-rot">VELÓRIO ONLINE · SALA <?php echo esc_html( $sala ); ?></p>
		<h2>Transmissão encerrada</h2>
		<p class="vo-nota">Obrigado por acompanhar. Você ainda pode deixar uma homenagem no Legado de Luz.</p>
		<a class="vo-enviar" href="<?php echo esc_url( home_url( '/legado-de-luz/' ) ); ?>" data-vo-legado-fim>Ver o Legado de Luz</a>
	</div>
</div>

<?php wp_footer(); ?>
</body>
</html>
