/* rc20 (12/11/2026): velório online das salas (page-velorio-online-sala.php).
 * Mesmos endereços de antes (senha, cadastro, cookie, mensagens e transmissão). O que mudou:
 * - o vídeo reconecta sozinho quando a internet oscila e avisa "vai começar em instantes" antes de começar;
 * - botão "Ativar som" (o navegador obriga o vídeo a começar mudo);
 * - data do sepultamento certa para quem está fora do Brasil (sem conversão de fuso);
 * - país, estado e cidade escolhidos de uma lista com busca (cidades oficiais do IBGE);
 * - se o cadastro do visitante falhar, a pessoa entra mesmo assim (a senha é o que libera);
 * - o Legado de Luz abre o memorial do falecido da sala;
 * - avisos na própria página, sem as caixas de alerta do navegador. */
(function () {
	'use strict';

	var raiz = document.querySelector('[data-vo]');
	if (!raiz) { return; }

	var CFG = {
		sala: raiz.getAttribute('data-sala'),
		stream: raiz.getAttribute('data-stream'),
		dados: raiz.getAttribute('data-dados'),
		leads: raiz.getAttribute('data-leads'),
		mensagem: raiz.getAttribute('data-mensagem'),
		homenagens: raiz.getAttribute('data-homenagens'),
		legado: raiz.getAttribute('data-legado'),
		cidades: raiz.getAttribute('data-cidades')
	};
	var COOKIE = 'acessoSala' + CFG.sala;
	var SALA_SENHA = 'sala-' + CFG.sala;

	function $(s, base) { return (base || document).querySelector(s); }
	function txt(v) { return String(v == null ? '' : v).trim(); }
	function p2(n) { n = String(n); return n.length < 2 ? '0' + n : n; }
	function sem(v) { return txt(v).normalize ? txt(v).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase() : txt(v).toLowerCase(); }

	var el = {
		video: $('[data-vo-video]'),
		aovivo: $('[data-vo-aovivo]'),
		som: $('[data-vo-som]'),
		aviso: $('[data-vo-aviso]'),
		avisoTit: $('[data-vo-aviso-tit]'),
		avisoTxt: $('[data-vo-aviso-txt]'),
		nome: $('[data-vo-nome]'),
		datas: $('[data-vo-datas]'),
		velorio: $('[data-vo-velorio]'),
		data: $('[data-vo-data]'),
		hora: $('[data-vo-hora]'),
		local: $('[data-vo-local]'),
		legado: $('[data-vo-legado]'),
		legadoTxt: $('[data-vo-legado-txt]'),
		legadoFim: $('[data-vo-legado-fim]'),
		acesso: $('[data-vo-acesso]'),
		encerrado: $('[data-vo-encerrado]'),
		msg: $('[data-vo-msg]')
	};

	/* ================================================================
	 * Cookie de acesso (o mesmo de antes: acessoSalaNN = id do registro)
	 * ================================================================ */
	function lerCookie(nome) {
		var partes = document.cookie ? document.cookie.split('; ') : [];
		for (var i = 0; i < partes.length; i++) {
			if (partes[i].indexOf(nome + '=') === 0) {
				try { return decodeURIComponent(partes[i].slice(nome.length + 1)); } catch (e) { return ''; }
			}
		}
		return '';
	}
	function gravarCookie(nome, valor) {
		document.cookie = nome + '=' + encodeURIComponent(valor) + '; path=/; max-age=' + (60 * 60 * 24 * 2) + '; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');
	}

	/* ================================================================
	 * Janelas
	 * ================================================================ */
	function travar() {
		var aberta = !el.acesso.hidden || !el.encerrado.hidden || !el.msg.hidden;
		document.body.classList.toggle('vo-travada', aberta);
	}
	function mostrar(janela, sim) { janela.hidden = !sim; travar(); }

	/* ================================================================
	 * Dados do velório (/salaNN.php?modo=online, a cada 30 s)
	 * ================================================================ */
	var st = { registro: '', liberado: false, ultimo: '', falecido: '' };
	var DIAS = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];

	// A data vem como AAAA-MM-DD: monta o dia sem passar por fuso horário (quem está fora do Brasil vê o dia certo).
	function partesData(v) {
		var m = txt(v).match(/^(\d{4})-(\d{2})-(\d{2})/);
		return m && m[1] !== '0000' ? { a: +m[1], m: +m[2], d: +m[3] } : null;
	}
	function dataCurta(v) {
		var p = partesData(v);
		return p ? p2(p.d) + '/' + p2(p.m) + '/' + p.a : '';
	}
	function dataSepultamento(v) {
		var p = partesData(v);
		if (!p) { return txt(v) || 'A definir'; }
		var alvo = Date.UTC(p.a, p.m - 1, p.d);
		var h = new Date();
		var hoje = Date.UTC(h.getFullYear(), h.getMonth(), h.getDate());
		var dif = Math.round((alvo - hoje) / 86400000);
		var dm = p2(p.d) + '/' + p2(p.m);
		if (dif === 0) { return 'Hoje, ' + dm; }
		if (dif === 1) { return 'Amanhã, ' + dm; }
		return DIAS[new Date(alvo).getUTCDay()] + ', ' + dm;
	}
	function hora(v) {
		var m = txt(v).match(/^(\d{1,2}):(\d{2})/);
		return m ? p2(m[1]) + ':' + m[2] : (txt(v) || 'A definir');
	}

	function desenharDados(item) {
		var nome = txt(item.nome_completo) || 'Nome a definir';
		el.nome.textContent = nome;
		st.falecido = nome;

		var nasc = dataCurta(item.data_nascimento), falec = dataCurta(item.data_falecimento || item.data_obito);
		el.datas.textContent = '';
		[['✦ ', nasc], ['✝ ', falec]].forEach(function (par) {
			if (!par[1]) { return; }
			var s = document.createElement('span');
			s.appendChild(document.createTextNode(par[0]));
			var b = document.createElement('b');
			b.textContent = par[1];
			s.appendChild(b);
			el.datas.appendChild(s);
		});
		el.datas.hidden = !el.datas.childNodes.length;

		var velorio = txt(item.local_velorio);
		el.velorio.textContent = velorio ? 'Velório: ' + velorio : '';
		el.velorio.hidden = !velorio;

		el.data.textContent = dataSepultamento(item.data_sepultamento);
		el.hora.textContent = hora(item.horario_sepultamento);
		el.local.textContent = txt(item.local_sepultamento) || 'A definir';
		var para = $('[data-vo-msg-para]');
		if (para) { para.textContent = 'Para a família de ' + nome + '.'; }
	}

	function buscarDados() {
		var url = CFG.dados + '?modo=online&nocache=' + Date.now();
		return fetch(url, { cache: 'no-store', credentials: 'same-origin' })
			.then(function (r) { if (!r.ok) { throw new Error('HTTP ' + r.status); } return r.json(); })
			.then(function (lista) {
				if (!Array.isArray(lista) || !lista.length) {
					st.registro = '';
					encerrar();
					return;
				}
				var item = lista[0] || {};
				st.registro = txt(item.id);
				mostrar(el.encerrado, false);
				desenharDados(item);
				verificarAcesso();
				carregarLegado();
			})
			.catch(function (e) {
				// Sem internet ou servidor fora: mantém o que está na tela e tenta de novo no próximo ciclo.
				if (window.console) { console.warn('[velorio-online] dados:', e && e.message); }
			});
	}

	function encerrar() {
		player.parar();
		mostrar(el.acesso, false);
		mostrar(el.msg, false);
		mostrar(el.encerrado, true);
	}

	function verificarAcesso() {
		if (!st.registro) { encerrar(); return; }
		if (lerCookie(COOKIE) === st.registro) {
			st.liberado = true;
			mostrar(el.acesso, false);
			player.iniciar();
		} else {
			st.liberado = false;
			player.parar();
			mostrar(el.acesso, true);
		}
	}

	/* Legado de Luz do falecido da sala (mesma resposta usada na página de homenagem da sala). */
	var legadoCarregado = '';
	function carregarLegado() {
		if (legadoCarregado === st.registro) { return; }
		legadoCarregado = st.registro;
		fetch(CFG.homenagens + '?acao=carregar_sala&sala=' + encodeURIComponent(CFG.sala) + '&cache_bust=' + Date.now(), { credentials: 'include', cache: 'no-store', headers: { Accept: 'application/json' } })
			.then(function (r) { return r.json(); })
			.then(function (d) {
				var h = d && d.homenagem;
				var u = txt(h && (h.link_publico || h.legado_luz_link));
				if (!/^https:\/\/(www\.)?planoassistencialintegrado\.com\.br\//i.test(u)) { return; }
				el.legado.href = u;
				if (el.legadoFim) { el.legadoFim.href = u; }
				var primeiro = st.falecido.split(/\s+/).slice(0, 3).join(' ');
				if (primeiro) { el.legadoTxt.textContent = 'Memorial de ' + primeiro; }
			})
			.catch(function () { /* fica o endereço geral do Legado de Luz */ });
	}

	/* ================================================================
	 * Vídeo: reconecta sozinho e avisa o que está acontecendo
	 * ================================================================ */
	var player = (function () {
		var hls = null, ativo = false, tocou = false, tentativas = 0, timer = null, travado = null;
		var v = el.video;

		function aviso(tit, texto) {
			if (!tit) { el.aviso.hidden = true; return; }
			el.avisoTit.textContent = tit;
			el.avisoTxt.textContent = texto || '';
			el.aviso.hidden = false;
		}
		function estadoEspera() {
			if (tocou) { aviso('Reconectando…', 'A conexão oscilou. O vídeo volta sozinho.'); }
			else { aviso('A transmissão vai começar em instantes', 'Deixe esta página aberta. O vídeo aparece sozinho.'); }
			el.aovivo.hidden = true;
			el.som.hidden = true;
		}
		function limpar() {
			clearTimeout(timer); timer = null;
			clearTimeout(travado); travado = null;
			if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }
			try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) {}
		}
		function agendar() {
			if (!ativo) { return; }
			clearTimeout(timer);
			tentativas++;
			// Ainda não começou: tenta a cada 10 s. Caiu no meio: 2 s, 4 s, 8 s… até 15 s.
			var espera = tocou ? Math.min(15000, 2000 * Math.pow(2, Math.min(tentativas - 1, 3))) : 10000;
			timer = setTimeout(conectar, espera);
		}
		function conectar() {
			if (!ativo) { return; }
			limpar();
			estadoEspera();
			if (window.Hls && window.Hls.isSupported()) {
				hls = new window.Hls({
					liveSyncDurationCount: 3,
					liveMaxLatencyDurationCount: 6,
					maxBufferLength: 10,
					maxMaxBufferLength: 30,
					startLevel: 0,
					manifestLoadingMaxRetry: 1,
					levelLoadingMaxRetry: 2,
					fragLoadingMaxRetry: 3
				});
				var recuperacoes = 0;
				hls.on(window.Hls.Events.MANIFEST_PARSED, function () { v.play().catch(function () {}); });
				hls.on(window.Hls.Events.ERROR, function (ev, data) {
					if (!data || !data.fatal) { return; }
					if (data.type === window.Hls.ErrorTypes.MEDIA_ERROR && recuperacoes < 2) {
						recuperacoes++;
						try { hls.recoverMediaError(); return; } catch (e) {}
					}
					estadoEspera();
					agendar();
				});
				hls.loadSource(CFG.stream);
				hls.attachMedia(v);
			} else if (v.canPlayType('application/vnd.apple.mpegurl')) {
				// iPhone/iPad: o próprio navegador toca a transmissão.
				v.src = CFG.stream;
				v.play().catch(function () {});
			} else {
				aviso('Este navegador não consegue abrir a transmissão', 'Tente pelo Google Chrome ou pelo Safari.');
			}
		}

		v.addEventListener('playing', function () {
			tocou = true;
			tentativas = 0;
			clearTimeout(travado);
			aviso('');
			el.aovivo.hidden = false;
			el.som.hidden = !v.muted;
		});
		v.addEventListener('waiting', function () {
			if (!ativo || !tocou) { return; }
			clearTimeout(travado);
			// Parado carregando por mais de 12 s: reconecta.
			travado = setTimeout(function () { estadoEspera(); agendar(); }, 12000);
		});
		v.addEventListener('error', function () {
			if (!ativo || hls) { return; } // com hls.js, quem trata os erros é ele
			estadoEspera();
			agendar();
		});
		v.addEventListener('volumechange', function () { el.som.hidden = !v.muted || !tocou; });
		el.som.addEventListener('click', function () {
			v.muted = false;
			if (v.volume === 0) { v.volume = 1; }
			v.play().catch(function () {});
			el.som.hidden = true;
		});

		return {
			iniciar: function () {
				if (ativo) { return; }
				ativo = true;
				tentativas = 0;
				conectar();
			},
			parar: function () {
				ativo = false;
				limpar();
				el.aovivo.hidden = true;
				el.som.hidden = true;
				aviso('Aguardando acesso', '');
			}
		};
	})();

	/* ================================================================
	 * Lista com busca (país, estado e cidade)
	 * ================================================================ */
	function Combo(no, aoEscolher) {
		var input = no.querySelector('input');
		var lista = no.querySelector('ul');
		var opcoes = [];
		var livre = false;
		var valor = '';
		var marcado = -1;
		var id = 'vo-lista-' + Math.random().toString(36).slice(2);
		lista.id = id;
		input.setAttribute('aria-controls', id);

		function fechar() { lista.hidden = true; input.setAttribute('aria-expanded', 'false'); marcado = -1; }
		function desenhar() {
			var q = sem(input.value);
			var achados = [];
			for (var i = 0; i < opcoes.length && achados.length < 60; i++) {
				var n = opcoes[i].busca;
				if (!q || n.indexOf(q) === 0) { achados.push(opcoes[i]); }
			}
			if (q && achados.length < 60) {
				for (var j = 0; j < opcoes.length && achados.length < 60; j++) {
					var b = opcoes[j].busca;
					if (b.indexOf(q) > 0 && achados.indexOf(opcoes[j]) < 0) { achados.push(opcoes[j]); }
				}
			}
			lista.textContent = '';
			if (!achados.length) {
				var li0 = document.createElement('li');
				li0.className = 'vo-vazio';
				li0.textContent = 'Nada encontrado';
				lista.appendChild(li0);
			}
			achados.forEach(function (o, k) {
				var li = document.createElement('li');
				li.setAttribute('role', 'option');
				li.id = id + '-' + k;
				li.textContent = o.nome;
				li.addEventListener('mousedown', function (e) { e.preventDefault(); escolher(o); });
				lista.appendChild(li);
			});
			marcado = -1;
			lista.hidden = false;
			input.setAttribute('aria-expanded', 'true');
		}
		function escolher(o) {
			var mudou = valor !== o.valor;
			valor = o.valor;
			input.value = o.nome;
			input.classList.remove('vo-invalido');
			fechar();
			if (aoEscolher && mudou) { aoEscolher(o); }
		}
		function perdeu() {
			var tinha = valor !== '';
			valor = '';
			if (aoEscolher && tinha) { aoEscolher(null); }
		}
		function confirmarDigitado() {
			if (livre) { valor = txt(input.value); if (aoEscolher) { aoEscolher(null); } return; }
			var q = sem(input.value);
			if (!q) { perdeu(); return; }
			for (var i = 0; i < opcoes.length; i++) {
				if (opcoes[i].busca === q || sem(opcoes[i].valor) === q) { escolher(opcoes[i]); return; }
			}
			perdeu();
			input.classList.add('vo-invalido');
		}

		input.addEventListener('input', function () {
			if (livre) { valor = txt(input.value); if (aoEscolher) { aoEscolher(null); } return; }
			input.classList.remove('vo-invalido');
			desenhar();
			perdeu();
		});
		input.addEventListener('focus', function () { if (!livre && opcoes.length) { desenhar(); } });
		input.addEventListener('blur', function () { setTimeout(function () { fechar(); confirmarDigitado(); }, 120); });
		input.addEventListener('keydown', function (e) {
			if (livre || lista.hidden) { return; }
			var itens = lista.querySelectorAll('[role="option"]');
			if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
				e.preventDefault();
				marcado = Math.max(0, Math.min(itens.length - 1, marcado + (e.key === 'ArrowDown' ? 1 : -1)));
				for (var i = 0; i < itens.length; i++) { itens[i].setAttribute('aria-selected', i === marcado ? 'true' : 'false'); }
				if (itens[marcado]) { itens[marcado].scrollIntoView({ block: 'nearest' }); input.setAttribute('aria-activedescendant', itens[marcado].id); }
			} else if (e.key === 'Enter') {
				if (marcado >= 0 && itens[marcado]) {
					e.preventDefault();
					var nome = itens[marcado].textContent;
					for (var j = 0; j < opcoes.length; j++) { if (opcoes[j].nome === nome) { escolher(opcoes[j]); break; } }
				}
			} else if (e.key === 'Escape') {
				fechar();
			}
		});

		return {
			opcoes: function (lst) {
				livre = false;
				opcoes = lst.map(function (o) { return { nome: o.nome, valor: o.valor, busca: sem(o.nome) }; });
				input.setAttribute('aria-autocomplete', 'list');
			},
			livre: function (placeholder) {
				livre = true;
				opcoes = [];
				fechar();
				input.setAttribute('aria-autocomplete', 'none');
				if (placeholder) { input.placeholder = placeholder; }
			},
			definir: function (nomeOuValor) {
				var q = sem(nomeOuValor);
				for (var i = 0; i < opcoes.length; i++) {
					if (opcoes[i].busca === q || sem(opcoes[i].valor) === q) { escolher(opcoes[i]); return true; }
				}
				return false;
			},
			limpar: function (placeholder) { valor = ''; input.value = ''; input.classList.remove('vo-invalido'); if (placeholder) { input.placeholder = placeholder; } },
			valor: function () { return livre ? txt(input.value) : valor; },
			texto: function () { return txt(input.value); },
			habilitar: function (sim) { input.disabled = !sim; },
			ehLivre: function () { return livre; }
		};
	}

	var PAISES = [["AF","Afeganistão"],["ZA","África do Sul"],["AL","Albânia"],["DE","Alemanha"],["AD","Andorra"],["AO","Angola"],["AI","Anguila"],["AQ","Antártida"],["AG","Antígua e Barbuda"],["SA","Arábia Saudita"],["DZ","Argélia"],["AR","Argentina"],["AM","Armênia"],["AW","Aruba"],["AU","Austrália"],["AT","Áustria"],["AZ","Azerbaijão"],["BS","Bahamas"],["BD","Bangladesh"],["BB","Barbados"],["BH","Barein"],["BE","Bélgica"],["BZ","Belize"],["BJ","Benin"],["DY","Benin"],["BM","Bermudas"],["BY","Bielorrússia"],["BO","Bolívia"],["BA","Bósnia e Herzegovina"],["BW","Botsuana"],["BR","Brasil"],["BN","Brunei"],["BG","Bulgária"],["BF","Burquina Faso"],["HV","Burquina Faso"],["BI","Burundi"],["BT","Butão"],["CV","Cabo Verde"],["CM","Camarões"],["KH","Camboja"],["CA","Canadá"],["QA","Catar"],["KZ","Cazaquistão"],["TD","Chade"],["CL","Chile"],["CN","China"],["CY","Chipre"],["VA","Cidade do Vaticano"],["CO","Colômbia"],["KM","Comores"],["CD","Congo - Kinshasa"],["KP","Coreia do Norte"],["KR","Coreia do Sul"],["CI","Costa do Marfim"],["CR","Costa Rica"],["HR","Croácia"],["CU","Cuba"],["CW","Curaçao"],["DK","Dinamarca"],["DJ","Djibuti"],["DM","Dominica"],["EG","Egito"],["SV","El Salvador"],["AE","Emirados Árabes Unidos"],["EC","Equador"],["ER","Eritreia"],["SK","Eslováquia"],["SI","Eslovênia"],["ES","Espanha"],["SZ","Essuatíni"],["US","Estados Unidos"],["EE","Estônia"],["ET","Etiópia"],["FJ","Fiji"],["PH","Filipinas"],["FI","Finlândia"],["FR","França"],["GA","Gabão"],["GM","Gâmbia"],["GH","Gana"],["GE","Geórgia"],["GI","Gibraltar"],["GD","Granada"],["GR","Grécia"],["GL","Groenlândia"],["GP","Guadalupe"],["GU","Guam"],["GT","Guatemala"],["GG","Guernsey"],["GY","Guiana"],["GF","Guiana Francesa"],["GN","Guiné"],["GQ","Guiné Equatorial"],["GW","Guiné-Bissau"],["HT","Haiti"],["HN","Honduras"],["HK","Hong Kong, RAE da China"],["HU","Hungria"],["YD","Iêmen"],["YE","Iêmen"],["BV","Ilha Bouvet"],["CX","Ilha Christmas"],["IM","Ilha de Man"],["NF","Ilha Norfolk"],["AX","Ilhas Aland"],["KY","Ilhas Cayman"],["CC","Ilhas Cocos (Keeling)"],["CK","Ilhas Cook"],["FO","Ilhas Faroé"],["GS","Ilhas Geórgia do Sul e Sandwich do Sul"],["HM","Ilhas Heard e McDonald"],["FK","Ilhas Malvinas"],["MP","Ilhas Marianas do Norte"],["MH","Ilhas Marshall"],["UM","Ilhas Menores Distantes dos EUA"],["PN","Ilhas Pitcairn"],["SB","Ilhas Salomão"],["TC","Ilhas Turcas e Caicos"],["VI","Ilhas Virgens Americanas"],["VG","Ilhas Virgens Britânicas"],["IN","Índia"],["ID","Indonésia"],["IR","Irã"],["IQ","Iraque"],["IE","Irlanda"],["IS","Islândia"],["IL","Israel"],["IT","Itália"],["JM","Jamaica"],["JP","Japão"],["JE","Jersey"],["JO","Jordânia"],["KW","Kuwait"],["LA","Laos"],["LS","Lesoto"],["LV","Letônia"],["LB","Líbano"],["LR","Libéria"],["LY","Líbia"],["LI","Liechtenstein"],["LT","Lituânia"],["LU","Luxemburgo"],["MO","Macau, RAE da China"],["MK","Macedônia do Norte"],["MG","Madagascar"],["MY","Malásia"],["MW","Malaui"],["MV","Maldivas"],["ML","Mali"],["MT","Malta"],["MA","Marrocos"],["MQ","Martinica"],["MU","Maurício"],["MR","Mauritânia"],["YT","Mayotte"],["MX","México"],["MM","Mianmar (Birmânia)"],["FM","Micronésia"],["MZ","Moçambique"],["MD","Moldávia"],["MC","Mônaco"],["MN","Mongólia"],["ME","Montenegro"],["MS","Montserrat"],["NA","Namíbia"],["NR","Nauru"],["NP","Nepal"],["NI","Nicarágua"],["NE","Níger"],["NG","Nigéria"],["NU","Niue"],["NO","Noruega"],["NC","Nova Caledônia"],["NZ","Nova Zelândia"],["OM","Omã"],["NL","Países Baixos"],["BQ","Países Baixos Caribenhos"],["PW","Palau"],["PA","Panamá"],["PG","Papua-Nova Guiné"],["PK","Paquistão"],["PY","Paraguai"],["PE","Peru"],["PF","Polinésia Francesa"],["PL","Polônia"],["PR","Porto Rico"],["PT","Portugal"],["KE","Quênia"],["KG","Quirguistão"],["KI","Quiribati"],["GB","Reino Unido"],["CF","República Centro-Africana"],["CG","República do Congo"],["DO","República Dominicana"],["RE","Reunião"],["RO","Romênia"],["RW","Ruanda"],["RU","Rússia"],["EH","Saara Ocidental"],["WS","Samoa"],["AS","Samoa Americana"],["SM","San Marino"],["SH","Santa Helena"],["LC","Santa Lúcia"],["BL","São Bartolomeu"],["KN","São Cristóvão e Névis"],["MF","São Martinho"],["PM","São Pedro e Miquelão"],["ST","São Tomé e Príncipe"],["VC","São Vicente e Granadinas"],["SC","Seicheles"],["SN","Senegal"],["SL","Serra Leoa"],["RS","Sérvia"],["SG","Singapura"],["SX","Sint Maarten"],["SY","Síria"],["SO","Somália"],["LK","Sri Lanka"],["SD","Sudão"],["SS","Sudão do Sul"],["SE","Suécia"],["CH","Suíça"],["SR","Suriname"],["SJ","Svalbard e Jan Mayen"],["TJ","Tadjiquistão"],["TH","Tailândia"],["TW","Taiwan"],["TZ","Tanzânia"],["CZ","Tchéquia"],["IO","Território Britânico do Oceano Índico"],["TF","Territórios Franceses do Sul"],["PS","Territórios palestinos"],["TL","Timor-Leste"],["TG","Togo"],["TK","Tokelau"],["TO","Tonga"],["TT","Trinidad e Tobago"],["TN","Tunísia"],["TM","Turcomenistão"],["TR","Turquia"],["TV","Tuvalu"],["UA","Ucrânia"],["UG","Uganda"],["UY","Uruguai"],["UZ","Uzbequistão"],["NH","Vanuatu"],["VU","Vanuatu"],["VE","Venezuela"],["VD","Vietnã"],["VN","Vietnã"],["WF","Wallis e Futuna"],["ZM","Zâmbia"],["RH","Zimbábue"],["ZW","Zimbábue"]];
	var UFS = [['AC', 'Acre'], ['AL', 'Alagoas'], ['AP', 'Amapá'], ['AM', 'Amazonas'], ['BA', 'Bahia'], ['CE', 'Ceará'], ['DF', 'Distrito Federal'], ['ES', 'Espírito Santo'], ['GO', 'Goiás'], ['MA', 'Maranhão'], ['MT', 'Mato Grosso'], ['MS', 'Mato Grosso do Sul'], ['MG', 'Minas Gerais'], ['PA', 'Pará'], ['PB', 'Paraíba'], ['PR', 'Paraná'], ['PE', 'Pernambuco'], ['PI', 'Piauí'], ['RJ', 'Rio de Janeiro'], ['RN', 'Rio Grande do Norte'], ['RS', 'Rio Grande do Sul'], ['RO', 'Rondônia'], ['RR', 'Roraima'], ['SC', 'Santa Catarina'], ['SP', 'São Paulo'], ['SE', 'Sergipe'], ['TO', 'Tocantins']];

	// País provável pelo fuso horário do aparelho (só para já vir preenchido; a pessoa pode trocar).
	function paisPeloFuso() {
		var tz = '';
		try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
		var mapa = {
			'Europe/Lisbon': 'PT', 'Atlantic/Madeira': 'PT', 'Atlantic/Azores': 'PT', 'Europe/Madrid': 'ES', 'Europe/London': 'GB',
			'Europe/Paris': 'FR', 'Europe/Rome': 'IT', 'Europe/Berlin': 'DE', 'Europe/Dublin': 'IE', 'Europe/Zurich': 'CH',
			'Europe/Amsterdam': 'NL', 'Europe/Brussels': 'BE', 'Asia/Tokyo': 'JP', 'America/Asuncion': 'PY',
			'America/Montevideo': 'UY', 'America/Argentina/Buenos_Aires': 'AR', 'America/Santiago': 'CL',
			'America/Toronto': 'CA', 'America/Vancouver': 'CA', 'Australia/Sydney': 'AU', 'America/Bogota': 'CO', 'America/Lima': 'PE'
		};
		if (mapa[tz]) { return mapa[tz]; }
		if (/^America\/(New_York|Chicago|Denver|Los_Angeles|Phoenix|Anchorage|Detroit|Indiana|Kentucky|Boise)/.test(tz) || tz === 'Pacific/Honolulu') { return 'US'; }
		return 'BR';
	}

	/* ================================================================
	 * Formulário de acesso (senha)
	 * ================================================================ */
	(function () {
		var form = $('[data-vo-form-acesso]');
		var f = {
			nome: $('[data-vo-a-nome]'), fone: $('[data-vo-a-fone]'), senha: $('[data-vo-a-senha]'),
			erro: $('[data-vo-a-erro]'), enviar: $('[data-vo-a-enviar]'), dica: $('[data-vo-dica-cidade]'),
			rotEstado: $('[data-vo-l-estado]')
		};
		var cache = {};
		var pedidoCidades = 0;

		var cidade = Combo($('[data-vo-combo="cidade"]'), conferir);
		var estado = Combo($('[data-vo-combo="estado"]'), function (o) {
			if (pais.valor() === 'BR') { carregarCidades(o ? o.valor : ''); }
			conferir();
		});
		var pais = Combo($('[data-vo-combo="pais"]'), function () { ajustarPais(); conferir(); });

		pais.opcoes(PAISES.map(function (p) { return { nome: p[1], valor: p[0] }; }));
		estado.opcoes(UFS.map(function (u) { return { nome: u[1], valor: u[0] }; }));

		function carregarCidades(uf) {
			cidade.limpar(uf ? 'Carregando…' : 'Escolha o estado');
			cidade.habilitar(!!uf);
			f.dica.hidden = true;
			if (!uf) { return; }
			var este = ++pedidoCidades;
			var pronto = cache[uf] ? Promise.resolve(cache[uf]) : fetch(CFG.cidades + uf + '.json', { cache: 'force-cache' }).then(function (r) { if (!r.ok) { throw new Error(); } return r.json(); });
			pronto.then(function (lst) {
				if (este !== pedidoCidades) { return; }
				cache[uf] = lst;
				lst = lst.slice().sort(function (a, b) { return a.localeCompare(b, 'pt-BR'); });
				cidade.opcoes(lst.map(function (n) { return { nome: n, valor: n }; }));
				cidade.limpar('Digite para buscar');
				f.dica.hidden = false;
			}).catch(function () {
				if (este !== pedidoCidades) { return; }
				// Lista indisponível: deixa digitar para não travar a entrada.
				cidade.livre('Digite a cidade');
			});
		}

		function ajustarPais() {
			var br = pais.valor() === 'BR';
			if (br) {
				f.rotEstado.textContent = 'Estado';
				if (estado.ehLivre()) { estado.opcoes(UFS.map(function (u) { return { nome: u[1], valor: u[0] }; })); estado.limpar('Digite para buscar'); carregarCidades(''); }
			} else if (pais.valor()) {
				f.rotEstado.textContent = 'Estado / Província';
				if (!estado.ehLivre()) { estado.livre('Digite o estado'); estado.limpar('Digite o estado'); }
				if (!cidade.ehLivre()) { cidade.livre('Digite a cidade'); cidade.limpar('Digite a cidade'); }
				cidade.habilitar(true);
				f.dica.hidden = true;
			}
		}

		function conferir() {
			var ok = txt(f.nome.value).length >= 3 && f.fone.value.replace(/\D/g, '').length >= 8 && !!pais.valor() && !!estado.valor() && !!cidade.valor() && txt(f.senha.value) !== '';
			f.enviar.disabled = !ok;
			return ok;
		}
		[f.nome, f.fone, f.senha].forEach(function (i) { i.addEventListener('input', conferir); });

		// Máscara simples de telefone brasileiro (fora do Brasil, deixa como a pessoa digitar).
		f.fone.addEventListener('input', function () {
			if (pais.valor() !== 'BR') { return; }
			// Quem digita com o código do país (+55 77 9...) não pode virar DDD 55: tira o 55 da frente.
			var d = f.fone.value.replace(/\D/g, '');
			if (d.length > 11 && d.indexOf('55') === 0) { d = d.slice(2); }
			d = d.slice(0, 11);
			var s = d;
			if (d.length > 2) { s = '(' + d.slice(0, 2) + ') ' + d.slice(2); }
			if (d.length > 7) { s = '(' + d.slice(0, 2) + ') ' + d.slice(2, d.length - 4) + '-' + d.slice(-4); }
			f.fone.value = s;
		});

		$('[data-vo-mostrar]').addEventListener('click', function () {
			var vendo = f.senha.type === 'text';
			f.senha.type = vendo ? 'password' : 'text';
			this.textContent = vendo ? 'Mostrar' : 'Ocultar';
		});

		function erro(t) { f.erro.textContent = t || ''; f.erro.hidden = !t; }

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			if (!conferir()) { return; }
			erro('');
			f.enviar.disabled = true;
			f.enviar.textContent = 'Conferindo…';
			var nomePais = pais.texto();
			fetch(CFG.dados + '?action=verificar_senha', {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: new URLSearchParams({ sala: SALA_SENHA, senha: txt(f.senha.value) }).toString()
			})
				.then(function (r) { return r.json().catch(function () { return null; }); })
				.then(function (d) {
					if (!d || d.sucesso !== true) {
						throw new Error(d && d.msg ? d.msg : 'Senha incorreta. Confira com a família e tente de novo.');
					}
					st.registro = txt(d.registro_id) || st.registro;
					// Cadastro do visitante: se falhar, a pessoa entra mesmo assim (a senha já foi conferida).
					return fetch(CFG.leads, {
						method: 'POST',
						credentials: 'same-origin',
						headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
						body: new URLSearchParams({
							nome: txt(f.nome.value),
							pais: nomePais,
							estado: estado.valor(),
							cidade: cidade.valor(),
							telefone: txt(f.fone.value)
						}).toString()
					}).then(function (r) { return r.text(); }).then(function (t) {
						if (txt(t) !== 'Dados gravados com sucesso' && window.console) { console.warn('[velorio-online] cadastro:', t); }
					}).catch(function (e2) { if (window.console) { console.warn('[velorio-online] cadastro:', e2 && e2.message); } });
				})
				.then(function () {
					if (st.registro) { gravarCookie(COOKIE, st.registro); }
					f.senha.value = '';
					verificarAcesso();
				})
				.catch(function (e3) {
					erro(e3 && e3.message && !/fetch|network/i.test(e3.message) ? e3.message : 'Não foi possível conferir agora. Verifique a internet e tente de novo.');
				})
				.then(function () { f.enviar.textContent = 'Assistir à transmissão'; conferir(); });
		});

		// Já vem preenchido: país pelo fuso; na Bahia (fuso próprio), o estado também.
		var provavel = paisPeloFuso();
		pais.definir(provavel);
		ajustarPais();
		var tz = '';
		try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
		if (provavel === 'BR') {
			cidade.habilitar(false);
			if (tz === 'America/Bahia') { estado.definir('BA'); }
		}
		conferir();
	})();

	/* ================================================================
	 * Mensagem (mesmo envio de antes: /saveMessage.php)
	 * ================================================================ */
	(function () {
		var form = $('[data-vo-form-msg]');
		var m = {
			nome: $('[data-vo-m-nome]'), texto: $('[data-vo-m-texto]'), cont: $('[data-vo-m-cont]'),
			erro: $('[data-vo-m-erro]'), ok: $('[data-vo-m-ok]'), enviar: $('[data-vo-m-enviar]'),
			imgs: $('[data-vo-imgs]'), escolher: $('[data-vo-escolher]'), arquivo: $('[data-vo-arquivo]'), previa: $('[data-vo-previa]')
		};
		var escolhida = '', foto = null, urlPrevia = '';

		$('[data-vo-abrir-msg]').addEventListener('click', function () {
			m.ok.hidden = true; m.erro.hidden = true;
			mostrar(el.msg, true);
			setTimeout(function () { m.nome.focus(); }, 50);
		});
		$('[data-vo-fechar-msg]').addEventListener('click', function () { mostrar(el.msg, false); });
		el.msg.addEventListener('click', function (e) { if (e.target === el.msg) { mostrar(el.msg, false); } });
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !el.msg.hidden) { mostrar(el.msg, false); } });

		function marcar(btn) {
			Array.prototype.forEach.call(m.imgs.querySelectorAll('button'), function (b) { b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'); });
		}
		m.imgs.addEventListener('click', function (e) {
			var b = e.target.closest('button[data-vo-img]');
			if (!b) { return; }
			escolhida = b.getAttribute('data-vo-img');
			foto = null; m.arquivo.value = '';
			m.previa.hidden = true;
			marcar(b);
		});
		m.escolher.addEventListener('click', function () { m.arquivo.click(); });
		m.arquivo.addEventListener('change', function () {
			var arq = m.arquivo.files && m.arquivo.files[0];
			if (!arq) { return; }
			if (!/^image\//.test(arq.type)) { avisar('Escolha uma foto (imagem).'); m.arquivo.value = ''; return; }
			foto = arq; escolhida = ''; marcar(null);
			if (urlPrevia) { URL.revokeObjectURL(urlPrevia); }
			urlPrevia = URL.createObjectURL(arq);
			m.previa.src = urlPrevia;
			m.previa.hidden = false;
		});
		m.texto.addEventListener('input', function () { m.cont.textContent = String(m.texto.value.length); });

		// Fotos grandes do celular são reduzidas antes de enviar (envio mais rápido; mesma imagem na tela).
		function reduzir(arq) {
			if (!arq || arq.size < 1500000 || !window.createImageBitmap) { return Promise.resolve(arq); }
			return createImageBitmap(arq).then(function (bmp) {
				var lado = 1600, esc = Math.min(1, lado / Math.max(bmp.width, bmp.height));
				var c = document.createElement('canvas');
				c.width = Math.round(bmp.width * esc); c.height = Math.round(bmp.height * esc);
				c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
				return new Promise(function (ok) {
					c.toBlob(function (b) { ok(b ? new File([b], (arq.name || 'foto').replace(/\.[^.]+$/, '') + '.jpg', { type: 'image/jpeg' }) : arq); }, 'image/jpeg', 0.85);
				});
			}).catch(function () { return arq; });
		}

		function avisar(t) { m.erro.textContent = t || ''; m.erro.hidden = !t; }

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			avisar(''); m.ok.hidden = true;
			if (txt(m.nome.value).length < 2) { avisar('Escreva seu nome.'); m.nome.focus(); return; }
			if (!txt(m.texto.value)) { avisar('Escreva a mensagem.'); m.texto.focus(); return; }
			m.enviar.disabled = true; m.enviar.textContent = 'Enviando…';
			reduzir(foto).then(function (arq) {
				var fd = new FormData();
				fd.append('name', txt(m.nome.value));
				fd.append('selectedImage', arq ? '' : escolhida);
				if (arq) { fd.append('imageUpload', arq, arq.name || 'foto.jpg'); }
				fd.append('messageText', txt(m.texto.value));
				return fetch(CFG.mensagem, { method: 'POST', body: fd, credentials: 'same-origin' });
			}).then(function (r) {
				if (!r.ok) { throw new Error('HTTP ' + r.status); }
				m.texto.value = ''; m.cont.textContent = '0';
				escolhida = ''; foto = null; m.arquivo.value = ''; m.previa.hidden = true; marcar(null);
				m.ok.hidden = false;
				setTimeout(function () { mostrar(el.msg, false); m.ok.hidden = true; }, 2500);
			}).catch(function () {
				avisar('Não foi possível enviar agora. Verifique a internet e tente de novo.');
			}).then(function () { m.enviar.disabled = false; m.enviar.textContent = 'Enviar mensagem'; });
		});
	})();

	/* ================================================================
	 * Início
	 * ================================================================ */
	player.parar();
	el.avisoTit.textContent = 'Carregando…';
	buscarDados();
	setInterval(buscarDados, 30000);
	document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') { buscarDados(); } });
})();
