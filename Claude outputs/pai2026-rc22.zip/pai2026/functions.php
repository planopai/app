<?php
/**
 * Tema Plano PAI 2026.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PAI_VER', '1.2.0-rc22' );
define( 'PAI_DIR', get_template_directory() );
define( 'PAI_URI', get_template_directory_uri() );

require PAI_DIR . '/inc/helpers.php';
require PAI_DIR . '/inc/customizer.php';
require PAI_DIR . '/inc/elementor.php';
require PAI_DIR . '/inc/rotas.php';
require PAI_DIR . '/inc/adesao.php';
require PAI_DIR . '/inc/checkout.php';
require PAI_DIR . '/inc/carrinho.php';
require PAI_DIR . '/inc/seo.php';
require PAI_DIR . '/inc/conteudo-nativo.php';

/* ------------------------------------------------------------------ */
/* Recursos do tema                                                    */
/* ------------------------------------------------------------------ */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' ); // o título continua vindo do Rank Math
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-lightbox' );

	register_nav_menus( array(
		'principal'   => 'Menu principal',
		'rodape-inst' => 'Rodapé: Institucional',
		'rodape-asso' => 'Rodapé: Associado',
		'rodape-tran' => 'Rodapé: Transparência',
	) );
} );

/* ------------------------------------------------------------------ */
/* CSS e JS: um arquivo de cada, sem jQuery                            */
/* ------------------------------------------------------------------ */
add_action( 'wp_enqueue_scripts', function () {
	// rc20: o velório online tem CSS e JS próprios (página em tela própria, sem o topo e o rodapé do site).
	if ( '' !== pai_velorio_online_sala() ) {
		wp_enqueue_style( 'pai-velorio-online', PAI_URI . '/assets/css/velorio-online.css', array(), PAI_VER );
		wp_enqueue_script( 'pai-hls', PAI_URI . '/assets/js/vendor/hls.light.min.js', array(), '1.7.3', array( 'strategy' => 'defer', 'in_footer' => true ) );
		wp_enqueue_script( 'pai-velorio-online', PAI_URI . '/assets/js/velorio-online.js', array( 'pai-hls' ), PAI_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
		return;
	}
	wp_enqueue_style( 'pai-main', PAI_URI . '/assets/css/main.css', array(), PAI_VER );
	wp_enqueue_script( 'pai-main', PAI_URI . '/assets/js/main.js', array(), PAI_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
	if ( '' !== pai_homenagem_sala() ) {
		wp_enqueue_script( 'pai-homenagem-sala', PAI_URI . '/assets/js/homenagem-sala.js', array(), PAI_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
	}
}, 20 );

/* Fonte Nunito hospedada no próprio site (mais rápido e sem enviar dados ao Google). */
add_action( 'wp_head', function () {
	foreach ( array( 400, 800 ) as $peso ) {
		echo '<link rel="preload" href="' . esc_url( PAI_URI . '/assets/fonts/nunito-' . $peso . '.woff2' ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	}
}, 2 );

/**
 * rc16 (11/11/2026): páginas de homenagem das salas (/enviar-homenagem-sala-01/, -02/ e -03/), endereço dos
 * QR codes das salas. Devolve "01", "02" ou "03"; vazio nas outras páginas.
 * Para voltar a usar o Elementor numa delas, crie na página o campo personalizado pai_usar_elementor = 1.
 */
function pai_homenagem_sala() {
	if ( ! is_page() ) {
		return '';
	}
	$id   = get_queried_object_id();
	$slug = (string) get_post_field( 'post_name', $id );
	if ( ! preg_match( '/^enviar-homenagem-sala-(0[1-3])$/', $slug, $m ) ) {
		return '';
	}
	if ( get_post_meta( $id, 'pai_usar_elementor', true ) ) {
		return '';
	}
	return $m[1];
}

/**
 * rc17 (12/11/2026): painéis das salas na TV (/painel-01/, -02/ e -03/). Devolve "01", "02" ou "03"; vazio fora deles.
 * Para voltar ao Elementor numa delas, crie na página o campo personalizado pai_usar_elementor = 1.
 */
function pai_painel_sala() {
	if ( ! is_page() ) {
		return '';
	}
	$id   = get_queried_object_id();
	$slug = (string) get_post_field( 'post_name', $id );
	if ( ! preg_match( '/^painel-(0[1-3])$/', $slug, $m ) ) {
		return '';
	}
	if ( get_post_meta( $id, 'pai_usar_elementor', true ) ) {
		return '';
	}
	return $m[1];
}

/**
 * rc19 (12/11/2026): TVs de mensagens dentro das salas (/mensagens-tv/ = Sala 01, /mensagens-tv-sala-02/ e
 * /mensagens-tv-sala-03/). Devolve "01", "02" ou "03"; vazio fora delas.
 * Para voltar ao Elementor numa delas, crie na página o campo personalizado pai_usar_elementor = 1.
 */
function pai_mensagens_tv_sala() {
	if ( ! is_page() ) {
		return '';
	}
	$id   = get_queried_object_id();
	$slug = (string) get_post_field( 'post_name', $id );
	if ( 'mensagens-tv' === $slug ) {
		$sala = '01';
	} elseif ( preg_match( '/^mensagens-tv-sala-(0[1-3])$/', $slug, $m ) ) {
		$sala = $m[1];
	} else {
		return '';
	}
	if ( get_post_meta( $id, 'pai_usar_elementor', true ) ) {
		return '';
	}
	return $sala;
}

/**
 * rc20 (12/11/2026): velório online das salas (/velorio-online-sala-01/, -02/ e -03/). Devolve "01", "02" ou "03".
 * Para voltar ao Elementor numa delas, crie na página o campo personalizado pai_usar_elementor = 1.
 */
function pai_velorio_online_sala() {
	if ( ! is_page() ) {
		return '';
	}
	$id   = get_queried_object_id();
	$slug = (string) get_post_field( 'post_name', $id );
	if ( ! preg_match( '/^velorio-online-sala-(0[1-3])$/', $slug, $m ) ) {
		return '';
	}
	if ( get_post_meta( $id, 'pai_usar_elementor', true ) ) {
		return '';
	}
	return $m[1];
}

/* rc21: no velório online, tira o HTML da galeria de fotos do WooCommerce (PhotoSwipe) que o rodapé do site imprime.
   Sem o CSS dele (que a página não carrega), os botões apareciam como tracinhos brancos no canto de baixo. */
add_action( 'template_redirect', function () {
	if ( '' !== pai_velorio_online_sala() ) {
		remove_action( 'wp_footer', 'woocommerce_photoswipe' );
	}
} );

/** Nome de cada sala no painel ("SALA 01 PRESENÇA"). Pode ser trocado na página pelo campo personalizado pai_nome_sala. */
function pai_nomes_salas() {
	return apply_filters( 'pai_nomes_salas', array(
		'01' => 'Presença',
		'02' => 'Encontro',
		'03' => '',
	) );
}

/*
 * rc17: endereço curto do QR code dos painéis. /h1, /h2 e /h3 (maiúsculas ou minúsculas) levam à página de
 * homenagem da sala. Endereço curto = QR code com menos quadradinhos = celular lê de mais longe.
 */
add_action( 'template_redirect', function () {
	$caminho = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH );
	$base    = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( '' !== $base && 0 === strpos( $caminho, $base ) ) {
		$caminho = substr( $caminho, strlen( $base ) );
	}
	if ( preg_match( '/^h([1-3])\/?$/i', trim( $caminho, '/' ) . '', $m ) ) {
		nocache_headers();
		wp_safe_redirect( home_url( '/enviar-homenagem-sala-0' . $m[1] . '/' ), 302, 'PAI' );
		exit;
	}
}, 0 );

/**
 * Páginas montadas pelo tema (não usam o conteúdo do Elementor).
 */
function pai_pagina_do_tema() {
	$paginas = array_merge(
		array(
			'planos-funerarios', 'coroas-de-flores', 'atendimento-24-horas', 'guia-para-familias',
			'sobre-nos', 'contato-plano-pai', 'servicos-plano-pai', 'velorio-online', 'telemedicina',
			'aplicativo', 'tutoriais', 'parceiros', 'seja-nosso-parceiro', 'trabalhe-conosco',
			'galeria', 'urnas', 'termos-e-condicoes', 'politica-de-privacidade', 'landing-page',
		),
		array_keys( pai_especialidades() )
	);
	$artigo = is_singular( 'post' ) && ! pai_feito_no_elementor( get_queried_object_id() );
	$rota   = function_exists( 'pai_rota' ) && '' !== pai_rota();
	return is_front_page() || is_page( $paginas ) || $artigo || $rota || '' !== pai_homenagem_sala()
		|| '' !== pai_velorio_online_sala() || is_home() || is_category() || is_tag() || is_search() || is_404();
}



/**
 * Nas páginas montadas pelo tema, tira os arquivos do Elementor, dos addons,
 * do kit de estilos do Elementor e de plugins que essas páginas não usam.
 * Roda em vários momentos porque alguns plugins colocam arquivos tarde (no rodapé).
 */
/** Página de produto ou de categoria da loja (usam o modelo woocommerce.php do tema). */
function pai_pagina_da_loja() {
	return function_exists( 'is_product' ) && ( is_product() || is_shop() || is_product_taxonomy() );
}

function pai_limpar_fila() {
	$loja     = pai_pagina_da_loja();
	$checkout = pai_eh_checkout() || pai_eh_carrinho(); // checkout e carrinho também são montados pelo tema (inc/checkout.php, inc/carrinho.php)
	if ( ! pai_pagina_do_tema() && ! $loja && ! $checkout ) {
		return;
	}
	$fora = array(
		'/plugins/elementor', 'happy-elementor-addons', 'essential-addons-for-elementor', 'royal-elementor-addons',
		'header-footer-elementor', '/plugins/shopengine', '/uploads/elementor/', 'wonder-blocks',
		'/plugins/contact-form-7/', 'jetpack-forms', 'paypal-payment', '/js/mediaelement/',
	);
	$handles_fora = array( 'elementor-frontend', 'elementor-post-11', 'nfd-wonder-blocks-utilities', 'wpr-lightbox-css', 'wp-mediaelement', 'contact-form-7' );
	$woo = $loja || $checkout || is_page( 'coroas-de-flores' );

	foreach ( array( wp_styles(), wp_scripts() ) as $fila ) {
		foreach ( (array) $fila->queue as $handle ) {
			$src   = isset( $fila->registered[ $handle ] ) ? (string) $fila->registered[ $handle ]->src : '';
			$tirar = in_array( $handle, $handles_fora, true ) || 0 === strpos( $handle, 'elementor-' ) || 0 === strpos( $handle, 'wpr-' ) || 0 === strpos( $handle, 'happy-' );
			if ( ! $tirar && '' !== $src ) {
				foreach ( $fora as $trecho ) {
					if ( false !== strpos( $src, $trecho ) ) {
						$tirar = true;
						break;
					}
				}
				// WooCommerce só é necessário na página de coroas.
				if ( ! $woo && false !== strpos( $src, '/plugins/woocommerce/' ) ) {
					$tirar = true;
				}
			}
			if ( $tirar ) {
				if ( $fila instanceof WP_Styles ) {
					wp_dequeue_style( $handle );
				} else {
					wp_dequeue_script( $handle );
				}
			}
		}
	}
	foreach ( array( 'wp-block-library', 'wp-block-library-theme', 'global-styles', 'classic-theme-styles' ) as $h ) {
		wp_dequeue_style( $h );
	}
}
add_action( 'wp_enqueue_scripts', 'pai_limpar_fila', 9999 );
add_action( 'wp_print_styles', 'pai_limpar_fila', 1 );
add_action( 'wp_print_footer_scripts', 'pai_limpar_fila', 1 );
add_action( 'wp_footer', 'pai_limpar_fila', 1 );

/* Tira as classes do Elementor do <body> nas páginas do tema (o kit de cores do Elementor pintava o fundo e os botões). */
add_filter( 'body_class', function ( $classes ) {
	$loja = function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() );
	if ( ! pai_pagina_do_tema() && ! $loja ) {
		return $classes;
	}
	return array_values( array_filter( $classes, function ( $c ) {
		return 0 !== strpos( $c, 'elementor' ) && 0 !== strpos( $c, 'ehf-' );
	} ) );
}, 999 );

/**
 * Garante o modelo do tema nas páginas que ele monta, mesmo quando a página está
 * marcada no Elementor como "Largura total", "Canvas" ou quando o padrão do site
 * no Elementor é "Largura total" (nesses casos o Elementor assumia a página).
 */
add_filter( 'template_include', function ( $modelo ) {
	// Produto e categorias da loja: sempre o modelo do tema (no lugar do modelo do ShopEngine/Elementor).
	if ( pai_pagina_da_loja() ) {
		$p = locate_template( 'woocommerce.php' );
		return $p ? $p : $modelo;
	}
	if ( is_front_page() ) {
		$p = locate_template( 'front-page.php' );
		return $p ? $p : $modelo;
	}
	if ( ! is_page() ) {
		return $modelo;
	}
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	if ( '' !== pai_painel_sala() ) {
		$p = locate_template( 'page-painel-sala.php' );
		return $p ? $p : $modelo;
	}
	if ( '' !== pai_mensagens_tv_sala() ) {
		$p = locate_template( 'page-mensagens-tv.php' );
		return $p ? $p : $modelo;
	}
	if ( '' !== pai_velorio_online_sala() ) {
		$p = locate_template( 'page-velorio-online-sala.php' );
		return $p ? $p : $modelo;
	}
	if ( '' !== pai_homenagem_sala() ) {
		$p = locate_template( 'page-homenagem-sala.php' );
		return $p ? $p : $modelo;
	}
	if ( isset( pai_especialidades()[ $slug ] ) ) {
		$p = locate_template( 'page-parceiros.php' );
		return $p ? $p : $modelo;
	}
	if ( pai_pagina_do_tema() ) {
		$p = locate_template( 'page-' . $slug . '.php' );
		if ( $p ) {
			return $p;
		}
	}
	return $modelo;
}, 9999 );

/* Sem emojis do WordPress (scripts extras em toda página). */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
add_filter( 'emoji_svg_url', '__return_false' );

/* ------------------------------------------------------------------ */
/* Tema claro/escuro sem "piscar": aplica a escolha antes de desenhar  */
/* ------------------------------------------------------------------ */
add_action( 'wp_head', function () {
	echo "<script>try{if(localStorage.getItem('pai-tema')==='claro'){document.documentElement.classList.add('light')}}catch(e){}</script>\n";
	echo '<meta name="theme-color" content="#232B3F">' . "\n";
}, 1 );

/* ------------------------------------------------------------------ */
/* WooCommerce: usa o layout do tema                                   */
/* ------------------------------------------------------------------ */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
add_filter( 'woocommerce_enqueue_styles', function ( $estilos ) {
	// Mantém só o layout básico da loja; as cores vêm do main.css.
	unset( $estilos['woocommerce-smallscreen'] );
	return $estilos;
} );

/* Resumo do artigo mais curto nas listas. */
add_filter( 'excerpt_length', function () {
	return 24;
} );
add_filter( 'excerpt_more', function () {
	return '…';
} );

/* ------------------------------------------------------------------ */
/* O tema tem cabeçalho e rodapé próprios: desliga os do plugin         */
/* "Elementor Header & Footer Builder", que se sobrepõem aos do tema.   */
/* ------------------------------------------------------------------ */
add_filter( 'hfe_header_enabled', '__return_false', 99 );
add_filter( 'hfe_footer_enabled', '__return_false', 99 );
add_filter( 'hfe_before_footer_enabled', '__return_false', 99 );

/* Aviso explícito para evitar que o candidato de migração seja confundido com
 * uma substituição final do Elementor. Nunca remove plugins automaticamente. */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) || ! is_admin() ) { return; }
	if ( ! class_exists( '\\Elementor\\Plugin' ) ) {
		echo '<div class="notice notice-warning"><p><strong>PAI2026 — migração experimental:</strong> antes de operar sem Elementor, valide Velório Online, pagamentos, formulários e integrações em homologação. Consulte LEIA-MIGRACAO-ELEMENTOR.txt.</p></div>';
	}
} );

/* ------------------------------------------------------------------ */
/* Produtos relacionados: só coroas (não mostra "Mensalidade em atraso" etc.) */
/* ------------------------------------------------------------------ */
add_filter( 'woocommerce_related_products', function ( $ids ) {
	return array_values( array_filter( (array) $ids, function ( $id ) {
		$cats = wp_get_post_terms( $id, 'product_cat', array( 'fields' => 'slugs' ) );
		if ( is_wp_error( $cats ) ) {
			return true;
		}
		foreach ( $cats as $c ) {
			if ( 0 === strpos( $c, 'coroas-de-flores' ) ) {
				return true;
			}
		}
		return false;
	} ) );
}, 20 );
add_filter( 'woocommerce_output_related_products_args', function ( $args ) {
	$args['posts_per_page'] = 4;
	$args['columns']        = 4;
	return $args;
} );

/* Corrige o endereço antigo da área do associado salvo no painel (app → club). */
add_action( 'after_setup_theme', function () {
	$v = (string) get_theme_mod( 'pai_url_associado', '' );
	if ( '' !== $v && false !== strpos( $v, 'app.planoassistencialintegrado.com.br' ) ) {
		set_theme_mod( 'pai_url_associado', 'https://club.planoassistencialintegrado.com.br/' );
	}
} );

/* Dados da empresa para o Google (empresa local: sede e Memorial, 24 horas). */
add_action( 'wp_head', function () {
	if ( ! is_front_page() && ! is_page( array( 'contato-plano-pai', 'sobre-nos' ) ) ) {
		return;
	}
	$logo = PAI_URI . '/assets/img/logo-claro.svg';
	$base = array(
		'@type'        => 'LocalBusiness',
		'url'          => home_url( '/' ),
		'logo'         => $logo,
		'image'        => $logo,
		'priceRange'   => '$$',
		'openingHours' => 'Mo-Su 00:00-23:59',
		'areaServed'   => 'Barreiras-BA e região',
		'sameAs'       => array_values( array_filter( array( (string) pai_opt( 'instagram' ) ) ) ),
	);
	$locais = array(
		array_merge( $base, array( '@id' => home_url( '/#sede' ), 'name' => 'Plano PAI - Plano Assistencial Integrado', 'telephone' => '+' . pai_digitos( pai_opt( 'whatsapp' ) ), 'address' => array( '@type' => 'PostalAddress', 'streetAddress' => 'Av. Dr. Clériston Andrade, 135, Centro', 'addressLocality' => 'Barreiras', 'addressRegion' => 'BA', 'addressCountry' => 'BR' ) ) ),
		array_merge( $base, array( '@id' => home_url( '/#memorial' ), 'name' => 'Memorial Senhor do Bonfim', 'telephone' => '+' . pai_digitos( pai_opt( 'tel_plantao' ) ), 'address' => array( '@type' => 'PostalAddress', 'streetAddress' => 'Av. Antônio Carlos Magalhães, 3348, Flamengo', 'addressLocality' => 'Barreiras', 'addressRegion' => 'BA', 'addressCountry' => 'BR' ) ) ),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $locais ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}, 30 );

/* A janela de fotos do WooCommerce (PhotoSwipe) só é usada na página do produto.
   Nas outras páginas ela ficava no fim do HTML, sem CSS, e aparecia como retângulos no canto. */
add_action( 'wp', function () {
	if ( function_exists( 'is_product' ) && ! is_product() ) {
		remove_action( 'wp_footer', 'woocommerce_photoswipe' );
	}
} );
